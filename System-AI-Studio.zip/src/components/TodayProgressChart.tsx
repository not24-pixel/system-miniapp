import React, { memo } from 'react';
import { Cell, Pie, PieChart } from 'recharts';

interface TodayProgressChartProps {
  doneCount: number;
  totalCount: number;
  monarchTheme?: boolean;
  hudTheme?: 'blue' | 'monarch' | 'igris' | 'sovereign';
  isRed?: boolean;
}

export const TodayProgressChart: React.FC<TodayProgressChartProps> = memo(({
  doneCount,
  totalCount,
  monarchTheme = false,
  hudTheme,
  isRed = false,
}) => {
  const safeTotal = Math.max(1, totalCount);
  const clampedDone = Math.min(safeTotal, Math.max(0, doneCount));
  const remaining = Math.max(0, safeTotal - clampedDone);
  const percent = totalCount > 0 ? Math.round((clampedDone / totalCount) * 100) : 0;

  const skin = isRed ? 'red' : hudTheme || (monarchTheme ? 'monarch' : 'blue');
  const activeColor =
    skin === 'red'
      ? '#ff4d4d'
      : skin === 'monarch'
      ? '#c084fc'
      : skin === 'igris'
      ? '#fb7185'
      : skin === 'sovereign'
      ? '#fbbf24'
      : '#00e5ff';
  const trackColor =
    skin === 'red'
      ? 'rgba(255, 77, 77, 0.18)'
      : skin === 'monarch'
      ? 'rgba(168, 85, 247, 0.2)'
      : skin === 'igris'
      ? 'rgba(244, 63, 94, 0.2)'
      : skin === 'sovereign'
      ? 'rgba(245, 158, 11, 0.2)'
      : 'rgba(0, 229, 255, 0.16)';

  const chartData =
    clampedDone === 0
      ? [{ name: 'Осталось', value: 1, isDone: false }]
      : remaining === 0
      ? [{ name: 'Выполнено', value: clampedDone, isDone: true }]
      : [
          { name: 'Выполнено', value: clampedDone, isDone: true },
          { name: 'Осталось', value: remaining, isDone: false },
        ];

  return (
    <div className="relative w-[84px] h-[84px] shrink-0 flex items-center justify-center">
      <PieChart width={84} height={84}>
        <Pie
          data={chartData}
          cx="50%"
          cy="50%"
          innerRadius={27}
          outerRadius={37}
          startAngle={90}
          endAngle={-270}
          paddingAngle={clampedDone > 0 && remaining > 0 ? 4 : 0}
          dataKey="value"
          stroke="none"
          isAnimationActive={false}
        >
          {chartData.map((entry, idx) => (
            <Cell
              key={`cell-${idx}`}
              fill={entry.isDone ? activeColor : trackColor}
            />
          ))}
        </Pie>
      </PieChart>
      <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center leading-none">
        <span className="text-[15px] font-extrabold font-tabular text-white">
          {percent}%
        </span>
        <span className="text-[10px] font-tabular text-[#9deeff] mt-0.5">
          {doneCount}/{totalCount}
        </span>
      </div>
    </div>
  );
});
