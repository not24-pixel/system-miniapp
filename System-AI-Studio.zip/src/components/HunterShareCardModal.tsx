import React, { memo, useEffect, useMemo, useState } from 'react';
import {
  Check,
  Copy,
  Crown,
  Download,
  Flame,
  Ghost,
  Lock,
  Send,
  Share2,
  X,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { UserAppState } from '../shared/types';
import { playSystemSound } from '../shared/sound';
import { getHunterRankInfo } from './SystemWidgets';

type CardSkinId = 'blue' | 'monarch' | 'igris' | 'sovereign';

interface SkinConfig {
  id: CardSkinId;
  label: string;
  proOnly: boolean;
  accent: string;
  glow: string;
  bgTop: string;
  bgMid: string;
  barStart: string;
  borderClass: string;
  surfaceClass: string;
  badgeClass: string;
  textAccentClass: string;
  sealLabel: string;
}

const CARD_SKINS: Record<CardSkinId, SkinConfig> = {
  blue: {
    id: 'blue',
    label: 'Охотник',
    proOnly: false,
    accent: '#38f8ff',
    glow: '#00bfff',
    bgTop: '#03172b',
    bgMid: '#030b16',
    barStart: '#0066ff',
    borderClass: 'border-[#38f8ff]',
    surfaceClass: 'bg-[#031325]',
    badgeClass: 'border-[#38f8ff]/80 bg-[#062d4a]/90 text-[#9deeff]',
    textAccentClass: 'text-[#72f8ff]',
    sealLabel: 'СИСТЕМА · БАЗОВЫЙ',
  },
  monarch: {
    id: 'monarch',
    label: 'Монарх',
    proOnly: true,
    accent: '#c084fc',
    glow: '#9333ea',
    bgTop: '#190633',
    bgMid: '#0b031a',
    barStart: '#6d28d9',
    borderClass: 'border-[#c084fc]',
    surfaceClass: 'bg-[#120526]',
    badgeClass: 'border-[#c084fc]/85 bg-[#290b4f]/90 text-[#e9d5ff]',
    textAccentClass: 'text-[#d8b4fe]',
    sealLabel: 'ТЕНЕВОЙ МОНАРХ · PRO',
  },
  igris: {
    id: 'igris',
    label: 'Игрис',
    proOnly: true,
    accent: '#fb7185',
    glow: '#e11d48',
    bgTop: '#29050f',
    bgMid: '#120208',
    barStart: '#be123c',
    borderClass: 'border-[#fb7185]',
    surfaceClass: 'bg-[#1a040c]',
    badgeClass: 'border-[#fb7185]/85 bg-[#3f0917]/90 text-[#fecdd3]',
    textAccentClass: 'text-[#fda4af]',
    sealLabel: 'АЛЫЙ РЫЦАРЬ · PRO',
  },
  sovereign: {
    id: 'sovereign',
    label: 'S-Ранг',
    proOnly: true,
    accent: '#fbbf24',
    glow: '#d97706',
    bgTop: '#241703',
    bgMid: '#110b02',
    barStart: '#b45309',
    borderClass: 'border-[#fbbf24]',
    surfaceClass: 'bg-[#170f03]',
    badgeClass: 'border-[#fbbf24]/85 bg-[#382305]/90 text-[#fde68a]',
    textAccentClass: 'text-[#fcd34d]',
    sealLabel: 'ЗОЛОТОЙ РАНГ · PRO',
  },
};

export interface HunterShareCardModalProps {
  open: boolean;
  user: UserAppState;
  monarchTheme: boolean;
  onClose: () => void;
  onOpenPlus?: (reason?: 'habits' | 'goals' | 'accounts' | 'feature' | 'general', featureLabel?: string) => void;
}

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function getPentagonPoint(cx: number, cy: number, radius: number, index: number): [number, number] {
  const angle = -Math.PI / 2 + (index * 2 * Math.PI) / 5;
  return [cx + radius * Math.cos(angle), cy + radius * Math.sin(angle)];
}

export const HunterShareCardModal: React.FC<HunterShareCardModalProps> = memo(({
  open,
  user,
  onClose,
  onOpenPlus,
}) => {
  const initialSkin: CardSkinId =
    user.subscription.active && user.hudTheme && user.hudTheme in CARD_SKINS
      ? (user.hudTheme as CardSkinId)
      : 'blue';
  const [selectedSkin, setSelectedSkin] = useState<CardSkinId>(initialSkin);
  const [copiedText, setCopiedText] = useState(false);
  const [savedPng, setSavedPng] = useState(false);

  useEffect(() => {
    if (open) {
      setSelectedSkin(
        user.subscription.active && user.hudTheme && user.hudTheme in CARD_SKINS
          ? (user.hudTheme as CardSkinId)
          : 'blue'
      );
      setCopiedText(false);
      setSavedPng(false);
    }
  }, [open, user.subscription.active, user.hudTheme]);

  const skin = CARD_SKINS[selectedSkin] || CARD_SKINS.blue;
  const isSkinLocked = skin.proOnly && !user.subscription.active;
  const reducedMotion = user.reducedMotion;
  const callsign = user.playerCallsign?.trim() || 'Игрок';
  const rankInfo = getHunterRankInfo(user.level);
  const rankLetter = rankInfo.rank.split('-')[0] || 'E';
  const streak = user.streakDays || 0;
  const bestStreak = Math.max(streak, user.bestStreakDays || 0);
  const shadows = user.shadows || [];
  const shadowBonusXp = shadows.length === 0 ? 0 : user.subscription.active ? Math.min(40, shadows.length * 10) : 5;
  const botUsername = user.subscription.botUsername || 'systema_app_bot';
  const shareUrl = `https://t.me/${botUsername}?start=${user.subscription.referralCode}`;

  const xpPct =
    user.nextLevelXp > 0
      ? Math.min(100, Math.max(0, Math.round((user.currentXp / user.nextLevelXp) * 100)))
      : 0;

  const statItems = useMemo<Array<{ code: string; value: number }>>(
    () => [
      { code: 'СИЛ', value: user.stats.strength },
      { code: 'ВЫН', value: user.stats.endurance },
      { code: 'ЛВК', value: user.stats.agility },
      { code: 'ИНТ', value: user.stats.intelligence },
      { code: 'ВОС', value: user.stats.perception },
    ],
    [
      user.stats.strength,
      user.stats.endurance,
      user.stats.agility,
      user.stats.intelligence,
      user.stats.perception,
    ]
  );

  const combatPower = useMemo(() => {
    const statSum = statItems.reduce((acc, s) => acc + s.value, 0);
    return statSum * 12 + user.level * 120 + streak * 35 + shadows.length * 150;
  }, [statItems, user.level, streak, shadows.length]);

  const maxRadarStat = Math.max(25, ...statItems.map((s) => s.value));

  const radarPolygonPoints = useMemo(() => {
    return statItems
      .map((st, idx) => {
        const ratio = Math.max(0.22, Math.min(1, st.value / maxRadarStat));
        const [px, py] = getPentagonPoint(60, 58, 38 * ratio, idx);
        return `${px.toFixed(1)},${py.toFixed(1)}`;
      })
      .join(' ');
  }, [statItems, maxRadarStat]);

  const buildShareText = () =>
    [
      `[ ОКНО СТАТУСА СИСТЕМЫ ]`,
      `Охотник: ${callsign} · ${rankInfo.rank} («${rankInfo.title}»)`,
      `Уровень: ${user.level} · БМ: ${combatPower.toLocaleString('ru-RU')}`,
      `Серия: ${streak} дн. (рекорд: ${bestStreak} дн.)`,
      `Статы: ${statItems.map((s) => `${s.code} ${s.value}`).join(' · ')}`,
      shadows.length > 0 ? `Тени (${shadows.length}): ${shadows.map((s) => s.name).join(', ')}` : '',
      `Пробудиться в Системе: ${shareUrl}`,
    ]
      .filter(Boolean)
      .join('\n');

  const handleCopyOrShareTelegram = (mode: 'copy' | 'telegram') => {
    playSystemSound('ui_step', user.soundEnabled, user.hapticsEnabled);
    const text = buildShareText();
    navigator.clipboard?.writeText(text).catch(() => {});

    if (mode === 'telegram') {
      const tgShareUrl = `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(
        `Мой статус в Системе: ${callsign} · Ур. ${user.level} (${rankInfo.rank}, БМ ${combatPower}). Пробудись!`
      )}`;
      const tg = (
        window as unknown as {
          Telegram?: { WebApp?: { openTelegramLink?: (url: string) => void } };
        }
      ).Telegram?.WebApp;
      if (tg?.openTelegramLink) {
        tg.openTelegramLink(tgShareUrl);
      }
    }

    setCopiedText(true);
    window.setTimeout(() => setCopiedText(false), 2200);
  };

  const handleDownloadPng = () => {
    if (isSkinLocked) {
      playSystemSound('ui_step', user.soundEnabled, user.hapticsEnabled);
      onClose();
      onOpenPlus?.('feature', `Скин карточки «${skin.label}»`);
      return;
    }

    playSystemSound('quest_complete', user.soundEnabled, user.hapticsEnabled);
    const W = 1080;
    const H = 1920;
    const canvas = document.createElement('canvas');
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const grad = ctx.createLinearGradient(0, 0, 0, H);
    grad.addColorStop(0, skin.bgTop);
    grad.addColorStop(0.5, skin.bgMid);
    grad.addColorStop(1, '#02040a');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    // Coordinate grid
    ctx.strokeStyle = `${skin.accent}18`;
    ctx.lineWidth = 1.5;
    for (let x = 0; x <= W; x += 48) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, H);
      ctx.stroke();
    }
    for (let y = 0; y <= H; y += 48) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(W, y);
      ctx.stroke();
    }

    // Outer Glow Frame
    ctx.save();
    ctx.strokeStyle = skin.accent;
    ctx.lineWidth = 6;
    ctx.shadowColor = skin.glow;
    ctx.shadowBlur = 36;
    ctx.strokeRect(52, 68, W - 104, H - 136);
    ctx.restore();

    ctx.strokeStyle = 'rgba(255,255,255,0.28)';
    ctx.lineWidth = 2;
    ctx.strokeRect(76, 92, W - 152, H - 184);

    // Header Badge
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    drawRoundedRect(ctx, 130, 140, W - 260, 88, 6);
    ctx.fill();
    ctx.strokeStyle = skin.accent;
    ctx.lineWidth = 2.5;
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 40px Manrope, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('КАРТОЧКА ОХОТНИКА СИСТЕМЫ', W / 2, 198);

    // Rank Diamond Crest
    ctx.save();
    ctx.translate(W / 2, 345);
    ctx.rotate(Math.PI / 4);
    ctx.fillStyle = `${skin.accent}24`;
    ctx.strokeStyle = skin.accent;
    ctx.lineWidth = 5;
    ctx.shadowColor = skin.glow;
    ctx.shadowBlur = 24;
    ctx.fillRect(-72, -72, 144, 144);
    ctx.strokeRect(-72, -72, 144, 144);
    ctx.restore();

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 76px JetBrains Mono, monospace';
    ctx.textAlign = 'center';
    ctx.fillText(rankLetter, W / 2, 372);

    ctx.fillStyle = skin.accent;
    ctx.font = 'bold 30px JetBrains Mono, monospace';
    ctx.fillText(`[ ${rankInfo.rank} · ${rankInfo.title.toUpperCase()} ]`, W / 2, 480);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 68px Manrope, sans-serif';
    ctx.fillText(callsign, W / 2, 560);

    ctx.fillStyle = skin.accent;
    ctx.font = 'bold 32px JetBrains Mono, monospace';
    ctx.fillText(`БОЕВАЯ МОЩЬ: ${combatPower.toLocaleString('ru-RU')} · СЕРИЯ ${streak} ДН.`, W / 2, 618);

    // Level & XP Panel
    ctx.fillStyle = 'rgba(4,12,26,0.85)';
    drawRoundedRect(ctx, 120, 668, W - 240, 170, 8);
    ctx.fill();
    ctx.strokeStyle = skin.accent;
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.textAlign = 'left';
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 46px Manrope, sans-serif';
    ctx.fillText(`УРОВЕНЬ ${user.level}`, 160, 738);
    ctx.textAlign = 'right';
    ctx.fillStyle = skin.accent;
    ctx.font = 'bold 32px JetBrains Mono, monospace';
    ctx.fillText(`${user.currentXp} / ${user.nextLevelXp} XP`, W - 160, 738);

    const barX = 160;
    const barY = 772;
    const barW = W - 320;
    ctx.fillStyle = 'rgba(255,255,255,0.12)';
    drawRoundedRect(ctx, barX, barY, barW, 28, 4);
    ctx.fill();
    const gBar = ctx.createLinearGradient(barX, barY, barX + barW, barY);
    gBar.addColorStop(0, skin.barStart);
    gBar.addColorStop(1, skin.accent);
    ctx.fillStyle = gBar;
    drawRoundedRect(ctx, barX + 3, barY + 3, Math.max(16, Math.round((barW - 6) * (xpPct / 100))), 22, 2);
    ctx.fill();

    // Pentagon Stat Radar Canvas
    const rCx = W / 2;
    const rCy = 1105;
    const rMax = 185;
    [0.35, 0.68, 1].forEach((ring) => {
      ctx.beginPath();
      for (let i = 0; i < 5; i++) {
        const [px, py] = getPentagonPoint(rCx, rCy, rMax * ring, i);
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.strokeStyle = 'rgba(255,255,255,0.22)';
      ctx.lineWidth = 2;
      ctx.stroke();
    });

    ctx.beginPath();
    statItems.forEach((st, idx) => {
      const ratio = Math.max(0.22, Math.min(1, st.value / maxRadarStat));
      const [px, py] = getPentagonPoint(rCx, rCy, rMax * ratio, idx);
      if (idx === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    });
    ctx.closePath();
    ctx.fillStyle = `${skin.accent}40`;
    ctx.fill();
    ctx.strokeStyle = skin.accent;
    ctx.lineWidth = 4;
    ctx.stroke();

    statItems.forEach((st, idx) => {
      const [lx, ly] = getPentagonPoint(rCx, rCy, rMax + 64, idx);
      ctx.textAlign = 'center';
      ctx.fillStyle = 'rgba(255,255,255,0.85)';
      ctx.font = 'bold 28px JetBrains Mono, monospace';
      ctx.fillText(st.code, lx, ly - 10);
      ctx.fillStyle = skin.accent;
      ctx.font = 'bold 38px JetBrains Mono, monospace';
      ctx.fillText(String(st.value), lx, ly + 30);
    });

    // Shadow Army Box
    ctx.fillStyle = 'rgba(4,12,26,0.85)';
    drawRoundedRect(ctx, 120, 1410, W - 240, 260, 8);
    ctx.fill();
    ctx.strokeStyle = skin.accent;
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.textAlign = 'left';
    ctx.fillStyle = skin.accent;
    ctx.font = 'bold 30px JetBrains Mono, monospace';
    ctx.fillText(`АРМИЯ ТЕНЕЙ (${shadows.length})`, 156, 1466);
    ctx.textAlign = 'right';
    ctx.fillText(`+${shadowBonusXp} XP К ЗАДАНИЯМ`, W - 156, 1466);

    if (shadows.length === 0) {
      ctx.textAlign = 'center';
      ctx.fillStyle = 'rgba(255,255,255,0.72)';
      ctx.font = '600 28px Manrope, sans-serif';
      ctx.fillText('Заверши цель или серию 7 дней для извлечения Тени', W / 2, 1565);
    } else {
      shadows.slice(0, 3).forEach((sh, i) => {
        const yPos = 1528 + i * 52;
        ctx.textAlign = 'left';
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 30px Manrope, sans-serif';
        ctx.fillText(`[${sh.rank}] ${sh.name}`, 156, yPos);
        ctx.textAlign = 'right';
        ctx.fillStyle = skin.accent;
        ctx.font = 'bold 26px JetBrains Mono, monospace';
        ctx.fillText(user.subscription.active ? '+10 XP за задания' : sh.bonusText, W - 156, yPos);
      });
    }

    // Watermark / Footer
    ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(255,255,255,0.75)';
    ctx.font = '600 26px Manrope, sans-serif';
    ctx.fillText(
      user.subscription.active
        ? `СИСТЕМА+ · ${skin.sealLabel}`
        : `Пробудись в Telegram: @${botUsername}`,
      W / 2,
      1760
    );
    ctx.fillStyle = skin.accent;
    ctx.font = 'bold 32px JetBrains Mono, monospace';
    ctx.fillText(`@${botUsername}`, W / 2, 1810);

    const dataUrl = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `systema-${skin.id}-lv${user.level}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setSavedPng(true);
    window.setTimeout(() => setSavedPng(false), 2500);
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={reducedMotion ? { opacity: 1 } : { opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.16 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-2.5 bg-black/92"
          role="dialog"
          aria-modal="true"
          aria-label="Карточка охотника 9:16"
        >
          <motion.div
            initial={reducedMotion ? false : { scale: 0.94, opacity: 0, y: 10 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.96, opacity: 0, y: 6 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className={`relative w-full max-w-[404px] max-h-[94dvh] flex flex-col border-2 text-white overflow-hidden ${skin.borderClass} ${skin.surfaceClass} shadow-[0_0_44px_rgba(0,0,0,0.9)]`}
          >
            <button
              type="button"
              onClick={onClose}
              aria-label="Закрыть карточку"
              className="absolute top-1.5 right-1.5 z-30 min-w-[44px] min-h-[44px] flex items-center justify-center text-white/80 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex-1 overflow-y-auto system-scroll p-3.5 space-y-3">
              {/* Top Modal Title */}
              <div className="text-center pr-6 pl-6">
                <div className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 border text-[10.5px] font-mono uppercase tracking-[0.12em] ${skin.badgeClass}`}>
                  <Share2 className="w-3 h-3" />
                  <span>АРТЕФАКТ ОХОТНИКА · 9:16</span>
                </div>
              </div>

              {/* LIVE Scaled Vertical 9:16 Poster Card Preview */}
              <div className="flex justify-center">
                <div
                  className={`relative w-full max-w-[266px] aspect-[9/16] border-2 ${skin.borderClass} p-3 flex flex-col justify-between overflow-hidden`}
                  style={{
                    background: `linear-gradient(180deg, ${skin.bgTop} 0%, ${skin.bgMid} 58%, #02040a 100%)`,
                    boxShadow: `0 0 28px ${skin.glow}55, inset 0 0 18px ${skin.glow}30`,
                  }}
                >
                  {/* Coordinate Grid Overlay */}
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-0 opacity-35"
                    style={{
                      backgroundImage: `linear-gradient(${skin.accent}22 1px, transparent 1px), linear-gradient(90deg, ${skin.accent}22 1px, transparent 1px)`,
                      backgroundSize: '18px 18px',
                    }}
                  />

                  {/* Top Seal + Rank Crest */}
                  <div className="relative z-10 text-center space-y-1.5">
                    <div
                      className="text-[9px] font-mono uppercase tracking-[0.16em] py-0.5 border"
                      style={{ borderColor: `${skin.accent}66`, color: skin.accent }}
                    >
                      ОКНО СТАТУСА СИСТЕМЫ
                    </div>

                    <div className="flex justify-center pt-1.5 pb-1">
                      <div
                        className="w-11 h-11 rotate-45 border-2 flex items-center justify-center shadow-lg"
                        style={{
                          borderColor: skin.accent,
                          backgroundColor: `${skin.accent}22`,
                          boxShadow: `0 0 16px ${skin.glow}88`,
                        }}
                      >
                        <span className="-rotate-45 text-[20px] font-extrabold font-mono text-white">
                          {rankLetter}
                        </span>
                      </div>
                    </div>

                    <div className={`text-[10px] font-mono font-bold uppercase tracking-[0.08em] ${skin.textAccentClass}`}>
                      [ {rankInfo.rank} · {rankInfo.title} ]
                    </div>
                    <div className="text-[19px] font-extrabold text-white leading-none truncate">
                      {callsign}
                    </div>
                    <div className="text-[10.5px] font-mono text-white/80 font-tabular">
                      Ур. {user.level} · БМ {combatPower.toLocaleString('ru-RU')}
                    </div>
                  </div>

                  {/* Middle: XP Bar + Pentagon Stat Radar SVG */}
                  <div className="relative z-10 space-y-1.5">
                    <div className="border bg-black/45 p-1.5 space-y-1" style={{ borderColor: `${skin.accent}44` }}>
                      <div className="flex items-center justify-between text-[10px] font-tabular">
                        <span className="font-bold text-amber-300 flex items-center gap-1">
                          <Flame className="w-3 h-3 fill-amber-400 text-amber-400" />
                          Серия: {streak} дн.
                        </span>
                        <span className={skin.textAccentClass}>{xpPct}%</span>
                      </div>
                      <div className="w-full h-1.5 bg-white/15 overflow-hidden">
                        <div
                          className="h-full"
                          style={{
                            width: `${xpPct}%`,
                            background: `linear-gradient(90deg, ${skin.barStart}, ${skin.accent})`,
                          }}
                        />
                      </div>
                    </div>

                    {/* SVG Pentagon Radar */}
                    <div className="flex items-center justify-center py-0.5">
                      <svg viewBox="0 0 120 116" className="w-[144px] h-[136px]">
                        {[0.38, 0.7, 1].map((scale) => (
                          <polygon
                            key={scale}
                            points={[0, 1, 2, 3, 4]
                              .map((i) => {
                                const [x, y] = getPentagonPoint(60, 58, 38 * scale, i);
                                return `${x.toFixed(1)},${y.toFixed(1)}`;
                              })
                              .join(' ')}
                            fill="none"
                            stroke="rgba(255,255,255,0.22)"
                            strokeWidth="0.9"
                          />
                        ))}
                        <polygon
                          points={radarPolygonPoints}
                          fill={`${skin.accent}45`}
                          stroke={skin.accent}
                          strokeWidth="1.8"
                        />
                        {statItems.map((st, i) => {
                          const [lx, ly] = getPentagonPoint(60, 58, 50, i);
                          return (
                            <g key={st.code}>
                              <text
                                x={lx}
                                y={ly - 2}
                                textAnchor="middle"
                                fill="rgba(255,255,255,0.78)"
                                fontSize="6.5"
                                fontFamily="monospace"
                                fontWeight="bold"
                              >
                                {st.code}
                              </text>
                              <text
                                x={lx}
                                y={ly + 6}
                                textAnchor="middle"
                                fill={skin.accent}
                                fontSize="7.5"
                                fontFamily="monospace"
                                fontWeight="bold"
                              >
                                {st.value}
                              </text>
                            </g>
                          );
                        })}
                      </svg>
                    </div>
                  </div>

                  {/* Bottom: Shadows & Watermark */}
                  <div className="relative z-10 space-y-1.5">
                    <div className="border bg-black/50 p-1.5 text-[10px]" style={{ borderColor: `${skin.accent}44` }}>
                      <div className="flex items-center justify-between font-mono font-bold">
                        <span className="flex items-center gap-1 text-white">
                          <Ghost className="w-3 h-3" style={{ color: skin.accent }} />
                          <span>ТЕНИ ({shadows.length})</span>
                        </span>
                        <span style={{ color: skin.accent }}>+{shadowBonusXp} XP</span>
                      </div>
                      {shadows.length === 0 ? (
                        <div className="text-white/65 truncate mt-0.5">
                          Заверши цель · призови Тень
                        </div>
                      ) : (
                        <div className="text-white/90 truncate mt-0.5 font-medium">
                          {shadows[0].name}
                        </div>
                      )}
                    </div>
                    <div className="text-center text-[9.5px] font-mono text-white/75">
                      @{botUsername} · {user.subscription.active ? skin.label.toUpperCase() : 'FREE'}
                    </div>
                  </div>
                </div>
              </div>

              {/* 4-Skin Selector directly under the 9:16 Poster */}
              <div className="space-y-1">
                <div className="text-[11px] font-bold uppercase tracking-[0.06em] text-white/75 text-center">
                  Выберите стиль карточки
                </div>
                <div className="grid grid-cols-4 gap-1.5">
                  {(Object.values(CARD_SKINS) as SkinConfig[]).map((cfg) => {
                    const active = selectedSkin === cfg.id;
                    const locked = cfg.proOnly && !user.subscription.active;
                    return (
                      <button
                        key={cfg.id}
                        type="button"
                        onClick={() => {
                          playSystemSound('ui_step', user.soundEnabled, user.hapticsEnabled);
                          setSelectedSkin(cfg.id);
                        }}
                        className={`min-h-[44px] px-1 py-1.5 border text-[11px] font-bold flex items-center justify-center gap-1 cursor-pointer transition-colors ${
                          active
                            ? `${cfg.borderClass} bg-white/10 text-white`
                            : 'border-white/30 bg-black/45 text-white/75 hover:border-white/65'
                        }`}
                      >
                        {locked && <Lock className="w-2.5 h-2.5 shrink-0" style={{ color: cfg.accent }} />}
                        <span className="truncate">{cfg.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Big Conversion Actions */}
              <div className="space-y-2 pt-0.5">
                {isSkinLocked ? (
                  <button
                    type="button"
                    onClick={handleDownloadPng}
                    className="w-full min-h-[48px] px-4 py-2.5 border-2 border-amber-400 bg-gradient-to-r from-[#2e1c03] to-[#1a1004] text-amber-200 hover:border-white hover:text-white font-extrabold text-[13.5px] flex items-center justify-center gap-2 cursor-pointer shadow-[0_0_16px_rgba(251,191,36,0.35)]"
                  >
                    <Crown className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>ОТКРЫТЬ «{skin.label.toUpperCase()}» В СИСТЕМА+ · 99 ⭐</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleDownloadPng}
                    className={`w-full min-h-[48px] px-4 py-2.5 border-2 ${skin.borderClass} bg-white/10 hover:bg-white/15 text-white font-extrabold text-[14px] flex items-center justify-center gap-2 cursor-pointer`}
                  >
                    {savedPng ? <Check className="w-4 h-4" /> : <Download className="w-4 h-4" />}
                    <span>{savedPng ? '9:16 PNG СОХРАНЁН' : 'СКАЧАТЬ 9:16 PNG ДЛЯ TIKTOK'}</span>
                  </button>
                )}

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleCopyOrShareTelegram('telegram')}
                    className="min-h-[44px] px-3 py-2 border border-[#38f8ff]/75 bg-[#062d4a]/85 hover:border-white text-white font-bold text-[12.5px] flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5 text-[#38f8ff]" />
                    <span>В Telegram</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleCopyOrShareTelegram('copy')}
                    className="min-h-[44px] px-3 py-2 border border-white/55 bg-black/50 hover:border-white text-white font-bold text-[12.5px] flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    {copiedText ? <Check className="w-3.5 h-3.5 text-[#72f8ff]" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedText ? 'Скопировано' : 'Скопировать'}</span>
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
});
