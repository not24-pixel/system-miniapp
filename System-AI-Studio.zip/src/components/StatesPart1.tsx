import React, { memo, useState, useEffect, useRef } from 'react';
import {
  Archive,
  BookOpen,
  Briefcase,
  Calendar,
  Check,
  ChevronDown,
  ChevronRight,
  Clock,
  Coffee,
  Coins,
  Compass,
  CreditCard,
  Edit3,
  Eye,
  GraduationCap,
  Home,
  Info,
  Laptop,
  Lock,
  Plus,
  RotateCcw,
  Settings,
  ShoppingCart,
  Target,
  Trash2,
  Wallet,
  Zap,
  Activity,
  Shield,
  Gift,
  Star,
  Crown,
  Infinity as InfinityIcon,
  Repeat,
  TrendingUp,
  Flame,
  Ghost,
  Share2,
  Sparkles,
  Send,
} from 'lucide-react';
import {
  formatRub,
  parseNaturalFinanceInput,
  parseSmartFinanceInput,
} from '../shared/constants';
import { getTzIsoDaysAgo, localIsoDaysAgo } from '../shared/fixtures';
import { postApiAction } from '../shared/apiClient';
import {
  LifeRoleId,
  PlayerSubTabId,
  SkillBranchId,
  StatKey,
  UserAppState,
} from '../shared/types';
import {
  PlayerTopTabs,
  SystemButton,
  SystemCheckbox,
  SystemHeaderBox,
  SystemProgressBar,
  SystemSquareIcon,
  SystemTypewriter,
  getHunterRankInfo,
  formatRolesSubtitle,
} from './SystemWidgets';
import { motion } from 'motion/react';
import { playSystemSound } from '../shared/sound';
import { SkillTreeGraph } from './SkillTreeGraph';
import { RollingNumber } from './RollingNumber';
import { DashboardOverview } from './DashboardOverview';
import { TodayProgressChart } from './TodayProgressChart';
import { HabitsCalendarGrid } from './HabitsCalendarGrid';
import { ElectricCheckboxBurst, ElectricRowArc } from './ElectricBurst';

export interface ScreenPartProps {
  stateId: number;
  user: UserAppState;
  navigateState: (id: number) => void;
  apiAction: (endpoint: string, body?: Record<string, unknown>, nextStateId?: number) => Promise<void>;
  busy: boolean;
  prologueActive?: boolean;
  errorBanner: string | null;
  selectedTaskId?: string | null;
  setSelectedTaskId?: (id: string | null) => void;
  selectedEntryId?: string | null;
  setSelectedEntryId?: (id: string | null) => void;
  selectedHabitId?: string | null;
  setSelectedHabitId?: (id: string | null) => void;
  selectedGoalId?: string | null;
  setSelectedGoalId?: (id: string | null) => void;
  limitReason?: 'habits' | 'goals' | 'accounts';
  setLimitReason?: (reason: 'habits' | 'goals' | 'accounts') => void;
  openPlusModal?: (
    reason?: 'habits' | 'goals' | 'accounts' | 'feature' | 'general',
    featureLabel?: string
  ) => void;
  settingsReturnState?: number | null;
  setSettingsReturnState?: (id: number | null) => void;
  isAdmin?: boolean;
  onOpenShareCard?: () => void;
}

function pluralizePoints(n: number): string {
  const abs = Math.abs(n) % 100;
  const n1 = abs % 10;
  if (abs > 10 && abs < 20) return 'ОЧКОВ';
  if (n1 > 1 && n1 < 5) return 'ОЧКА';
  if (n1 === 1) return 'ОЧКО';
  return 'ОЧКОВ';
}

interface ClassPresetBlueprint {
  recommendedType: 'scheduled_action' | 'deadline_project' | 'savings';
  statFocus: string;
  scheduledList: string[];
  defaultScheduled: string;
  defaultMinutes: number;
  defaultSessions: number;
  projectList: string[];
  projectTitle: string;
  projectStep: string;
  savingsList: string[];
  savingsTitle: string;
  savingsTarget: string;
}

function getSingleRoleBlueprint(
  role: LifeRoleId,
  customRoleText?: string
): ClassPresetBlueprint {
  switch (role) {
    case 'studying':
      return {
        recommendedType: 'scheduled_action',
        statFocus: 'ИНТ +2 · Память и знания',
        scheduledList: [
          'Изучение материала по плану',
          'Английский и практика речи',
          'Решение задач и конспекты',
        ],
        defaultScheduled: 'Изучение материала по плану',
        defaultMinutes: 25,
        defaultSessions: 21,
        projectList: [
          'Подготовить и сдать проект',
          'Закрыть экзамен или диплом',
          'Пройти профильный курс',
        ],
        projectTitle: 'Подготовить и сдать проект',
        projectStep: 'Составить структуру и план разделов',
        savingsList: [
          'Резерв на обучение и технику',
          'Курсы и сертификация',
          'Ноутбук для учёбы',
        ],
        savingsTitle: 'Резерв на обучение и технику',
        savingsTarget: '60000',
      };
    case 'employed':
      return {
        recommendedType: 'scheduled_action',
        statFocus: 'ВЫН +2 · Карьера и выносливость',
        scheduledList: [
          'Глубокая работа без отвлечений',
          'Апгрейд карьерного навыка',
          'Утренний спринт по главной задаче',
        ],
        defaultScheduled: 'Глубокая работа без отвлечений',
        defaultMinutes: 30,
        defaultSessions: 21,
        projectList: [
          'Закрыть проект на повышение',
          'Пройти ревью и поднять грейд',
          'Автоматизировать рабочую рутину',
        ],
        projectTitle: 'Закрыть проект на повышение',
        projectStep: 'Выписать 3 измеримых результата квартала',
        savingsList: [
          'Подушка безопасности (3 мес.)',
          'Резерв на смену работы',
          'Инвестиционный старт',
        ],
        savingsTitle: 'Подушка безопасности (3 мес.)',
        savingsTarget: '150000',
      };
    case 'freelance':
      return {
        recommendedType: 'deadline_project',
        statFocus: 'ЛВК +2 · Клиенты и доход',
        scheduledList: [
          'Отклики и поиск клиентов',
          'Глубокий спринт по заказам',
          'Упаковка кейсов в портфолио',
        ],
        defaultScheduled: 'Отклики и поиск клиентов',
        defaultMinutes: 30,
        defaultSessions: 21,
        projectList: [
          'Запустить портфолио и прайс',
          'Выйти на 3 стабильных клиента',
          'Собрать сайт-визитку и офер',
        ],
        projectTitle: 'Запустить портфолио и прайс',
        projectStep: 'Выбрать 3 лучших кейса для портфолио',
        savingsList: [
          'Финансовая подушка фрилансера',
          'Резерв на спокойный месяц',
          'Фонд апгрейда техники',
        ],
        savingsTitle: 'Финансовая подушка фрилансера',
        savingsTarget: '100000',
      };
    case 'business':
      return {
        recommendedType: 'deadline_project',
        statFocus: 'ВОС +2 · Продукт и масштаб',
        scheduledList: [
          'Рост выручки и воронки',
          'Ключевые продажи и переговоры',
          'Аудит метрик и гипотез',
        ],
        defaultScheduled: 'Рост выручки и воронки',
        defaultMinutes: 45,
        defaultSessions: 21,
        projectList: [
          'Запустить продукт и воронку',
          'Собрать MVP и первые 5 оплат',
          'Систематизировать поток заявок',
        ],
        projectTitle: 'Запустить продукт и воронку',
        projectStep: 'Сформулировать офер и план запуска на 7 дней',
        savingsList: [
          'Операционный резерв бизнеса',
          'Бюджет на трафик и тесты',
          'Резервный фонд компании',
        ],
        savingsTitle: 'Операционный резерв бизнеса',
        savingsTarget: '250000',
      };
    case 'family':
      return {
        recommendedType: 'scheduled_action',
        statFocus: 'СИЛ +2 · Энергия и опора',
        scheduledList: [
          'Спорт и восстановление энергии',
          'Вечер с семьёй без экранов',
          'Утренний порядок и ритм дома',
        ],
        defaultScheduled: 'Спорт и восстановление энергии',
        defaultMinutes: 15,
        defaultSessions: 21,
        projectList: [
          'Завершить домашний проект',
          'Организовать семейный отпуск',
          'Наладить семейный бюджет',
        ],
        projectTitle: 'Завершить домашний проект',
        projectStep: 'Составить список этапов и смету',
        savingsList: [
          'Семейная подушка безопасности',
          'Фонд отпуска и здоровья',
          'Резерв на крупную покупку',
        ],
        savingsTitle: 'Семейная подушка безопасности',
        savingsTarget: '150000',
      };
    case 'custom':
    default: {
      const topic = customRoleText?.trim();
      return {
        recommendedType: 'scheduled_action',
        statFocus: 'ИНТ +1 / ВЫН +1 · Свой путь',
        scheduledList: topic
          ? [
              `Практика: ${topic}`,
              'Глубокий фокус без отвлечений',
              'Ежедневный шаг к мастерству',
            ]
          : [
              'Практика ключевого навыка',
              'Глубокий фокус без отвлечений',
              'Ежедневный шаг к мастерству',
            ],
        defaultScheduled: topic ? `Практика: ${topic}` : 'Практика ключевого навыка',
        defaultMinutes: 20,
        defaultSessions: 21,
        projectList: topic
          ? [
              `Запустить проект: ${topic}`,
              'Собрать первый результат за 14 дней',
              'Выйти на стабильный ритм',
            ]
          : [
              'Запустить личный проект',
              'Собрать первый результат за 14 дней',
              'Выйти на стабильный ритм',
            ],
        projectTitle: topic ? `Запустить проект: ${topic}` : 'Запустить личный проект',
        projectStep: 'Определить первый проверяемый шаг',
        savingsList: topic
          ? [`Фонд на цель: ${topic}`, 'Личная подушка безопасности', 'Бюджет на развитие']
          : ['Личная подушка безопасности', 'Фонд на развитие', 'Резерв свободы'],
        savingsTitle: topic ? `Фонд на цель: ${topic}` : 'Личная подушка безопасности',
        savingsTarget: '100000',
      };
    }
  }
}

function getRoleAwarePresets(roles: LifeRoleId[], customRoleText?: string): ClassPresetBlueprint {
  const safeRoles: LifeRoleId[] = roles && roles.length > 0 ? roles : ['employed'];
  const primary = getSingleRoleBlueprint(safeRoles[0], customRoleText);
  if (safeRoles.length === 1) return primary;

  // Hybrid class merge: anchor on primary class and blend top mission from secondary class
  const secondary = getSingleRoleBlueprint(safeRoles[1], customRoleText);
  const mergeList = (a: string[], b: string[]) => {
    const out = [a[0]];
    if (b[0] && !out.includes(b[0])) out.push(b[0]);
    for (const item of [...a.slice(1), ...b.slice(1)]) {
      if (out.length >= 3) break;
      if (!out.includes(item)) out.push(item);
    }
    return out;
  };

  return {
    ...primary,
    scheduledList: mergeList(primary.scheduledList, secondary.scheduledList),
    projectList: mergeList(primary.projectList, secondary.projectList),
    savingsList: mergeList(primary.savingsList, secondary.savingsList),
  };
}

export const StatesPart1: React.FC<ScreenPartProps> = memo(({
  stateId,
  user,
  navigateState,
  apiAction,
  busy,
  prologueActive = false,
  setSelectedTaskId,
  setSelectedEntryId,
  selectedHabitId,
  setSelectedHabitId,
  selectedGoalId,
  setSelectedGoalId,
  setLimitReason,
  openPlusModal,
  settingsReturnState,
  setSettingsReturnState,
  onOpenShareCard,
}) => {
  const [inviteStageDone, setInviteStageDone] = useState(false);
  const [refuseOverload, setRefuseOverload] = useState(false);
  const [inviteTimerSec, setInviteTimerSec] = useState(10);
  const [refusalLockAttempts, setRefusalLockAttempts] = useState(0);
  const [quickFinanceInput, setQuickFinanceInput] = useState('');
  const [smartStepsPreview, setSmartStepsPreview] = useState<string[]>([]);
  const [smartStepsLoading, setSmartStepsLoading] = useState(false);
  const [habitSparkKey, setHabitSparkKey] = useState<Record<string, number>>({});
  const [chestSparkKey, setChestSparkKey] = useState(0);
  const lastRoleSigRef = useRef<string>('');
  const inviteTimeoutTriggeredRef = useRef(false);
  const refuseRedirectTimerRef = useRef<number | null>(null);

  // Overhauled Onboarding States (04 -> 05 -> 06..08)
  const [callsignDraft, setCallsignDraft] = useState(user.playerCallsign || '');
  const [rolesDraft, setRolesDraft] = useState<LifeRoleId[]>(user.roles || []);
  const [customRoleDraft, setCustomRoleDraft] = useState(user.customRoleText || '');

  const [selectedGoalType, setSelectedGoalType] = useState<'scheduled_action' | 'deadline_project' | 'savings'>('scheduled_action');
  const [goalTitle, setGoalTitle] = useState('Фокус над ключевым проектом');
  const [goalTargetSessions, setGoalTargetSessions] = useState<number>(21);
  const [goalMinutes, setGoalMinutes] = useState<number>(30);
  const [goalDays, setGoalDays] = useState<number>(5);
  const [goalPreferredTime, setGoalPreferredTime] = useState('Вечером');

  const [projTitle, setProjTitle] = useState('Запустить портфолио и прайс');
  const [projDeadline, setProjDeadline] = useState('Через 30 дней');
  const [projStep, setProjStep] = useState('Выбрать 3 лучших кейса для портфолио');
  const [projMandatory, setProjMandatory] = useState(true);

  const [savTitle, setSavTitle] = useState('Подушка безопасности');
  const [savTarget, setSavTarget] = useState('100000');
  const [savCurrent, setSavCurrent] = useState('30000');
  const [savDeadline, setSavDeadline] = useState('Без жёсткой даты');

  // Reset sequential typewriter lock when entering invitation states 01/02/03
  useEffect(() => {
    if (refuseRedirectTimerRef.current !== null) {
      window.clearTimeout(refuseRedirectTimerRef.current);
      refuseRedirectTimerRef.current = null;
    }
    inviteTimeoutTriggeredRef.current = false;
    if (stateId === 1 || stateId === 2 || stateId === 3) {
      setInviteStageDone(false);
      setRefuseOverload(false);
      setInviteTimerSec(10);
      setRefusalLockAttempts(0);
    }
  }, [stateId]);

  // Tense Solo Leveling countdown pressure while hesitating on State 01 (starts ONLY after prologue AND typewriter finish)
  useEffect(() => {
    if (stateId !== 1 || prologueActive || !inviteStageDone) return;
    const t = setInterval(() => {
      setInviteTimerSec((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(t);
  }, [stateId, prologueActive, inviteStageDone]);

  // When life-threshold countdown expires at 00:00, force critical refusal lock -> State 02
  useEffect(() => {
    if (
      stateId !== 1 ||
      prologueActive ||
      !inviteStageDone ||
      busy ||
      inviteTimerSec > 0 ||
      inviteTimeoutTriggeredRef.current
    ) {
      return;
    }
    inviteTimeoutTriggeredRef.current = true;
    setRefuseOverload(true);
    playSystemSound('refusal_rejected', user.soundEnabled, user.hapticsEnabled);
    refuseRedirectTimerRef.current = window.setTimeout(() => {
      refuseRedirectTimerRef.current = null;
      apiAction('/api/onboarding/refuse', {}, 2);
    }, 650);
  }, [stateId, prologueActive, inviteStageDone, busy, inviteTimerSec, user.soundEnabled, user.hapticsEnabled, apiAction]);

  // Cleanup any pending redirect timeout on unmount
  useEffect(() => {
    return () => {
      if (refuseRedirectTimerRef.current !== null) {
        window.clearTimeout(refuseRedirectTimerRef.current);
      }
    };
  }, []);

  // Sync roles draft cleanly when entering State 04 (prefill Telegram first_name if available)
  useEffect(() => {
    if (stateId === 4) {
      setRolesDraft(user.roles || []);
      setCustomRoleDraft(user.customRoleText || '');
      let tgFirstName = '';
      try {
        tgFirstName =
          (
            window as unknown as {
              Telegram?: { WebApp?: { initDataUnsafe?: { user?: { first_name?: string } } } };
            }
          ).Telegram?.WebApp?.initDataUnsafe?.user?.first_name?.trim() || '';
      } catch {
        tgFirstName = '';
      }
      setCallsignDraft(
        user.playerCallsign && user.playerCallsign !== 'Игрок'
          ? user.playerCallsign
          : tgFirstName
      );
    }
  }, [stateId, user.roles, user.customRoleText, user.playerCallsign]);

  // Sync recommended vector automatically when player updates class roles or opens State 05
  useEffect(() => {
    const roleSig = `${(user.roles || []).join(',')}|${user.customRoleText || ''}`;
    if (roleSig !== lastRoleSigRef.current) {
      lastRoleSigRef.current = roleSig;
      if (stateId === 5 || user.bootstrapState !== 'ready') {
        const bp = getRoleAwarePresets(user.roles, user.customRoleText);
        setSelectedGoalType(bp.recommendedType);
      }
    }
  }, [stateId, user.roles, user.customRoleText, user.bootstrapState]);

  // Adapt default Goal Presets automatically when entering States 06/07/08, OR sync existing goal when editing
  useEffect(() => {
    if (stateId !== 6 && stateId !== 7 && stateId !== 8) return;
    const editingGoal = selectedGoalId ? user.goals.find((g) => g.id === selectedGoalId) : null;
    if (editingGoal) {
      if (stateId === 6 && editingGoal.type === 'scheduled_action') {
        setGoalTitle(editingGoal.title);
        setGoalMinutes(editingGoal.durationMinutes || 15);
        setGoalTargetSessions(editingGoal.targetValue || 21);
        setGoalDays(editingGoal.daysPerWeek || 5);
        setGoalPreferredTime(editingGoal.preferredTime || 'Вечером');
        return;
      }
      if (stateId === 7 && editingGoal.type === 'deadline_project') {
        setProjTitle(editingGoal.title);
        setProjDeadline(editingGoal.deadlineText || 'Через 30 дней');
        setProjMandatory(Boolean(editingGoal.mandatoryDeadline));
        return;
      }
      if (stateId === 8 && editingGoal.type === 'savings') {
        setSavTitle(editingGoal.title);
        setSavTarget(String(editingGoal.targetValue));
        setSavCurrent(String(editingGoal.currentValue));
        setSavDeadline(editingGoal.deadlineText || 'Без жёсткой даты');
        return;
      }
    }
    const presets = getRoleAwarePresets(user.roles, user.customRoleText);
    if (stateId === 6) {
      setGoalTitle(presets.defaultScheduled);
      setGoalMinutes(presets.defaultMinutes);
      setGoalTargetSessions(presets.defaultSessions);
    } else if (stateId === 7) {
      setProjTitle(presets.projectTitle);
      setProjStep(presets.projectStep);
      setSmartStepsPreview([]);
    } else if (stateId === 8) {
      setSavTitle(presets.savingsTitle);
      setSavTarget(presets.savingsTarget);
      setSavCurrent(user.bootstrapState === 'ready' ? '0' : '10000');
    }
  }, [stateId, user.roles, user.customRoleText, selectedGoalId, user.goals, user.bootstrapState]);

  const [confirmDeleteKey, setConfirmDeleteKey] = useState<string | null>(null);
  const [showArchivedHabits, setShowArchivedHabits] = useState(false);
  const [showArchivedGoals, setShowArchivedGoals] = useState(false);
  const [showArchivedAccounts, setShowArchivedAccounts] = useState(false);

  useEffect(() => {
    setConfirmDeleteKey(null);
  }, [stateId, selectedGoalId, selectedHabitId]);

  const [habitName, setHabitName] = useState('Чтение');
  const [habitDuration, setHabitDuration] = useState('15 минут');
  const [habitDays, setHabitDays] = useState<string[]>(['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ']);
  const [habitDeadline, setHabitDeadline] = useState('23:00');
  const [habitMandatory, setHabitMandatory] = useState(true);

  const [smartInput, setSmartInput] = useState('Кофе 200, продукты 1500');
  const activeAccounts = user.accounts.filter((a) => a.status === 'active');
  const fallbackAcc = activeAccounts[0] || user.accounts[0] || { id: 'acc_card', name: 'Карта' };
  const selectableAccounts = activeAccounts.length > 0 ? activeAccounts : user.accounts;
  const parsedDrafts = parseSmartFinanceInput(smartInput, fallbackAcc.id, fallbackAcc.name, selectableAccounts);

  const [expenseAmount, setExpenseAmount] = useState(200);
  const [expenseCategory, setExpenseCategory] = useState('Еда');
  const [expenseAccount, setExpenseAccount] = useState(fallbackAcc.id);
  const [expenseDate, setExpenseDate] = useState('Сегодня');
  const [expenseTitle, setExpenseTitle] = useState('Кофе');

  const [incomeAmount, setIncomeAmount] = useState(50000);
  const [incomeCategory, setIncomeCategory] = useState('Зарплата');
  const [incomeAccount, setIncomeAccount] = useState(fallbackAcc.id);

  const [transferAmount, setTransferAmount] = useState(1000);
  const [transferFrom, setTransferFrom] = useState(selectableAccounts[0]?.id || 'acc_card');
  const [transferTo, setTransferTo] = useState(
    selectableAccounts[1]?.id || selectableAccounts[0]?.id || 'acc_cash'
  );

  const [showNewAccForm, setShowNewAccForm] = useState(false);
  const [newAccName, setNewAccName] = useState('');
  const [newAccType, setNewAccType] = useState<'card' | 'cash' | 'savings'>('savings');
  const [newAccBalance, setNewAccBalance] = useState('0');

  // Keep selected accounts synchronized with active user.accounts list
  useEffect(() => {
    const pool = user.accounts.filter((a) => a.status === 'active');
    const source = pool.length > 0 ? pool : user.accounts;
    if (source.length === 0) return;
    if (!source.some((a) => a.id === expenseAccount)) {
      setExpenseAccount(source[0].id);
    }
    if (!source.some((a) => a.id === incomeAccount)) {
      setIncomeAccount(source[0].id);
    }
    if (!source.some((a) => a.id === transferFrom)) {
      setTransferFrom(source[0].id);
    }
    if (!source.some((a) => a.id === transferTo) || transferTo === transferFrom) {
      const other = source.find((a) => a.id !== transferFrom) || source[0];
      if (other && other.id !== transferTo) {
        setTransferTo(other.id);
      }
    }
  }, [user.accounts, expenseAccount, incomeAccount, transferFrom, transferTo]);

  const [selectedSkillBranch, setSelectedSkillBranch] = useState<SkillBranchId>('focus');
  const [skillsViewMode, setSkillsViewMode] = useState<'graph' | 'list'>('graph');

  const switchSubTab = (sub: PlayerSubTabId) => {
    navigateState(sub === 'status' ? 28 : 31);
  };

  const isQuarantined = Boolean(
    user.penaltyQuest?.active &&
      user.penaltyQuest.status !== 'completed' &&
      user.penaltyQuest.status !== 'completed_late' &&
      user.penaltyQuest.status !== 'cancelled_error'
  );

  // --- ПЕРВЫЙ ВХОД (States 01, 02, 03) — 1:1 Solo Leveling Double Dungeon Awakening ---
  if (stateId === 1) {
    const isUrgent = inviteStageDone && inviteTimerSec <= 3;
    const getTgFirstName = () => {
      try {
        return (
          (
            window as unknown as {
              Telegram?: { WebApp?: { initDataUnsafe?: { user?: { first_name?: string } } } };
            }
          ).Telegram?.WebApp?.initDataUnsafe?.user?.first_name?.trim() || ''
        );
      } catch {
        return '';
      }
    };

    return (
      <div className="flex flex-col items-center justify-between min-h-full py-4 text-center">
        <div className="w-full space-y-2.5">
          <SystemSquareIcon kind="alert" palette={refuseOverload ? 'red' : 'blue'} />
          <SystemHeaderBox title="УВЕДОМЛЕНИЕ" palette={refuseOverload ? 'red' : 'blue'} />
          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 0.35, delay: 0.12 }}
            className="w-4/5 mx-auto border-t border-[#38f8ff]/80 shadow-[0_0_10px_#00e5ff] my-2"
          />
          <div
            className={`mx-auto w-4/5 space-y-1 text-[11px] font-mono font-tabular ${
              isUrgent ? 'text-[#ff9999]' : 'text-[#72f8ff]/90'
            }`}
          >
            <div className="flex items-center justify-between">
              <span>{inviteStageDone ? 'ЖИЗНЕННЫЙ ПОРОГ' : 'СКАНИРОВАНИЕ...'}</span>
              <span className={`font-bold ${inviteTimerSec === 0 ? 'animate-pulse text-[#ff4d4d]' : ''}`}>
                {inviteTimerSec === 0
                  ? '00:00 · КРИТИЧЕСКИЙ ПОРОГ'
                  : `00:${String(inviteTimerSec).padStart(2, '0')} СЕК`}
              </span>
            </div>
            <div className="w-full h-1 bg-white/10 overflow-hidden">
              <div
                className={`h-full transition-all duration-500 ${
                  isUrgent
                    ? 'bg-[#ff3b3b] shadow-[0_0_10px_#ff1e27]'
                    : 'bg-[#00e5ff] shadow-[0_0_10px_#00e5ff]'
                }`}
                style={{ width: `${(inviteTimerSec / 10) * 100}%` }}
              />
            </div>
          </div>
        </div>

        <SystemTypewriter
          lines={['Вы получили право', 'стать Игроком.']}
          subLines={[
            'Если вы не примете приглашение,\nсердце остановится через 0.02 сек.',
          ]}
          palette={refuseOverload ? 'red' : 'blue'}
          soundEnabled={user.soundEnabled}
          speedMs={22}
          onFinish={() => setInviteStageDone(true)}
        />

        <motion.div
          initial={{ opacity: 0.35, y: 8 }}
          animate={{ opacity: inviteStageDone ? 1 : 0.72, y: 0 }}
          transition={{ duration: 0.25 }}
          className="w-full grid grid-cols-2 gap-3 pt-3 pointer-events-auto"
        >
          <SystemButton
            label="ПРИНЯТЬ"
            palette="blue"
            highlighted
            disabled={busy || refuseOverload}
            onClick={() => {
              inviteTimeoutTriggeredRef.current = true;
              if (refuseRedirectTimerRef.current !== null) {
                window.clearTimeout(refuseRedirectTimerRef.current);
                refuseRedirectTimerRef.current = null;
              }
              playSystemSound('system_activated', user.soundEnabled, user.hapticsEnabled);
              apiAction('/api/onboarding/accept', { firstName: getTgFirstName() }, 3);
            }}
          />
          <motion.div
            animate={
              refuseOverload
                ? {
                    x: [0, -8, 9, -7, 6, -3, 0],
                    scale: [1, 1.06, 0.88, 0.65],
                    opacity: [1, 1, 0.5, 0],
                    opacity: 0.75,
                  }
                : { x: 0, scale: 1, opacity: 1 }
            }
            transition={{ duration: 0.32 }}
          >
            <SystemButton
              label="ОТКАЗАТЬСЯ"
              palette={refuseOverload ? 'red' : 'blue'}
              disabled={busy || refuseOverload}
              onClick={() => {
                inviteTimeoutTriggeredRef.current = true;
                if (refuseRedirectTimerRef.current !== null) {
                  window.clearTimeout(refuseRedirectTimerRef.current);
                  refuseRedirectTimerRef.current = null;
                }
                setRefuseOverload(true);
                playSystemSound('refusal_rejected', user.soundEnabled, user.hapticsEnabled);
                refuseRedirectTimerRef.current = window.setTimeout(() => {
                  refuseRedirectTimerRef.current = null;
                  apiAction('/api/onboarding/refuse', {}, 2);
                }, 310);
              }}
            />
          </motion.div>
        </motion.div>
      </div>
    );
  }

  if (stateId === 2) {
    const getTgFirstName = () => {
      try {
        return (
          (
            window as unknown as {
              Telegram?: { WebApp?: { initDataUnsafe?: { user?: { first_name?: string } } } };
            }
          ).Telegram?.WebApp?.initDataUnsafe?.user?.first_name?.trim() || ''
        );
      } catch {
        return '';
      }
    };

    return (
      <div className="flex flex-col items-center justify-between min-h-full py-4 text-center">
        <div className="w-full space-y-2.5">
          <SystemSquareIcon kind="alert" palette="red" />
          <SystemHeaderBox title="ОТКАЗ ОТКЛОНЁН" palette="red" />
          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 0.25, delay: 0.06 }}
            className="w-4/5 mx-auto border-t border-[#ff4d4d] shadow-[0_0_14px_#ff1e27] my-2"
          />

          {/* Critical Cardiac Pressure Bar (00:02 Flatline Threat) */}
          <div className="mx-auto w-4/5 px-2.5 py-1.5 border border-[#ff4d4d]/70 bg-[#240307]/85 flex items-center justify-between text-[11px] font-mono text-[#ffb3b3]">
            <span className="flex items-center gap-1.5 font-bold">
              <Activity className="w-3.5 h-3.5 text-[#ff3b3b] animate-pulse" />
              ПУЛЬС: КРИТИЧЕСКИЙ
            </span>
            <span className="font-bold text-[#ff4d4d] animate-pulse">00:00:02</span>
          </div>
        </div>

        <SystemTypewriter
          lines={['Вы не можете', 'отказаться от Системы.']}
          subLines={[
            refusalLockAttempts > 0
              ? 'ПОВТОРНЫЙ ОТКАЗ НЕВОЗМОЖЕН.\nДля выживания примите приглашение.'
              : 'При отказе ваше сердце остановится.\nПримите пробуждение сейчас.',
          ]}
          palette="red"
          soundEnabled={user.soundEnabled}
          speedMs={18}
          onFinish={() => setInviteStageDone(true)}
        />

        <motion.div
          initial={{ opacity: 0.65, scale: 0.98 }}
          animate={{
            opacity: 1,
            scale: 1,
          }}
          transition={{ duration: 0.24 }}
          className="w-full pt-3 space-y-2.5 pointer-events-auto"
        >
          <SystemButton
            label="ПРИНЯТЬ ПРОБУЖДЕНИЕ"
            palette="red"
            highlighted
            disabled={busy}
            onClick={() => {
              playSystemSound('system_activated', user.soundEnabled, user.hapticsEnabled);
              apiAction('/api/onboarding/accept', { firstName: getTgFirstName() }, 3);
            }}
          />

          {/* Interactive Locked Refusal Button that violently rejects attempts */}
          <motion.button
            key={`lock_refuse_${refusalLockAttempts}`}
            type="button"
            onClick={() => {
              setRefusalLockAttempts((c) => c + 1);
              playSystemSound('refusal_rejected', user.soundEnabled, user.hapticsEnabled);
            }}
            animate={
              refusalLockAttempts > 0
                ? { x: [0, -8, 8, -6, 6, -3, 0] }
                : { x: 0 }
            }
            transition={{ duration: 0.32 }}
            className="w-full py-2 px-3 border border-[#ff4d4d]/45 bg-[#1a0306]/80 flex items-center justify-center gap-2 text-[12px] font-mono tracking-[0.06em] text-[#ff8585]/80 cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5 text-[#ff4d4d]" />
            <span className="line-through decoration-[#ff4d4d]/80">
              {refusalLockAttempts > 0
                ? 'ОТКАЗ ЗАБЛОКИРОВАН · ВЫХОДА НЕТ'
                : 'ОТКАЗАТЬСЯ [ ЗАБЛОКИРОВАНО ]'}
            </span>
          </motion.button>
        </motion.div>
      </div>
    );
  }

  if (stateId === 3) {
    const callsign = user.playerCallsign?.trim() || 'Игрок';
    const rankInfo = getHunterRankInfo(user.level);
    return (
      <div className="flex flex-col items-center justify-between min-h-full py-4 text-center space-y-3">
        <div className="w-full space-y-3">
          <SystemSquareIcon kind="alert" palette="blue" />
          <SystemHeaderBox title="ВЫБОР ПРИНЯТ" palette="blue" />
          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 0.35, delay: 0.12 }}
            className="w-4/5 mx-auto border-t border-[#38f8ff]/80 shadow-[0_0_10px_#00e5ff] my-2"
          />
        </div>

        <SystemTypewriter
          lines={['Добро пожаловать,', `${callsign}.`]}
          subLines={['Система приняла нового носителя.', 'Контракт с Системой подписан.']}
          palette="blue"
          soundEnabled={user.soundEnabled}
          speedMs={22}
          onFinish={() => setInviteStageDone(true)}
        />

        {/* Immediate Awakening Reward Strip */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.28, delay: 0.15 }}
          className="w-full p-3 border border-[#38f8ff]/70 bg-[#04182b]/90 shadow-[0_0_16px_rgba(0,225,255,0.28)] space-y-2 text-left"
        >
          <div className="flex items-center justify-between text-[12px] font-mono">
            <span className="font-bold text-[#72f8ff]">
              [{rankInfo.rank} · {rankInfo.title.toUpperCase()}]
            </span>
            <span className="font-extrabold text-[#38f8ff]">+15 XP ПРОБУЖДЕНИЯ</span>
          </div>
          <SystemProgressBar value={user.currentXp} max={user.nextLevelXp} />
          <div className="flex items-center justify-between text-[11.5px] text-white/85 font-tabular">
            <span>★ Трофей: Контракт с Системой</span>
            <span>
              {user.currentXp} / {user.nextLevelXp} XP
            </span>
          </div>
        </motion.div>

        <div className="w-full pt-1">
          <SystemButton
            label="ПРОДОЛЖИТЬ"
            palette="blue"
            highlighted
            onClick={() => {
              playSystemSound('tab_switch', user.soundEnabled, user.hapticsEnabled);
              navigateState(4);
            }}
          />
        </div>
      </div>
    );
  }

  // --- ПРОФИЛЬ И НАСТРОЙКА ПЕРВОЙ ЦЕЛИ (States 04, 05, 06, 07, 08, 09) ---
  if (stateId === 4) {
    const classOptions: Array<{
      id: LifeRoleId;
      title: string;
      hint: string;
      statBonus: string;
      Icon: React.FC<{ className?: string }>;
    }> = [
      { id: 'studying', title: 'Учёба', hint: 'Знания и навыки', statBonus: '+2 ИНТ', Icon: GraduationCap },
      { id: 'employed', title: 'Найм', hint: 'Карьера и фокус', statBonus: '+2 ВЫН', Icon: Briefcase },
      { id: 'freelance', title: 'Фриланс', hint: 'Клиенты и доход', statBonus: '+2 ЛВК', Icon: Laptop },
      { id: 'business', title: 'Бизнес', hint: 'Продукт и рост', statBonus: '+2 ВОС', Icon: Target },
      { id: 'family', title: 'Семья', hint: 'Ритм и опора', statBonus: '+2 СИЛ', Icon: Home },
      { id: 'custom', title: 'Свой путь', hint: 'Своя сфера', statBonus: '+1 ИНТ/ВЫН', Icon: Compass },
    ];

    const toggleLocalRole = (roleId: LifeRoleId) => {
      playSystemSound('ui_step', user.soundEnabled, user.hapticsEnabled);
      setRolesDraft((prev) =>
        prev.includes(roleId) ? prev.filter((r) => r !== roleId) : [...prev, roleId]
      );
    };

    const canContinue =
      rolesDraft.length > 0 &&
      (!rolesDraft.includes('custom') || customRoleDraft.trim().length > 0 || rolesDraft.length > 1);

    const submitRoles = (quickStart = false) => {
      playSystemSound('tab_switch', user.soundEnabled, user.hapticsEnabled);
      const returnTo = settingsReturnState
        ? settingsReturnState
        : quickStart || user.bootstrapState === 'ready'
        ? quickStart
          ? 11
          : 28
        : 5;
      setSettingsReturnState?.(null);
      apiAction(
        '/api/onboarding/roles',
        {
          roles: rolesDraft,
          customRoleText: customRoleDraft.trim(),
          playerCallsign: callsignDraft.trim() || 'Игрок',
          quickStart,
        },
        returnTo
      );
    };

    return (
      <div className="h-full flex flex-col justify-between gap-2 overflow-hidden">
        <div className="shrink-0 space-y-2">
          <SystemHeaderBox
            title="ПРОФИЛЬ ИГРОКА"
            onBack={
              settingsReturnState
                ? () => {
                    const target = settingsReturnState;
                    setSettingsReturnState?.(null);
                    navigateState(target);
                  }
                : undefined
            }
          />

          <div className="space-y-1">
            <label className="text-[11px] uppercase tracking-[0.06em] text-[#9deeff] block">
              Позывной (необязательно)
            </label>
            <input
              type="text"
              placeholder="Игрок"
              maxLength={32}
              value={callsignDraft}
              onChange={(e) => setCallsignDraft(e.target.value)}
              className="w-full px-3 py-2 rounded-[5px] border border-white/75 bg-[#031221] text-[15px] font-semibold text-white focus:outline-none focus:border-[#00e5ff]"
            />
          </div>

          <div className="pt-1 border-t border-white/20 flex items-baseline justify-between gap-2">
            <div>
              <div className="text-[14px] font-bold text-white">Класс / сфера</div>
              <div className="text-[11px] text-white/75">
                Выберите от 1 направления — даст бонус статов и стартовый квест
              </div>
            </div>
          </div>
        </div>

        {/* Scrollable larger class cards filling middle space with zero empty void */}
        <div className="flex-1 min-h-0 overflow-y-auto system-scroll system-scroll-blue space-y-2 pr-0.5 py-0.5">
          {classOptions.map(({ id, title, hint, statBonus, Icon }) => {
            const selected = rolesDraft.includes(id);
            return (
              <button
                key={id}
                type="button"
                onClick={() => toggleLocalRole(id)}
                className={`w-full px-3.5 py-2.5 rounded-[6px] border text-left flex items-center justify-between gap-3 min-h-[64px] transition-all cursor-pointer ${
                  selected
                    ? 'border-[#38f8ff] bg-[#062d4a]/95 shadow-[0_0_14px_rgba(0,225,255,0.42)]'
                    : 'border-white/35 bg-black/45 hover:border-white/70'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-10 h-10 rounded-[5px] border flex items-center justify-center shrink-0 ${
                      selected ? 'border-[#38f8ff] bg-[#03182b]' : 'border-white/25 bg-[#020b16]'
                    }`}
                  >
                    <Icon className={`w-5 h-5 ${selected ? 'text-[#38f8ff]' : 'text-white/80'}`} />
                  </div>
                  <div className="min-w-0">
                    <div className="text-[15px] font-bold text-white truncate">{title}</div>
                    <div className="text-[12px] text-white/75 truncate">{hint}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2.5 shrink-0">
                  <span className="px-2 py-0.5 border border-[#38f8ff]/45 bg-[#031221] font-mono text-[11px] font-bold text-[#72f8ff]">
                    {statBonus}
                  </span>
                  <span
                    className={`w-5 h-5 rounded-[4px] border flex items-center justify-center shrink-0 ${
                      selected ? 'border-white bg-[#0077b6]' : 'border-white/60 bg-black/40'
                    }`}
                  >
                    {selected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                  </span>
                </div>
              </button>
            );
          })}

          {rolesDraft.includes('custom') && (
            <input
              type="text"
              placeholder="Опишите ваш путь (например: Стартап, Спорт, Музыка)"
              value={customRoleDraft}
              onChange={(e) => setCustomRoleDraft(e.target.value)}
              className="w-full px-3 py-2 rounded-[5px] border border-[#38f8ff] bg-[#031221] text-[14px] font-medium text-white focus:outline-none"
            />
          )}
        </div>

        {/* Fixed Bottom CTA — Always visible without scrolling */}
        <div className="shrink-0 pt-2 border-t border-[#38f8ff]/45 bg-[#020e1c]/95 space-y-1.5">
          <SystemButton
            label={user.bootstrapState === 'ready' ? 'СОХРАНИТЬ ПРОФИЛЬ' : 'ПОДТВЕРДИТЬ КЛАСС'}
            highlighted
            disabled={!canContinue || busy}
            onClick={() => submitRoles(false)}
          />
          {user.bootstrapState !== 'ready' && !settingsReturnState && (
            <button
              type="button"
              disabled={!canContinue || busy}
              onClick={() => submitRoles(true)}
              className="w-full py-1.5 text-[12px] font-semibold text-[#9deeff] hover:text-white underline underline-offset-2 cursor-pointer disabled:opacity-40"
            >
              Быстрый старт сразу в «Сегодня» (цель по умолчанию)
            </button>
          )}
        </div>
      </div>
    );
  }

  if (stateId === 5) {
    const isOnboardingFlow = user.bootstrapState !== 'ready';
    const presets = getRoleAwarePresets(user.roles, user.customRoleText);
    const goalTypes: Array<{
      id: 'scheduled_action' | 'deadline_project' | 'savings';
      title: string;
      desc: string;
      sample: string;
      nextState: number;
    }> = [
      {
        id: 'scheduled_action',
        title: 'Ежедневная дисциплина',
        desc: 'Регулярный навык с таймером и чётким недельным ритмом',
        sample: `Старт: «${presets.defaultScheduled}» · ${presets.defaultMinutes} мин`,
        nextState: 6,
      },
      {
        id: 'deadline_project',
        title: 'Целевой проект',
        desc: 'Большая миссия с пошаговыми вехами и контрольным сроком',
        sample: `Старт: «${presets.projectTitle}» · 3 вехи`,
        nextState: 7,
      },
      {
        id: 'savings',
        title: 'Финансовый резерв',
        desc: 'Накопление нужной суммы с привязкой к вашим счетам',
        sample: `Старт: «${presets.savingsTitle}» · ${formatRub(Number(presets.savingsTarget))}`,
        nextState: 8,
      },
    ];

    const selectedMeta =
      goalTypes.find((g) => g.id === selectedGoalType) || goalTypes[0];
    const currentTargetState = selectedMeta.nextState;
    const roleSummary = formatRolesSubtitle(user.roles, user.customRoleText);
    const hasMultipleRoles = (user.roles?.length || 0) > 1;
    const firstQuestPreview =
      selectedGoalType === 'scheduled_action'
        ? `${presets.defaultScheduled} · ${presets.defaultMinutes} мин`
        : selectedGoalType === 'deadline_project'
        ? presets.projectStep
        : `Финансовая проверка: ${presets.savingsTitle}`;

    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5">
        <div className="space-y-2.5">
          <SystemHeaderBox
            title={isOnboardingFlow ? 'ВЕКТОР ПЕРВОЙ МИССИИ' : 'НОВАЯ ЦЕЛЬ'}
            onBack={() => navigateState(isOnboardingFlow ? 4 : 16)}
          />

          <div className="py-2 px-3 border border-[#38f8ff]/45 bg-[#04182b]/85 text-center space-y-0.5">
            <div className="text-[11px] uppercase tracking-[0.08em] text-[#72f8ff]">
              {hasMultipleRoles ? 'Выбранные классы' : 'Выбранный класс'}
            </div>
            <div className="text-[16px] font-bold text-white leading-tight">{roleSummary}</div>
            <div className="text-[11.5px] font-mono text-[#9deeff]/90">{presets.statFocus}</div>
          </div>

          <div className="space-y-2 pt-0.5">
            {goalTypes.map((gt) => {
              const active = selectedGoalType === gt.id;
              const isRecommended = gt.id === presets.recommendedType;
              return (
                <button
                  key={gt.id}
                  type="button"
                  onClick={() => {
                    playSystemSound('ui_step', user.soundEnabled, user.hapticsEnabled);
                    setSelectedGoalType(gt.id);
                  }}
                  className={`w-full p-3 rounded-[5px] border text-left flex items-start gap-3 transition-all cursor-pointer ${
                    active
                      ? 'border-[#38f8ff] bg-[#062d4a]/90 shadow-[0_0_16px_rgba(0,225,255,0.42)]'
                      : 'border-white/35 bg-black/35 hover:border-white/70'
                  }`}
                >
                  <span className="w-5 h-5 mt-0.5 rounded-full border-2 border-white flex items-center justify-center shrink-0">
                    {active && <span className="w-2.5 h-2.5 rounded-full bg-white shadow-[0_0_6px_#fff]" />}
                  </span>
                  <div className="min-w-0 flex-1">
                    {isRecommended && (
                      <div className="text-[10.5px] font-bold uppercase tracking-[0.06em] text-[#38f8ff] mb-0.5">
                        ★ Рекомендация для вашего класса
                      </div>
                    )}
                    <div className="text-[15.5px] font-bold leading-snug text-white">{gt.title}</div>
                    <div className="text-[12px] text-white/75 leading-snug mt-0.5">{gt.desc}</div>
                    <div className="text-[11.5px] text-[#b9fbff] font-medium mt-1 truncate">
                      {gt.sample}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="space-y-2.5 pt-1">
          <div className="p-2.5 border border-white/25 bg-[#031221]/80 space-y-1 text-left">
            <div className="flex items-center justify-between text-[11px] uppercase tracking-[0.06em] text-[#72f8ff]">
              <span>Стартовый контракт в «Сегодня»</span>
              <span className="font-mono font-bold text-white">+30 XP</span>
            </div>
            <div className="text-[13px] font-semibold text-white truncate">
              Квест: {firstQuestPreview}
            </div>
            <div className="text-[11.5px] text-white/75">
              После создания миссии сразу откроется первый шаг с таймером и XP.
            </div>
          </div>

          <SystemButton
            label={isOnboardingFlow ? 'НАСТРОИТЬ МИССИЮ' : 'ПРОДОЛЖИТЬ'}
            highlighted
            onClick={() => {
              playSystemSound('tab_switch', user.soundEnabled, user.hapticsEnabled);
              setSelectedGoalId?.(null);
              navigateState(currentTargetState);
            }}
          />
        </div>
      </div>
    );
  }

  if (stateId === 6) {
    const presets = getRoleAwarePresets(user.roles, user.customRoleText);
    const editingScheduled = selectedGoalId
      ? user.goals.find((g) => g.id === selectedGoalId && g.type === 'scheduled_action')
      : null;

    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5">
        <div className="space-y-2.5">
          <SystemHeaderBox
            title={editingScheduled ? 'ИЗМЕНИТЬ МИССИЮ' : 'НАСТРОЙКА МИССИИ'}
            onBack={() => navigateState(editingScheduled ? 16 : 5)}
          />

          {!editingScheduled && (
            <div className="space-y-1.5">
              <div className="text-[12px] text-[#9deeff]">Быстрый выбор под ваш класс:</div>
              <div className="flex flex-wrap gap-1.5">
                {presets.scheduledList.map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setGoalTitle(preset)}
                    className={`px-2 py-1 border text-[11px] font-semibold transition-colors cursor-pointer ${
                      goalTitle === preset
                        ? 'border-[#38f8ff] bg-[#062d4a] text-white'
                        : 'border-white/35 bg-black/40 text-white/80 hover:border-white'
                    }`}
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-1">
            <label className="text-[13px] text-white/85 block">Название квеста</label>
            <input
              type="text"
              value={goalTitle}
              onChange={(e) => setGoalTitle(e.target.value)}
              className="w-full px-3 py-2 rounded-[5px] border border-white/80 bg-[#031221] text-[15px] font-semibold text-white focus:outline-none focus:border-[#00e5ff]"
            />
          </div>

          <div className="space-y-1 border-t border-white/25 pt-2">
            <span className="text-[13px] text-white/85 block">Длительность одной сессии</span>
            <div className="grid grid-cols-4 gap-1.5">
              {[15, 30, 45, 60].map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setGoalMinutes(m)}
                  className={`py-1.5 rounded-[5px] border text-[13px] font-bold cursor-pointer ${
                    goalMinutes === m
                      ? 'border-[#38f8ff] bg-gradient-to-b from-[#0088ff]/60 to-[#00d4ff]/50 shadow-[0_0_10px_rgba(0,225,255,0.45)]'
                      : 'border-white/50 bg-black/40 text-white/85'
                  }`}
                >
                  {m} мин
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 border-t border-white/25 pt-2">
            <div className="space-y-1">
              <span className="text-[13px] text-white/85 block">Цель (сессий)</span>
              <div className="grid grid-cols-3 gap-1">
                {[14, 21, 30].map((cnt) => (
                  <button
                    key={cnt}
                    type="button"
                    onClick={() => setGoalTargetSessions(cnt)}
                    className={`py-1.5 rounded-[5px] border text-[13px] font-bold cursor-pointer ${
                      goalTargetSessions === cnt
                        ? 'border-[#38f8ff] bg-[#062d4a] text-white'
                        : 'border-white/45 bg-black/40 text-white/80'
                    }`}
                  >
                    {cnt}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1">
              <span className="text-[13px] text-white/85 block">Дней в неделю</span>
              <div className="grid grid-cols-3 gap-1">
                {[3, 5, 7].map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setGoalDays(d)}
                    className={`py-1.5 rounded-[5px] border text-[13px] font-bold cursor-pointer ${
                      goalDays === d
                        ? 'border-[#38f8ff] bg-[#062d4a] text-white'
                        : 'border-white/45 bg-black/40 text-white/80'
                    }`}
                  >
                    {d}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-1 border-t border-white/25 pt-2">
            <span className="text-[13px] text-white/85 block">Предпочтительное время</span>
            <div className="relative">
              <select
                value={goalPreferredTime}
                onChange={(e) => setGoalPreferredTime(e.target.value)}
                className="w-full appearance-none pl-3 pr-9 py-2 rounded-[5px] border border-white/80 bg-[#031221] text-[15px] font-semibold text-white"
              >
                <option value="Утром">Утром</option>
                <option value="Днём">Днём</option>
                <option value="Вечером">Вечером</option>
              </select>
              <ChevronDown className="w-4 h-4 absolute right-3 top-2.5 pointer-events-none text-white/80" />
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <SystemButton
            label={editingScheduled ? 'СОХРАНИТЬ ЦЕЛЬ' : 'СОЗДАТЬ ЦЕЛЬ'}
            highlighted
            disabled={busy || !goalTitle.trim()}
            onClick={() =>
              editingScheduled
                ? apiAction(
                    '/api/goals/update',
                    {
                      goalId: editingScheduled.id,
                      title: goalTitle.trim(),
                      durationMinutes: goalMinutes,
                      targetValue: goalTargetSessions,
                      daysPerWeek: goalDays,
                      preferredTime: goalPreferredTime,
                    },
                    16
                  )
                : apiAction(
                    '/api/goals/create',
                    {
                      type: 'scheduled_action',
                      title: goalTitle.trim(),
                      targetValue: goalTargetSessions,
                      durationMinutes: goalMinutes,
                      daysPerWeek: goalDays,
                      preferredTime: goalPreferredTime,
                      isOnboarding: user.bootstrapState !== 'ready',
                    },
                    user.bootstrapState !== 'ready' ? 9 : 16
                  )
            }
          />
          {editingScheduled && (
            confirmDeleteKey === `goal_${editingScheduled.id}` ? (
              <div className="p-2 rounded-[6px] border border-[#ff4d4d] bg-[#2a0409] space-y-1.5">
                <div className="text-[12px] text-[#ffb3b3] text-center font-semibold">
                  Удалить цель навсегда? Невыполненные связанные задачи тоже уберутся.
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() =>
                      apiAction(
                        '/api/goals/delete',
                        { goalId: editingScheduled.id, mode: 'delete', deleteLinkedTasks: true },
                        16
                      )
                    }
                    className="py-1.5 rounded border border-[#ff4d4d] bg-[#7f1d1d]/80 text-[12px] font-bold text-white cursor-pointer"
                  >
                    Точно удалить
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmDeleteKey(null)}
                    className="py-1.5 rounded border border-white/40 bg-black/40 text-[12px] text-white/85 cursor-pointer"
                  >
                    Отмена
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  disabled={busy}
                  onClick={() =>
                    apiAction('/api/goals/delete', { goalId: editingScheduled.id, mode: 'archive' }, 16)
                  }
                  className="py-2 px-2 rounded-[6px] border border-white/40 bg-black/30 text-[13px] text-white/85 hover:border-white flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Archive className="w-3.5 h-3.5" />
                  <span>В архив</span>
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmDeleteKey(`goal_${editingScheduled.id}`)}
                  className="py-2 px-2 rounded-[6px] border border-[#ff4d4d]/60 bg-[#2a0509]/70 text-[13px] text-[#ffb3b3] hover:border-[#ff4d4d] flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Удалить</span>
                </button>
              </div>
            )
          )}
        </div>
      </div>
    );
  }

  if (stateId === 7) {
    const presets = getRoleAwarePresets(user.roles, user.customRoleText);
    const editingProject = selectedGoalId
      ? user.goals.find((g) => g.id === selectedGoalId && g.type === 'deadline_project')
      : null;

    return (
      <div className="flex flex-col justify-between min-h-full space-y-3">
        <div className="space-y-2.5">
          <SystemHeaderBox
            title={editingProject ? 'ИЗМЕНИТЬ ПРОЕКТ' : 'ЦЕЛЕВОЙ ПРОЕКТ'}
            onBack={() => navigateState(editingProject ? 17 : 5)}
          />

          {!editingProject && (
            <div className="space-y-1.5">
              <div className="text-[12px] text-[#9deeff]">Проекты под ваш класс:</div>
              <div className="flex flex-wrap gap-1.5">
                {presets.projectList.map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setProjTitle(preset)}
                    className={`px-2 py-1 border text-[11px] font-semibold transition-colors cursor-pointer ${
                      projTitle === preset
                        ? 'border-[#38f8ff] bg-[#062d4a] text-white'
                        : 'border-white/35 bg-black/40 text-white/80 hover:border-white'
                    }`}
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-1">
            <label className="text-[14px] text-white/85">Название проекта:</label>
            <input
              type="text"
              value={projTitle}
              onChange={(e) => setProjTitle(e.target.value)}
              className="w-full px-3 py-2.5 rounded-[5px] border border-white/80 bg-[#031221] text-[16px] font-semibold"
            />
          </div>

          <div className="space-y-1 border-t border-white/25 pt-2">
            <label className="text-[14px] text-white/85">Контрольный срок:</label>
            <div className="relative">
              <select
                value={projDeadline}
                onChange={(e) => setProjDeadline(e.target.value)}
                className="w-full appearance-none pl-3 pr-9 py-2.5 rounded-[5px] border border-white/80 bg-[#031221] text-[16px] font-semibold text-white"
              >
                <option value="Через 7 дней">Через 7 дней</option>
                <option value="Через 14 дней">Через 14 дней</option>
                <option value="Через 30 дней">Через 30 дней</option>
              </select>
              <ChevronDown className="w-5 h-5 absolute right-3 top-3 pointer-events-none" />
            </div>
          </div>

          {!editingProject && (
            <div className="space-y-1.5 border-t border-white/25 pt-2">
              <div className="flex items-center justify-between gap-2">
                <label className="text-[14px] text-white/85">Первый проверяемый шаг:</label>
                <button
                  type="button"
                  disabled={smartStepsLoading || !projTitle.trim()}
                  onClick={async () => {
                    setSmartStepsLoading(true);
                    try {
                      const res = await postApiAction('/api/goals/smart-steps', {
                        title: projTitle.trim(),
                        apply: false,
                      });
                      if (res.steps && res.steps.length > 0) {
                        setProjStep(res.steps[0]);
                        setSmartStepsPreview(res.steps);
                        playSystemSound('ui_step', user.soundEnabled, user.hapticsEnabled);
                      }
                    } finally {
                      setSmartStepsLoading(false);
                    }
                  }}
                  className="px-2 py-0.5 border border-[#38f8ff]/70 bg-[#062d4a]/85 text-[11px] font-bold text-[#9deeff] hover:border-white hover:text-white flex items-center gap-1 cursor-pointer disabled:opacity-45"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>{smartStepsLoading ? 'Подбор...' : 'Умные этапы'}</span>
                </button>
              </div>
              <textarea
                rows={2}
                value={projStep}
                onChange={(e) => setProjStep(e.target.value)}
                className="w-full px-3 py-2 rounded-[5px] border border-white/80 bg-[#031221] text-[16px] font-semibold resize-none"
              />
              {smartStepsPreview.length > 0 && (
                <div className="p-2 border border-[#38f8ff]/40 bg-[#04182b]/80 space-y-1 text-[11.5px] text-[#b9fbff]">
                  <div className="font-bold text-[#72f8ff]">План из 3 вех под проект:</div>
                  {smartStepsPreview.map((s, idx) => (
                    <div key={idx} className="leading-snug">
                      {idx + 1}. {s}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          <div className="border-t border-white/25 pt-2.5 flex items-center justify-between">
            <div>
              <div className="text-[16px] font-bold">Обязательный срок</div>
              <div className="text-[13px] text-white/80 mt-0.5">При пропуске этапа — штрафной квест</div>
            </div>
            <button
              type="button"
              onClick={() => setProjMandatory(!projMandatory)}
              aria-label="Переключить обязательный срок"
              className={`w-12 h-6 rounded-[2px] border p-0.5 transition-colors cursor-pointer ${
                projMandatory
                  ? 'border-[#38f8ff] bg-[#063254] shadow-[0_0_10px_rgba(0,225,255,0.55)]'
                  : 'border-white/45 bg-black/50'
              }`}
            >
              <span
                className={`block w-5 h-full rounded-[1px] transition-transform ${
                  projMandatory ? 'translate-x-[22px] bg-[#38f8ff]' : 'translate-x-0 bg-white/75'
                }`}
              />
            </button>
          </div>
        </div>

        <div className="space-y-2">
          <SystemButton
            label={editingProject ? 'СОХРАНИТЬ ПРОЕКТ' : 'СОЗДАТЬ ПРОЕКТ'}
            highlighted
            disabled={busy || !projTitle.trim()}
            onClick={() =>
              editingProject
                ? apiAction(
                    '/api/goals/update',
                    {
                      goalId: editingProject.id,
                      title: projTitle.trim(),
                      deadlineText: projDeadline,
                      mandatoryDeadline: projMandatory,
                    },
                    17
                  )
                : apiAction(
                    '/api/goals/create',
                    {
                      type: 'deadline_project',
                      title: projTitle.trim(),
                      deadlineText: projDeadline,
                      firstStepTitle: projStep.trim(),
                      mandatoryDeadline: projMandatory,
                      isOnboarding: user.bootstrapState !== 'ready',
                    },
                    user.bootstrapState !== 'ready' ? 9 : 16
                  )
            }
          />
          {editingProject && (
            confirmDeleteKey === `goal_${editingProject.id}` ? (
              <div className="p-2 rounded-[6px] border border-[#ff4d4d] bg-[#2a0409] space-y-1.5">
                <div className="text-[12px] text-[#ffb3b3] text-center font-semibold">
                  Удалить проект и его этапы навсегда?
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() =>
                      apiAction(
                        '/api/goals/delete',
                        { goalId: editingProject.id, mode: 'delete', deleteLinkedTasks: true },
                        16
                      )
                    }
                    className="py-1.5 rounded border border-[#ff4d4d] bg-[#7f1d1d]/80 text-[12px] font-bold text-white cursor-pointer"
                  >
                    Точно удалить
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmDeleteKey(null)}
                    className="py-1.5 rounded border border-white/40 bg-black/40 text-[12px] text-white/85 cursor-pointer"
                  >
                    Отмена
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  disabled={busy}
                  onClick={() =>
                    apiAction('/api/goals/delete', { goalId: editingProject.id, mode: 'archive' }, 16)
                  }
                  className="py-2 px-2 rounded-[6px] border border-white/40 bg-black/30 text-[13px] text-white/85 hover:border-white flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Archive className="w-3.5 h-3.5" />
                  <span>В архив</span>
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmDeleteKey(`goal_${editingProject.id}`)}
                  className="py-2 px-2 rounded-[6px] border border-[#ff4d4d]/60 bg-[#2a0509]/70 text-[13px] text-[#ffb3b3] hover:border-[#ff4d4d] flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Удалить</span>
                </button>
              </div>
            )
          )}
        </div>
      </div>
    );
  }

  if (stateId === 8) {
    const presets = getRoleAwarePresets(user.roles, user.customRoleText);
    const editingSavings = selectedGoalId
      ? user.goals.find((g) => g.id === selectedGoalId && g.type === 'savings')
      : null;

    return (
      <div className="flex flex-col justify-between min-h-full space-y-3">
        <div className="space-y-2.5">
          <SystemHeaderBox
            title={editingSavings ? 'ОБНОВИТЬ РЕЗЕРВ' : 'ФИНАНСОВЫЙ РЕЗЕРВ'}
            onBack={() => navigateState(editingSavings ? 16 : 5)}
          />

          {!editingSavings && (
            <div className="space-y-1.5">
              <div className="text-[12px] text-[#9deeff]">Резерв под ваш класс:</div>
              <div className="flex flex-wrap gap-1.5">
                {presets.savingsList.map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setSavTitle(preset)}
                    className={`px-2 py-1 border text-[11px] font-semibold transition-colors cursor-pointer ${
                      savTitle === preset
                        ? 'border-[#38f8ff] bg-[#062d4a] text-white'
                        : 'border-white/35 bg-black/40 text-white/80 hover:border-white'
                    }`}
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-1">
            <label className="text-[14px] text-white/85">Название цели:</label>
            <input
              type="text"
              value={savTitle}
              readOnly={Boolean(editingSavings)}
              onChange={(e) => setSavTitle(e.target.value)}
              className="w-full px-3 py-2 rounded-[5px] border border-white/80 bg-[#031221] text-[16px] font-semibold read-only:opacity-75"
            />
          </div>

          <div className="space-y-1 border-t border-white/25 pt-2">
            <label className="text-[14px] text-white/85">Целевая сумма (₽):</label>
            <input
              type="number"
              value={savTarget}
              readOnly={Boolean(editingSavings)}
              onChange={(e) => setSavTarget(e.target.value)}
              className="w-full px-3 py-2 rounded-[5px] border border-white/80 bg-[#031221] text-[17px] font-bold font-tabular read-only:opacity-75"
            />
          </div>

          <div className="space-y-1 border-t border-white/25 pt-2">
            <label className="text-[14px] text-white/85">Уже отложено (₽):</label>
            <input
              type="number"
              value={savCurrent}
              onChange={(e) => setSavCurrent(e.target.value)}
              className="w-full px-3 py-2 rounded-[5px] border border-white/80 bg-[#031221] text-[17px] font-bold font-tabular"
            />
            <div className="flex items-start gap-2 text-[12px] text-white/80 pt-0.5">
              <Info className="w-4 h-4 shrink-0 mt-0.5 text-[#38e8ff]" />
              <span>Отложенное учитывается в общем остатке на счетах</span>
            </div>
          </div>

          {!editingSavings && (
            <div className="space-y-1 border-t border-white/25 pt-2">
              <label className="text-[14px] text-white/85">Ориентир по сроку:</label>
              <div className="relative">
                <select
                  value={savDeadline}
                  onChange={(e) => setSavDeadline(e.target.value)}
                  className="w-full appearance-none pl-3 pr-9 py-2 rounded-[5px] border border-white/80 bg-[#031221] text-[15px] font-semibold text-white"
                >
                  <option value="Без жёсткой даты">Без жёсткой даты</option>
                  <option value="За 1 месяц">За 1 месяц</option>
                  <option value="За 3 месяца">За 3 месяца</option>
                  <option value="За 6 месяцев">За 6 месяцев</option>
                  <option value="За 1 год">За 1 год</option>
                </select>
                <ChevronDown className="w-4 h-4 absolute right-3 top-2.5 pointer-events-none text-white/80" />
              </div>
            </div>
          )}
        </div>

        <div className="space-y-2">
          <SystemButton
            label={editingSavings ? 'ОБНОВИТЬ СУММУ' : 'СОЗДАТЬ РЕЗЕРВ'}
            highlighted
            disabled={busy || !savTitle.trim()}
            onClick={() =>
              editingSavings
                ? apiAction(
                    '/api/goals/update-savings',
                    {
                      goalId: editingSavings.id,
                      newAllocatedRub: Number(savCurrent) || 0,
                    },
                    16
                  )
                : apiAction(
                    '/api/goals/create',
                    {
                      type: 'savings',
                      title: savTitle.trim(),
                      targetSavingsRub: Number(savTarget) || 100000,
                      alreadySavedRub: Number(savCurrent) || 0,
                      deadlineText: savDeadline,
                      isOnboarding: user.bootstrapState !== 'ready',
                    },
                    user.bootstrapState !== 'ready' ? 9 : 16
                  )
            }
          />
          {editingSavings && (
            confirmDeleteKey === `goal_${editingSavings.id}` ? (
              <div className="p-2 rounded-[6px] border border-[#ff4d4d] bg-[#2a0409] space-y-1.5">
                <div className="text-[12px] text-[#ffb3b3] text-center font-semibold">
                  Удалить накопительную цель? Деньги на счетах останутся нетронутыми.
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() =>
                      apiAction(
                        '/api/goals/delete',
                        { goalId: editingSavings.id, mode: 'delete' },
                        16
                      )
                    }
                    className="py-1.5 rounded border border-[#ff4d4d] bg-[#7f1d1d]/80 text-[12px] font-bold text-white cursor-pointer"
                  >
                    Точно удалить
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmDeleteKey(null)}
                    className="py-1.5 rounded border border-white/40 bg-black/40 text-[12px] text-white/85 cursor-pointer"
                  >
                    Отмена
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  disabled={busy}
                  onClick={() =>
                    apiAction('/api/goals/delete', { goalId: editingSavings.id, mode: 'archive' }, 16)
                  }
                  className="py-2 px-2 rounded-[6px] border border-white/40 bg-black/30 text-[13px] text-white/85 hover:border-white flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Archive className="w-3.5 h-3.5" />
                  <span>В архив</span>
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmDeleteKey(`goal_${editingSavings.id}`)}
                  className="py-2 px-2 rounded-[6px] border border-[#ff4d4d]/60 bg-[#2a0509]/70 text-[13px] text-[#ffb3b3] hover:border-[#ff4d4d] flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Удалить</span>
                </button>
              </div>
            )
          )}
        </div>
      </div>
    );
  }

  if (stateId === 9) {
    const firstTask = user.tasks[0] || {
      id: 'tsk_first',
      title: 'Английский · 15 минут',
      durationMinutes: 15,
      xpReward: 30,
      goalId: undefined as string | undefined,
    };
    const firstGoal =
      (firstTask.goalId && user.goals.find((g) => g.id === firstTask.goalId)) ||
      user.goals[user.goals.length - 1] || {
        title: 'Первая цель',
        currentValue: 0,
        targetValue: 20,
      };

    return (
      <div className="flex flex-col justify-between min-h-full space-y-3">
        <div className="space-y-3">
          <SystemHeaderBox title="ПЕРВОЕ ЗАДАНИЕ" />

          <div className="text-center space-y-1.5 py-1">
            <div className="text-[18px] font-bold">
              {user.playerCallsign?.trim() || 'Игрок'} · Уровень{' '}
              <RollingNumber value={user.level} metricKey="player_level" />
            </div>
            <div className="text-[15px] text-white/90 font-tabular">
              <RollingNumber value={user.currentXp} metricKey="player_xp" useGrouping /> /{' '}
              <RollingNumber value={user.nextLevelXp} useGrouping /> XP
            </div>
            <SystemProgressBar value={user.currentXp} max={user.nextLevelXp} />
          </div>

          <div className="border-t border-white/30 pt-3 flex items-center gap-3">
            <BookOpen className="w-8 h-8 text-white shrink-0" />
            <div className="border-l border-white/40 pl-3">
              <div className="text-[18px] font-bold leading-snug">{firstTask.title}</div>
            </div>
          </div>

          <div className="grid grid-cols-5 gap-2.5 pt-1">
            <div className="col-span-3 py-2.5 px-3 rounded-[6px] border border-white/80 bg-black/40 flex items-center justify-center gap-2 text-[22px] font-bold font-tabular">
              <Clock className="w-5 h-5 text-white/90" />
              <span>{firstTask.durationMinutes || 15}:00</span>
            </div>
            <div className="col-span-2 py-2.5 px-2 rounded-[6px] border border-[#38f8ff] bg-[#063254] shadow-[0_0_14px_rgba(0,225,255,0.5)] flex items-center justify-center text-[18px] font-bold font-tabular">
              <RollingNumber value={firstTask.xpReward || 30} prefix="+" suffix=" XP" />
            </div>
          </div>

          <SystemButton
            label="НАЧАТЬ"
            highlighted
            onClick={async () => {
              await apiAction('/api/tasks/start-focus', { taskId: firstTask.id });
              await apiAction('/api/onboarding/complete', {}, 59);
            }}
          />

          <div className="border-t border-white/30 pt-3 space-y-2">
            <div className="flex items-center gap-2.5">
              <Target className="w-6 h-6 text-[#38e8ff] shrink-0" />
              <div>
                <div className="text-[14px] text-white/80">Связанная цель:</div>
                <div className="text-[15px] font-semibold">{firstGoal.title}</div>
              </div>
            </div>
            <div className="text-[14px] font-tabular">
              <RollingNumber value={firstGoal.currentValue} /> / {firstGoal.targetValue}
            </div>
            <SystemProgressBar value={firstGoal.currentValue} max={firstGoal.targetValue} />
          </div>
        </div>

        <button
          type="button"
          onClick={() => apiAction('/api/onboarding/complete', {}, 11)}
          className="w-full py-2.5 px-3 rounded-[6px] border border-white/50 bg-black/40 flex items-center justify-center gap-2.5 text-[15px] font-semibold hover:border-white cursor-pointer"
        >
          <span>Перейти к задачам дня</span>
        </button>
      </div>
    );
  }

  // --- ВОЗВРАЩЕНИЕ / СВОДКА СИСТЕМЫ (State 10) ---
  if (stateId === 10) {
    return (
      <DashboardOverview
        user={user}
        busy={busy}
        navigateState={navigateState}
        apiAction={apiAction}
        setSelectedGoalId={setSelectedGoalId}
        setSelectedTaskId={setSelectedTaskId}
        openPlusModal={openPlusModal}
        onOpenShareCard={onOpenShareCard}
      />
    );
  }

  if (stateId === 11 || stateId === 12) {
    const totalBalance = user.accounts
      .filter((a) => a.status === 'active')
      .reduce((sum, a) => sum + a.balanceRub, 0);

    const priorityTask = user.tasks.find((t) => !t.completed) || user.tasks[0];

    if (user.tasks.length === 0) {
      return (
        <div className="flex flex-col items-center justify-between min-h-full text-center space-y-4">
          <SystemHeaderBox title="СЕГОДНЯ" />

          <div className="my-auto space-y-4 px-2">
            <BookOpen className="w-16 h-16 mx-auto text-white drop-shadow-[0_0_12px_rgba(0,225,255,0.5)] stroke-[1.5]" />
            <h2 className="text-[22px] font-bold leading-snug">
              На сегодня
              <br />
              заданий нет.
            </h2>
            <p className="text-[15px] text-white/85 leading-snug">
              Добавьте задание вручную
              <br />
              или выберите из цели.
            </p>
          </div>

          <div className="w-full space-y-3">
            <SystemButton
              label="ДОБАВИТЬ ЗАДАНИЕ"
              highlighted
              onClick={() => {
                setSelectedTaskId?.(null);
                setSelectedGoalId?.(null);
                navigateState(60);
              }}
            />
            <button
              type="button"
              onClick={() => navigateState(16)}
              className="text-[15px] underline underline-offset-4 text-white/90 hover:text-white cursor-pointer"
            >
              Выбрать из цели
            </button>
          </div>
        </div>
      );
    }

    const tasksDoneCount = user.tasks.filter((t) => t.completed).length;
    const tasksTotalCount = user.tasks.length;
    const activeHudSkin = user.subscription.active ? user.hudTheme || 'blue' : 'blue';

    return (
      <div className="flex flex-col justify-between min-h-full space-y-3 pb-2">
        <div className="space-y-2.5">
          <SystemHeaderBox title="СЕГОДНЯ" />

          {/* Level + XP Bar paired with Recharts Daily Tasks Donut */}
          <div className="p-2.5 border border-white/30 bg-[#031221]/80 flex items-center justify-between gap-3">
            <div className="flex-1 min-w-0 space-y-1.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[16px] font-bold truncate">
                  Уровень <RollingNumber value={user.level} metricKey="player_level" />
                </span>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-[11px] font-bold text-amber-300 flex items-center gap-0.5 font-tabular">
                    <Flame className="w-3.5 h-3.5 text-amber-400" />
                    <span>{user.streakDays || 0}д</span>
                  </span>
                  <span className="text-[11px] font-bold uppercase tracking-[0.06em] text-[#72f8ff]">
                    {getHunterRankInfo(user.level).rank}
                  </span>
                </div>
              </div>
              <div className="text-[13px] font-tabular text-white/90">
                <RollingNumber value={user.currentXp} metricKey="player_xp" useGrouping /> /{' '}
                <RollingNumber value={user.nextLevelXp} useGrouping /> XP
              </div>
              <SystemProgressBar value={user.currentXp} max={user.nextLevelXp} />
            </div>

            <div className="flex flex-col items-center pl-2 border-l border-white/20">
              <TodayProgressChart
                doneCount={tasksDoneCount}
                totalCount={tasksTotalCount}
                monarchTheme={activeHudSkin === 'monarch'}
                hudTheme={activeHudSkin}
              />
              <span className="text-[10px] uppercase tracking-[0.06em] text-white/75 -mt-1">
                Прогресс дня
              </span>
            </div>
          </div>

          {/* Active Penalty Quest Banner inside Today if assigned */}
          {user.penaltyQuest.active && (
            <div className="p-2.5 rounded-[6px] border border-[#ff4d4d] bg-[#2b0408]/90 shadow-[0_0_14px_rgba(255,40,40,0.35)] flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-full border-2 border-white flex items-center justify-center font-bold text-sm shrink-0">
                  !
                </div>
                <div className="text-left">
                  <div className="text-[14px] font-bold text-white">Штрафной квест · Карантин</div>
                  <div className="text-[11.5px] text-white/85 leading-snug">
                    Задачи и XP заморожены ({user.penaltyQuest.reasonTitle}). Финансы открыты.
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => navigateState(40)}
                className="min-h-[40px] px-3 py-1.5 rounded border border-white/80 bg-[#4a060d] text-[12px] font-bold text-white hover:bg-[#660812] cursor-pointer shrink-0"
              >
                Открыть
              </button>
            </div>
          )}

          {/* Next Priority Action (shown cleanly when there is an incomplete task) */}
          {priorityTask && !priorityTask.completed && (
            <div className="space-y-2">
              {user.tasks.length > 1 && (
                <div className="flex items-center gap-2.5 px-2 py-1.5 border border-[#38f8ff]/40 bg-[#04182b]/75">
                  <BookOpen className="w-5 h-5 shrink-0 text-[#38f8ff]" />
                  <div className="min-w-0">
                    <div className="text-[10px] uppercase tracking-[0.08em] text-[#9deeff]">
                      Следующее действие
                    </div>
                    <div className="text-[14px] font-bold leading-snug truncate">
                      {priorityTask.title}
                    </div>
                  </div>
                </div>
              )}
              <SystemButton
                label={
                  isQuarantined
                    ? 'СНЯТЬ ШТРАФНОЙ КАРАНТИН'
                    : user.tasks.length === 1
                    ? `НАЧАТЬ ФОКУС · ${priorityTask.durationMinutes || 15} МИН`
                    : 'НАЧАТЬ ФОКУС'
                }
                palette={isQuarantined ? 'red' : 'blue'}
                highlighted
                onClick={() =>
                  isQuarantined
                    ? navigateState(40)
                    : apiAction('/api/tasks/start-focus', { taskId: priorityTask.id }, 59)
                }
              />
            </div>
          )}

          {/* Daily Quest Chest */}
          {(() => {
            const doneActions =
              tasksDoneCount +
              user.habits.filter((h) => h.status === 'active' && h.completedToday).length;
            const todayKey = getTzIsoDaysAgo(0, user.timezone);
            const alreadyClaimed = user.lastDailyClaimDate === todayKey;
            const now = new Date();
            const midnight = new Date(now);
            midnight.setHours(24, 0, 0, 0);
            const diffMin = Math.max(0, Math.floor((midnight.getTime() - now.getTime()) / 60000));
            const remHrs = Math.floor(diffMin / 60);
            const remMins = diffMin % 60;
            const canClaim = !alreadyClaimed && doneActions >= 2 && !isQuarantined;
            return (
              <div className="relative p-2.5 border border-[#38e8ff]/50 bg-[#04182b]/85 space-y-1.5 overflow-visible">
                <ElectricRowArc burstKey={chestSparkKey} />
                <div className="flex items-center justify-between text-[12px]">
                  <span className="font-bold text-[#72f8ff] uppercase tracking-wide flex items-center gap-1.5">
                    <Gift className="w-3.5 h-3.5" />
                    Ежедневный квест
                  </span>
                  <span className="font-tabular text-white/75">
                    Сброс через {remHrs}ч {String(remMins).padStart(2, '0')}м
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2 text-[13px]">
                  <span className="text-white/90 font-tabular">
                    Действий: <strong>{Math.min(doneActions, 2)} / 2</strong>
                  </span>
                  {alreadyClaimed ? (
                    <span className="text-[12px] font-bold text-[#72f8ff]">
                      {user.lastChestBonusText || 'Сундук открыт ✓'}
                    </span>
                  ) : (
                      <button
                        type="button"
                        disabled={(!canClaim && !isQuarantined) || busy}
                        onClick={() => {
                          if (isQuarantined) {
                            navigateState(40);
                            return;
                          }
                          setChestSparkKey((k) => k + 1);
                          apiAction('/api/daily-quest/claim', {});
                        }}
                        className={`relative min-h-[38px] px-3 py-1.5 border text-[12px] font-bold flex items-center gap-1.5 transition-colors ${
                          canClaim
                            ? 'border-[#38f8ff] bg-[#063254] text-white shadow-[0_0_10px_rgba(0,225,255,0.45)] hover:bg-[#084573] cursor-pointer'
                            : isQuarantined
                            ? 'border-[#ff4d4d]/80 bg-[#2b0408]/80 text-[#ffb3b3] hover:border-white cursor-pointer'
                            : 'border-white/30 bg-black/40 text-white/55 cursor-not-allowed'
                        }`}
                      >
                        <ElectricCheckboxBurst
                          burstKey={chestSparkKey}
                          tagText={user.subscription.active ? '+150 XP' : '+100 XP'}
                        />
                        {(!canClaim || isQuarantined) && <Lock className="w-3 h-3" />}
                        <span>
                          {isQuarantined
                            ? 'Заморожен'
                            : user.subscription.active
                            ? 'Сундук +150 XP'
                            : 'Сундук +100 XP'}
                        </span>
                      </button>
                  )}
                </div>
              </div>
            );
          })()}

          {/* Daily Quest Progress & Tasks List with inline + Добавить button */}
          <div className="border-t border-white/30 pt-2">
            <div className="py-1.5 px-2.5 bg-white/5 flex items-center justify-between text-[13px] font-bold tracking-[0.05em] uppercase border-b border-white/30">
              <span>ЗАДАНИЯ ДНЯ</span>
              <div className="flex items-center gap-2.5">
                <span className="font-tabular text-[#72f8ff]">
                  <RollingNumber value={tasksDoneCount} metricKey="today_tasks_done" /> /{' '}
                  <RollingNumber value={tasksTotalCount} metricKey="today_tasks_total" />
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedTaskId?.(null);
                    navigateState(60);
                  }}
                  className="min-h-[40px] px-3 py-1.5 border border-[#38f8ff]/80 bg-[#062d4a]/80 text-[12px] font-bold text-[#9deeff] hover:border-white hover:text-white cursor-pointer flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Задача</span>
                </button>
              </div>
            </div>
            <div className="divide-y divide-white/25">
              {user.tasks.map((t) => (
                <SystemCheckbox
                  key={t.id}
                  checked={t.completed}
                  label={t.title}
                  electricTag={`+${t.xpReward || 25} XP`}
                  sublabel={
                    isQuarantined
                      ? 'Заморожено штрафным квестом'
                      : t.recurrence && t.recurrence !== 'none'
                      ? `↻ Автоповтор · ${t.dueDateText}`
                      : t.dueDateText !== 'Сегодня'
                      ? `Срок: ${t.dueDateText}`
                      : undefined
                  }
                  onChange={() =>
                    isQuarantined
                      ? navigateState(40)
                      : apiAction('/api/tasks/toggle', { taskId: t.id }, !t.completed ? 27 : undefined)
                  }
                  rightSlot={
                    <div className="flex items-center gap-1">
                      {isQuarantined && (
                        <Lock className="w-3.5 h-3.5 text-[#ff6b6b] shrink-0" />
                      )}
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedTaskId?.(t.id);
                          navigateState(60);
                        }}
                        className="p-1.5 text-white/70 hover:text-[#38f8ff] cursor-pointer"
                        aria-label="Изменить задание"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                    </div>
                  }
                />
              ))}
            </div>
          </div>
        </div>

        {/* Compact Finance Snapshot + Inline 1-Line Quick Finance Input */}
        <div className="border-t border-white/30 pt-2.5 pb-2 space-y-2">
          <div className="flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={() => navigateState(19)}
              className="text-left cursor-pointer group"
            >
              <div className="text-[11px] uppercase tracking-[0.06em] text-white/75 group-hover:text-[#9deeff]">
                На счетах
              </div>
              <div className="text-[19px] font-extrabold font-tabular leading-tight">
                <RollingNumber
                  value={totalBalance}
                  metricKey="finance_total_balance"
                  useGrouping
                  suffix=" ₽"
                />
              </div>
            </button>
            <button
              type="button"
              onClick={() => navigateState(19)}
              className="px-2.5 py-1.5 border border-white/40 bg-[#04182b] text-[12px] font-semibold text-[#9deeff] hover:border-[#38f8ff] hover:text-white cursor-pointer"
            >
              Все финансы →
            </button>
          </div>
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              const text = quickFinanceInput.trim();
              if (!text || busy) return;
              const acc = user.accounts.find((a) => a.status === 'active') || user.accounts[0];
              const parsed = parseNaturalFinanceInput(
                text,
                user.accounts,
                acc?.id || 'acc_card',
                acc?.name || 'Карта'
              ).filter((item) => item.amountRub && item.amountRub > 0);
              if (parsed.length === 0) {
                navigateState(20);
                return;
              }
              await apiAction('/api/finance/commit-batch', {
                idempotencyKey: `qf_${Date.now()}`,
                items: parsed,
              });
              setQuickFinanceInput('');
            }}
            className="flex items-center gap-1.5"
          >
            <input
              type="text"
              value={quickFinanceInput}
              onChange={(e) => setQuickFinanceInput(e.target.value)}
              placeholder="Быстрая запись: Кофе 200, такси 450"
              className="flex-1 min-w-0 px-2.5 py-1.5 rounded-[4px] border border-white/45 bg-[#031221] text-[13px] text-white placeholder:text-white/45 focus:outline-none focus:border-[#38f8ff]"
            />
            <button
              type="submit"
              disabled={busy || !quickFinanceInput.trim()}
              aria-label="Записать расход или доход"
              className="min-h-[34px] px-2.5 border border-[#38f8ff]/80 bg-[#063254] text-[12px] font-bold text-white hover:bg-[#084573] flex items-center gap-1 cursor-pointer disabled:opacity-45 shrink-0"
            >
              <Send className="w-3.5 h-3.5" />
              <span>ОК</span>
            </button>
          </form>
        </div>
      </div>
    );
  }

  // --- ПРИВЫЧКИ (States 13, 14, 15) ---
  if (stateId === 13) {
    const activeHabits = user.habits.filter((h) => h.status === 'active');
    const completedCount = activeHabits.filter((h) => h.completedToday).length;

    return (
      <div className="flex flex-col justify-between min-h-full space-y-3 pb-2">
        <div className="space-y-2.5">
          <SystemHeaderBox title="ПРИВЫЧКИ" />

          {isQuarantined && (
            <button
              type="button"
              onClick={() => navigateState(40)}
              className="w-full p-2 border border-[#ff4d4d] bg-[#2e050a]/90 flex items-center justify-between gap-2 text-left cursor-pointer hover:border-white"
            >
              <span className="flex items-center gap-2 text-[12px] text-white">
                <Lock className="w-4 h-4 text-[#ff6b6b] shrink-0" />
                <span>Штрафной карантин: отметки привычек заморожены</span>
              </span>
              <span className="text-[11px] font-bold text-[#ffb3b3] underline shrink-0">Снять</span>
            </button>
          )}

          <div className="text-center space-y-1.5 py-1">
            <div className="text-[18px] font-bold">Сегодня</div>
            <div className="text-[15px] font-tabular">
              <RollingNumber value={completedCount} metricKey="habits_done_today" /> /{' '}
              <RollingNumber value={activeHabits.length} metricKey="habits_total_today" /> выполнено
            </div>
            <SystemProgressBar value={completedCount} max={Math.max(1, activeHabits.length)} />
          </div>

          <div className="divide-y divide-white/25 border-t border-white/30">
            {activeHabits.length === 0 ? (
              <div className="py-5 text-center text-[14px] text-white/75">
                Активных привычек пока нет. Добавьте первую регулярную привычку.
              </div>
            ) : (
              activeHabits.map((h) => (
                <SystemCheckbox
                  key={h.id}
                  checked={h.completedToday}
                  label={h.title}
                  electricTag="+25 XP"
                  sublabel={
                    isQuarantined
                      ? 'Заморожено штрафным квестом'
                      : h.completedToday
                      ? `${h.durationMinutes} минут`
                      : `${h.currentMinutesToday} / ${h.durationMinutes} минут`
                  }
                  onChange={() =>
                    isQuarantined
                      ? navigateState(40)
                      : apiAction('/api/habits/progress', { habitId: h.id })
                  }
                  rightSlot={
                    <div className="flex items-center gap-1.5">
                      {!h.completedToday && (
                        <button
                          type="button"
                          onClick={() => {
                            if (isQuarantined) {
                              navigateState(40);
                              return;
                            }
                            setHabitSparkKey((prev) => ({
                              ...prev,
                              [h.id]: (prev[h.id] || 0) + 1,
                            }));
                            apiAction('/api/habits/progress', { habitId: h.id, addMinutes: 5 });
                          }}
                          className={`relative min-h-[40px] px-2.5 py-1.5 rounded-[4px] border text-[12px] font-bold cursor-pointer overflow-visible ${
                            isQuarantined
                              ? 'border-[#ff4d4d]/60 bg-[#2b0408]/60 text-[#ffb3b3]'
                              : 'border-white/80 bg-black/50 hover:border-[#00e5ff]'
                          }`}
                        >
                          <ElectricCheckboxBurst
                            burstKey={habitSparkKey[h.id] || 0}
                            tagText="+5 мин"
                          />
                          {isQuarantined ? '🔒' : '+5 мин'}
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedHabitId?.(h.id);
                          setHabitName(h.title);
                          setHabitDuration(`${h.durationMinutes} минут`);
                          setHabitDays(h.daysOfWeek);
                          setHabitDeadline(h.deadlineTime || '23:00');
                          setHabitMandatory(h.mandatory);
                          navigateState(14);
                        }}
                        aria-label="Редактировать привычку"
                        className="w-10 h-10 rounded-[4px] border border-white/35 bg-black/40 text-white/80 hover:text-[#38e8ff] hover:border-[#38e8ff] flex items-center justify-center cursor-pointer"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedHabitId?.(h.id);
                          setHabitName(h.title);
                          setHabitDuration(`${h.durationMinutes} минут`);
                          setHabitDays(h.daysOfWeek);
                          setHabitDeadline(h.deadlineTime || '23:00');
                          setHabitMandatory(h.mandatory);
                          navigateState(15);
                        }}
                        className="min-h-[40px] px-2.5 py-1.5 rounded-[4px] border border-white/35 bg-black/40 text-[12px] text-white/90 hover:border-white cursor-pointer"
                      >
                        История
                      </button>
                    </div>
                  }
                />
              ))
            )}
          </div>

          <div className="text-center text-[13.5px] text-white/85 pt-1 font-tabular flex items-center justify-center gap-1.5">
            <span>
              Активных привычек: {activeHabits.length} / {user.subscription.active ? '∞' : '3'}
            </span>
            {!user.subscription.active && (
              <button
                type="button"
                onClick={() => openPlusModal?.('habits')}
                className="text-[#38f8ff] underline underline-offset-2 font-bold cursor-pointer hover:text-white"
              >
                (∞ в Система+)
              </button>
            )}
          </div>

          <SystemButton
            label="ДОБАВИТЬ ПРИВЫЧКУ"
            onClick={() => {
              if (!user.subscription.active && activeHabits.length >= 3) {
                if (openPlusModal) {
                  openPlusModal('habits');
                } else {
                  setLimitReason?.('habits');
                  navigateState(46);
                }
              } else {
                setSelectedHabitId?.(null);
                setHabitName('');
                setHabitDuration('15 минут');
                setHabitDays(['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ']);
                setHabitDeadline('23:00');
                setHabitMandatory(true);
                navigateState(14);
              }
            }}
          />

          {/* Monthly Habits Grid Calendar (completed / missed / penalty) */}
          <HabitsCalendarGrid
            habits={user.habits}
            penaltyQuest={user.penaltyQuest}
            onOpenPenalty={() => navigateState(40)}
            onOpenHabitHistory={(habitId) => {
              const target = user.habits.find((x) => x.id === habitId);
              if (target) {
                setSelectedHabitId?.(target.id);
                setHabitName(target.title);
                setHabitDuration(`${target.durationMinutes} минут`);
                setHabitDays(target.daysOfWeek);
                setHabitDeadline(target.deadlineTime || '23:00');
                setHabitMandatory(target.mandatory);
              }
              navigateState(15);
            }}
          />

          {activeHabits.length === 0 && (
            <div className="pt-2 space-y-1.5">
              <div className="text-[11px] uppercase tracking-[0.06em] text-center text-[#9deeff]">
                Быстрый старт в 1 нажатие
              </div>
              <div className="grid grid-cols-1 gap-1.5">
                {[
                  { title: 'Чтение', durationMinutes: 15 },
                  { title: 'Тренировка', durationMinutes: 30 },
                  { title: 'Английский', durationMinutes: 15 },
                ].map((preset) => (
                  <button
                    key={preset.title}
                    type="button"
                    disabled={busy}
                    onClick={() =>
                      apiAction('/api/habits/create', {
                        title: preset.title,
                        durationMinutes: preset.durationMinutes,
                        daysOfWeek: ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ'],
                        deadlineTime: '23:00',
                        mandatory: true,
                      })
                    }
                    className="w-full py-2 px-3 border border-white/40 bg-[#031221]/85 hover:border-[#38f8ff] flex items-center justify-between text-[13.5px] font-semibold cursor-pointer"
                  >
                    <span>
                      {preset.title} · {preset.durationMinutes} мин
                    </span>
                    <span className="text-[#38f8ff] text-[12px] font-bold">+ Добавить</span>
                  </button>
                ))}
              </div>
            </div>
          )}
          {user.habits.some((h) => h.status === 'archived') && (
            <div className="pt-1 border-t border-white/25 space-y-1.5">
              <button
                type="button"
                onClick={() => setShowArchivedHabits((v) => !v)}
                className="w-full py-1.5 px-2 text-[12px] text-white/75 hover:text-white flex items-center justify-between cursor-pointer"
              >
                <span className="flex items-center gap-1.5">
                  <Archive className="w-3.5 h-3.5 text-[#38e8ff]" />
                  <span>
                    Архив привычек ({user.habits.filter((h) => h.status === 'archived').length})
                  </span>
                </span>
                <ChevronDown
                  className={`w-4 h-4 transition-transform ${showArchivedHabits ? 'rotate-180' : ''}`}
                />
              </button>
              {showArchivedHabits && (
                <div className="space-y-1.5">
                  {user.habits
                    .filter((h) => h.status === 'archived')
                    .map((ah) => (
                      <div
                        key={ah.id}
                        className="p-2 rounded border border-white/30 bg-black/45 flex items-center justify-between gap-2 text-[12.5px]"
                      >
                        <span className="truncate text-white/80">{ah.title}</span>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => apiAction('/api/habits/save', { id: ah.id, restore: true })}
                            className="px-2 py-1 rounded border border-[#38f8ff]/60 bg-[#062d4a]/70 text-[#9deeff] hover:border-white cursor-pointer flex items-center gap-1"
                          >
                            <RotateCcw className="w-3 h-3" />
                            <span>Вернуть</span>
                          </button>
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => apiAction('/api/habits/save', { id: ah.id, deleteHabit: true })}
                            className="p-1.5 rounded border border-[#ff4d4d]/50 bg-[#2a0509] text-[#ffb3b3] hover:border-[#ff4d4d] cursor-pointer"
                            aria-label="Удалить привычку"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </div>
          )}
        </div>

        {activeHabits.length > 0 && (
          <button
            type="button"
            onClick={() => {
              const first = activeHabits[0];
              if (first) {
                setSelectedHabitId?.(first.id);
                setHabitName(first.title);
                setHabitDuration(`${first.durationMinutes} минут`);
                setHabitDays(first.daysOfWeek);
                setHabitDeadline(first.deadlineTime || '23:00');
                setHabitMandatory(first.mandatory);
              } else {
                setSelectedHabitId?.(null);
                setHabitName('');
              }
              navigateState(14);
            }}
            className="w-full py-2 px-3 rounded-[6px] border border-white/40 bg-black/30 flex items-center justify-between text-[14px] text-white/85 hover:border-white cursor-pointer"
          >
            <span>Настроить расписание привычки</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        )}
      </div>
    );
  }

  if (stateId === 14) {
    const allDays = ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ', 'ВС'];
    const toggleDay = (d: string) => {
      setHabitDays((prev) => (prev.includes(d) ? prev.filter((x) => x !== d) : [...prev, d]));
    };

    const existingHabit = selectedHabitId
      ? user.habits.find((h) => h.id === selectedHabitId)
      : undefined;

    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5">
        <div className="space-y-2.5">
          <SystemHeaderBox
            title={existingHabit ? 'НАСТРОЙКА ПРИВЫЧКИ' : 'НОВАЯ ПРИВЫЧКА'}
            onBack={() => navigateState(13)}
          />

          <div className="space-y-1">
            <label className="text-[13px] text-white/85">Название привычки</label>
            <input
              type="text"
              value={habitName}
              placeholder="Например, Чтение"
              onChange={(e) => setHabitName(e.target.value)}
              className="w-full px-3 py-2 rounded-[6px] border border-white/80 bg-[#031221] text-[16px] font-semibold"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[13px] text-white/85">Длительность</label>
            <div className="relative">
              <select
                value={habitDuration}
                onChange={(e) => setHabitDuration(e.target.value)}
                className="w-full appearance-none pl-3 pr-9 py-2 rounded-[6px] border border-white/80 bg-[#031221] text-[15px] font-semibold text-white"
              >
                <option value="15 минут">15 минут</option>
                <option value="30 минут">30 минут</option>
                <option value="45 минут">45 минут</option>
              </select>
              <ChevronDown className="w-4 h-4 absolute right-3 top-2.5 pointer-events-none" />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[13px] text-white/85">Дни недели</label>
            <div className="grid grid-cols-7 gap-1">
              {allDays.map((d) => {
                const active = habitDays.includes(d);
                return (
                  <button
                    key={d}
                    type="button"
                    onClick={() => toggleDay(d)}
                    className={`py-2 rounded-[5px] border text-[13px] font-bold cursor-pointer ${
                      active
                        ? 'border-[#38f8ff] bg-[#063456] text-white shadow-[0_0_8px_rgba(0,225,255,0.45)]'
                        : 'border-white/50 bg-black/40 text-white/75'
                    }`}
                  >
                    {d}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[13px] text-white/85">Время выполнения</label>
            <div className="relative">
              <select
                value={habitDeadline}
                onChange={(e) => setHabitDeadline(e.target.value)}
                className="w-full appearance-none pl-3 pr-9 py-2 rounded-[6px] border border-white/80 bg-[#031221] text-[15px] font-semibold text-white"
              >
                <option value="21:00">До 21:00</option>
                <option value="22:00">До 22:00</option>
                <option value="23:00">До 23:00</option>
              </select>
              <ChevronDown className="w-4 h-4 absolute right-3 top-2.5 pointer-events-none" />
            </div>
          </div>

          <div className="border-t border-white/25 pt-2 flex items-center justify-between">
            <div>
              <div className="text-[15px] font-bold">Обязательная</div>
              <div className="text-[12px] text-white/80">За пропуск — штрафной квест.</div>
            </div>
            <button
              type="button"
              onClick={() => setHabitMandatory(!habitMandatory)}
              aria-label="Переключить обязательность привычки"
              className={`w-12 h-6 rounded-[2px] border p-0.5 transition-colors cursor-pointer ${
                habitMandatory
                  ? 'border-[#38f8ff] bg-[#063254] shadow-[0_0_10px_rgba(0,225,255,0.55)]'
                  : 'border-white/45 bg-black/50'
              }`}
            >
              <span
                className={`block w-5 h-full rounded-[1px] transition-transform ${
                  habitMandatory ? 'translate-x-[22px] bg-[#38f8ff]' : 'translate-x-0 bg-white/75'
                }`}
              />
            </button>
          </div>
        </div>

        <div className="space-y-2">
          <SystemButton
            label="СОХРАНИТЬ"
            highlighted
            disabled={busy || !habitName.trim() || habitDays.length === 0}
            onClick={() =>
              apiAction(
                '/api/habits/save',
                {
                  id: existingHabit?.id,
                  title: habitName.trim(),
                  durationMinutes: parseInt(habitDuration, 10) || 15,
                  daysOfWeek: habitDays,
                  deadlineTime: habitDeadline,
                  mandatory: habitMandatory,
                },
                13
              )
            }
          />
          {existingHabit && (
            confirmDeleteKey === `habit_${existingHabit.id}` ? (
              <div className="p-2 rounded-[6px] border border-[#ff4d4d] bg-[#2a0409] space-y-1.5">
                <div className="text-[12px] text-[#ffb3b3] text-center font-semibold">
                  Удалить привычку «{existingHabit.title}» и всю её историю?
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() =>
                      apiAction('/api/habits/save', { id: existingHabit.id, deleteHabit: true }, 13)
                    }
                    className="py-1.5 rounded border border-[#ff4d4d] bg-[#7f1d1d]/80 text-[12px] font-bold text-white cursor-pointer"
                  >
                    Точно удалить
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmDeleteKey(null)}
                    className="py-1.5 rounded border border-white/40 bg-black/40 text-[12px] text-white/85 cursor-pointer"
                  >
                    Отмена
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  disabled={busy}
                  onClick={() =>
                    apiAction('/api/habits/save', { id: existingHabit.id, archive: true }, 13)
                  }
                  className="py-2 px-2 rounded-[6px] border border-white/40 bg-black/30 text-[13px] text-white/85 hover:border-white flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Archive className="w-3.5 h-3.5" />
                  <span>В архив</span>
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmDeleteKey(`habit_${existingHabit.id}`)}
                  className="py-2 px-2 rounded-[6px] border border-[#ff4d4d]/60 bg-[#2a0509]/70 text-[13px] text-[#ffb3b3] hover:border-[#ff4d4d] flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Удалить</span>
                </button>
              </div>
            )
          )}
        </div>
      </div>
    );
  }

  if (stateId === 15) {
    const targetHabit =
      (selectedHabitId && user.habits.find((h) => h.id === selectedHabitId)) ||
      user.habits.find((h) => h.status === 'active') ||
      user.habits[0];

    const historyItems = targetHabit?.history || [];
    const statusLabelMap: Record<string, string> = {
      completed: 'Выполнено',
      partial: 'Частично',
      missed: 'Пропуск',
      unscheduled: 'Не запланировано',
      pending: 'В процессе',
    };

    return (
      <div className="flex flex-col justify-between min-h-full space-y-3">
        <div className="space-y-3">
          <SystemHeaderBox title="ИСТОРИЯ ПРИВЫЧКИ" onBack={() => navigateState(13)} />

          <div className="px-3 py-2 rounded-[6px] border border-white/80 bg-[#031221] flex items-center justify-between text-[16px] font-semibold">
            <span>{targetHabit?.title || habitName || 'Привычка'}</span>
            {targetHabit && (
              <button
                type="button"
                onClick={() => {
                  setSelectedHabitId?.(targetHabit.id);
                  setHabitName(targetHabit.title);
                  setHabitDuration(`${targetHabit.durationMinutes} минут`);
                  setHabitDays(targetHabit.daysOfWeek);
                  setHabitDeadline(targetHabit.deadlineTime || '23:00');
                  setHabitMandatory(targetHabit.mandatory);
                  navigateState(14);
                }}
                className="text-[13px] text-[#38e8ff] underline cursor-pointer"
              >
                Изменить
              </button>
            )}
          </div>

          <div className="divide-y divide-white/25 border-t border-white/25">
            {historyItems.length === 0 ? (
              <div className="py-4 text-center text-[14px] text-white/75">
                История отметок по этой привычке пока пуста.
              </div>
            ) : (
              historyItems.map((item) => (
                <SystemCheckbox
                  key={`${item.dateLabel}_${item.isoDate}`}
                  checked={item.status === 'completed'}
                  missed={item.status === 'missed'}
                  label={`${item.dateLabel} · ${statusLabelMap[item.status] || item.status}`}
                  sublabel={
                    item.status === 'partial' && typeof item.valueMinutes === 'number'
                      ? `${item.valueMinutes} / ${item.targetMinutes || targetHabit?.durationMinutes || 15} мин`
                      : undefined
                  }
                />
              ))
            )}
          </div>

          {user.penaltyQuest.active && (
            <>
              <div className="p-3.5 rounded-[6px] border border-[#ff4d4d] bg-[#2b0408]/85 shadow-[0_0_16px_rgba(255,40,40,0.35)] flex items-center gap-3">
                <div className="w-8 h-8 rounded-full border-2 border-white flex items-center justify-center font-bold shrink-0">
                  !
                </div>
                <div className="text-[16px] font-bold leading-snug text-white">
                  Штрафной квест
                  <br />
                  назначен
                </div>
              </div>

              <div className="text-center">
                <button
                  type="button"
                  onClick={() => navigateState(40)}
                  className="text-[16px] font-semibold underline underline-offset-4 text-white hover:text-[#38e8ff] cursor-pointer"
                >
                  Открыть квест
                </button>
              </div>
            </>
          )}
        </div>

        <button
          type="button"
          onClick={() => navigateState(45)}
          className="w-full py-2.5 px-3 rounded-[6px] border border-white/40 bg-black/30 flex items-center justify-between text-[14px] text-white/90 hover:border-white cursor-pointer"
        >
          <span>История штрафных квестов</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    );
  }

  // --- ЦЕЛИ И ПРОГРЕСС (States 16, 17, 18) ---
  if (stateId === 16) {
    const activeGoals = user.goals.filter((g) => g.status === 'active');

    return (
      <div className="flex flex-col justify-between min-h-full space-y-3">
        <div className="space-y-3">
          <SystemHeaderBox title="ЦЕЛИ" />

          <div className="divide-y divide-white/30">
            {activeGoals.length === 0 ? (
              <div className="py-5 text-center text-[14px] text-white/75">
                Активных целей пока нет. Создайте новую цель ниже.
              </div>
            ) : (
              activeGoals.map((g) => {
                const pct = g.targetValue > 0 ? Math.min(100, Math.round((g.currentValue / g.targetValue) * 100)) : 0;

                if (g.type === 'deadline_project') {
                  return (
                    <button
                      key={g.id}
                      type="button"
                      onClick={() => {
                        setSelectedGoalId?.(g.id);
                        navigateState(17);
                      }}
                      className="w-full text-left py-3 space-y-1 cursor-pointer group"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[18px] font-bold group-hover:text-[#38e8ff]">{g.title}</span>
                        <ChevronRight className="w-5 h-5 text-white/75" />
                      </div>
                      <div className="text-[15px] text-white/85 font-tabular">
                        <RollingNumber value={g.currentValue} metricKey={`goal_cur_${g.id}`} /> /{' '}
                        {g.targetValue} этапов
                      </div>
                    </button>
                  );
                }

                if (g.type === 'savings') {
                  const remainingRub = Math.max(0, g.targetValue - g.currentValue);
                  const monthlySurplus = Math.max(0, user.monthIncomeRub - user.monthExpenseRub);
                  const estMonths =
                    remainingRub === 0
                      ? 0
                      : monthlySurplus > 0
                      ? Math.max(1, Math.ceil(remainingRub / monthlySurplus))
                      : null;

                  return (
                    <button
                      key={g.id}
                      type="button"
                      onClick={() => {
                        setSelectedGoalId?.(g.id);
                        navigateState(8);
                      }}
                      className="w-full text-left py-3 space-y-1.5 cursor-pointer group"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[18px] font-bold leading-snug group-hover:text-[#38e8ff]">
                          {g.title}
                        </span>
                        <Edit3 className="w-4 h-4 text-white/70 shrink-0" />
                      </div>
                      <div className="text-[15px] text-white/90 font-tabular">
                        <RollingNumber
                          value={g.currentValue}
                          metricKey={`goal_cur_${g.id}`}
                          useGrouping
                        />{' '}
                        / {g.targetValue.toLocaleString('ru-RU')} ₽ ={' '}
                        <RollingNumber
                          value={pct}
                          metricKey={`goal_pct_${g.id}`}
                          suffix="%"
                        />
                      </div>
                      <SystemProgressBar value={g.currentValue} max={g.targetValue} />
                      {remainingRub > 0 && (
                        <div className="flex items-center justify-between text-[11.5px] pt-0.5 font-tabular">
                          {user.subscription.active ? (
                            <span className="text-[#9deeff]">
                              {estMonths !== null
                                ? `Прогноз Система+: ~${estMonths} мес. (при остатке +${monthlySurplus.toLocaleString('ru-RU')} ₽/мес)`
                                : 'Зафиксируйте доходы месяца для прогноза срока'}
                            </span>
                          ) : (
                            <span className="text-amber-300/90 flex items-center gap-1">
                              <Lock className="w-3 h-3 shrink-0" />
                              <span>Прогноз срока накопления · в Система+</span>
                            </span>
                          )}
                        </div>
                      )}
                    </button>
                  );
                }

                return (
                  <div key={g.id} className="py-3 flex items-center justify-between gap-2 group">
                    <button
                      type="button"
                      onClick={() => apiAction('/api/tasks/start-focus', { goalId: g.id }, 59)}
                      className="flex-1 text-left space-y-1.5 cursor-pointer min-w-0"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[18px] font-bold leading-snug group-hover:text-[#38e8ff] truncate">
                          {g.title}
                        </span>
                        <ChevronRight className="w-5 h-5 text-white/75 shrink-0" />
                      </div>
                      <div className="text-[15px] text-white/90 font-tabular">
                        <RollingNumber value={g.currentValue} metricKey={`goal_cur_${g.id}`} /> /{' '}
                        {g.targetValue} ·{' '}
                        <RollingNumber value={pct} metricKey={`goal_pct_${g.id}`} suffix="%" />
                      </div>
                      <SystemProgressBar value={g.currentValue} max={g.targetValue} />
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedGoalId?.(g.id);
                        navigateState(6);
                      }}
                      aria-label="Редактировать или удалить цель"
                      className="p-2 rounded-[4px] border border-white/30 bg-black/40 text-white/75 hover:text-[#38e8ff] hover:border-[#38e8ff] cursor-pointer shrink-0"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                  </div>
                );
              })
            )}
          </div>

          <div className="text-center text-[13.5px] text-white/85 font-tabular pt-1 flex items-center justify-center gap-1.5">
            <span>
              Активных целей: <RollingNumber value={activeGoals.length} metricKey="goals_active_count" /> /{' '}
              {user.subscription.active ? '∞' : '3'}
            </span>
            {!user.subscription.active && (
              <button
                type="button"
                onClick={() => openPlusModal?.('goals')}
                className="text-[#38f8ff] underline underline-offset-2 font-bold cursor-pointer hover:text-white"
              >
                (∞ в Система+)
              </button>
            )}
          </div>

          <SystemButton
            label="СОЗДАТЬ ЦЕЛЬ"
            onClick={() => {
              if (!user.subscription.active && activeGoals.length >= 3) {
                if (openPlusModal) {
                  openPlusModal('goals');
                } else {
                  setLimitReason?.('goals');
                  navigateState(46);
                }
              } else {
                setSelectedGoalId?.(null);
                navigateState(5);
              }
            }}
          />

          {activeGoals.length < 3 && (
            <div className="p-2.5 border border-white/25 bg-[#031221]/65 text-[12px] text-white/75 leading-snug text-center">
              Добавьте <strong className="text-white">проект с этапами</strong> или{' '}
              <strong className="text-white">накопительную цель</strong> — задания и прогресс
              свяжутся автоматически.
            </div>
          )}

          {user.goals.some((g) => g.status === 'archived') && (
            <div className="pt-1 border-t border-white/25 space-y-1.5">
              <button
                type="button"
                onClick={() => setShowArchivedGoals((v) => !v)}
                className="w-full py-1.5 px-2 text-[12px] text-white/75 hover:text-white flex items-center justify-between cursor-pointer"
              >
                <span className="flex items-center gap-1.5">
                  <Archive className="w-3.5 h-3.5 text-[#38e8ff]" />
                  <span>
                    Архив целей ({user.goals.filter((g) => g.status === 'archived').length})
                  </span>
                </span>
                <ChevronDown
                  className={`w-4 h-4 transition-transform ${showArchivedGoals ? 'rotate-180' : ''}`}
                />
              </button>
              {showArchivedGoals && (
                <div className="space-y-1.5">
                  {user.goals
                    .filter((g) => g.status === 'archived')
                    .map((ag) => (
                      <div
                        key={ag.id}
                        className="p-2 rounded border border-white/30 bg-black/45 flex items-center justify-between gap-2 text-[12.5px]"
                      >
                        <span className="truncate text-white/80">{ag.title}</span>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() =>
                              apiAction('/api/goals/delete', { goalId: ag.id, mode: 'restore' })
                            }
                            className="px-2 py-1 rounded border border-[#38f8ff]/60 bg-[#062d4a]/70 text-[#9deeff] hover:border-white cursor-pointer flex items-center gap-1"
                          >
                            <RotateCcw className="w-3 h-3" />
                            <span>Вернуть</span>
                          </button>
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() =>
                              apiAction('/api/goals/delete', {
                                goalId: ag.id,
                                mode: 'delete',
                                deleteLinkedTasks: true,
                              })
                            }
                            className="p-1.5 rounded border border-[#ff4d4d]/50 bg-[#2a0509] text-[#ffb3b3] hover:border-[#ff4d4d] cursor-pointer"
                            aria-label="Удалить цель"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }

  if (stateId === 17) {
    const projectGoal =
      (selectedGoalId && user.goals.find((g) => g.id === selectedGoalId)) ||
      user.goals.find((g) => g.type === 'deadline_project') || {
        id: 'goal_portfolio',
        title: 'ПОРТФОЛИО',
        currentValue: 1,
        targetValue: 3,
        deadlineText: 'через 7 дней',
        milestones: [
          { id: 'ms_1', goalId: 'goal_portfolio', title: 'Собрать примеры', order: 1, completed: true, locked: false, mandatory: true },
          { id: 'ms_2', goalId: 'goal_portfolio', title: 'Оформить страницы', order: 2, completed: false, locked: false, mandatory: true },
          { id: 'ms_3', goalId: 'goal_portfolio', title: 'Опубликовать', order: 3, completed: false, locked: true, mandatory: true },
        ],
      };

    const milestones = projectGoal.milestones || [];
    const linkedTask = user.tasks.find((t) => t.goalId === projectGoal.id && !t.completed) ||
      user.tasks.find((t) => t.goalId === projectGoal.id);

    return (
      <div className="flex flex-col justify-between min-h-full space-y-3">
        <div className="space-y-3">
          <SystemHeaderBox title={projectGoal.title.toUpperCase()} onBack={() => navigateState(16)} />
          <div className="text-center text-[16px] font-semibold font-tabular py-1 border-b border-white/30">
            <RollingNumber value={projectGoal.currentValue} metricKey={`goal_cur_${projectGoal.id}`} /> /{' '}
            {projectGoal.targetValue} этапов
          </div>

          <div className="space-y-2.5">
            {milestones.map((ms) => {
              if (ms.locked) {
                return (
                  <div
                    key={ms.id}
                    className="py-2.5 px-2 flex items-center gap-3 text-white/60 border-b border-white/25"
                  >
                    <Lock className="w-5 h-5 shrink-0" />
                    <span className="text-[16px] font-semibold">{ms.title}</span>
                  </div>
                );
              }

              const isCurrentActive = !ms.completed && !ms.locked;
              return (
                <div
                  key={ms.id}
                  className={
                    isCurrentActive
                      ? 'px-2.5 rounded-[4px] border border-[#38f8ff] bg-[#062d4a]/85 shadow-[0_0_16px_rgba(0,225,255,0.45)] [&>div]:border-b-0'
                      : ''
                  }
                >
                  <SystemCheckbox
                    checked={ms.completed}
                    label={ms.title}
                    electricTag="ВЕХА ✓"
                    onChange={() =>
                      apiAction('/api/goals/milestone-toggle', {
                        goalId: projectGoal.id,
                        milestoneId: ms.id,
                      })
                    }
                  />
                </div>
              );
            })}
          </div>

          <div className="text-center py-2 text-[16px] text-white/90">
            Ближайший срок:
            <br />
            <span className="font-bold">{projectGoal.deadlineText || 'через 7 дней'}</span>
          </div>
        </div>

        <div className="space-y-2 text-center">
          <SystemButton
            label={linkedTask ? 'ОТКРЫТЬ ЗАДАНИЕ' : 'ДОБАВИТЬ ЗАДАНИЕ'}
            highlighted
            onClick={() => {
              setSelectedGoalId?.(projectGoal.id);
              setSelectedTaskId?.(linkedTask ? linkedTask.id : null);
              navigateState(60);
            }}
          />
          <button
            type="button"
            disabled={busy}
            onClick={() =>
              apiAction('/api/goals/smart-steps', {
                goalId: projectGoal.id,
                title: projectGoal.title,
                apply: true,
              })
            }
            className="w-full min-h-[46px] py-2 px-3 border border-[#38f8ff]/70 bg-[#062d4a]/80 text-[13px] font-bold text-[#9deeff] hover:border-white hover:text-white cursor-pointer flex items-center justify-between gap-2 disabled:opacity-45"
          >
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-[#38f8ff]" />
              <span>Умная разбивка на 3 вехи</span>
            </span>
            <span className="text-[11px] font-mono text-white/80">
              {user.subscription.active
                ? '∞ PRO'
                : `${Math.max(0, 2 - (user.smartStepsUsedCount || 0))}/2 Free`}
            </span>
          </button>
          <button
            type="button"
            onClick={() => {
              setSelectedGoalId?.(projectGoal.id);
              navigateState(7);
            }}
            className="text-[15px] underline underline-offset-4 text-white/90 hover:text-white cursor-pointer"
          >
            Изменить цель
          </button>
        </div>
      </div>
    );
  }

  if (stateId === 18) {
    const completedGoalTitle =
      user.lastCompletedGoalTitle ||
      user.goals.find((g) => g.status === 'completed')?.title ||
      '20 занятий английским';
    const completedGoalProgress = user.lastCompletedGoalProgress || '20 / 20';

    return (
      <div className="flex flex-col items-center justify-between min-h-full py-2 text-center">
        <div className="w-full space-y-3">
          <SystemSquareIcon kind="check" />
          <SystemHeaderBox title="ЦЕЛЬ ВЫПОЛНЕНА" />
        </div>

        <div className="w-full space-y-3 my-auto">
          <div className="text-[20px] font-bold leading-snug system-text-glow-blue">
            {completedGoalTitle}
          </div>
          <SystemProgressBar value={20} max={20} />
          <div className="text-[16px] font-bold font-tabular">
            <RollingNumber value={100} animateFrom={0} suffix="%" />
          </div>

          <div className="border-t border-b border-white/35 py-3 space-y-1">
            <div className="text-[28px] font-extrabold font-tabular text-white drop-shadow-[0_0_14px_rgba(0,225,255,0.75)]">
              <RollingNumber value={500} animateFrom={0} prefix="+" suffix=" XP" />
            </div>
            <div className="text-[16px] text-white/90 font-tabular">{completedGoalProgress}</div>
          </div>
        </div>

        <div className="w-full space-y-3">
          <SystemButton label="К МОИМ ЦЕЛЯМ" highlighted onClick={() => navigateState(16)} />
          <button
            type="button"
            onClick={() => navigateState(5)}
            className="text-[15px] underline underline-offset-4 text-white/90 hover:text-white cursor-pointer"
          >
            Создать следующую
          </button>
        </div>
      </div>
    );
  }

  // --- ФИНАНСЫ (States 19, 20, 21, 22, 23, 24) ---
  if (stateId === 19) {
    const totalBalance = user.accounts
      .filter((a) => a.status === 'active')
      .reduce((sum, a) => sum + a.balanceRub, 0);
    const monthNet = user.monthIncomeRub - user.monthExpenseRub;
    const defaultFinAcc = user.accounts.find((a) => a.status === 'active') ||
      user.accounts[0] || { id: 'acc_card', name: 'Карта' };
    const inlineDrafts = quickFinanceInput.trim()
      ? parseNaturalFinanceInput(
          quickFinanceInput,
          user.accounts,
          defaultFinAcc.id,
          defaultFinAcc.name
        )
      : [];
    const inlineValidDrafts = inlineDrafts.filter((d) => (d.amountRub || 0) > 0);

    // Compute current month expenses by category for comparison
    const currentByCat: Record<string, number> = {};
    for (const e of user.financialEntries) {
      if (e.type === 'expense') {
        const cat = e.category || 'Прочее';
        currentByCat[cat] = (currentByCat[cat] || 0) + e.amountRub;
      }
    }
    const prevByCat = user.prevMonthExpensesByCategory || {};
    const analyticsCats = Array.from(
      new Set([...Object.keys(currentByCat), ...Object.keys(prevByCat)])
    ).slice(0, 4);

    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5">
        <div className="space-y-2.5">
          <SystemHeaderBox title="ФИНАНСЫ" />

          <div className="text-center py-1">
            <div className="text-[15px] text-white/85">На счетах</div>
            <div className="text-[28px] font-extrabold font-tabular">
              <RollingNumber
                value={totalBalance}
                metricKey="finance_total_balance"
                useGrouping
                suffix=" ₽"
              />
            </div>
          </div>

          {/* Inline Free Natural-Language Multi-Item Finance Bar */}
          <div className="p-2.5 rounded-[8px] border border-[#00e5ff]/60 bg-[#031221]/90 space-y-2">
            <div className="flex items-center justify-between text-[11px] uppercase tracking-[0.06em]">
              <span className="text-[#9deeff] font-bold">Умная строка</span>
              <span className="text-[#38f8ff] font-bold">∞ Бесплатно</span>
            </div>
            <input
              type="text"
              value={quickFinanceInput}
              onChange={(e) => setQuickFinanceInput(e.target.value)}
              placeholder="Кофе 200, такси 500, +15к фриланс..."
              className="w-full px-3 py-2 rounded-[6px] border border-white/75 bg-black/50 text-[14px] font-medium text-white placeholder:text-white/45 focus:outline-none focus:border-[#00e5ff]"
            />
            {inlineDrafts.length > 0 && (
              <div className="space-y-1 pt-0.5">
                {inlineDrafts.map((d) => (
                  <button
                    key={d.id}
                    type="button"
                    onClick={() => {
                      if (d.type === 'income') {
                        const incomeCats = ['Зарплата', 'Фриланс', 'Премия', 'Бизнес', 'Прочее'];
                        setIncomeAmount(d.amountRub || 1000);
                        setIncomeCategory(incomeCats.includes(d.category) ? d.category : 'Прочее');
                        setIncomeAccount(d.accountId);
                        navigateState(22);
                        return;
                      }
                      setExpenseTitle(d.title);
                      setExpenseAmount(d.amountRub || 200);
                      setExpenseCategory(d.category === 'Требует уточнения' ? 'Прочее' : d.category);
                      setExpenseAccount(d.accountId);
                      setExpenseDate(d.dateLabel || 'Сегодня');
                      navigateState(21);
                    }}
                    className="w-full min-h-[42px] px-2.5 py-1.5 rounded border border-white/35 bg-black/40 flex items-center justify-between text-[13px] hover:border-[#38e8ff] cursor-pointer text-left"
                  >
                    <span className="truncate pr-2">
                      <span className="font-semibold text-white">{d.title}</span>{' '}
                      <span className="text-[#9deeff]">· {d.category}</span>
                      {d.dateLabel !== 'Сегодня' ? (
                        <span className="text-white/60"> · {d.dateLabel}</span>
                      ) : null}
                    </span>
                    <span
                      className={`font-bold font-tabular shrink-0 ${
                        d.type === 'income' ? 'text-emerald-300' : 'text-white'
                      }`}
                    >
                      {d.amountRub
                        ? d.type === 'income'
                          ? `+${formatRub(d.amountRub)}`
                          : `−${formatRub(d.amountRub)}`
                        : 'Сумма?'}
                    </span>
                  </button>
                ))}
                {inlineValidDrafts.length > 0 && (
                  <SystemButton
                    label={`ЗАПИСАТЬ (${inlineValidDrafts.length})`}
                    highlighted
                    disabled={busy}
                    onClick={async () => {
                      const textSnapshot = quickFinanceInput;
                      setQuickFinanceInput('');
                      await apiAction(
                        '/api/finance/commit-batch',
                        {
                          idempotencyKey: `inline_${textSnapshot}_${Date.now()}`,
                          items: inlineValidDrafts.map((d) => ({
                            title: d.title,
                            category: d.category,
                            amountRub: d.amountRub || 0,
                            accountId: d.accountId,
                            type: d.type,
                            dateLabel: d.dateLabel || 'Сегодня',
                          })),
                        },
                        19
                      );
                    }}
                  />
                )}
              </div>
            )}
          </div>

          {/* Accounts Section with Explicit Counter + "+ Счёт" Trigger */}
          <div className="space-y-1">
            <div className="flex items-center justify-between px-1 py-1 bg-white/5 border-t border-white/30">
              <div className="flex items-center gap-2 text-[12px] font-bold uppercase tracking-[0.05em]">
                <span>СЧЕТА</span>
                <span className="font-tabular text-[#72f8ff]">
                  {user.accounts.filter((a) => a.status === 'active').length} /{' '}
                  {user.subscription.active ? '∞' : '3'}
                </span>
                {!user.subscription.active && (
                  <button
                    type="button"
                    onClick={() => openPlusModal?.('accounts')}
                    className="text-[11px] font-semibold lowercase text-[#38e8ff] underline cursor-pointer"
                  >
                    ∞ в Система+
                  </button>
                )}
              </div>
              <button
                type="button"
                onClick={() => {
                  const activeAccCount = user.accounts.filter((a) => a.status === 'active').length;
                  if (!user.subscription.active && activeAccCount >= 3) {
                    if (openPlusModal) openPlusModal('accounts');
                    else {
                      setLimitReason?.('accounts');
                      navigateState(46);
                    }
                  } else {
                    setShowNewAccForm(true);
                    navigateState(24);
                  }
                }}
                className="min-h-[40px] px-3 py-1.5 border border-[#38f8ff]/80 bg-[#062d4a]/80 text-[12px] font-bold text-[#9deeff] hover:border-white hover:text-white cursor-pointer flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Счёт</span>
              </button>
            </div>

            <div className="divide-y divide-white/25 border-t border-b border-white/35">
              {user.accounts
                .filter((a) => a.status === 'active')
                .map((acc) => (
                  <button
                  key={acc.id}
                  type="button"
                  onClick={() => {
                    setShowNewAccForm(false);
                    navigateState(24);
                  }}
                  className="w-full py-2 flex items-center justify-between text-[15px] hover:bg-white/5 cursor-pointer"
                >
                  <span className="flex items-center gap-2.5 font-medium">
                    {acc.type === 'card' ? (
                      <CreditCard className="w-5 h-5 text-[#38e8ff]" />
                    ) : acc.type === 'cash' ? (
                      <Wallet className="w-5 h-5 text-[#38e8ff]" />
                    ) : (
                      <Coins className="w-5 h-5 text-[#38e8ff]" />
                    )}
                    {acc.name}
                  </span>
                  <span className="font-bold font-tabular">
                    <RollingNumber
                      value={acc.balanceRub}
                      metricKey={`acc_bal_${acc.id}`}
                      useGrouping
                      suffix=" ₽"
                    />
                  </span>
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-1 text-[14px]">
            <div className="text-center font-bold tracking-[0.05em] uppercase text-white/90 pb-1">
              ИТОГИ ЗА МЕСЯЦ
            </div>
            <div className="flex justify-between py-0.5 border-b border-white/20">
              <span className="text-white/85">Доходы</span>
              <span className="font-bold font-tabular">
                <RollingNumber
                  value={user.monthIncomeRub}
                  metricKey="finance_month_income"
                  useGrouping
                  suffix=" ₽"
                />
              </span>
            </div>
            <div className="flex justify-between py-0.5 border-b border-white/20">
              <span className="text-white/85">Расходы</span>
              <span className="font-bold font-tabular">
                <RollingNumber
                  value={user.monthExpenseRub}
                  metricKey="finance_month_expense"
                  useGrouping
                  suffix=" ₽"
                />
              </span>
            </div>
            <div className="flex justify-between py-0.5">
              <span className="text-white/85">Баланс</span>
              <span className="font-bold font-tabular">
                <RollingNumber
                  value={monthNet}
                  metricKey="finance_month_net"
                  prefix={monthNet > 0 ? '+' : ''}
                  useGrouping
                  suffix=" ₽"
                />
              </span>
            </div>
          </div>

          {/* Month-over-Month Category Analytics (PRO) */}
          {user.subscription.active ? (
            <div className="p-2.5 rounded-[8px] border border-white/40 bg-[#04182b]/75 space-y-1.5">
              <div className="flex items-center justify-between text-[12px] font-bold uppercase tracking-[0.05em] text-[#9deeff]">
                <span className="flex items-center gap-1.5">
                  <TrendingUp className="w-3.5 h-3.5 text-[#38e8ff]" />
                  Сравнение с прошлым месяцем
                </span>
                <span className="text-amber-300">СИСТЕМА+</span>
              </div>
              <div className="space-y-1 text-[12px]">
                {analyticsCats.map((cat) => {
                  const cur = currentByCat[cat] || 0;
                  const prev = prevByCat[cat] || 0;
                  const diffPct = prev > 0 ? Math.round(((cur - prev) / prev) * 100) : cur > 0 ? 100 : 0;
                  return (
                    <div key={cat} className="flex items-center justify-between border-b border-white/10 pb-0.5 last:border-b-0">
                      <span className="text-white/85">{cat}</span>
                      <span className="font-tabular font-semibold">
                        {formatRub(cur)}{' '}
                        <span className={diffPct > 0 ? 'text-[#ff8585]' : 'text-emerald-300'}>
                          ({diffPct > 0 ? `+${diffPct}%` : `${diffPct}%`})
                        </span>
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => openPlusModal?.('feature', 'Аналитика по месяцам')}
              className="w-full p-2.5 rounded-[8px] border border-white/35 bg-[#04182b]/65 hover:border-[#38e8ff] flex items-center justify-between text-left cursor-pointer"
            >
              <div>
                <div className="text-[12px] font-bold uppercase tracking-[0.05em] text-[#9deeff] flex items-center gap-1.5">
                  <TrendingUp className="w-3.5 h-3.5" />
                  Сравнение с прошлым месяцем
                </div>
                <div className="text-[12px] text-white/75">
                  Динамика трат по категориям в Система+
                </div>
              </div>
              <Lock className="w-4 h-4 text-[#38e8ff] shrink-0" />
            </button>
          )}

          {/* Action Buttons cleanly arranged above Last Entries */}
          <div className="grid grid-cols-3 gap-1.5 pt-0.5">
            <button
              type="button"
              onClick={() => navigateState(20)}
              className="py-2 px-2 rounded border border-[#38e8ff]/75 bg-[#062d4a]/70 text-[12px] font-bold hover:border-white cursor-pointer"
            >
              Ввод списком
            </button>
            <button
              type="button"
              onClick={() => navigateState(22)}
              className="py-2 px-2 rounded border border-white/45 bg-black/40 text-[12px] font-semibold hover:border-[#38e8ff] cursor-pointer"
            >
              + Доход
            </button>
            <button
              type="button"
              onClick={() => navigateState(23)}
              className="py-2 px-2 rounded border border-white/45 bg-black/40 text-[12px] font-semibold hover:border-[#38e8ff] cursor-pointer"
            >
              ⇄ Перевод
            </button>
          </div>
        </div>

        <div className="space-y-1.5 pt-1 pb-3">
          <div className="text-center text-[12px] font-bold tracking-[0.06em] uppercase text-white/80">
            ПОСЛЕДНИЕ ЗАПИСИ
          </div>
          <div className="space-y-1.5">
            {user.financialEntries.length === 0 ? (
              <div className="py-2 text-center text-[13px] text-white/70">
                Записей пока нет. Введите трату в умную строку выше.
              </div>
            ) : (
              user.financialEntries.slice(0, 4).map((e) => (
                <button
                  key={e.id}
                  type="button"
                  onClick={() => {
                    setSelectedEntryId?.(e.id);
                    navigateState(58);
                  }}
                  className="w-full px-3 py-2 rounded-[6px] border border-white/60 bg-black/40 flex items-center justify-between text-[14px] hover:border-[#38e8ff] cursor-pointer"
                >
                  <span className="flex items-center gap-2 font-medium truncate">
                    <ShoppingCart className="w-4 h-4 text-[#38e8ff] shrink-0" />
                    <span className="truncate">{e.title}</span>
                  </span>
                  <span className="font-bold font-tabular shrink-0 ml-2">
                    {e.type === 'income'
                      ? `+${formatRub(e.amountRub)}`
                      : e.type === 'transfer'
                      ? formatRub(e.amountRub)
                      : `−${formatRub(e.amountRub)}`}
                  </span>
                </button>
              ))
            )}
          </div>
        </div>
      </div>
    );
  }

  if (stateId === 20) {
    const hasPositiveAmount = parsedDrafts.some((d) => (d.amountRub || 0) > 0);
    return (
      <div className="flex flex-col justify-between min-h-full space-y-3">
        <div className="space-y-3">
          <SystemHeaderBox title="БЫСТРЫЙ ВВОД" onBack={() => navigateState(19)} />

          <input
            type="text"
            value={smartInput}
            onChange={(e) => setSmartInput(e.target.value)}
            placeholder="Кофе 200, продукты 1500"
            className="w-full px-3.5 py-3 rounded-[8px] border-2 border-white/85 bg-[#031221] text-[16px] font-semibold text-white focus:outline-none focus:border-[#00e5ff]"
          />

          <div className="divide-y divide-white/25 border-t border-b border-white/30">
            {parsedDrafts.map((d, index) => (
              <button
                key={d.id}
                type="button"
                onClick={() => {
                  if (d.type === 'income') {
                    const incomeCats = ['Зарплата', 'Фриланс', 'Премия', 'Бизнес', 'Прочее'];
                    setIncomeAmount(d.amountRub || 1000);
                    setIncomeCategory(incomeCats.includes(d.category) ? d.category : 'Прочее');
                    setIncomeAccount(d.accountId);
                    navigateState(22);
                    return;
                  }
                  setExpenseTitle(d.title);
                  setExpenseAmount(d.amountRub || 200);
                  setExpenseCategory(d.category === 'Требует уточнения' ? 'Прочее' : d.category);
                  setExpenseAccount(d.accountId);
                  setExpenseDate(d.dateLabel || 'Сегодня');
                  navigateState(21);
                }}
                className="w-full py-3 flex items-center justify-between gap-2 text-left hover:bg-white/5 cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  {index === 0 ? (
                    <Coffee className="w-6 h-6 text-white/90 shrink-0" />
                  ) : (
                    <ShoppingCart className="w-6 h-6 text-white/90 shrink-0" />
                  )}
                  <div>
                    <div className="text-[15px] font-bold">
                      {d.title} · {d.category}
                    </div>
                    <div className="text-[13px] text-white/75">{d.accountName}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[15px] font-bold font-tabular">
                    {d.amountRub ? (d.type === 'income' ? `+${formatRub(d.amountRub)}` : `−${formatRub(d.amountRub)}`) : 'Уточнить'}
                  </span>
                  <Edit3 className="w-4 h-4 text-white/80" />
                </div>
              </button>
            ))}
          </div>

          <div className="text-center text-[13px] text-white/80">
            Нажмите строку для правки
          </div>
        </div>

        <SystemButton
          label={`ЗАПИСАТЬ (${parsedDrafts.filter((d) => (d.amountRub || 0) > 0).length})`}
          highlighted
          disabled={busy || !hasPositiveAmount}
          onClick={() =>
            apiAction(
              '/api/finance/commit-batch',
              {
                idempotencyKey: `batch_${smartInput}_${Date.now()}`,
                items: parsedDrafts
                  .filter((d) => (d.amountRub || 0) > 0)
                  .map((d) => ({
                    title: d.title,
                    category: d.category === 'Требует уточнения' ? 'Прочее' : d.category,
                    amountRub: d.amountRub || 0,
                    accountId: d.accountId,
                    type: d.type,
                    dateLabel: d.dateLabel || 'Сегодня',
                  })),
              },
              19
            )
          }
        />
      </div>
    );
  }

  if (stateId === 21) {
    return (
      <div className="flex flex-col justify-between min-h-full space-y-3">
        <div className="space-y-3">
          <SystemHeaderBox title="НОВАЯ ТРАТА" onBack={() => navigateState(20)} />

          <div className="text-center py-2 border-b border-white/30">
            <input
              type="number"
              min={1}
              value={expenseAmount}
              onChange={(e) => setExpenseAmount(Math.max(0, Number(e.target.value) || 0))}
              className="w-44 text-center bg-transparent border-b border-white/40 text-[32px] font-extrabold font-tabular focus:outline-none focus:border-[#00e5ff]"
            />
            <span className="text-[28px] font-extrabold ml-1">₽</span>
          </div>

          <div className="space-y-2.5 text-[15px]">
            <div className="flex items-center justify-between py-1.5 border-b border-white/25">
              <span className="text-white/85">Категория</span>
              <div className="relative w-44">
                <select
                  value={expenseCategory}
                  onChange={(e) => setExpenseCategory(e.target.value)}
                  className="w-full appearance-none pl-3 pr-9 py-1.5 rounded-[6px] border border-white/80 bg-[#031221] font-semibold text-white"
                >
                  <option value="Еда">Еда</option>
                  <option value="Продукты">Продукты</option>
                  <option value="Транспорт">Транспорт</option>
                  <option value="Жильё и связь">Жильё и связь</option>
                  <option value="Подписки">Подписки</option>
                  <option value="Покупки">Покупки</option>
                  <option value="Здоровье">Здоровье</option>
                  <option value="Досуг">Досуг</option>
                  <option value="Дом и быт">Дом и быт</option>
                  <option value="Прочее">Прочее</option>
                </select>
                <ChevronDown className="w-4 h-4 absolute right-2.5 top-2.5 pointer-events-none text-white/80" />
              </div>
            </div>

            <div className="flex items-center justify-between py-1.5 border-b border-white/25">
              <span className="text-white/85">Счёт</span>
              <div className="relative w-44">
                <select
                  value={expenseAccount}
                  onChange={(e) => setExpenseAccount(e.target.value)}
                  className="w-full appearance-none pl-3 pr-9 py-1.5 rounded-[6px] border border-white/80 bg-[#031221] font-semibold text-white"
                >
                  {selectableAccounts.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.name}
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-4 h-4 absolute right-2.5 top-2.5 pointer-events-none text-white/80" />
              </div>
            </div>

            <div className="flex items-center justify-between py-1.5 border-b border-white/25">
              <span className="text-white/85">Дата</span>
              <div className="relative w-44">
                <select
                  value={expenseDate}
                  onChange={(e) => setExpenseDate(e.target.value)}
                  className="w-full appearance-none pl-3 pr-9 py-1.5 rounded-[6px] border border-white/80 bg-[#031221] font-semibold text-white"
                >
                  <option value="Сегодня">Сегодня</option>
                  <option value="Вчера">Вчера</option>
                  <option value="Позавчера">Позавчера</option>
                </select>
                <ChevronDown className="w-4 h-4 absolute right-2.5 top-2.5 pointer-events-none text-white/80" />
              </div>
            </div>

            <div className="flex items-center justify-between py-1.5 border-b border-white/25">
              <span className="text-white/85">Название</span>
              <input
                type="text"
                value={expenseTitle}
                onChange={(e) => setExpenseTitle(e.target.value)}
                className="w-44 px-3 py-1.5 rounded-[6px] border border-white/80 bg-[#031221] font-semibold"
              />
            </div>
          </div>
        </div>

        <div className="space-y-2.5">
          <SystemButton
            label={`ЗАПИСАТЬ ${formatRub(expenseAmount)}`}
            highlighted
            disabled={busy || expenseAmount <= 0 || !expenseTitle.trim()}
            onClick={() =>
              apiAction(
                '/api/finance/commit-batch',
                {
                  idempotencyKey: `single_${Date.now()}`,
                  items: [
                    {
                      title: expenseTitle.trim(),
                      category: expenseCategory,
                      amountRub: expenseAmount,
                      accountId: expenseAccount,
                      type: 'expense',
                      dateLabel: expenseDate,
                    },
                  ],
                },
                19
              )
            }
          />
          <SystemButton
            label="Отмена"
            bracketed={false}
            onClick={() => navigateState(19)}
          />
        </div>
      </div>
    );
  }

  if (stateId === 22) {
    return (
      <div className="flex flex-col justify-between min-h-full space-y-3">
        <div className="space-y-3">
          <SystemHeaderBox title="НОВЫЙ ДОХОД" onBack={() => navigateState(19)} />

          <div className="text-center space-y-1">
            <span className="text-[14px] text-white/85">Сумма (₽)</span>
            <input
              type="number"
              min={1}
              value={incomeAmount}
              onChange={(e) => setIncomeAmount(Math.max(0, Number(e.target.value) || 0))}
              className="w-full py-2.5 px-3 rounded-[6px] border border-white/85 bg-[#031221] text-center text-[24px] font-extrabold font-tabular"
            />
          </div>

          <div className="divide-y divide-white/25 border-t border-b border-white/30">
            <div className="py-2.5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Wallet className="w-5 h-5 text-[#38e8ff]" />
                <span className="text-[14px] text-white/80">Категория:</span>
              </div>
              <div className="relative">
                <select
                  value={incomeCategory}
                  onChange={(e) => setIncomeCategory(e.target.value)}
                  className="appearance-none pl-3 pr-8 py-1 rounded border border-white/60 bg-[#031221] text-[15px] font-bold text-white"
                >
                  <option value="Зарплата">Зарплата</option>
                  <option value="Фриланс">Фриланс</option>
                  <option value="Премия">Премия</option>
                  <option value="Бизнес">Бизнес</option>
                  <option value="Прочее">Прочее</option>
                </select>
                <ChevronDown className="w-4 h-4 absolute right-2 top-1.5 pointer-events-none text-white/80" />
              </div>
            </div>

            <div className="py-2.5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <CreditCard className="w-5 h-5 text-[#38e8ff]" />
                <span className="text-[14px] text-white/80">Счёт:</span>
              </div>
              <div className="relative">
                <select
                  value={incomeAccount}
                  onChange={(e) => setIncomeAccount(e.target.value)}
                  className="appearance-none pl-3 pr-8 py-1 rounded border border-white/60 bg-[#031221] text-[15px] font-bold text-white"
                >
                  {selectableAccounts.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.name}
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-4 h-4 absolute right-2 top-1.5 pointer-events-none text-white/80" />
              </div>
            </div>

            <div className="py-2.5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Calendar className="w-5 h-5 text-[#38e8ff]" />
                <span className="text-[14px] text-white/80">Дата:</span>
              </div>
              <span className="text-[15px] font-bold">Сегодня</span>
            </div>
          </div>
        </div>

        <SystemButton
          label="ЗАПИСАТЬ ДОХОД"
          highlighted
          disabled={busy || incomeAmount <= 0}
          onClick={() =>
            apiAction(
              '/api/finance/commit-batch',
              {
                idempotencyKey: `inc_${Date.now()}`,
                items: [
                  {
                    title: incomeCategory,
                    category: incomeCategory,
                    amountRub: incomeAmount,
                    accountId: incomeAccount,
                    type: 'income',
                  },
                ],
              },
              19
            )
          }
        />
      </div>
    );
  }

  if (stateId === 23) {
    const fromAcc = selectableAccounts.find((a) => a.id === transferFrom) || selectableAccounts[0];
    const toAcc =
      selectableAccounts.find((a) => a.id === transferTo) ||
      selectableAccounts.find((a) => a.id !== fromAcc?.id) ||
      selectableAccounts[0];
    const hasTwoAccounts =
      selectableAccounts.length >= 2 && fromAcc && toAcc && fromAcc.id !== toAcc.id;

    return (
      <div className="flex flex-col justify-between min-h-full space-y-3">
        <div className="space-y-2.5">
          <SystemHeaderBox title="ПЕРЕВОД" onBack={() => navigateState(19)} />

          <div className="text-center space-y-1">
            <span className="text-[14px] text-white/85">Сумма перевода (₽)</span>
            <input
              type="number"
              min={1}
              value={transferAmount}
              onChange={(e) => setTransferAmount(Math.max(0, Number(e.target.value) || 0))}
              className="w-full py-2 px-3 rounded-[6px] border border-white/85 bg-[#031221] text-center text-[24px] font-extrabold font-tabular"
            />
          </div>

          <div className="divide-y divide-white/25 border-t border-b border-white/30">
            <div className="py-2 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <CreditCard className="w-5 h-5 text-[#38e8ff]" />
                <span className="text-[14px] text-white/80">Откуда:</span>
              </div>
              <div className="relative">
                <select
                  value={fromAcc?.id || ''}
                  onChange={(e) => setTransferFrom(e.target.value)}
                  className="appearance-none pl-3 pr-8 py-1 rounded border border-white/60 bg-[#031221] text-[15px] font-bold text-white"
                >
                  {selectableAccounts.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.name}
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-4 h-4 absolute right-2 top-1.5 pointer-events-none text-white/80" />
              </div>
            </div>

            <div className="py-2 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Coins className="w-5 h-5 text-[#38e8ff]" />
                <span className="text-[14px] text-white/80">Куда:</span>
              </div>
              <div className="relative">
                <select
                  value={toAcc?.id || ''}
                  onChange={(e) => setTransferTo(e.target.value)}
                  className="appearance-none pl-3 pr-8 py-1 rounded border border-white/60 bg-[#031221] text-[15px] font-bold text-white"
                >
                  {selectableAccounts.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.name}
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-4 h-4 absolute right-2 top-1.5 pointer-events-none text-white/80" />
              </div>
            </div>
          </div>

          <div className="text-center text-[13px] text-white/85">
            {!hasTwoAccounts
              ? 'Выберите разные счета для перевода.'
              : 'Перевод не меняет общий остаток.'}
          </div>

          {fromAcc && toAcc && (
            <div className="p-2.5 rounded-[6px] border border-white/60 bg-black/40 space-y-1.5 text-[14px] font-tabular">
              <div className="flex justify-between border-b border-white/20 pb-1">
                <span>{fromAcc.name}</span>
                <span className="font-bold">
                  {fromAcc.balanceRub.toLocaleString('ru-RU')} → {(fromAcc.balanceRub - transferAmount).toLocaleString('ru-RU')} ₽
                </span>
              </div>
              <div className="flex justify-between">
                <span>{toAcc.name}</span>
                <span className="font-bold">
                  {toAcc.balanceRub.toLocaleString('ru-RU')} → {(toAcc.balanceRub + transferAmount).toLocaleString('ru-RU')} ₽
                </span>
              </div>
            </div>
          )}
        </div>

        <SystemButton
          label="ПЕРЕВЕСТИ"
          highlighted
          disabled={busy || !hasTwoAccounts || transferAmount <= 0}
          onClick={() =>
            apiAction(
              '/api/finance/transfer',
              { fromAccountId: fromAcc!.id, toAccountId: toAcc!.id, amountRub: transferAmount },
              24
            )
          }
        />
      </div>
    );
  }

  if (stateId === 24) {
    const activeAccounts = user.accounts.filter((a) => a.status === 'active');
    const archivedAccounts = user.accounts.filter((a) => a.status === 'archived');
    const totalBalance = activeAccounts.reduce((sum, a) => sum + a.balanceRub, 0);

    return (
      <div className="flex flex-col justify-between min-h-full space-y-3">
        <div className="space-y-3">
          <SystemHeaderBox title="МОИ СЧЕТА" onBack={() => navigateState(19)} />

          <div className="text-center py-1 border-b border-white/30">
            <div className="text-[15px] text-white/85">Общий остаток</div>
            <div className="text-[28px] font-extrabold font-tabular">
              <RollingNumber
                value={totalBalance}
                metricKey="finance_total_balance"
                useGrouping
                suffix=" ₽"
              />
            </div>
          </div>

          <div className="text-center text-[14px] text-white/85 font-tabular">
            Активных счетов: {activeAccounts.length} / {user.subscription.active ? '∞' : '3'}
          </div>

          <div className="space-y-2">
            {activeAccounts.map((acc) => {
              const otherAcc = activeAccounts.find((x) => x.id !== acc.id);
              const isConfirming = confirmDeleteKey === `acc_${acc.id}`;
              return (
                <div key={acc.id} className="space-y-1.5">
                  <div className="flex items-stretch gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        setTransferFrom(acc.id);
                        if (otherAcc) setTransferTo(otherAcc.id);
                        navigateState(23);
                      }}
                      className="flex-1 px-3 py-2.5 rounded-[6px] border border-white/75 bg-[#031221] flex items-center justify-between hover:border-[#38e8ff] cursor-pointer min-w-0"
                    >
                      <span className="flex items-center gap-2 text-[15px] font-bold truncate">
                        {acc.type === 'card' ? (
                          <CreditCard className="w-4 h-4 text-[#38e8ff] shrink-0" />
                        ) : acc.type === 'cash' ? (
                          <Wallet className="w-4 h-4 text-[#38e8ff] shrink-0" />
                        ) : (
                          <Coins className="w-4 h-4 text-[#38e8ff] shrink-0" />
                        )}
                        <span className="truncate">{acc.name}</span>
                      </span>
                      <span className="flex items-center gap-1 text-[15px] font-bold font-tabular shrink-0">
                        <RollingNumber
                          value={acc.balanceRub}
                          metricKey={`acc_bal_${acc.id}`}
                          useGrouping
                          suffix=" ₽"
                        />
                        <ChevronRight className="w-4 h-4 text-white/75" />
                      </span>
                    </button>
                    {activeAccounts.length > 1 && (
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() =>
                            apiAction('/api/finance/manage-account', {
                              accountId: acc.id,
                              action: 'archive',
                            })
                          }
                          aria-label={`Архивировать счёт ${acc.name}`}
                          className="px-2 h-full rounded-[6px] border border-white/35 bg-[#031221] text-white/75 hover:border-white hover:text-white cursor-pointer"
                        >
                          <Archive className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setConfirmDeleteKey(isConfirming ? null : `acc_${acc.id}`)
                          }
                          aria-label={`Удалить счёт ${acc.name}`}
                          className="px-2 h-full rounded-[6px] border border-[#ff4d4d]/50 bg-[#2a0509]/80 text-[#ffb3b3] hover:border-[#ff4d4d] cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>

                  {isConfirming && (
                    <div className="p-2 rounded-[6px] border border-[#ff4d4d] bg-[#2a0409] space-y-1.5">
                      <div className="text-[12px] text-[#ffb3b3]">
                        {acc.balanceRub === 0
                          ? `Удалить счёт «${acc.name}» (баланс 0 ₽)?`
                          : otherAcc
                          ? `На счёте ${formatRub(acc.balanceRub)}. Перевести остаток на «${otherAcc.name}» и удалить счёт?`
                          : 'Должен остаться хотя бы один активный счёт.'}
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() =>
                            apiAction('/api/finance/manage-account', {
                              accountId: acc.id,
                              action: 'delete',
                              transferToAccountId: otherAcc?.id,
                            })
                          }
                          className="flex-1 py-1.5 px-2 rounded border border-[#ff4d4d] bg-[#7f1d1d]/85 text-[11.5px] font-bold text-white cursor-pointer"
                        >
                          {acc.balanceRub === 0 ? 'Точно удалить' : 'Перевести и удалить'}
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteKey(null)}
                          className="py-1.5 px-3 rounded border border-white/40 bg-black/40 text-[11.5px] text-white/85 cursor-pointer"
                        >
                          Отмена
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {showNewAccForm && (
            <div className="p-3 rounded-[6px] border border-[#38f8ff] bg-[#04182b]/90 space-y-2">
              <div className="text-[13px] font-bold text-[#72f8ff] uppercase">Новый счёт</div>
              <input
                type="text"
                placeholder="Название (например: Накопительный)"
                value={newAccName}
                onChange={(e) => setNewAccName(e.target.value)}
                className="w-full px-2.5 py-1.5 rounded-[4px] border border-white/60 bg-black/45 text-[14px] text-white"
              />
              <div className="grid grid-cols-2 gap-2">
                <div className="relative">
                  <select
                    value={newAccType}
                    onChange={(e) => setNewAccType(e.target.value as 'card' | 'cash' | 'savings')}
                    className="w-full appearance-none pl-2 pr-7 py-1.5 rounded-[4px] border border-white/60 bg-[#031221] text-[13px] text-white"
                  >
                    <option value="savings">Накопительный</option>
                    <option value="card">Карта</option>
                    <option value="cash">Наличные</option>
                  </select>
                  <ChevronDown className="w-3.5 h-3.5 absolute right-2 top-2 pointer-events-none text-white/80" />
                </div>
                <input
                  type="number"
                  placeholder="Баланс ₽"
                  value={newAccBalance}
                  onChange={(e) => setNewAccBalance(e.target.value)}
                  className="px-2.5 py-1.5 rounded-[4px] border border-white/60 bg-black/45 text-[14px] font-tabular"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <SystemButton
                  label="СОЗДАТЬ"
                  highlighted
                  disabled={busy || !newAccName.trim()}
                  onClick={async () => {
                    await apiAction('/api/finance/create-account', {
                      name: newAccName.trim(),
                      type: newAccType,
                      balanceRub: Number(newAccBalance) || 0,
                    });
                    setShowNewAccForm(false);
                    setNewAccName('');
                    setNewAccBalance('0');
                  }}
                />
                <SystemButton
                  label="Отмена"
                  bracketed={false}
                  onClick={() => setShowNewAccForm(false)}
                />
              </div>
            </div>
          )}

          {archivedAccounts.length > 0 && (
            <div className="pt-1 border-t border-white/25 space-y-1.5">
              <button
                type="button"
                onClick={() => setShowArchivedAccounts((v) => !v)}
                className="w-full py-1 px-1 text-[12px] text-white/75 hover:text-white flex items-center justify-between cursor-pointer"
              >
                <span className="flex items-center gap-1.5">
                  <Archive className="w-3.5 h-3.5 text-[#38e8ff]" />
                  <span>Архив счетов ({archivedAccounts.length})</span>
                </span>
                <ChevronDown
                  className={`w-4 h-4 transition-transform ${showArchivedAccounts ? 'rotate-180' : ''}`}
                />
              </button>
              {showArchivedAccounts && (
                <div className="space-y-1.5">
                  {archivedAccounts.map((aa) => (
                    <div
                      key={aa.id}
                      className="p-2 rounded border border-white/30 bg-black/45 flex items-center justify-between gap-2 text-[12.5px]"
                    >
                      <span className="truncate text-white/80">
                        {aa.name} · {formatRub(aa.balanceRub)}
                      </span>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() =>
                            apiAction('/api/finance/manage-account', {
                              accountId: aa.id,
                              action: 'restore',
                            })
                          }
                          className="px-2 py-1 rounded border border-[#38f8ff]/60 bg-[#062d4a]/70 text-[#9deeff] hover:border-white cursor-pointer flex items-center gap-1"
                        >
                          <RotateCcw className="w-3 h-3" />
                          <span>Вернуть</span>
                        </button>
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() =>
                            apiAction('/api/finance/manage-account', {
                              accountId: aa.id,
                              action: 'delete',
                              transferToAccountId: activeAccounts[0]?.id,
                            })
                          }
                          className="p-1.5 rounded border border-[#ff4d4d]/50 bg-[#2a0509] text-[#ffb3b3] hover:border-[#ff4d4d] cursor-pointer"
                          aria-label="Удалить архивный счёт"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          <div className="text-center text-[13px] text-white/85 border-t border-b border-white/25 py-2">
            В том числе в целях накоплений: {formatRub(user.allocatedToGoalsRub)} (уже учтено в балансе счетов).
          </div>
        </div>

        {!showNewAccForm && (
          <SystemButton
            label="ДОБАВИТЬ СЧЁТ"
            onClick={() => {
              if (!user.subscription.active && activeAccounts.length >= 3) {
                if (openPlusModal) {
                  openPlusModal('accounts');
                } else {
                  setLimitReason?.('accounts');
                  navigateState(46);
                }
              } else {
                setShowNewAccForm(true);
              }
            }}
          />
        )}
      </div>
    );
  }

  // --- ПУСТОТА И ОБРАТНАЯ СВЯЗЬ (States 25, 26, 27) ---
  if (stateId === 25) {
    return (
      <div className="flex flex-col items-center justify-between min-h-full text-center space-y-3">
        <SystemHeaderBox title="СЕГОДНЯ" />

        <div className="my-auto space-y-4 px-2">
          <BookOpen className="w-16 h-16 mx-auto text-white drop-shadow-[0_0_12px_rgba(0,225,255,0.5)] stroke-[1.5]" />
          <h2 className="text-[22px] font-bold leading-snug">
            На сегодня
            <br />
            заданий нет.
          </h2>
          <p className="text-[15px] text-white/85 leading-snug">
            Добавьте задание вручную
            <br />
            или выберите из цели.
          </p>
        </div>

        <div className="w-full space-y-3">
          <SystemButton
            label="ДОБАВИТЬ ЗАДАНИЕ"
            highlighted
            onClick={() => {
              setSelectedTaskId?.(null);
              setSelectedGoalId?.(null);
              navigateState(60);
            }}
          />
          <button
            type="button"
            onClick={() => navigateState(16)}
            className="text-[15px] underline underline-offset-4 text-white/90 hover:text-white cursor-pointer"
          >
            Выбрать из цели
          </button>
        </div>
      </div>
    );
  }

  if (stateId === 26) {
    return (
      <div className="flex flex-col justify-between min-h-full space-y-3">
        <div className="space-y-3">
          <SystemHeaderBox title="РАСХОД" onBack={() => navigateState(21)} />

          <div className="space-y-1">
            <label className="text-[14px] text-white/85">Сумма</label>
            <div className="px-3 py-2.5 rounded-[6px] border border-white/80 bg-[#031221] flex justify-between items-center text-[18px] font-bold font-tabular">
              <span>{expenseAmount}</span>
              <span>₽</span>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[14px] text-white/85">Название</label>
            <div className="px-3 py-2.5 rounded-[6px] border border-white/80 bg-[#031221] text-[16px] font-semibold">
              {expenseTitle}
            </div>
          </div>

          <div className="p-3 rounded-[6px] border-2 border-[#ff4d4d] bg-[#36050a]/90 shadow-[0_0_14px_rgba(255,50,50,0.45)] flex items-center gap-3">
            <div className="w-7 h-7 rounded-full border-2 border-white flex items-center justify-center font-bold shrink-0">
              !
            </div>
            <span className="text-[15px] font-bold text-white">Не удалось сохранить.</span>
          </div>

          <div className="text-center text-[15px] text-white/90">Черновик сохранён.</div>
        </div>

        <div className="space-y-3 text-center">
          <SystemButton
            label="ПОВТОРИТЬ"
            highlighted
            onClick={() =>
              apiAction(
                '/api/finance/commit-batch',
                {
                  idempotencyKey: 'retry_coffee_200',
                  items: [{ title: expenseTitle, category: expenseCategory, amountRub: expenseAmount, accountId: expenseAccount, type: 'expense' }],
                },
                19
              )
            }
          />
          <button
            type="button"
            onClick={() => navigateState(21)}
            className="text-[15px] underline underline-offset-4 text-white/90 hover:text-white cursor-pointer"
          >
            Вернуться к форме
          </button>
        </div>
      </div>
    );
  }

  if (stateId === 27) {
    const bd = user.lastCompletedTaskBreakdown || {
      taskId: 'tsk_reading',
      title: 'Английский · 15 минут',
      baseXp: 30,
      bonusXp: 5,
      bonusName: 'Фокус',
      totalXp: 35,
      goalTitle: '',
      goalProgressText: '',
      goalProgressPercent: 0,
    };

    return (
      <div className="flex flex-col justify-between min-h-full space-y-3">
        <div className="space-y-3">
          <SystemHeaderBox title="СЕГОДНЯ" onBack={() => navigateState(11)} />

          <SystemCheckbox
            checked={true}
            label={bd.title}
            initialBurst={true}
            electricTag={`+${bd.totalXp} XP`}
          />

          <div className="relative overflow-hidden p-3 rounded-[8px] border border-[#38f8ff] bg-[#05233a]/85 shadow-[0_0_16px_rgba(0,225,255,0.4)] text-center space-y-1">
            <ElectricRowArc burstKey={(bd.taskId?.length || 1) + (bd.totalXp || 0)} />
            <div className="relative z-10 text-[20px] font-extrabold font-tabular">
              Получено <RollingNumber value={bd.totalXp} animateFrom={0} suffix=" XP" />
            </div>
            <div className="relative z-10 text-[14px] text-white/90 font-tabular">
              Задание <RollingNumber value={bd.baseXp} animateFrom={0} />{' '}
              {bd.bonusXp > 0 && (
                <>
                  · {bd.bonusName} <RollingNumber value={bd.bonusXp} animateFrom={0} prefix="+" />
                </>
              )}
            </div>
          </div>

          {bd.goalTitle && bd.goalProgressText ? (
            <div className="border-t border-white/30 pt-3 space-y-2.5">
              <div className="text-center text-[15px] text-white/90">Связанная цель</div>
              <div className="flex items-center gap-3">
                <BookOpen className="w-8 h-8 shrink-0" />
                <div className="border-l border-white/35 pl-3">
                  <div className="text-[17px] font-bold">{bd.goalTitle}</div>
                  <div className="text-[14px] text-white/85 font-tabular">{bd.goalProgressText}</div>
                </div>
              </div>
              <SystemProgressBar value={bd.goalProgressPercent} max={100} />
            </div>
          ) : (
            <div className="border-t border-white/25 pt-3 text-center text-[13px] text-white/75">
              Задание выполнено без привязки к цели.
            </div>
          )}
        </div>

        <div className="space-y-2.5 text-center border-t border-white/30 pt-3">
          <SystemButton
            label="ПРОДОЛЖИТЬ"
            highlighted
            onClick={() => navigateState(11)}
          />
          <SystemButton
            label="ОТМЕНИТЬ ВЫПОЛНЕНИЕ"
            bracketed={false}
            onClick={() => apiAction('/api/tasks/toggle', { taskId: bd.taskId }, 11)}
          />
          <p className="text-[12px] text-white/80 leading-snug">
            Отмена вернёт задание в список и снимет полученные XP ({bd.totalXp})
            {bd.goalTitle ? ', а также откатит прогресс цели (−1).' : '.'}
          </p>
        </div>
      </div>
    );
  }

  // --- ХАРАКТЕРИСТИКИ И ПРОФИЛЬ ИГРОКА (States 28, 29, 30) ---
  if (stateId === 28 || stateId === 29) {
    const statRows: Array<{ key: StatKey; label: string }> = [
      { key: 'strength', label: 'Сила' },
      { key: 'endurance', label: 'Выносливость' },
      { key: 'agility', label: 'Ловкость' },
      { key: 'intelligence', label: 'Интеллект' },
      { key: 'perception', label: 'Восприятие' },
    ];

    const pendingTotal = (Object.values(user.pendingStatAdditions) as number[]).reduce((a, b) => a + b, 0);
    const hasPendingSelection = stateId === 29 || pendingTotal > 0;
    const effectiveSelected = pendingTotal;
    const effectiveRemaining = Math.max(0, user.unspentStatPoints - effectiveSelected);

    const curRankInfo = getHunterRankInfo(user.level);
    const nextLevel = user.level + 1;
    const nextRankInfo = getHunterRankInfo(nextLevel);
    const rankPromotesNext = nextRankInfo.rank !== curRankInfo.rank;
    const remainingXpToNext = Math.max(0, user.nextLevelXp - user.currentXp);

    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5 pb-4">
        <div className="space-y-2">
          <SystemHeaderBox
            title="ИГРОК"
            rightAction={
              <button
                type="button"
                onClick={() => navigateState(70)}
                aria-label="Настройки ночного периода и профиля"
                className="p-1 text-white/85 hover:text-[#38e8ff] cursor-pointer"
              >
                <Settings className="w-5 h-5" />
              </button>
            }
          />
          <PlayerTopTabs
            active="status"
            onSelect={switchSubTab}
            soundEnabled={user.soundEnabled}
            hapticsEnabled={user.hapticsEnabled}
          />

          {isQuarantined && (
            <button
              type="button"
              onClick={() => navigateState(40)}
              className="w-full p-2 border border-[#ff4d4d] bg-[#2e050a]/90 flex items-center justify-between gap-2 text-left cursor-pointer hover:border-white"
            >
              <span className="flex items-center gap-2 text-[12px] text-white">
                <Lock className="w-4 h-4 text-[#ff6b6b] shrink-0" />
                <span>Карантин Системы: прокачка заморожена до снятия штрафа</span>
              </span>
              <span className="text-[11px] font-bold text-[#ffb3b3] underline shrink-0">Открыть</span>
            </button>
          )}

          {!hasPendingSelection ? (
            <div className="text-center space-y-2 pb-2.5 border-b border-white/30">
              <div className="space-y-0.5">
                <div className="flex items-center justify-center gap-2">
                  <span className="text-[18px] font-bold">
                    {user.playerCallsign?.trim() || 'Игрок'} · Ур.{' '}
                    <RollingNumber value={user.level} metricKey="player_level" />
                  </span>
                  <span className="px-2 py-0.5 border border-[#38f8ff]/85 bg-[#062d4a] text-[11px] font-bold text-[#72f8ff]">
                    {curRankInfo.rank}
                  </span>
                </div>
                <div className="text-[12.5px] font-semibold text-[#72f8ff]">
                  Титул: «{curRankInfo.title}»{' '}
                  <span className="text-white/45">|</span>{' '}
                  <span className="text-white/80 font-normal">
                    {formatRolesSubtitle(user.roles, user.customRoleText)}
                  </span>
                </div>
              </div>

              {/* Nearest Next-Level XP Indicator */}
              <div className="p-2.5 border border-[#38f8ff]/55 bg-[#031221]/90 space-y-1.5 text-left">
                <div className="flex items-center justify-between gap-2 text-[11.5px]">
                  <span className="font-bold uppercase tracking-[0.06em] text-[#9deeff]">
                    Ближайший уровень: Ур. {user.level} → Ур. {nextLevel}
                  </span>
                  {rankPromotesNext ? (
                    <span className="px-1.5 py-0.5 border border-amber-400/75 bg-[#241705]/90 text-[10px] font-bold text-amber-200 shrink-0">
                      Ранг → {nextRankInfo.rank}
                    </span>
                  ) : (
                    <span className="text-[10.5px] text-white/65 shrink-0">+3 очка статов</span>
                  )}
                </div>

                <SystemProgressBar value={user.currentXp} max={user.nextLevelXp} />

                <div className="flex items-center justify-between text-[12px] font-tabular">
                  <span className="font-bold text-white">
                    <RollingNumber value={user.currentXp} metricKey="player_xp" useGrouping /> /{' '}
                    <RollingNumber value={user.nextLevelXp} useGrouping /> XP
                  </span>
                  <span className="font-semibold text-[#72f8ff]">
                    До апа: <RollingNumber value={remainingXpToNext} useGrouping suffix=" XP" />
                  </span>
                </div>
              </div>

              {/* Prominent Hero Hunter 9:16 Card + Sistema+ & Referral Cards */}
              {onOpenShareCard && (
                <button
                  type="button"
                  onClick={onOpenShareCard}
                  className="w-full min-h-[52px] px-3.5 py-2.5 border border-[#38f8ff] bg-gradient-to-r from-[#062c49] via-[#041d33] to-[#083559] hover:border-white text-left flex items-center justify-between gap-2.5 cursor-pointer shadow-[0_0_16px_rgba(0,225,255,0.28)]"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-9 h-9 border border-[#38f8ff]/70 bg-[#031221] flex items-center justify-center shrink-0">
                      <Share2 className="w-4 h-4 text-[#38f8ff]" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-[14px] font-extrabold text-white truncate">
                        Карточка Охотника · 9:16
                      </div>
                      <div className="text-[11px] text-[#9deeff] truncate">
                        Ранг, Пентаграмма статов и 4 скина для TikTok / Сторис
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#38f8ff] shrink-0" />
                </button>
              )}

              <div className="grid grid-cols-1 gap-2 pt-0.5">
                <button
                  type="button"
                  onClick={() =>
                    user.subscription.active
                      ? navigateState(48)
                      : openPlusModal
                      ? openPlusModal('general')
                      : navigateState(47)
                  }
                  className={`w-full min-h-[54px] px-3.5 py-2.5 border text-left flex items-center justify-between gap-2.5 cursor-pointer ${
                    user.subscription.active
                      ? 'border-amber-400/90 bg-[#1f1505]/90 text-amber-200'
                      : 'border-amber-400/90 bg-gradient-to-r from-[#2b1a04] via-[#1c1b30] to-[#062d4a] text-amber-200 shadow-[0_0_16px_rgba(251,191,36,0.26)] hover:border-amber-300'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Crown className="w-5 h-5 text-amber-400 shrink-0" />
                    <div className="min-w-0">
                      <div className="text-[14px] font-extrabold text-white truncate">
                        {user.subscription.active ? 'Система+ Активна' : 'СИСТЕМА+ · Усилить Игрока'}
                      </div>
                      <div className="text-[11px] text-amber-100/85 truncate">
                        {user.subscription.active
                          ? 'Безлимит целей, Тени ×2 XP и 3 облика открыты'
                          : 'Тени ×2 XP · 3 облика · Сундук ×1.5 · Щит серии'}
                      </div>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 border border-amber-400/75 bg-black/45 text-[12px] font-extrabold text-amber-300 shrink-0">
                    {user.subscription.active ? 'PRO' : '99 ⭐'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    navigateState(user.subscription.referralBonusDaysAvailable > 0 ? 53 : 52)
                  }
                  className="w-full min-h-[48px] px-3.5 py-2 border border-white/45 bg-[#041527]/90 hover:border-[#38e8ff] text-left flex items-center justify-between gap-2.5 cursor-pointer"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Gift className="w-4 h-4 text-[#38e8ff] shrink-0" />
                    <div className="min-w-0">
                      <div className="text-[13.5px] font-bold text-white truncate">
                        Пригласить игрока · +3 дня Системы+
                      </div>
                      <div className="text-[11px] text-white/70 truncate">
                        Отправить личное приглашение в Telegram
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-white/70 shrink-0" />
                </button>
              </div>

              <div className="text-[15px] font-bold pt-1 font-tabular">
                Очки прокачки:{' '}
                <RollingNumber value={user.unspentStatPoints} metricKey="player_unspent" />
              </div>
            </div>
          ) : (
            <div className="text-center text-[15px] font-semibold py-1 border-b border-white/30 font-tabular">
              Выбрано <RollingNumber value={effectiveSelected} metricKey="stats_selected" /> · Осталось{' '}
              <RollingNumber value={effectiveRemaining} metricKey="stats_remaining" />
            </div>
          )}

          <div className="divide-y divide-white/25">
            {statRows.map(({ key, label }) => {
              const baseVal = user.stats[key];
              const pendingAdd = user.pendingStatAdditions[key];
              const highlightedRow = pendingAdd > 0;

              return (
                <div
                  key={key}
                  className={`py-2 px-2 flex items-center justify-between rounded-[5px] ${
                    highlightedRow
                      ? 'border border-[#38f8ff] bg-[#062d4a]/80 shadow-[0_0_12px_rgba(0,225,255,0.4)]'
                      : ''
                  }`}
                >
                  <span className="text-[15px] font-bold">{label}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[16px] font-bold font-tabular flex items-center gap-1.5">
                      <RollingNumber
                        value={baseVal + pendingAdd}
                        metricKey={`stat_val_${key}`}
                        className={pendingAdd > 0 ? 'text-[#72f8ff]' : ''}
                      />
                      {pendingAdd > 0 && (
                        <span className="text-[12px] text-[#38f8ff] font-semibold">
                          (+{pendingAdd})
                        </span>
                      )}
                    </span>
                    <button
                      type="button"
                      disabled={pendingAdd <= 0 || busy}
                      onClick={() => {
                        if (isQuarantined) {
                          navigateState(40);
                          return;
                        }
                        playSystemSound('stat_tick', user.soundEnabled, user.hapticsEnabled);
                        const nextTotal = Math.max(0, pendingTotal - 1);
                        apiAction(
                          '/api/player/stats/preview',
                          { stat: key, delta: -1 },
                          nextTotal === 0 ? 28 : undefined
                        );
                      }}
                      className="w-10 h-10 rounded-[4px] border border-white/75 bg-black/50 flex items-center justify-center text-[17px] font-bold hover:border-[#38e8ff] cursor-pointer disabled:opacity-35 disabled:pointer-events-none"
                    >
                      −
                    </button>
                    <button
                      type="button"
                      disabled={(effectiveRemaining <= 0 && !isQuarantined) || busy}
                      onClick={() => {
                        if (isQuarantined) {
                          navigateState(40);
                          return;
                        }
                        playSystemSound('stat_tick', user.soundEnabled, user.hapticsEnabled);
                        apiAction('/api/player/stats/preview', { stat: key, delta: 1 }, 29);
                      }}
                      className="w-10 h-10 rounded-[4px] border border-white/75 bg-black/50 flex items-center justify-center text-[17px] font-bold hover:border-[#38e8ff] cursor-pointer disabled:opacity-35 disabled:pointer-events-none"
                    >
                      +
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {!hasPendingSelection ? (
          <div className="space-y-2 pt-1">
            {(() => {
              const allSkills = Object.values(user.skills);
              const readySkill = allSkills.find(
                (s) =>
                  s.level < s.maxLevel &&
                  s.requirementsForNext.length > 0 &&
                  s.requirementsForNext.every((r) => r.current >= r.target)
              );
              const featuredSkill = readySkill || user.skills.focus;
              const isReady = Boolean(readySkill);

              return (
                <button
                  type="button"
                  onClick={() => navigateState(31)}
                  className={`w-full p-2.5 rounded-[6px] border text-center space-y-0.5 cursor-pointer ${
                    isReady
                      ? 'border-[#ffd166] bg-[#1a1405]/85 shadow-[0_0_12px_rgba(255,209,102,0.35)]'
                      : 'border-white/60 bg-black/40 hover:border-[#38e8ff]'
                  }`}
                >
                  <div
                    className={`relative text-[12px] border-b pb-1 flex items-center justify-center ${
                      isReady ? 'text-[#ffe599] border-[#ffd166]/35 font-bold' : 'text-white/80 border-white/25'
                    }`}
                  >
                    <span>
                      {isReady ? 'Улучшение доступно · открыть граф навыков' : 'Следующее улучшение'}
                    </span>
                    <ChevronRight className="w-3.5 h-3.5 absolute right-0.5 text-white/60" />
                  </div>
                  <div className="text-[14.5px] font-bold pt-0.5">
                    {featuredSkill.level >= featuredSkill.maxLevel
                      ? `${featuredSkill.name} · Макс. уровень (3 / 3)`
                      : `${featuredSkill.name} · уровень ${featuredSkill.level + 1}`}
                  </div>
                  {featuredSkill.requirementsForNext.length > 0 && (
                    <div className="text-[12px] text-white/90 font-tabular">
                      {featuredSkill.requirementsForNext
                        .map((r) => `${r.label} ${r.current} / ${r.target}`)
                        .join(' · ')}
                    </div>
                  )}
                </button>
              );
            })()}

            {user.trophies && user.trophies.length > 0 && (
              <div className="flex flex-wrap justify-center gap-1.5 pt-0.5">
                {user.trophies.map((trophy) => (
                  <span
                    key={trophy}
                    className="px-2 py-0.5 border border-[#38f8ff]/45 bg-[#04182b]/75 text-[11px] font-semibold text-[#b9fbff]"
                  >
                    ★ {trophy}
                  </span>
                ))}
              </div>
            )}

            {/* Streak + Extracted Shadows Section */}
            {(() => {
              const shadowCount = user.shadows?.length || 0;
              const shadowXpBonus = user.subscription.active
                ? Math.min(40, shadowCount * 10)
                : shadowCount > 0
                ? 5
                : 0;
              return (
                <div className="p-3 rounded-[6px] border border-[#38f8ff]/45 bg-[#031221]/90 space-y-2 text-left">
                  <div className="flex items-center justify-between text-[12.5px] font-tabular">
                    <span className="font-bold text-amber-300 flex items-center gap-1.5">
                      <Flame className="w-4 h-4 text-amber-400" />
                      <span>Серия: {user.streakDays || 0} дн.</span>
                    </span>
                    <span className="text-white/75">
                      Рекорд: {Math.max(user.streakDays || 0, user.bestStreakDays || 0)} дн.
                    </span>
                  </div>

                  <div className="border-t border-white/15 pt-2 space-y-1.5">
                    <div className="flex items-center justify-between text-[11px] uppercase tracking-[0.06em] text-[#9deeff] font-bold">
                      <span className="flex items-center gap-1">
                        <Ghost className="w-3.5 h-3.5 text-[#38e8ff]" />
                        <span>
                          Тени Системы ({shadowCount}
                          {!user.subscription.active ? '/1' : ''})
                        </span>
                      </span>
                      <span>
                        +{shadowXpBonus} XP{user.subscription.active ? ' (×2 PRO)' : ''}
                      </span>
                    </div>
                    {!user.shadows || user.shadows.length === 0 ? (
                      <div className="text-[12px] text-white/75">
                        Завершите цель или серию 7 дней, чтобы извлечь первую Тень.
                      </div>
                    ) : (
                      <div className="flex flex-wrap gap-1.5 pt-0.5">
                        {user.shadows.map((sh) => (
                          <span
                            key={sh.id}
                            className="px-2 py-0.5 border border-[#c084fc]/55 bg-[#1b0833]/75 text-[11px] font-semibold text-[#e9d5ff]"
                          >
                            [{sh.rank}] {sh.name} · {user.subscription.active ? '+10 XP' : sh.bonusText}
                          </span>
                        ))}
                      </div>
                    )}
                    {!user.subscription.active && (
                      <button
                        type="button"
                        onClick={() => openPlusModal?.('feature', 'Безлимитная армия теней (×2 XP)')}
                        className="w-full min-h-[36px] mt-1 px-2.5 py-1.5 border border-amber-400/50 bg-[#1f1404]/70 text-[11.5px] font-semibold text-amber-200 hover:border-amber-300 flex items-center justify-between gap-2 cursor-pointer"
                      >
                        <span>Free-лимит: 1 Тень · Безлимит и ×2 XP в Система+</span>
                        <span className="font-bold text-amber-300">99 ⭐</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })()}

            <button
              type="button"
              onClick={() => navigateState(45)}
              className="w-full min-h-[46px] py-2.5 px-3 rounded-[6px] border border-white/40 bg-black/40 flex items-center justify-between text-[13.5px] font-semibold text-white/85 hover:border-white hover:text-white cursor-pointer"
            >
              <span>История штрафных квестов</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className="p-3 rounded-[6px] border border-white/75 bg-[#031221] space-y-2.5">
            {(() => {
              const affectedSkills = Object.values(user.skills).filter(
                (sk) => (user.pendingStatAdditions[sk.sourceStat] || 0) > 0
              );
              const previewSkills = affectedSkills.length > 0 ? affectedSkills : [user.skills.focus];
              return (
                <div className="space-y-2">
                  {previewSkills.map((sk) => {
                    const addVal = user.pendingStatAdditions[sk.sourceStat] || 0;
                    const projectedStat = user.stats[sk.sourceStat] + addVal;
                    const statReq = sk.requirementsForNext[0];
                    const secondaryReq = sk.requirementsForNext[1];
                    return (
                      <div key={sk.id} className="space-y-1 border-b border-white/15 pb-2 last:border-b-0 last:pb-0">
                        <div className="flex items-center gap-2">
                          <BookOpen className="w-5 h-5 text-[#38e8ff] shrink-0" />
                          <span className="text-[15px] font-bold">
                            {sk.name} ·{' '}
                            {sk.level >= sk.maxLevel
                              ? `Макс. ур. (${sk.maxLevel}/${sk.maxLevel})`
                              : `уровень ${sk.level + 1}`}
                          </span>
                        </div>
                        {statReq ? (
                          <div className="flex items-center gap-2 text-[13px] text-white/95 font-tabular">
                            <Check
                              className={`w-4 h-4 shrink-0 ${
                                projectedStat >= statReq.target ? 'text-[#38f8ff]' : 'text-white/40'
                              }`}
                            />
                            <span>
                              {statReq.label}: {projectedStat} / {statReq.target}
                              {addVal > 0 ? ` (+${addVal})` : ''}
                            </span>
                          </div>
                        ) : (
                          <div className="text-[12.5px] text-white/75">
                            Навык {sk.name} на максимальном уровне
                          </div>
                        )}
                        {secondaryReq && (
                          <div className="space-y-1">
                            <div className="text-[12.5px] text-white/90 font-tabular">
                              {secondaryReq.label}: {secondaryReq.current} / {secondaryReq.target}
                            </div>
                            <SystemProgressBar value={secondaryReq.current} max={secondaryReq.target} />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              );
            })()}
            <SystemButton
              label={
                isQuarantined
                  ? 'СНЯТЬ КАРАНТИН ДЛЯ ЗАЧЁТА'
                  : `ПОДТВЕРДИТЬ · ${effectiveSelected} ${pluralizePoints(effectiveSelected)}`
              }
              palette={isQuarantined ? 'red' : 'blue'}
              highlighted
              disabled={(!isQuarantined && effectiveSelected <= 0) || busy}
              onClick={() =>
                isQuarantined
                  ? navigateState(40)
                  : apiAction('/api/player/stats/commit', {}, 28)
              }
            />
            <div className="text-center">
              <button
                type="button"
                onClick={() => apiAction('/api/player/stats/reset', {}, 28)}
                className="text-[13px] underline underline-offset-4 text-white/85 hover:text-white cursor-pointer"
              >
                Сбросить выбор
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  if (stateId === 30) {
    const rankInfo = getHunterRankInfo(user.level);
    const xpGain = user.lastLevelUpXpGain || 250;
    return (
      <div className="flex flex-col items-center justify-between min-h-full py-2 text-center">
        <div className="w-full space-y-3">
          <SystemSquareIcon kind="alert" />
          <SystemHeaderBox title="УРОВЕНЬ ПОВЫШЕН" />
        </div>

        <div className="w-full space-y-3 my-auto border-t border-b border-white/35 py-4">
          <div className="text-[22px] font-extrabold font-tabular system-text-glow-blue">
            Уровень {Math.max(1, user.level - 1)} →{' '}
            <RollingNumber value={user.level} animateFrom={Math.max(1, user.level - 1)} />
          </div>
          <div className="inline-block px-3 py-0.5 border border-[#38f8ff] bg-[#062d4a] text-[13px] font-bold text-[#72f8ff]">
            [ {rankInfo.rank} · {rankInfo.title} ]
          </div>
          <div className="text-[18px] font-bold text-[#38f8ff] font-tabular">
            <RollingNumber value={xpGain} animateFrom={0} prefix="+" suffix=" XP" />
          </div>
          <div className="text-[18px] font-bold text-white">+3 очка прокачки</div>
        </div>

        <div className="w-full space-y-2">
          <div className="text-[15px] font-tabular">
            Опыт <RollingNumber value={user.currentXp} metricKey="player_xp" useGrouping /> /{' '}
            <RollingNumber value={user.nextLevelXp} useGrouping /> XP
          </div>
          <SystemProgressBar value={user.currentXp} max={user.nextLevelXp} />
        </div>

        <div className="w-full space-y-2 pt-2">
          <SystemButton
            label="РАСПРЕДЕЛИТЬ ОЧКИ"
            highlighted
            onClick={() => navigateState(user.unspentStatPoints > 0 ? 29 : 28)}
          />
          <button
            type="button"
            onClick={() => {
              setSkillsViewMode('graph');
              navigateState(31);
            }}
            className="w-full py-1.5 text-[14px] font-semibold text-[#72f8ff] underline underline-offset-4 hover:text-white cursor-pointer"
          >
            Открыть граф навыков и апгрейдов
          </button>
          <SystemButton label="Продолжить" bracketed={false} onClick={() => navigateState(11)} />
        </div>
      </div>
    );
  }

  // --- НАВЫКИ (States 31..39) ---
  if (stateId === 31) {
    const branches: Array<{ id: SkillBranchId; label: string; stateTarget: number; Icon: React.FC<{ className?: string }> }> = [
      { id: 'impulse', label: 'Импульс', stateTarget: 37, Icon: Zap },
      { id: 'rhythm', label: 'Ритм', stateTarget: 34, Icon: Activity },
      { id: 'focus', label: 'Фокус', stateTarget: 32, Icon: Target },
      { id: 'planning', label: 'Планирование', stateTarget: 35, Icon: Calendar },
      { id: 'control', label: 'Контроль', stateTarget: 36, Icon: Shield },
    ];

    const previewSkill = user.skills[selectedSkillBranch] || user.skills.focus;
    const previewTargetState =
      branches.find((b) => b.id === selectedSkillBranch)?.stateTarget || 32;

    return (
      <div className="flex flex-col justify-between min-h-full space-y-2">
        <div className="space-y-2">
          <SystemHeaderBox
            title="ИГРОК"
            rightAction={
              <button
                type="button"
                onClick={() => navigateState(70)}
                aria-label="Настройки"
                className="p-1 text-white/85 hover:text-[#38e8ff] cursor-pointer"
              >
                <Settings className="w-5 h-5" />
              </button>
            }
          />
          <PlayerTopTabs
            active="skills"
            onSelect={switchSubTab}
            soundEnabled={user.soundEnabled}
            hapticsEnabled={user.hapticsEnabled}
          />

          <div className="flex items-center justify-between gap-2 pt-0.5">
            <span className="text-[13px] font-bold tracking-[0.04em] uppercase text-white/90">
              {skillsViewMode === 'graph' ? 'ГРАФ РАЗВИТИЯ' : 'ВЕТКИ РАЗВИТИЯ'}
            </span>
            <div className="grid grid-cols-2 border border-white/45 rounded-[5px] bg-[#020c18] p-0.5 text-[12px] font-bold">
              <button
                type="button"
                onClick={() => {
                  playSystemSound('ui_step', user.soundEnabled, user.hapticsEnabled);
                  setSkillsViewMode('graph');
                }}
                className={`px-2.5 py-1 rounded-[4px] whitespace-nowrap cursor-pointer transition-colors ${
                  skillsViewMode === 'graph'
                    ? 'bg-[#083b63] text-[#38f8ff] shadow-[0_0_8px_rgba(0,225,255,0.35)]'
                    : 'text-white/75 hover:text-white'
                }`}
              >
                Граф
              </button>
              <button
                type="button"
                onClick={() => {
                  playSystemSound('ui_step', user.soundEnabled, user.hapticsEnabled);
                  setSkillsViewMode('list');
                }}
                className={`px-2.5 py-1 rounded-[4px] whitespace-nowrap cursor-pointer transition-colors ${
                  skillsViewMode === 'list'
                    ? 'bg-[#083b63] text-[#38f8ff] shadow-[0_0_8px_rgba(0,225,255,0.35)]'
                    : 'text-white/75 hover:text-white'
                }`}
              >
                Список
              </button>
            </div>
          </div>

          {skillsViewMode === 'graph' ? (
            <SkillTreeGraph
              user={user}
              busy={busy}
              onSelectBranch={(id) => setSelectedSkillBranch(id)}
              onOpenBranchState={(targetStateId) => navigateState(targetStateId)}
              onUpgradeSkill={async (skillId) => {
                if (isQuarantined) {
                  navigateState(40);
                  return;
                }
                await apiAction('/api/player/skills/upgrade', { skillId });
                if (!user.reducedMotion) {
                  await new Promise((resolve) => setTimeout(resolve, 950));
                }
                navigateState(38);
              }}
              onOpenStatAllocation={() =>
                navigateState(isQuarantined ? 40 : user.unspentStatPoints > 0 ? 29 : 28)
              }
            />
          ) : (
            <div className="space-y-2">
              {branches.map(({ id, label, stateTarget, Icon }) => {
                const selected = id === selectedSkillBranch;
                const branch = user.skills[id];
                const branchLevel = branch?.level ?? 1;
                const isReady =
                  branch &&
                  branch.level < branch.maxLevel &&
                  branch.requirementsForNext.length > 0 &&
                  branch.requirementsForNext.every((r) => r.current >= r.target);

                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => {
                      if (selectedSkillBranch === id) {
                        navigateState(stateTarget);
                      } else {
                        setSelectedSkillBranch(id);
                      }
                    }}
                    className={`w-full px-3 py-2.5 rounded-[6px] border flex items-center justify-between cursor-pointer ${
                      isReady
                        ? 'border-[#ffd166] bg-[#1a1405]/80 shadow-[0_0_12px_rgba(255,209,102,0.35)]'
                        : selected
                          ? 'border-[#38f8ff] bg-[#062d4a]/90 shadow-[0_0_14px_rgba(0,225,255,0.45)]'
                          : 'border-white/65 bg-black/40 hover:border-white'
                    }`}
                  >
                    <span className="flex items-center gap-3 text-[16px] font-bold">
                      <Icon className={`w-5 h-5 ${isReady ? 'text-[#ffd166]' : 'text-[#38e8ff]'}`} />
                      <span>{label}</span>
                    </span>
                    <span className="flex items-center gap-2">
                      {isReady && (
                        <span className="text-[11px] font-bold text-[#ffd166]">Апгрейд</span>
                      )}
                      <span className="text-[12px] text-white/75 font-tabular">Ур. {branchLevel}/3</span>
                      <ChevronRight className="w-5 h-5 text-white/80" />
                    </span>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {skillsViewMode === 'list' && (
          <div className="border-t border-white/30 pt-2.5 text-center space-y-2">
            <div className="text-[18px] font-bold">{previewSkill.name}</div>
            <div className="text-[14px] text-white/90">
              Уровень {previewSkill.level} / {previewSkill.maxLevel} · {previewSkill.currentEffectText}
            </div>
            <SystemButton
              label="ОТКРЫТЬ НАВЫК"
              bracketed={false}
              highlighted
              onClick={() => navigateState(previewTargetState)}
            />
          </div>
        )}
      </div>
    );
  }

  if (stateId === 32) {
    const focusSkill = user.skills.focus;
    const isMax = focusSkill.level >= focusSkill.maxLevel;
    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5">
        <div className="space-y-2.5">
          <SystemHeaderBox title="ИГРОК" onBack={() => navigateState(31)} />
          <PlayerTopTabs active="skills" onSelect={switchSubTab} soundEnabled={user.soundEnabled} hapticsEnabled={user.hapticsEnabled} />
          <SystemHeaderBox title="ФОКУС" />
          <div className="text-center text-[15px] font-bold">
            Уровень {focusSkill.level} / {focusSkill.maxLevel}
          </div>

          <div className="border-t border-b border-white/30 py-2.5 space-y-2 text-[14px]">
            <div className="flex items-center gap-3">
              <span className="px-2 py-0.5 rounded border border-white font-bold text-[12px]">XP</span>
              <span>{focusSkill.currentEffectText}</span>
            </div>
            <div className="flex items-center gap-3">
              <Calendar className="w-5 h-5 text-[#38e8ff] shrink-0" />
              <span>До 3 раз в день</span>
            </div>
          </div>

          <div className="space-y-1 border-b border-white/25 pb-2">
            <div className="text-[15px] font-bold">Почему это полезно</div>
            <div className="text-[14px] text-white/85">Работа над одной задачей.</div>
          </div>

          <div className="space-y-1 border-b border-white/25 pb-2">
            <div className="text-[15px] font-bold">Следующий уровень</div>
            <div className="text-[14px] text-white/85">
              {focusSkill.level === 1
                ? 'Две сессии с перерывом · +10 XP'
                : focusSkill.level === 2
                ? 'Цепочка из 3 сессий · +15 XP'
                : 'Максимальный уровень навыка достигнут'}
            </div>
          </div>

          {!isMax && (
            <button
              type="button"
              onClick={() => navigateState(focusSkill.level === 2 ? 39 : 33)}
              className="w-full py-2 px-3 rounded border border-white/40 bg-black/30 flex items-center justify-between text-[14px] font-bold text-[#38e8ff] hover:border-[#38e8ff] cursor-pointer"
            >
              <span>Условия перехода на уровень {focusSkill.level + 1}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>

        <SystemButton
          label="НАЧАТЬ СЕССИЮ"
          highlighted
          onClick={() => apiAction('/api/tasks/start-focus', {}, 59)}
        />
      </div>
    );
  }

  if (stateId === 33) {
    const focusSkill = user.skills.focus;
    const reqs = focusSkill.requirementsForNext;
    const intReq = reqs[0] || { label: 'Интеллект', current: user.stats.intelligence, target: 14 };
    const sessReq = reqs[1] || { label: 'Сессии', current: 9, target: 10 };
    const canUpgrade =
      focusSkill.level < focusSkill.maxLevel &&
      reqs.every((r) => r.current >= r.target);

    return (
      <div className="flex flex-col justify-between min-h-full space-y-3">
        <div className="space-y-2.5">
          <SystemHeaderBox title="ИГРОК" />
          <PlayerTopTabs active="skills" onSelect={switchSubTab} soundEnabled={user.soundEnabled} hapticsEnabled={user.hapticsEnabled} />
          <SystemHeaderBox
            title={`ДО УРОВНЯ ${Math.min(3, focusSkill.level + 1)}`}
            onBack={() => navigateState(32)}
          />

          <div className="divide-y divide-white/25">
            <SystemCheckbox
              checked={intReq.current >= intReq.target}
              label={intReq.label}
              rightSlot={
                <span className="font-bold font-tabular">
                  <RollingNumber value={intReq.current} metricKey="skill_req_focus_int" /> / {intReq.target}
                </span>
              }
            />
            <SystemCheckbox
              checked={sessReq.current >= sessReq.target}
              label={sessReq.label}
              rightSlot={
                <span className="font-bold font-tabular">
                  <RollingNumber value={sessReq.current} metricKey="skill_req_focus_sess" /> / {sessReq.target}
                </span>
              }
            />
          </div>

          <SystemProgressBar value={sessReq.current} max={sessReq.target} showCenterPercent />
          <div className="text-center text-[14px] text-white/90">
            {sessReq.current >= sessReq.target
              ? 'Все сессии выполнены'
              : `Осталось сессий: ${Math.max(0, sessReq.target - sessReq.current)}`}
          </div>

          <div className="border-t border-white/30 pt-2.5 text-center space-y-1">
            <div className="text-[16px] font-bold">Уровень 3</div>
            <div className="text-[14px] text-white/85">три сессии и +15 XP</div>
          </div>
        </div>

        {canUpgrade ? (
          <SystemButton
            label="УЛУЧШИТЬ НАВЫК"
            highlighted
            onClick={() => apiAction('/api/player/skills/upgrade', { skillId: 'focus' }, 38)}
          />
        ) : (
          <SystemButton
            label="НАЧАТЬ СЕССИЮ"
            highlighted
            onClick={() => apiAction('/api/tasks/start-focus', {}, 59)}
          />
        )}
      </div>
    );
  }

  if (stateId === 34) {
    const skill = user.skills.rhythm;
    const canUpgrade =
      skill.level < skill.maxLevel &&
      skill.requirementsForNext.every((r) => r.current >= r.target);
    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5">
        <div className="space-y-2.5">
          <SystemHeaderBox title="ИГРОК" onBack={() => navigateState(31)} />
          <PlayerTopTabs active="skills" onSelect={switchSubTab} soundEnabled={user.soundEnabled} hapticsEnabled={user.hapticsEnabled} />

          <div className="flex items-center gap-3 pb-2 border-b border-white/30">
            <SystemSquareIcon kind="shield" />
            <div>
              <div className="text-[19px] font-bold">РИТМ</div>
              <div className="text-[14px] text-white/85">Уровень {skill.level} / {skill.maxLevel}</div>
            </div>
          </div>

          <div className="space-y-1">
            <div className="text-[16px] font-bold">{skill.currentEffectText}</div>
            <div className="text-[14px] text-white/85">Сохраняет серию при одном пропуске.</div>
          </div>

          <div className="p-2.5 rounded-[6px] border border-white/60 bg-black/40 flex items-center gap-2.5 text-[13px]">
            <Info className="w-5 h-5 text-[#38e8ff] shrink-0" />
            <span>Пропуск остаётся в истории. Штрафной квест сохраняется.</span>
          </div>

          <div className="divide-y divide-white/25 text-[14px] border-t border-b border-white/25">
            {skill.requirementsForNext.map((r) => (
              <div key={r.id} className="py-1.5 flex items-center justify-between">
                <span>Условие ({r.label})</span>
                <span className="font-bold font-tabular">
                  <RollingNumber value={r.current} metricKey={`skill_req_rhythm_${r.id}`} /> / {r.target}
                </span>
              </div>
            ))}
            <div className="py-1.5 flex items-center gap-2">
              <Activity className="w-4 h-4 text-[#38e8ff]" />
              <span>Источник: <strong>{skill.sourceStatName}</strong></span>
            </div>
          </div>
        </div>

        {canUpgrade ? (
          <SystemButton
            label="УЛУЧШИТЬ НАВЫК"
            highlighted
            onClick={() => apiAction('/api/player/skills/upgrade', { skillId: 'rhythm' }, 38)}
          />
        ) : (
          <SystemButton label="ОТКРЫТЬ ИСТОРИЮ" bracketed={false} onClick={() => navigateState(15)} />
        )}
      </div>
    );
  }

  if (stateId === 35) {
    const skill = user.skills.planning;
    const canUpgrade =
      skill.level < skill.maxLevel &&
      skill.requirementsForNext.every((r) => r.current >= r.target);
    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5">
        <div className="space-y-2.5">
          <SystemHeaderBox title="ИГРОК" onBack={() => navigateState(31)} />
          <PlayerTopTabs active="skills" onSelect={switchSubTab} soundEnabled={user.soundEnabled} hapticsEnabled={user.hapticsEnabled} />

          <div className="flex items-center gap-3 pb-2 border-b border-white/30">
            <SystemSquareIcon kind="calendar" />
            <div>
              <div className="text-[19px] font-bold">ПЛАНИРОВАНИЕ</div>
              <div className="text-[14px] text-white/85">Уровень {skill.level} / {skill.maxLevel}</div>
            </div>
          </div>

          <div className="space-y-1">
            <div className="text-[16px] font-bold">{skill.currentEffectText}</div>
            <div className="text-[14px] text-white/85">
              Система предлагает первое незавершённое действие.
            </div>
          </div>

          <div className="divide-y divide-white/25 text-[14px] border-t border-b border-white/25">
            {skill.requirementsForNext.map((r) => (
              <div key={r.id} className="py-1.5 flex items-center justify-between">
                <span>Условие ({r.label})</span>
                <span className="font-bold font-tabular">
                  <RollingNumber value={r.current} metricKey={`skill_req_planning_${r.id}`} /> / {r.target}
                </span>
              </div>
            ))}
            <div className="py-1.5 flex items-center gap-2">
              <Zap className="w-4 h-4 text-[#38e8ff]" />
              <span>Источник: <strong>{skill.sourceStatName}</strong></span>
            </div>
          </div>

          {canUpgrade ? (
            <SystemButton
              label="УЛУЧШИТЬ НАВЫК"
              highlighted
              onClick={() => apiAction('/api/player/skills/upgrade', { skillId: 'planning' }, 38)}
            />
          ) : (
            <SystemButton label="ВЫБРАТЬ ЦЕЛЬ" highlighted onClick={() => navigateState(16)} />
          )}
        </div>

        <div className="p-2.5 rounded-[6px] border border-white/50 bg-black/40 flex items-center gap-2.5 text-[12px] text-white/85">
          <Info className="w-4 h-4 text-[#38e8ff] shrink-0" />
          <span>Ручное редактирование задач и целей доступно без этого навыка.</span>
        </div>
      </div>
    );
  }

  if (stateId === 36) {
    const skill = user.skills.control;
    const canUpgrade =
      skill.level < skill.maxLevel &&
      skill.requirementsForNext.every((r) => r.current >= r.target);
    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5">
        <div className="space-y-2.5">
          <SystemHeaderBox title="ИГРОК" onBack={() => navigateState(31)} />
          <PlayerTopTabs active="skills" onSelect={switchSubTab} soundEnabled={user.soundEnabled} hapticsEnabled={user.hapticsEnabled} />

          <div className="flex items-center gap-3 pb-2 border-b border-white/30">
            <SystemSquareIcon kind="coins" />
            <div>
              <div className="text-[19px] font-bold">КОНТРОЛЬ</div>
              <div className="text-[14px] text-white/85">Уровень {skill.level} / {skill.maxLevel}</div>
            </div>
          </div>

          <div className="space-y-1">
            <div className="text-[16px] font-bold">Проверка финансового учёта</div>
            <div className="text-[14px] text-white/90">{skill.currentEffectText}</div>
          </div>

          <div className="p-2 rounded-[6px] border border-white/50 bg-black/40 flex items-center gap-2 text-[13px]">
            <Info className="w-4 h-4 text-[#38e8ff] shrink-0" />
            <span>Не чаще 1 раза в день.</span>
          </div>

          <div className="divide-y divide-white/25 text-[14px] border-t border-b border-white/25">
            {skill.requirementsForNext.map((r) => (
              <div key={r.id} className="py-1.5 flex items-center justify-between">
                <span>Условие ({r.label})</span>
                <span className="font-bold font-tabular">
                  <RollingNumber value={r.current} metricKey={`skill_req_control_${r.id}`} /> / {r.target}
                </span>
              </div>
            ))}
            <div className="py-1.5 flex items-center gap-2">
              <Eye className="w-4 h-4 text-[#38e8ff]" />
              <span>Источник: <strong>{skill.sourceStatName}</strong></span>
            </div>
          </div>

          {canUpgrade ? (
            <SystemButton
              label="УЛУЧШИТЬ НАВЫК"
              highlighted
              onClick={() => apiAction('/api/player/skills/upgrade', { skillId: 'control' }, 38)}
            />
          ) : (
            <SystemButton
              label="ПРОВЕРИТЬ ЗАПИСИ"
              highlighted
              onClick={() => apiAction('/api/finance/reconcile', {}, 19)}
            />
          )}
        </div>

        <div className="p-2.5 rounded-[6px] border border-white/50 bg-black/40 flex items-center gap-2.5 text-[12px] text-white/85">
          <Info className="w-4 h-4 text-[#38e8ff] shrink-0" />
          <span>XP не начисляется за траты или пополнения.</span>
        </div>
      </div>
    );
  }

  if (stateId === 37) {
    const skill = user.skills.impulse;
    const canUpgrade =
      skill.level < skill.maxLevel &&
      skill.requirementsForNext.every((r) => r.current >= r.target);
    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5">
        <div className="space-y-2.5">
          <SystemHeaderBox title="ИГРОК" onBack={() => navigateState(31)} />
          <PlayerTopTabs active="skills" onSelect={switchSubTab} soundEnabled={user.soundEnabled} hapticsEnabled={user.hapticsEnabled} />

          <div className="flex items-center gap-3 pb-2 border-b border-white/30">
            <SystemSquareIcon kind="double-up" />
            <div>
              <div className="text-[19px] font-bold">ИМПУЛЬС</div>
              <div className="text-[14px] text-white/85">Уровень {skill.level} / {skill.maxLevel}</div>
            </div>
          </div>

          <div className="py-1.5 border-b border-white/25 text-[15px]">
            Источник: <strong>{skill.sourceStatName}</strong>
          </div>

          <div className="text-[15px] text-white/95 leading-snug py-1 border-b border-white/25">
            {skill.currentEffectText}
          </div>

          <div className="space-y-1 text-[14px] text-white/85">
            {skill.requirementsForNext.map((r) => (
              <div key={r.id} className="flex justify-between">
                <span>{r.label}:</span>
                <span className="font-bold text-white font-tabular">
                  <RollingNumber value={r.current} metricKey={`skill_req_impulse_${r.id}`} /> / {r.target}
                </span>
              </div>
            ))}
          </div>
        </div>

        {canUpgrade ? (
          <SystemButton
            label="УЛУЧШИТЬ НАВЫК"
            highlighted
            onClick={() => apiAction('/api/player/skills/upgrade', { skillId: 'impulse' }, 38)}
          />
        ) : (
          <SystemButton label="ВЫБРАТЬ ЗАДАНИЕ" highlighted onClick={() => navigateState(11)} />
        )}
      </div>
    );
  }

  if (stateId === 38) {
    const upgSkill = user.skills[user.lastUpgradedSkillId || 'focus'] || user.skills.focus;
    return (
      <div className="flex flex-col justify-between min-h-full space-y-3">
        <div className="space-y-2.5">
          <SystemHeaderBox title="ИГРОК" />
          <PlayerTopTabs active="skills" onSelect={switchSubTab} soundEnabled={user.soundEnabled} hapticsEnabled={user.hapticsEnabled} />

          <div className="flex items-center gap-3 py-1">
            <div className="w-10 h-10 border border-white flex items-center justify-center shrink-0">
              <Check className="w-6 h-6" />
            </div>
            <div className="flex-1 py-2 px-3 border border-white/85 text-center font-bold text-[16px]">
              НАВЫК УЛУЧШЕН
            </div>
          </div>

          <div className="text-center text-[19px] font-bold border-t border-b border-white/30 py-2">
            {upgSkill.name} · уровень {upgSkill.level}
          </div>

          <div className="space-y-2 text-[15px] py-1">
            <div className="flex items-center gap-2.5">
              <Zap className="w-5 h-5 text-[#38e8ff]" />
              <span>{upgSkill.currentEffectText}</span>
            </div>
            <div className="flex items-center gap-2.5">
              <Target className="w-5 h-5 text-[#38e8ff]" />
              <span>Источник: {upgSkill.sourceStatName}</span>
            </div>
          </div>

          <div className="border-t border-white/30 pt-2">
            <div className="text-center text-[14px] text-white/85 pb-1">
              {upgSkill.level >= upgSkill.maxLevel ? 'Достигнут максимальный уровень' : 'Следующие требования'}
            </div>
            {upgSkill.requirementsForNext.map((r) => (
              <SystemCheckbox
                key={r.id}
                checked={r.current >= r.target}
                label={`${r.label}  ${r.current} / ${r.target}`}
              />
            ))}
          </div>
        </div>

        <SystemButton label="ПРОДОЛЖИТЬ" highlighted onClick={() => navigateState(31)} />
      </div>
    );
  }

  const focusLv3Reqs = user.skills.focus.requirementsForNext;
  const canUpgradeLv3 =
    user.skills.focus.level === 2 &&
    focusLv3Reqs.length > 0 &&
    focusLv3Reqs.every((r) => r.current >= r.target);

  return (
    <div className="flex flex-col justify-between min-h-full space-y-3">
      <div className="space-y-2.5">
        <SystemHeaderBox title="ИГРОК" onBack={() => navigateState(32)} />
        <PlayerTopTabs active="skills" onSelect={switchSubTab} soundEnabled={user.soundEnabled} hapticsEnabled={user.hapticsEnabled} />

        <div className="flex items-center gap-3 pb-2 border-b border-white/30">
          <SystemSquareIcon kind="target" />
          <div className="text-[18px] font-bold">ФОКУС · УРОВЕНЬ 3</div>
        </div>

        <div className="space-y-1.5 text-[15px] border-b border-white/30 pb-2.5">
          <div>• +15 XP</div>
          <div>• Цепочка из 3 сессий</div>
        </div>

        <div>
          <div className="text-center text-[15px] font-bold pb-1">Требования</div>
          <SystemCheckbox
            checked={user.stats.intelligence >= 18}
            label={`Интеллект  ${user.stats.intelligence} / 18`}
          />
          <SystemCheckbox
            checked={(focusLv3Reqs[1]?.current ?? 0) >= (focusLv3Reqs[1]?.target ?? 25)}
            label={`Сессии  ${focusLv3Reqs[1]?.current ?? 10} / ${focusLv3Reqs[1]?.target ?? 25}`}
          />
        </div>
      </div>

      <div className="space-y-2">
        {canUpgradeLv3 ? (
          <SystemButton
            label="УЛУЧШИТЬ НАВЫК"
            highlighted
            onClick={() => apiAction('/api/player/skills/upgrade', { skillId: 'focus' }, 38)}
          />
        ) : (
          <SystemButton label="К ХАРАКТЕРИСТИКАМ" highlighted onClick={() => navigateState(28)} />
        )}
        <SystemButton
          label="Начать сессию"
          bracketed={false}
          onClick={() =>
            isQuarantined ? navigateState(40) : apiAction('/api/tasks/start-focus', {}, 59)
          }
        />
      </div>
    </div>
  );
});
