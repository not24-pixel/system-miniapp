import React, { memo, useEffect, useRef } from 'react';
import { Calendar, Target, CheckSquare, Coins, User } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { MainTabId, SystemPalette } from '../shared/types';
import { playSystemSound, triggerSystemHaptic } from '../shared/sound';
import { ManaParticleEmitter } from './ManaParticleEmitter';
import { SystemMetricsProvider } from './RollingNumber';
import { ElectricFrameSurge } from './ElectricBurst';

interface SystemFrameProps {
  stateId?: number;
  palette: SystemPalette;
  monarchTheme?: boolean;
  hudTheme?: 'blue' | 'monarch' | 'igris' | 'sovereign';
  activeTab: MainTabId | null;
  onSelectTab?: (tab: MainTabId) => void;
  reducedMotion?: boolean;
  soundEnabled?: boolean;
  hapticsEnabled?: boolean;
  manaPulse?: number;
  electricPulse?: number;
  topSlot?: React.ReactNode;
  children: React.ReactNode;
}

const DRAMATIC_UNFOLD_STATES = new Set([1, 2, 3, 9, 10, 18, 30, 38, 40, 43, 44]);
const RED_GLITCH_STATES = new Set([2, 40, 44, 71, 72]);

export const SystemFrame: React.FC<SystemFrameProps> = memo(({
  stateId = 1,
  palette,
  monarchTheme = false,
  hudTheme,
  activeTab,
  onSelectTab,
  reducedMotion = false,
  soundEnabled = true,
  hapticsEnabled = true,
  manaPulse = 0,
  electricPulse = 0,
  topSlot = null,
  children,
}) => {
  const isRed = palette === 'red';
  const activeSkin: 'blue' | 'monarch' | 'igris' | 'sovereign' = isRed
    ? 'blue'
    : hudTheme || (monarchTheme ? 'monarch' : 'blue');
  const isMonarch = !isRed && activeSkin === 'monarch';
  const isIgris = !isRed && activeSkin === 'igris';
  const isSovereign = !isRed && activeSkin === 'sovereign';

  const primaryStroke = isRed
    ? '#ff2a2a'
    : isMonarch
    ? '#a855f7'
    : isIgris
    ? '#f43f5e'
    : isSovereign
    ? '#f59e0b'
    : '#00e5ff';
  const secondaryStroke = isRed
    ? '#ff8080'
    : isMonarch
    ? '#d8b4fe'
    : isIgris
    ? '#fda4af'
    : isSovereign
    ? '#fde68a'
    : '#7dd3fc';
  const outerBorderClass = isRed
    ? 'border-[#ff3b3b] shadow-[0_0_24px_rgba(255,30,30,0.45),inset_0_0_18px_rgba(255,30,30,0.22)]'
    : isMonarch
    ? 'border-[#a855f7] shadow-[0_0_24px_rgba(168,85,247,0.42),inset_0_0_18px_rgba(168,85,247,0.2)]'
    : isIgris
    ? 'border-[#f43f5e] shadow-[0_0_24px_rgba(244,63,94,0.42),inset_0_0_18px_rgba(244,63,94,0.2)]'
    : isSovereign
    ? 'border-[#f59e0b] shadow-[0_0_24px_rgba(245,158,11,0.42),inset_0_0_18px_rgba(245,158,11,0.2)]'
    : 'border-[#00e1ff] shadow-[0_0_24px_rgba(0,225,255,0.4),inset_0_0_18px_rgba(0,225,255,0.18)]';

  const isDramaticState = DRAMATIC_UNFOLD_STATES.has(stateId);
  const isRedGlitch = RED_GLITCH_STATES.has(stateId);

  const scrollContainerRef = useRef<HTMLDivElement | null>(null);
  const lastScrollYRef = useRef<number>(0);
  const lastScrollSoundTsRef = useRef<number>(0);
  const lastHapticYRef = useRef<number>(0);
  const suppressScrollUntilRef = useRef<number>(0);

  // Reset scroll container cleanly on screen change without firing spurious scroll ticks
  useEffect(() => {
    suppressScrollUntilRef.current = Date.now() + 240;
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTop = 0;
    }
    lastScrollYRef.current = 0;
    lastHapticYRef.current = 0;
  }, [stateId]);

  const handleContentScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const now = Date.now();
    if (now < suppressScrollUntilRef.current) return;

    const currentY = e.currentTarget.scrollTop;
    const deltaY = Math.abs(currentY - lastScrollYRef.current);

    if (deltaY >= 64 && now - lastScrollSoundTsRef.current >= 70) {
      lastScrollYRef.current = currentY;
      lastScrollSoundTsRef.current = now;
      playSystemSound('scroll_tick', soundEnabled, false);

      if (hapticsEnabled && Math.abs(currentY - lastHapticYRef.current) >= 180) {
        lastHapticYRef.current = currentY;
        triggerSystemHaptic('scroll_tick', true);
      }
    }
  };

  const tabs: Array<{ id: MainTabId; label: string; Icon: React.FC<{ className?: string }> }> = [
    { id: 'today', label: 'Сегодня', Icon: Calendar },
    { id: 'goals', label: 'Цели', Icon: Target },
    { id: 'habits', label: 'Привычки', Icon: CheckSquare },
    { id: 'finance', label: 'Финансы', Icon: Coins },
    { id: 'player', label: 'Игрок', Icon: User },
  ];

  const frameAnimKey = isDramaticState ? `dramatic_${stateId}` : `steady_${palette}`;

  return (
    <div className="relative w-full max-w-[430px] mx-auto h-[100dvh] sm:h-[844px] sm:max-h-[94dvh] flex items-center justify-center overflow-hidden">
      <div className="w-full h-full flex items-center justify-center">
        <AnimatePresence mode="wait">
          <motion.div
            key={frameAnimKey}
            initial={
              reducedMotion
                ? { opacity: 1 }
                : isDramaticState
                ? { scaleY: 0.08, scaleX: 0.92, opacity: 0.4 }
                : { opacity: 0.95 }
            }
            animate={
              reducedMotion
                ? { opacity: 1 }
                : {
                    scaleY: 1,
                    scaleX: 1,
                    opacity: 1,
                    x: isRedGlitch ? [0, -6, 5, -3, 0] : 0,
                  }
            }
            transition={{
              scaleX: { duration: 0.14, ease: [0.16, 1, 0.3, 1] },
              scaleY: { duration: 0.22, ease: [0.16, 1, 0.3, 1] },
              opacity: { duration: 0.14 },
              x: { duration: 0.28, ease: 'easeInOut' },
            }}
            className={`relative w-full h-full flex flex-col justify-between sm:rounded-[8px] border-2 ${outerBorderClass} ${
              isRed
                ? 'system-glass-red'
                : isMonarch
                ? 'system-glass-monarch'
                : isIgris
                ? 'system-glass-igris'
                : isSovereign
                ? 'system-glass-sovereign'
                : 'system-glass-blue'
            } select-none overflow-hidden`}
          >
            {/* Static Coordinate Grid Planes (zero rAF / zero layout reflow) */}
            <div
              aria-hidden="true"
              className={`pointer-events-none absolute inset-0 z-0 ${
                isRed
                  ? 'system-grid-diag-red'
                  : isMonarch
                  ? 'system-grid-diag-monarch'
                  : isIgris
                  ? 'system-grid-diag-igris'
                  : isSovereign
                  ? 'system-grid-diag-sovereign'
                  : 'system-grid-diag-blue'
              }`}
            />
            <div
              aria-hidden="true"
              className={`pointer-events-none absolute inset-0 z-0 ${
                isRed
                  ? 'system-grid-red'
                  : isMonarch
                  ? 'system-grid-monarch'
                  : isIgris
                  ? 'system-grid-igris'
                  : isSovereign
                  ? 'system-grid-sovereign'
                  : 'system-grid-blue'
              }`}
            />

            {/* Crimson Bloodlust Vignette for Red Shift states */}
            {isRed && (
              <div className="pointer-events-none absolute inset-0 z-0 system-bloodlust-vignette opacity-60" />
            )}

            {/* Lightweight Canvas Mana Particle Emitter */}
            <ManaParticleEmitter
              palette={palette}
              reducedMotion={reducedMotion}
              burstKey={isDramaticState ? `burst_${stateId}` : `${palette}_${activeSkin}`}
              pulseKey={manaPulse}
              density={isRed ? 16 : 12}
            />

            {/* Electric Discharge Corner & Rim Arcs on task/habit/XP completion */}
            <ElectricFrameSurge burstKey={electricPulse} palette={palette} />

            {/* Top Geometric SVG Frame & Crystalline Center Node (lightweight 2-pass stroke, no feGaussianBlur) */}
            <svg
              className="pointer-events-none absolute top-0 left-0 right-0 w-full h-9 z-20"
              viewBox="0 0 400 36"
              fill="none"
              preserveAspectRatio="none"
            >
              <path
                d="M 2 24 L 14 10 L 88 10 L 98 18 L 155 18 L 168 4 L 232 4 L 245 18 L 302 18 L 312 10 L 386 10 L 398 24"
                stroke={primaryStroke}
                strokeWidth="5"
                strokeOpacity="0.22"
              />
              <path
                d="M 2 24 L 14 10 L 88 10 L 98 18 L 155 18 L 168 4 L 232 4 L 245 18 L 302 18 L 312 10 L 386 10 L 398 24"
                stroke={primaryStroke}
                strokeWidth="1.85"
              />
              <path
                d="M 18 14 L 84 14 L 94 22 L 306 22 L 316 14 L 382 14"
                stroke={secondaryStroke}
                strokeWidth="0.95"
                strokeOpacity="0.85"
              />
              <polygon
                points="174,2 226,2 216,18 184,18"
                fill={primaryStroke}
                fillOpacity="0.52"
                stroke="#ffffff"
                strokeWidth="1.25"
              />
              <polyline
                points="182,3 196,15 206,6 218,16"
                stroke="#ffffff"
                strokeWidth="1.2"
                strokeOpacity="0.92"
              />
              <rect x="6" y="4" width="18" height="3" fill="#ffffff" fillOpacity="0.85" />
              <rect x="376" y="4" width="18" height="3" fill="#ffffff" fillOpacity="0.85" />
            </svg>

            {/* Left & Right Inner Double Contour Hairlines + Corner Brackets */}
            <div
              className={`pointer-events-none absolute inset-x-[7px] top-[18px] bottom-[15px] border ${
                isRed
                  ? 'border-[#ff4d4d]/50'
                  : isMonarch
                  ? 'border-[#a855f7]/55'
                  : isIgris
                  ? 'border-[#f43f5e]/55'
                  : isSovereign
                  ? 'border-[#f59e0b]/55'
                  : 'border-[#38e8ff]/50'
              } z-10`}
            >
              <span
                className={`absolute -top-[1px] -left-[1px] w-3 h-3 border-t-2 border-l-2 ${
                  isRed
                    ? 'border-[#ff9999]'
                    : isMonarch
                    ? 'border-[#e9d5ff]'
                    : isIgris
                    ? 'border-[#fecdd3]'
                    : isSovereign
                    ? 'border-[#fef3c7]'
                    : 'border-white'
                }`}
              />
              <span
                className={`absolute -top-[1px] -right-[1px] w-3 h-3 border-t-2 border-r-2 ${
                  isRed
                    ? 'border-[#ff9999]'
                    : isMonarch
                    ? 'border-[#e9d5ff]'
                    : isIgris
                    ? 'border-[#fecdd3]'
                    : isSovereign
                    ? 'border-[#fef3c7]'
                    : 'border-white'
                }`}
              />
              <span
                className={`absolute -bottom-[1px] -left-[1px] w-3 h-3 border-b-2 border-l-2 ${
                  isRed
                    ? 'border-[#ff9999]'
                    : isMonarch
                    ? 'border-[#e9d5ff]'
                    : isIgris
                    ? 'border-[#fecdd3]'
                    : isSovereign
                    ? 'border-[#fef3c7]'
                    : 'border-white'
                }`}
              />
              <span
                className={`absolute -bottom-[1px] -right-[1px] w-3 h-3 border-b-2 border-r-2 ${
                  isRed
                    ? 'border-[#ff9999]'
                    : isMonarch
                    ? 'border-[#e9d5ff]'
                    : isIgris
                    ? 'border-[#fecdd3]'
                    : isSovereign
                    ? 'border-[#fef3c7]'
                    : 'border-white'
                }`}
              />
            </div>

            {/* Foreground UI Plane */}
            <div className="relative z-10 flex-1 flex flex-col justify-between min-h-0">
              {/* Pinned non-scrolling Top Slot (Global Search Bar) */}
              {topSlot}

              {/* Main Scrollable Content Area */}
              <div
                ref={scrollContainerRef}
                onScroll={handleContentScroll}
                className={`relative z-10 flex-1 min-h-0 overflow-y-auto px-5 ${
                  topSlot ? 'pt-2' : 'pt-9'
                } pb-5 system-scroll ${
                  isRed
                    ? 'system-scroll-red'
                    : isMonarch
                    ? 'system-scroll-monarch'
                    : isIgris
                    ? 'system-scroll-igris'
                    : isSovereign
                    ? 'system-scroll-sovereign'
                    : 'system-scroll-blue'
                }`}
              >
                <SystemMetricsProvider
                  reducedMotion={reducedMotion}
                  palette={palette}
                  monarchTheme={isMonarch}
                  hudTheme={activeSkin}
                >
                  {children}
                </SystemMetricsProvider>
              </div>

              {/* Bottom 5-Tab Navigation Dock */}
              {activeTab !== null && (
                <nav
                  aria-label="Навигация"
                  className="relative z-20 mx-[12px] mb-[19px] border border-white/75 bg-[#020812]/95 grid grid-cols-5"
                >
                  {tabs.map(({ id, label, Icon }) => {
                    const isActive = activeTab === id;
                    const activeBg = isRed
                      ? 'bg-gradient-to-b from-[#ff2a2a]/55 via-[#99000d]/50 to-[#ff2a2a]/65 shadow-[inset_0_0_12px_rgba(255,60,60,0.75)]'
                      : isMonarch
                      ? 'bg-gradient-to-b from-[#a855f7]/55 via-[#581c87]/50 to-[#c084fc]/65 shadow-[inset_0_0_12px_rgba(168,85,247,0.75)]'
                      : isIgris
                      ? 'bg-gradient-to-b from-[#f43f5e]/55 via-[#881337]/50 to-[#fb7185]/65 shadow-[inset_0_0_12px_rgba(244,63,94,0.75)]'
                      : isSovereign
                      ? 'bg-gradient-to-b from-[#f59e0b]/55 via-[#78350f]/50 to-[#fbbf24]/65 shadow-[inset_0_0_12px_rgba(245,158,11,0.75)]'
                      : 'bg-gradient-to-b from-[#00d4ff]/50 via-[#0055aa]/45 to-[#00e1ff]/65 shadow-[inset_0_0_12px_rgba(0,225,255,0.75)]';

                    return (
                      <button
                        key={id}
                        type="button"
                        onClick={() => {
                          playSystemSound('tab_switch', soundEnabled, hapticsEnabled);
                          onSelectTab?.(id);
                        }}
                        className={`relative min-h-[56px] py-1.5 px-0.5 flex flex-col items-center justify-center gap-1 border-r last:border-r-0 border-white/35 transition-colors active:scale-95 cursor-pointer overflow-hidden ${
                          isActive ? 'text-white' : 'text-white/85 hover:bg-white/5'
                        }`}
                      >
                        {isActive && (
                          <span className={`pointer-events-none absolute inset-0 ${activeBg}`} />
                        )}
                        {isActive && (
                          <span
                            aria-hidden="true"
                            className={`pointer-events-none absolute top-0 left-0 right-0 h-[2px] ${
                              isRed
                                ? 'bg-[#ff7a7a]'
                                : isMonarch
                                ? 'bg-[#d8b4fe]'
                                : isIgris
                                ? 'bg-[#fda4af]'
                                : isSovereign
                                ? 'bg-[#fde68a]'
                                : 'bg-[#72f8ff]'
                            }`}
                          />
                        )}
                        <Icon className="relative z-10 w-[21px] h-[21px] stroke-[2]" />
                        <span className="relative z-10 text-[11px] leading-none font-medium tracking-tight whitespace-nowrap">
                          {label}
                        </span>
                      </button>
                    );
                  })}
                </nav>
              )}
            </div>

            {/* Bottom Geometric SVG Frame & Crystalline Center Node */}
            <svg
              className="pointer-events-none absolute bottom-0 left-0 right-0 w-full h-6 z-20"
              viewBox="0 0 400 24"
              fill="none"
              preserveAspectRatio="none"
            >
              <path
                d="M 2 2 L 14 16 L 145 16 L 160 22 L 240 22 L 255 16 L 386 16 L 398 2"
                stroke={primaryStroke}
                strokeWidth="5"
                strokeOpacity="0.22"
              />
              <path
                d="M 2 2 L 14 16 L 145 16 L 160 22 L 240 22 L 255 16 L 386 16 L 398 2"
                stroke={primaryStroke}
                strokeWidth="1.85"
              />
              <polygon
                points="172,22 228,22 218,8 182,8"
                fill={primaryStroke}
                fillOpacity="0.52"
                stroke="#ffffff"
                strokeWidth="1.15"
              />
              <polyline
                points="185,20 198,10 208,19 216,11"
                stroke="#ffffff"
                strokeWidth="1.15"
                strokeOpacity="0.92"
              />
            </svg>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
});
