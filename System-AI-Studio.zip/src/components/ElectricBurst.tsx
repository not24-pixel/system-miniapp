import React from 'react';
import { SystemPalette } from '../shared/types';
import { HudSkinId, useSystemMetrics } from './RollingNumber';

interface ColorTokens {
  stroke: string;
  core: string;
  glow: string;
  sweep: string;
  badgeText: string;
}

function getArcColors(palette: SystemPalette, hudTheme: HudSkinId): ColorTokens {
  const skin = palette === 'red' ? 'red' : hudTheme;
  if (skin === 'red') {
    return {
      stroke: '#ff4d4d',
      core: '#ffd2cf',
      glow: 'rgba(255, 45, 45, 0.9)',
      sweep: 'rgba(255, 70, 70, 0.35)',
      badgeText: '#ffb3b3',
    };
  }
  if (skin === 'monarch') {
    return {
      stroke: '#c084fc',
      core: '#f3e8ff',
      glow: 'rgba(168, 85, 247, 0.95)',
      sweep: 'rgba(192, 132, 252, 0.36)',
      badgeText: '#e9d5ff',
    };
  }
  if (skin === 'igris') {
    return {
      stroke: '#fb7185',
      core: '#ffe4e6',
      glow: 'rgba(244, 63, 94, 0.95)',
      sweep: 'rgba(251, 113, 133, 0.36)',
      badgeText: '#fecdd3',
    };
  }
  if (skin === 'sovereign') {
    return {
      stroke: '#fbbf24',
      core: '#fef3c7',
      glow: 'rgba(245, 158, 11, 0.95)',
      sweep: 'rgba(251, 191, 36, 0.36)',
      badgeText: '#fde68a',
    };
  }
  return {
    stroke: '#38f8ff',
    core: '#e0ffff',
    glow: 'rgba(0, 229, 255, 0.95)',
    sweep: 'rgba(56, 248, 255, 0.36)',
    badgeText: '#9deeff',
  };
}

/**
 * Compact electric discharge SVG overlay originating around checkboxes/action buttons.
 * Remounting via `burstKey` plays a fast 520ms Solo Leveling lightning arc burst.
 */
export const ElectricCheckboxBurst: React.FC<{
  burstKey: number;
  palette?: SystemPalette;
  tagText?: string;
}> = ({ burstKey, palette = 'blue', tagText }) => {
  const { reducedMotion, hudTheme } = useSystemMetrics();
  if (burstKey <= 0 || reducedMotion) return null;

  const colors = getArcColors(palette, hudTheme);

  return (
    <span
      key={burstKey}
      aria-hidden="true"
      className="pointer-events-none absolute -inset-4 z-30 flex items-center justify-center overflow-visible"
    >
      {/* Expanding electric plasma ring */}
      <span
        className="absolute inset-1 rounded-[6px] electric-shock-ring"
        style={{
          borderColor: colors.stroke,
          boxShadow: `0 0 14px ${colors.glow}, inset 0 0 8px ${colors.glow}`,
        }}
      />

      {/* Radiating jagged SVG lightning arcs */}
      <svg
        viewBox="0 0 64 64"
        fill="none"
        className="w-16 h-16 overflow-visible electric-bolt-group"
      >
        {/* Top-left bolt */}
        <path
          d="M28 26 L19 19 L22 14 L11 8"
          stroke={colors.stroke}
          strokeWidth="2.1"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="electric-arc-path"
        />
        {/* Top-right bolt */}
        <path
          d="M36 26 L45 18 L43 13 L53 7"
          stroke={colors.core}
          strokeWidth="1.9"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="electric-arc-path"
        />
        {/* Bottom-left bolt */}
        <path
          d="M27 38 L17 44 L20 50 L10 56"
          stroke={colors.core}
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="electric-arc-path"
        />
        {/* Bottom-right bolt */}
        <path
          d="M37 38 L46 46 L42 51 L54 57"
          stroke={colors.stroke}
          strokeWidth="2.1"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="electric-arc-path"
        />
        {/* Right horizontal tendril */}
        <path
          d="M40 32 L51 29 L55 34 L63 30"
          stroke={colors.stroke}
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="electric-arc-path"
        />
        {/* Vertical top spark */}
        <path
          d="M32 23 L30 14 L35 10 L31 2"
          stroke={colors.stroke}
          strokeWidth="1.7"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="electric-arc-path"
        />
      </svg>

      {tagText && (
        <span
          className="absolute -top-2 left-1/2 -translate-x-1/2 whitespace-nowrap font-mono text-[11px] font-extrabold tracking-tight electric-float-tag"
          style={{
            color: colors.core,
            textShadow: `0 0 8px ${colors.glow}`,
          }}
        >
          {tagText}
        </span>
      )}
    </span>
  );
};

/**
 * Horizontal lightning tendril + surge flash sweeping across an entire task/habit row or XP card.
 */
export const ElectricRowArc: React.FC<{
  burstKey: number;
  palette?: SystemPalette;
}> = ({ burstKey, palette = 'blue' }) => {
  const { reducedMotion, hudTheme } = useSystemMetrics();
  if (burstKey <= 0 || reducedMotion) return null;

  const colors = getArcColors(palette, hudTheme);

  return (
    <div
      key={burstKey}
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 z-20 overflow-hidden"
    >
      {/* Rapid neon-white electric scan sweep */}
      <div
        className="absolute inset-y-0 left-0 w-1/2 electric-row-sweep"
        style={{
          background: `linear-gradient(90deg, transparent 0%, ${colors.sweep} 60%, ${colors.core} 90%, transparent 100%)`,
        }}
      />
      {/* Crisp jagged horizontal lightning filament */}
      <svg
        viewBox="0 0 360 44"
        preserveAspectRatio="none"
        fill="none"
        className="absolute inset-0 w-full h-full electric-bolt-group"
      >
        <path
          d="M6 22 L48 18 L66 26 L118 14 L142 25 L196 16 L225 27 L278 15 L312 24 L354 19"
          stroke={colors.stroke}
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="electric-arc-wide"
        />
        <path
          d="M20 22 L76 23 L102 19 L164 24 L208 18 L266 23 L334 20"
          stroke={colors.core}
          strokeWidth="1.1"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="electric-arc-wide"
        />
      </svg>
    </div>
  );
};

/**
 * Corner / rim electric discharge arcs that snap along the outer System HUD frame
 * on task completion, habit completion, or XP reward claims.
 */
export const ElectricFrameSurge: React.FC<{
  burstKey: number;
  palette?: SystemPalette;
}> = ({ burstKey, palette = 'blue' }) => {
  const { reducedMotion, hudTheme } = useSystemMetrics();
  if (burstKey <= 0 || reducedMotion) return null;

  const colors = getArcColors(palette, hudTheme);

  return (
    <div
      key={burstKey}
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 z-30 overflow-hidden"
    >
      {/* Inner electric rim pulse */}
      <div
        className="absolute inset-0 electric-frame-border-flash"
        style={{
          boxShadow: `inset 0 0 28px ${colors.glow}, inset 0 0 6px ${colors.core}`,
        }}
      />
      {/* Top-left & Bottom-right corner electric arcs */}
      <svg
        viewBox="0 0 400 720"
        preserveAspectRatio="none"
        fill="none"
        className="absolute inset-0 w-full h-full electric-bolt-group"
      >
        <path
          d="M8 52 L22 36 L14 24 L36 12 L68 14"
          stroke={colors.core}
          strokeWidth="2.2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="electric-arc-wide"
        />
        <path
          d="M392 54 L376 34 L384 22 L360 12 L326 14"
          stroke={colors.stroke}
          strokeWidth="2.2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="electric-arc-wide"
        />
        <path
          d="M12 670 L28 688 L20 698 L48 708 L88 706"
          stroke={colors.stroke}
          strokeWidth="2.2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="electric-arc-wide"
        />
        <path
          d="M388 668 L372 686 L380 698 L352 708 L312 706"
          stroke={colors.core}
          strokeWidth="2.2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="electric-arc-wide"
        />
      </svg>
    </div>
  );
};
