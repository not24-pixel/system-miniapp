import React, { memo, useEffect, useState } from 'react';
import {
  Ban,
  Bell,
  BookOpen,
  Calendar,
  Check,
  ChevronDown,
  Clock,
  Crown,
  Database,
  Dumbbell,
  FileText,
  Gift,
  Hourglass,
  Info,
  Layers,
  Lock,
  Palette,
  PauseCircle,
  PlayCircle,
  Repeat,
  RotateCcw,
  Shield,
  Sparkles,
  Star,
  Target,
  Wifi,
  WifiOff,
  Copy,
  UserPlus,
  Zap,
} from 'lucide-react';
import { formatTimerHMS, formatTimerMS } from '../shared/constants';
import { calculateNightWindowDurationHours } from '../shared/fixtures';
import { getAuthHeaders, getClientTimezone } from '../shared/apiClient';
import { PlayerSubTabId } from '../shared/types';
import type { ScreenPartProps } from './StatesPart1';
import {
  PlayerTopTabs,
  SystemButton,
  SystemCheckbox,
  SystemHeaderBox,
  SystemProgressBar,
  SystemSquareIcon,
  SystemTypewriter,
} from './SystemWidgets';
import { playSystemSound, triggerHaptic } from '../shared/sound';

const QUIZ_QUESTIONS = [
  {
    id: 'q1_step_clarity',
    prompt: 'Какой шаг проще проверить?',
    options: ['Заняться портфолио', 'Выбрать три работы', 'Стать продуктивнее'],
    correctIndex: 1,
  },
  {
    id: 'q2_start_time',
    prompt: 'Что снижает риск откладывания задачи на вечер?',
    options: [
      'Обещание сделать «когда появится время»',
      'Заранее указанное время начала и подготовленные материалы',
      'Ожидание особого вдохновения',
    ],
    correctIndex: 1,
  },
  {
    id: 'q3_scope_limit',
    prompt: 'Как поступить, если задача кажется слишком большой?',
    options: [
      'Выделить один проверяемый первый этап на 15 минут',
      'Отложить задачу до выходных',
      'Сразу запланировать 5 часов без перерыва',
    ],
    correctIndex: 0,
  },
  {
    id: 'q4_miss_recovery',
    prompt: 'Что происходит с историей при прохождении штрафного квеста?',
    options: [
      'Пропуск превращается в выполненную привычку',
      'Пропуск остаётся в истории, а бонусы навыков восстанавливаются',
      'За штрафной квест начисляется двойной XP',
    ],
    correctIndex: 1,
  },
  {
    id: 'q5_next_step',
    prompt: 'Какое условие обязательно для финального зачёта модуля после ответов?',
    options: [
      'Просто подождать окончания таймера',
      'Сохранить конкретный следующий шаг с временем начала',
      'Оплатить подписку Система+',
    ],
    correctIndex: 1,
  },
];

export const StatesPart2: React.FC<ScreenPartProps> = memo(({
  stateId,
  user,
  navigateState,
  apiAction,
  busy,
  selectedTaskId,
  setSelectedTaskId,
  selectedEntryId,
  selectedGoalId,
  setSelectedGoalId,
  limitReason = 'habits',
  openPlusModal,
  setSettingsReturnState,
  isAdmin = false,
}) => {
  const [selectedQuizOption, setSelectedQuizOption] = useState<number>(1);
  const [quizQuestionIdx, setQuizQuestionIdx] = useState<number>(0);

  const [selectedTrial, setSelectedTrial] = useState<'body' | 'focus' | 'revenge'>(
    user.penaltyQuest.selectedChallenge || 'body'
  );
  const [trialReps, setTrialReps] = useState<number>(0);
  const [trialFocusSecLeft, setTrialFocusSecLeft] = useState<number>(180);
  const [trialFocusPaused, setTrialFocusPaused] = useState<boolean>(false);
  const [revengeDoneChecked, setRevengeDoneChecked] = useState<boolean>(false);
  const [reflectionReason, setReflectionReason] = useState<string>(
    user.penaltyQuest.reflectionReason || 'Отвлёкся'
  );

  const [nextStepActionText, setNextStepActionText] = useState(
    user.penaltyQuest.nextStepAction || 'Выбрать три работы для портфолио'
  );
  const [nextStepWhenText, setNextStepWhenText] = useState(
    user.penaltyQuest.nextStepWhen || 'Завтра в 19:00'
  );

  const [editExpenseTitle, setEditExpenseTitle] = useState('Кофе');
  const [editExpenseNewAmount, setEditExpenseNewAmount] = useState(250);
  const [editExpenseCategory, setEditExpenseCategory] = useState('Еда');
  const [editExpenseAccount, setEditExpenseAccount] = useState('acc_card');

  const [editTaskTitle, setEditTaskTitle] = useState('Оформить страницу портфолио');
  const [editTaskGoalId, setEditTaskGoalId] = useState<string>('');
  const [editTaskDue, setEditTaskDue] = useState('Через 7 дней');
  const [editTaskPriority, setEditTaskPriority] = useState<'normal' | 'high'>('normal');
  const [editTaskRecurrence, setEditTaskRecurrence] = useState<'none' | 'daily' | 'weekdays' | 'weekly'>('none');

  const [nightStart, setNightStart] = useState(user.nightPeriodStart || '23:00');
  const [nightEnd, setNightEnd] = useState(user.nightPeriodEnd || '08:00');
  const [soundOn, setSoundOn] = useState<boolean>(user.soundEnabled !== false);
  const [hapticsOn, setHapticsOn] = useState<boolean>(user.hapticsEnabled !== false);
  const [botPushOn, setBotPushOn] = useState<boolean>(user.botNotificationsEnabled !== false);
  const [copiedLink, setCopiedLink] = useState(false);

  // Sync expense editing fields when entering State 58 or changing selectedEntryId
  useEffect(() => {
    if (stateId !== 58) return;
    const found =
      (selectedEntryId && user.financialEntries.find((e) => e.id === selectedEntryId)) ||
      user.financialEntries[0];
    if (found) {
      const matchedAcc =
        user.accounts.find((a) => a.id === found.accountId) || user.accounts[0];
      setEditExpenseTitle(found.title);
      setEditExpenseNewAmount(found.amountRub);
      setEditExpenseCategory(found.category || 'Еда');
      setEditExpenseAccount(matchedAcc?.id || 'acc_card');
    }
  }, [stateId, selectedEntryId, user.financialEntries, user.accounts]);

  // Sync task editing fields when entering State 60 or changing selectedTaskId
  useEffect(() => {
    if (stateId !== 60) return;
    const found = selectedTaskId ? user.tasks.find((t) => t.id === selectedTaskId) : null;
    if (found) {
      setEditTaskTitle(found.title);
      setEditTaskGoalId(found.goalId || '');
      setEditTaskDue(found.dueDateText || 'Сегодня');
      setEditTaskPriority(found.priority || 'normal');
      setEditTaskRecurrence(found.recurrence || 'none');
    } else {
      setEditTaskTitle('');
      setEditTaskGoalId(selectedGoalId || '');
      setEditTaskDue('Сегодня');
      setEditTaskPriority('normal');
      setEditTaskRecurrence('none');
    }
  }, [stateId, selectedTaskId, selectedGoalId, user.tasks]);

  // Sync trial/reflection/quiz drafts when entering States 41 / 42 / 62 / 63
  useEffect(() => {
    if (stateId === 41) {
      setSelectedTrial(user.penaltyQuest.selectedChallenge || 'body');
    } else if (stateId === 42) {
      setTrialReps(0);
      setTrialFocusSecLeft(180);
      setTrialFocusPaused(false);
      setRevengeDoneChecked(false);
    } else if (stateId === 62) {
      setQuizQuestionIdx(Math.min(QUIZ_QUESTIONS.length - 1, user.penaltyQuest.questionsPassed || 0));
    } else if (stateId === 63) {
      setReflectionReason(user.penaltyQuest.reflectionReason || 'Отвлёкся');
      setNextStepActionText(user.penaltyQuest.nextStepAction || 'Выбрать три работы для портфолио');
      setNextStepWhenText(user.penaltyQuest.nextStepWhen || 'Завтра в 19:00');
    }
  }, [
    stateId,
    user.penaltyQuest.selectedChallenge,
    user.penaltyQuest.reflectionReason,
    user.penaltyQuest.questionsPassed,
    user.penaltyQuest.nextStepAction,
    user.penaltyQuest.nextStepWhen,
  ]);

  // Sync settings toggles when user state updates
  useEffect(() => {
    setNightStart(user.nightPeriodStart || '23:00');
    setNightEnd(user.nightPeriodEnd || '08:00');
    setSoundOn(user.soundEnabled !== false);
    setHapticsOn(user.hapticsEnabled !== false);
    setBotPushOn(user.botNotificationsEnabled !== false);
  }, [
    user.nightPeriodStart,
    user.nightPeriodEnd,
    user.soundEnabled,
    user.hapticsEnabled,
    user.botNotificationsEnabled,
  ]);

  // Live working Focus Session countdown (State 59)
  const [focusSecLeft, setFocusSecLeft] = useState<number>(
    user.focusSession?.remainingSeconds || 685
  );
  const [focusPaused, setFocusPaused] = useState<boolean>(false);

  useEffect(() => {
    if (stateId === 59 && user.focusSession) {
      const baseRem = user.focusSession.remainingSeconds || user.focusSession.totalSeconds || 900;
      const elapsedSinceStart =
        user.focusSession.startedAtMs && !user.focusSession.paused
          ? Math.max(0, Math.floor((Date.now() - user.focusSession.startedAtMs) / 1000))
          : 0;
      setFocusSecLeft(Math.max(0, baseRem - elapsedSinceStart));
      setFocusPaused(Boolean(user.focusSession.paused));
    }
  }, [
    stateId,
    user.focusSession?.taskId,
    user.focusSession?.remainingSeconds,
    user.focusSession?.totalSeconds,
    user.focusSession?.paused,
    user.focusSession?.startedAtMs,
  ]);

  // Live working Penalty Deadline & Stage countdown (States 40, 41, 42, 61)
  const [penaltyDeadlineSec, setPenaltyDeadlineSec] = useState<number>(
    user.penaltyQuest?.remainingBudgetSeconds || 43199
  );
  const [stageElapsedSec, setStageElapsedSec] = useState<number>(
    user.penaltyQuest?.stage1ConfirmedSeconds || 78
  );

  useEffect(() => {
    if (typeof user.penaltyQuest?.stage1ConfirmedSeconds === 'number') {
      setStageElapsedSec(user.penaltyQuest.stage1ConfirmedSeconds);
    }
  }, [user.penaltyQuest?.stage1ConfirmedSeconds]);

  useEffect(() => {
    if (stateId !== 59 || focusPaused) return;
    const syncRemaining = () => {
      if (user.focusSession?.startedAtMs && !user.focusSession.paused) {
        const baseRem = user.focusSession.remainingSeconds || user.focusSession.totalSeconds || 900;
        const elapsed = Math.max(0, Math.floor((Date.now() - user.focusSession.startedAtMs) / 1000));
        setFocusSecLeft(Math.max(0, baseRem - elapsed));
      } else {
        setFocusSecLeft((prev) => (prev > 0 ? prev - 1 : 0));
      }
    };
    const interval = setInterval(syncRemaining, 1000);
    const onVisibility = () => {
      if (!document.hidden) syncRemaining();
    };
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      clearInterval(interval);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, [
    stateId,
    focusPaused,
    user.focusSession?.startedAtMs,
    user.focusSession?.remainingSeconds,
    user.focusSession?.totalSeconds,
    user.focusSession?.paused,
  ]);

  useEffect(() => {
    const activeChallenge = user.penaltyQuest.selectedChallenge || selectedTrial;
    if (stateId !== 42 || activeChallenge !== 'focus' || trialFocusPaused) return;
    const timer = setInterval(() => {
      setTrialFocusSecLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [stateId, user.penaltyQuest.selectedChallenge, selectedTrial, trialFocusPaused]);

  useEffect(() => {
    const isPenaltyScreen = [40, 41, 42, 61, 62, 63, 64, 67, 68, 69].includes(stateId);
    if (!isPenaltyScreen) return;
    let tickCount = 0;
    const interval = setInterval(() => {
      setPenaltyDeadlineSec((prev) => (prev > 0 ? prev - 1 : 0));
      if (stateId === 61) {
        setStageElapsedSec((prev) => Math.min(150, prev + 1));
        tickCount += 1;
        if (tickCount % 5 === 0) {
          fetch('/api/penalty/heartbeat', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify({ secondsDelta: 5 }),
          }).catch(() => {});
        }
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [stateId]);

  const switchSubTab = (sub: PlayerSubTabId) => {
    navigateState(sub === 'status' ? 28 : 31);
  };

  // --- ШТРАФНОЙ КВЕСТ (Гибридный поток: States 40, 41, 42 -> 63 -> 69 -> 43) ---
  if (stateId === 40) {
    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5 text-center pb-4">
        <div className="space-y-2">
          <SystemSquareIcon kind="alert" palette="red" />
          <SystemHeaderBox title="ШТРАФНОЙ КВЕСТ" palette="red" />

          <div className="border-t border-b border-white/35 py-2">
            <div className="text-[14px] text-white/85">Причина назначения:</div>
            <SystemTypewriter
              lines={[user.penaltyQuest.reasonTitle]}
              palette="red"
              soundEnabled={user.soundEnabled !== false}
              speedMs={22}
            />
          </div>

          <div className="rounded-[6px] border border-[#ff6b6b] bg-[#290408]/85 overflow-hidden">
            <div className="py-1.5 border-b border-white/30 text-[15px] font-bold">
              Срок снятия: 12 часов
            </div>
            <div className="py-2.5 space-y-0.5">
              <div className="text-[12.5px] text-white/85">До окончания срока</div>
              <div className="text-[32px] leading-none font-extrabold font-tabular tracking-tight drop-shadow-[0_0_12px_rgba(255,50,50,0.75)]">
                {formatTimerHMS(penaltyDeadlineSec)}
              </div>
            </div>
          </div>

          <div className="p-2.5 border border-[#ff4d4d]/70 bg-[#240307]/85 text-left space-y-1 text-[12.5px]">
            <div className="flex items-center gap-2 font-bold text-[#ffb3b3]">
              <Ban className="w-4 h-4 text-[#ff4d4d] shrink-0" />
              <span>ЗАМОРОЖЕНО НА КАРАНТИНЕ:</span>
            </div>
            <div className="text-white/90 pl-6 leading-snug">
              Выполнение заданий, фокус-таймер, привычки, начисление XP и прокачка.
            </div>
            <div className="text-emerald-300/95 pl-6 text-[12px] font-semibold">
              Открыто без ограничений: Финансы и Настройки.
            </div>
          </div>
        </div>

        <div className="space-y-2 pt-1">
          <SystemButton
            label="ПРИНЯТЬ ИСПЫТАНИЕ"
            palette="red"
            highlighted
            onClick={() => apiAction('/api/penalty/present', {}, 41)}
          />
          <button
            type="button"
            disabled={busy}
            onClick={() => {
              if (user.subscription.active) {
                if ((user.shieldChargesRemaining ?? 0) > 0) {
                  apiAction('/api/penalty/use-shield', {}, 11);
                } else {
                  openPlusModal?.('feature', 'Щит Системы (лимит 2/мес исчерпан)');
                }
              } else {
                openPlusModal?.('feature', 'Щит Системы (заморозка штрафа)');
              }
            }}
            className="w-full min-h-[48px] py-2.5 px-3 rounded-[6px] border border-[#38f8ff]/75 bg-[#062d4a]/80 text-center text-[13px] font-bold text-[#9deeff] hover:border-white hover:text-white cursor-pointer flex items-center justify-center gap-2 disabled:opacity-45"
          >
            <Shield className="w-4 h-4 text-[#38e8ff] shrink-0" />
            <span>
              {user.subscription.active
                ? `Щит Системы · Снять штраф и сохранить серию (${user.shieldChargesRemaining ?? 0} ост.)`
                : 'Щит Системы · Снять штраф + спасти серию'}
            </span>
          </button>
          <div className="text-[12px] text-white/80 leading-snug">
            Ночная пауза: {user.nightPeriodStart}–{user.nightPeriodEnd} · Финансы доступны
          </div>
        </div>
      </div>
    );
  }

  if (stateId === 41) {
    const trials: Array<{
      id: 'body' | 'focus' | 'revenge';
      title: string;
      badge: string;
      desc: string;
      Icon: React.FC<{ className?: string }>;
    }> = [
      {
        id: 'body',
        title: 'Выносливость · 20 повт.',
        badge: '~2 мин',
        desc: '20 отжиманий, приседаний или скручиваний со счётчиком.',
        Icon: Dumbbell,
      },
      {
        id: 'focus',
        title: 'Концентрация · 3 минуты',
        badge: '3:00',
        desc: '3 минуты тишины и фокуса без отвлечений по таймеру.',
        Icon: Zap,
      },
      {
        id: 'revenge',
        title: 'Реванш · шаг к задаче',
        badge: 'Дело',
        desc: 'Выполните 1 конкретный микро-шаг по пропущенному делу.',
        Icon: Target,
      },
    ];

    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5 pb-4">
        <div className="space-y-2">
          <div className="py-1 px-3 rounded-[5px] border border-white/60 bg-[#290408]/75 text-center text-[13px] font-semibold font-tabular">
            До окончания срока · {formatTimerHMS(penaltyDeadlineSec)}
          </div>

          <SystemHeaderBox
            title="ВЫБОР ИСПЫТАНИЯ"
            palette="red"
            onBack={() => navigateState(40)}
          />

          <p className="text-center text-[13px] text-white/85 leading-snug">
            Пройдите 1 реальное испытание и зафиксируйте следующий шаг, чтобы снять карантин.
          </p>

          <div className="space-y-2">
            {trials.map(({ id, title, badge, desc, Icon }) => {
              const active = selectedTrial === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => {
                    playSystemSound('ui_step', user.soundEnabled, user.hapticsEnabled);
                    setSelectedTrial(id);
                  }}
                  className={`w-full p-2.5 border text-left transition-colors cursor-pointer ${
                    active
                      ? 'border-[#ff6b6b] bg-[#3b060c]/95 shadow-[0_0_16px_rgba(255,50,50,0.45)]'
                      : 'border-white/40 bg-black/45 hover:border-white/75'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 font-bold text-[14.5px] text-white">
                      <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-[#ff7a7a]' : 'text-white/75'}`} />
                      <span>{title}</span>
                    </div>
                    <span className="px-1.5 py-0.5 border border-white/35 bg-black/40 text-[11px] font-mono text-white/85 shrink-0">
                      {badge}
                    </span>
                  </div>
                  <div className="text-[12px] text-white/80 leading-snug mt-1 pl-6">{desc}</div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="space-y-2 pt-1">
          <SystemButton
            label="НАЧАТЬ ИСПЫТАНИЕ"
            palette="red"
            highlighted
            disabled={busy}
            onClick={() =>
              apiAction('/api/penalty/select-challenge', { challenge: selectedTrial }, 42)
            }
          />
          <button
            type="button"
            disabled={busy}
            onClick={() => {
              if (user.subscription.active && (user.shieldChargesRemaining ?? 0) > 0) {
                apiAction('/api/penalty/use-shield', {}, 11);
              } else {
                openPlusModal?.('feature', 'Щит Системы (заморозка штрафа)');
              }
            }}
            className="w-full py-1.5 px-3 rounded-[6px] border border-[#38f8ff]/60 bg-[#062d4a]/75 text-center text-[12.5px] font-bold text-[#9deeff] hover:border-white cursor-pointer flex items-center justify-center gap-2 disabled:opacity-45"
          >
            <Shield className="w-4 h-4 text-[#38e8ff]" />
            <span>
              {user.subscription.active
                ? `Активировать Щит (${user.shieldChargesRemaining ?? 0} ост.)`
                : 'Заморозить Щитом Системы ★'}
            </span>
          </button>
        </div>
      </div>
    );
  }

  if (stateId === 42) {
    const activeChallenge = user.penaltyQuest.selectedChallenge || selectedTrial;
    const pendingTask = user.tasks.find((t) => !t.completed) || user.tasks[0];

    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5 text-center pb-4">
        <div className="space-y-2.5">
          <div className="py-1 px-3 rounded-[5px] border border-white/60 bg-[#290408]/75 text-[13px] font-semibold font-tabular">
            До окончания срока · {formatTimerHMS(penaltyDeadlineSec)}
          </div>

          {activeChallenge === 'body' && (
            <>
              <SystemHeaderBox
                title="ВЫНОСЛИВОСТЬ"
                palette="red"
                onBack={() => navigateState(41)}
              />
              <Dumbbell className="w-10 h-10 mx-auto text-[#ff7a7a]" />
              <div className="text-[14px] text-white/90">
                Выполните 20 отжиманий, приседаний или скручиваний
              </div>
              <div className="py-2">
                <div className="text-[44px] font-extrabold font-tabular leading-none">
                  {trialReps} <span className="text-[22px] text-white/65">/ 20</span>
                </div>
              </div>
              <SystemProgressBar value={trialReps} max={20} palette="red" />

              <div className="grid grid-cols-3 gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    playSystemSound('stat_tick', user.soundEnabled, user.hapticsEnabled);
                    setTrialReps((r) => Math.min(20, r + 1));
                  }}
                  className="py-2.5 border border-[#ff6b6b] bg-[#36050a] text-[15px] font-bold hover:bg-[#520810] cursor-pointer"
                >
                  +1 Повтор
                </button>
                <button
                  type="button"
                  onClick={() => {
                    playSystemSound('stat_tick', user.soundEnabled, user.hapticsEnabled);
                    setTrialReps((r) => Math.min(20, r + 5));
                  }}
                  className="py-2.5 border border-[#ff6b6b] bg-[#36050a] text-[15px] font-bold hover:bg-[#520810] cursor-pointer"
                >
                  +5 Повт.
                </button>
                <button
                  type="button"
                  onClick={() => setTrialReps(0)}
                  className="py-2.5 border border-white/45 bg-black/45 text-[13px] text-white/80 hover:text-white cursor-pointer"
                >
                  Сбросить
                </button>
              </div>
            </>
          )}

          {activeChallenge === 'focus' && (
            <>
              <SystemHeaderBox
                title="КОНЦЕНТРАЦИЯ"
                palette="red"
                onBack={() => navigateState(41)}
              />
              <Zap className="w-10 h-10 mx-auto text-[#ff7a7a]" />
              <div className="text-[14px] text-white/90">
                Проведите 3 минуты в тишине и фокусе без соцсетей
              </div>
              <div className="py-2">
                <div className="text-[44px] font-extrabold font-tabular leading-none">
                  {formatTimerMS(trialFocusSecLeft)}
                </div>
                <div className="text-[12.5px] text-white/75 mt-1">
                  {trialFocusSecLeft === 0
                    ? 'Испытание завершено!'
                    : trialFocusPaused
                    ? 'Таймер на паузе'
                    : 'Идёт отсчёт концентрации...'}
                </div>
              </div>
              <SystemProgressBar value={180 - trialFocusSecLeft} max={180} palette="red" />

              <button
                type="button"
                onClick={() => setTrialFocusPaused((p) => !p)}
                className="w-full py-2 border border-white/60 bg-black/45 text-[14px] font-bold hover:border-white cursor-pointer"
              >
                {trialFocusPaused ? 'ВОЗОБНОВИТЬ ТАЙМЕР' : 'ПАУЗА'}
              </button>
            </>
          )}

          {activeChallenge === 'revenge' && (
            <>
              <SystemHeaderBox
                title="РЕВАНШ ПО ДЕЛУ"
                palette="red"
                onBack={() => navigateState(41)}
              />
              <Target className="w-10 h-10 mx-auto text-[#ff7a7a]" />
              <div className="p-2.5 border border-white/40 bg-[#240307]/85 text-left space-y-1">
                <div className="text-[11px] uppercase tracking-wider text-white/65">
                  Цель реванша
                </div>
                <div className="text-[15px] font-bold text-white">
                  {pendingTask?.title || user.penaltyQuest.reasonTitle}
                </div>
              </div>
              <div className="border-t border-b border-white/25 text-left">
                <SystemCheckbox
                  checked={revengeDoneChecked}
                  label="Я выполнил(а) реальный 5-минутный шаг по этой задаче"
                  onChange={() => setRevengeDoneChecked((v) => !v)}
                />
              </div>
            </>
          )}
        </div>

        <div className="space-y-2 pt-1">
          {(() => {
            const trialCompleted =
              (activeChallenge === 'body' && trialReps >= 20) ||
              (activeChallenge === 'focus' && trialFocusSecLeft <= 0) ||
              (activeChallenge === 'revenge' && revengeDoneChecked);
            return (
              <SystemButton
                label="ЗАЧЕСТЬ ИСПЫТАНИЕ"
                palette="red"
                highlighted={trialCompleted}
                disabled={busy || !trialCompleted}
                onClick={() =>
                  apiAction('/api/penalty/trial-complete', { challenge: activeChallenge }, 63)
                }
              />
            );
          })()}

          <button
            type="button"
            onClick={() => navigateState(41)}
            className="text-[13px] underline underline-offset-4 text-white/80 hover:text-white cursor-pointer"
          >
            Выбрать другое испытание
          </button>
        </div>
      </div>
    );
  }

  // --- ИСХОДЫ ШТРАФНОГО КВЕСТА (States 43, 44, 45) ---
  if (stateId === 43) {
    const chMap: Record<string, string> = {
      body: 'Испытание: Выносливость (20 повт.)',
      focus: 'Испытание: Концентрация (3 мин)',
      revenge: 'Испытание: Реванш по делу',
    };
    const trialLabel =
      (user.penaltyQuest.selectedChallenge && chMap[user.penaltyQuest.selectedChallenge]) ||
      'Испытание пройдено';

    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5 text-center pb-4">
        <div className="space-y-2">
          <SystemHeaderBox title="Штрафной квест" palette="blue" onBack={() => navigateState(11)} />
          <SystemSquareIcon kind="check" palette="blue" />
          <SystemHeaderBox title="КАРАНТИН СНЯТ" palette="blue" />
          <div className="text-[15px] text-white/90">Доступ к Системе восстановлен</div>

          <div className="p-2.5 rounded-[6px] border border-white/65 bg-black/40 text-left divide-y divide-white/25">
            <SystemCheckbox checked={true} label={trialLabel} />
            <SystemCheckbox
              checked={true}
              label={`Причина: ${user.penaltyQuest.reflectionReason || 'разобрана'}`}
            />
            <SystemCheckbox checked={true} label="Следующий шаг добавлен в задачи" />
          </div>

          <div className="space-y-1 text-[14px] text-white/90 pt-1">
            <div className="font-bold text-white">Задания, Привычки, Фокус и XP открыты</div>
            <div>Пропуск сохранён в истории</div>
          </div>
        </div>

        <SystemButton label="К ДЕЛАМ" palette="blue" highlighted onClick={() => navigateState(11)} />
      </div>
    );
  }

  if (stateId === 44) {
    return (
      <div className="flex flex-col justify-between min-h-full space-y-3 text-center">
        <div className="space-y-2.5">
          <SystemHeaderBox title="Штрафной квест" palette="red" onBack={() => navigateState(40)} />
          <SystemSquareIcon kind="alert" palette="red" circleOnly />
          <SystemHeaderBox title="КВЕСТ ПРОСРОЧЕН" palette="red" />

          <div className="py-1">
            <div className="text-[38px] font-extrabold font-tabular leading-none drop-shadow-[0_0_12px_rgba(255,40,40,0.8)]">
              00:00:00
            </div>
            <div className="text-[15px] text-white/90 mt-1">Срок 12 часов истёк</div>
          </div>

          <div className="divide-y divide-white/25 border-t border-b border-white/35 text-left text-[15px]">
            <div className="py-2.5 flex items-center gap-3">
              <Layers className="w-6 h-6 text-white shrink-0" />
              <span className="border-l border-white/35 pl-3 font-medium">
                Пройденные этапы сохранены
              </span>
            </div>
            <div className="py-2.5 flex items-center gap-3">
              <PauseCircle className="w-6 h-6 text-white shrink-0" />
              <span className="border-l border-white/35 pl-3 font-medium">
                Бонусы остаются приостановленными
              </span>
            </div>
          </div>

          <div className="text-[14px] text-white/90">Задачи и финансы доступны</div>
        </div>

        <SystemButton
          label="ПРОДОЛЖИТЬ КВЕСТ"
          palette="red"
          highlighted
          onClick={() => navigateState(61)}
        />
      </div>
    );
  }

  if (stateId === 45) {
    return (
      <div className="flex flex-col justify-between min-h-full space-y-3">
        <div className="space-y-3">
          <SystemHeaderBox title="История квестов" onBack={() => navigateState(15)} />
          <SystemHeaderBox title="ИСТОРИЯ КВЕСТОВ" />

          <div className="divide-y divide-white/25 border-b border-white/30">
            {user.penaltyHistory.map((item) => (
              <div key={item.id} className="py-3 flex items-center justify-between gap-2">
                <div className="flex items-center gap-3">
                  <BookOpen className="w-6 h-6 shrink-0" />
                  <div className="border-l border-white/35 pl-2.5">
                    <div className="text-[15px] font-bold">{item.dateLabel} ·</div>
                    <div className="text-[14px] text-white/85">{item.title}</div>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded-[6px] border border-[#38f8ff] bg-[#062d4a] text-[12px] font-bold text-center leading-tight">
                  {item.outcome === 'completed_late' ? 'Выполнен с просрочкой' : 'Выполнен'}
                </span>
              </div>
            ))}
          </div>

          <div className="text-center text-[15px] text-white/90 py-2">
            Несколько пропусков —
            <br />
            один активный квест
          </div>
        </div>

        <div className="py-2.5 px-3 border border-white/80 bg-[#031221] text-center text-[17px] font-bold font-tabular">
          Активных квестов: {user.penaltyQuest.active ? 1 : 0}
        </div>
      </div>
    );
  }

  // --- СИСТЕМА+ (States 46, 47, 48, 49, 50, 51) ---
  if (stateId === 46) {
    const activeHabitsCount = user.habits.filter((h) => h.status !== 'archived').length;
    const activeGoalsCount = user.goals.filter((g) => g.status === 'active').length;
    const accountsCount = user.accounts.length;

    const limitCfg =
      limitReason === 'goals'
        ? {
            title: 'ЛИМИТ ЦЕЛЕЙ',
            counter: `Активных целей: ${activeGoalsCount} / 3`,
            desc: 'Чтобы добавить новую цель, подключите Система+ или завершите одну из текущих.',
            manageLabel: 'К списку целей',
            manageTarget: 16,
            backTarget: 16,
          }
        : limitReason === 'accounts'
          ? {
              title: 'ЛИМИТ СЧЕТОВ',
              counter: `Счетов в системе: ${accountsCount} / 3`,
              desc: 'Чтобы добавить больше трёх счетов, подключите Система+ или используйте текущие счета.',
              manageLabel: 'Управлять счетами',
              manageTarget: 24,
              backTarget: 19,
            }
          : {
              title: 'ЛИМИТ ПРИВЫЧЕК',
              counter: `Активных привычек: ${activeHabitsCount} / 3`,
              desc: 'Чтобы добавить новую привычку, расширьте возможности в Система+ или архивируйте одну из текущих.',
              manageLabel: 'Управлять привычками',
              manageTarget: 13,
              backTarget: 11,
            };

    return (
      <div className="flex flex-col justify-between min-h-full space-y-3 text-center">
        <div className="space-y-3">
          <SystemSquareIcon kind="alert" />
          <SystemHeaderBox title={limitCfg.title} />

          <div className="border-t border-b border-white/35 py-3 space-y-2">
            <div className="text-[19px] font-bold font-tabular">{limitCfg.counter}</div>
            <p className="text-[15px] text-white/90 leading-snug px-1">{limitCfg.desc}</p>
          </div>
        </div>

        <div className="space-y-2.5">
          <SystemButton
            label="ОТКРЫТЬ СИСТЕМУ+"
            highlighted
            onClick={() => (openPlusModal ? openPlusModal(limitReason) : navigateState(47))}
          />
          <SystemButton
            label={limitCfg.manageLabel}
            bracketed={false}
            onClick={() => navigateState(limitCfg.manageTarget)}
          />
          <SystemButton label="Позже" bracketed={false} onClick={() => navigateState(limitCfg.backTarget)} />
        </div>
      </div>
    );
  }

  if (stateId === 47) {
    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5">
        <div className="space-y-2">
          <SystemHeaderBox title="СИСТЕМА+" onBack={() => navigateState(28)} />
          <div className="py-2 border-b border-white/35 flex items-center justify-center gap-1.5 text-[20px] font-extrabold font-tabular">
            <span>от 99</span>
            <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
            <span>/ 30 дней</span>
          </div>

          <div className="divide-y divide-white/25">
            <SystemCheckbox checked={true} label="Армия Теней ∞ + ×2 XP и Сундук ×1.5" />
            <SystemCheckbox checked={true} label="3 облика HUD & 9:16: Монарх, Игрис, S-Ранг" />
            <SystemCheckbox checked={true} label="∞ цели, привычки, счета + Умные этапы" />
            <SystemCheckbox checked={true} label="Щит серии (2/мес) и пинги Telegram-бота" />
          </div>

          <div className="text-center text-[13px] text-white/85 pt-1">
            Оплата в 1 клик через Telegram Stars
          </div>
        </div>

        <div className="space-y-2.5 text-center">
          <SystemButton
            label="ВЫБРАТЬ ТАРИФ"
            highlighted
            onClick={() => (openPlusModal ? openPlusModal('general') : navigateState(49))}
          />
          <button
            type="button"
            onClick={() => navigateState(52)}
            className="text-[15px] underline underline-offset-4 text-white hover:text-[#38e8ff] cursor-pointer"
          >
            3 дня за приглашение
          </button>
        </div>
      </div>
    );
  }

  if (stateId === 48) {
    return (
      <div className="flex flex-col justify-between min-h-full space-y-3 text-center">
        <div className="space-y-3">
          <SystemHeaderBox title="ПОДПИСКА" onBack={() => navigateState(28)} />
          <SystemSquareIcon kind="check" />

          <div className="space-y-1 border-b border-white/35 pb-3">
            <div className="text-[21px] font-bold">Система+ активна</div>
            <div className="flex items-center justify-center gap-1.5 text-[18px] font-bold font-tabular">
              <span>{user.subscription.priceStars || 99}</span>
              <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
              <span>· {user.subscription.planLabel || '1 месяц'}</span>
            </div>
            <div className="text-[13px] text-[#9deeff]">
              {user.subscription.expiresAtLabel || 'Активна'}
            </div>
          </div>

          <div className="text-[15px] text-white/90">
            {user.subscription.autoRenew ? 'Автопродление включено' : 'Автопродление отключено'}
          </div>

          <SystemButton
            label={
              user.subscription.autoRenew
                ? 'ОТКЛЮЧИТЬ АВТОПРОДЛЕНИЕ'
                : 'ВКЛЮЧИТЬ АВТОПРОДЛЕНИЕ'
            }
            highlighted
            onClick={() => apiAction('/api/subscription/toggle-autorenew', {})}
          />

          <p className="text-[14px] text-white/85 leading-snug">
            Доступ сохранится до конца оплаченного периода.
          </p>
        </div>

        <div className="space-y-2">
          {user.subscription.referralBonusDaysAvailable > 0 && (
            <button
              type="button"
              onClick={() => navigateState(54)}
              className="block w-full text-[14px] text-[#38e8ff] underline underline-offset-4 cursor-pointer"
            >
              Использовать бонусные дни ({user.subscription.referralBonusDaysAvailable} дн.)
            </button>
          )}
          <button
            type="button"
            onClick={() => navigateState(28)}
            className="text-[15px] underline underline-offset-4 text-white/90 hover:text-white cursor-pointer"
          >
            Вернуться в профиль
          </button>
        </div>
      </div>
    );
  }

  if (stateId === 49) {
    return (
      <div className="flex flex-col justify-between min-h-full space-y-3 text-center">
        <div className="space-y-2.5">
          <SystemHeaderBox title="ПРОВЕРКА ОПЛАТЫ" onBack={() => navigateState(47)} />
          <SystemSquareIcon kind="refresh" />

          <p className="text-[16px] text-white/90 pt-2">
            Ожидаем подтверждение оплаты
            <br />
            в Telegram Stars.
          </p>

          <div className="py-2.5 px-4 rounded-[8px] border border-[#38f8ff] bg-[#062d4a]/75 flex items-center justify-center gap-1.5 text-[18px] font-bold font-tabular">
            <span>{user.subscription.priceStars || 99}</span>
            <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
            <span>· {user.subscription.planLabel || '30 дней'}</span>
          </div>
        </div>

        <div className="space-y-2">
          <SystemButton
            label="ОТКРЫТЬ ОКНО ОПЛАТЫ"
            highlighted
            disabled={busy}
            onClick={() => (openPlusModal ? openPlusModal('general') : apiAction('/api/subscription/subscribe', {}, 48))}
          />
          <button
            type="button"
            onClick={() => navigateState(50)}
            className="text-[14px] underline underline-offset-4 text-white/80 hover:text-white cursor-pointer"
          >
            Отменить проверку
          </button>
        </div>
      </div>
    );
  }

  if (stateId === 50) {
    return (
      <div className="flex flex-col justify-between min-h-full space-y-3 text-center">
        <div className="space-y-3">
          <SystemHeaderBox title="ОПЛАТА НЕ ЗАВЕРШЕНА" palette="red" onBack={() => navigateState(28)} />
          <SystemSquareIcon kind="alert" palette="red" />

          <div className="border-t border-b border-white/35 py-5 text-[17px] font-medium leading-snug">
            Подписка пока
            <br />
            не подключена.
          </div>
        </div>

        <div className="space-y-3">
          <SystemButton
            label="ПОВТОРИТЬ ОПЛАТУ"
            highlighted
            onClick={() => (openPlusModal ? openPlusModal('general') : navigateState(49))}
          />
          <button
            type="button"
            onClick={() => navigateState(28)}
            className="text-[15px] underline underline-offset-4 text-white/90 hover:text-white cursor-pointer"
          >
            Продолжить бесплатно
          </button>
        </div>
      </div>
    );
  }

  if (stateId === 51) {
    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5">
        <div className="space-y-2.5">
          <SystemHeaderBox title="СИСТЕМА+ ЗАВЕРШЕНА" onBack={() => navigateState(28)} />
          <SystemSquareIcon kind="hourglass" />

          <div className="divide-y divide-white/25 border-t border-b border-white/30 text-[14px]">
            <div className="py-2.5 flex items-center gap-3">
              <Crown className="w-6 h-6 text-[#38e8ff] shrink-0" />
              <span className="border-l border-white/35 pl-3">
                Сейчас действует бесплатный доступ.
              </span>
            </div>
            <div className="py-2.5 flex items-center gap-3">
              <Database className="w-6 h-6 text-[#38e8ff] shrink-0" />
              <span className="border-l border-white/35 pl-3">
                Созданные записи и история сохранены.
              </span>
            </div>
            <div className="py-2.5 flex items-center gap-3">
              <Check className="w-6 h-6 text-[#38e8ff] shrink-0" />
              <span className="border-l border-white/35 pl-3">
                Умный фин-ввод остаётся ∞ бесплатным.
              </span>
            </div>
          </div>
        </div>

        <div className="space-y-2.5 text-center">
          <SystemButton
            label="ПРОДЛИТЬ ЗА 99 ⭐"
            highlighted
            onClick={() => (openPlusModal ? openPlusModal('general') : navigateState(49))}
          />
          <button
            type="button"
            onClick={() => navigateState(28)}
            className="text-[15px] underline underline-offset-4 text-white/90 hover:text-white cursor-pointer"
          >
            К моим данным
          </button>
        </div>
      </div>
    );
  }

  // --- РЕФЕРАЛЬНЫЙ БОНУС (States 52..57) ---
  if (stateId === 52) {
    const botUsername = user.subscription.botUsername || 'systema_app_bot';
    const shareLink = `https://t.me/${botUsername}?start=${user.subscription.referralCode}`;

    return (
      <div className="flex flex-col justify-between min-h-full space-y-3 text-center">
        <div className="space-y-2.5">
          <SystemHeaderBox title="РЕФЕРАЛЬНЫЙ БОНУС" onBack={() => navigateState(28)} />
          <SystemSquareIcon kind="user-plus" />
          <SystemHeaderBox title="ПРИГЛАСИТЬ ИГРОКА" />

          <div className="space-y-2 pt-1">
            <div className="text-[20px] font-extrabold">+3 дня Системы+</div>
            <p className="text-[14px] text-white/90 leading-snug">
              За первый запуск новым игроком по вашей ссылке.
            </p>
            <p className="text-[14px] text-white/85">Один новый игрок — один бонус.</p>
          </div>
        </div>

        <div className="space-y-2.5">
          <SystemButton
            label="ПОДЕЛИТЬСЯ"
            highlighted
            onClick={() => {
              const tg = (window as unknown as { Telegram?: { WebApp?: { openTelegramLink?: (u: string) => void } } }).Telegram?.WebApp;
              const tgShareUrl = `https://t.me/share/url?url=${encodeURIComponent(shareLink)}&text=${encodeURIComponent('Присоединяйся к Системе')}`;
              if (tg?.openTelegramLink) {
                tg.openTelegramLink(tgShareUrl);
                return;
              }
              if (typeof navigator !== 'undefined' && navigator.share) {
                navigator.share({ title: 'Система', text: 'Присоединяйся к Системе', url: shareLink }).catch(() => {
                  navigator.clipboard?.writeText(shareLink).catch(() => {});
                  setCopiedLink(true);
                  setTimeout(() => setCopiedLink(false), 2000);
                });
                return;
              }
              navigator.clipboard?.writeText(shareLink).catch(() => {});
              setCopiedLink(true);
              setTimeout(() => setCopiedLink(false), 2000);
            }}
          />
          <SystemButton
            label={copiedLink ? 'ССЫЛКА СКОПИРОВАНА' : 'СКОПИРОВАТЬ ССЫЛКУ'}
            onClick={() => {
              navigator.clipboard?.writeText(shareLink).catch(() => {});
              setCopiedLink(true);
              setTimeout(() => setCopiedLink(false), 2000);
            }}
          />
          {user.subscription.referralBonusDaysAvailable > 0 && (
            <button
              type="button"
              onClick={() => navigateState(53)}
              className="text-[14px] text-[#38e8ff] underline underline-offset-4 cursor-pointer"
            >
              Перейти к начисленному бонусу ({user.subscription.referralBonusDaysAvailable} дн.)
            </button>
          )}
        </div>
      </div>
    );
  }

  if (stateId === 53) {
    return (
      <div className="flex flex-col justify-between min-h-full space-y-3 text-center">
        <div className="space-y-2.5">
          <SystemHeaderBox title="РЕФЕРАЛЬНЫЙ БОНУС" onBack={() => navigateState(28)} />
          <SystemSquareIcon kind="gift" />
          <SystemHeaderBox title="БОНУС НАЧИСЛЕН" />

          <div className="space-y-2 pt-1">
            <div className="text-[20px] font-extrabold">+3 дня Системы+</div>
            <p className="text-[15px] text-white/90 leading-snug">
              Новый игрок впервые открыл Mini App.
            </p>
            <p className="text-[15px] font-semibold text-[#38f8ff]">Бонус ждёт активации.</p>
          </div>
        </div>

        <div className="space-y-2.5">
          <SystemButton
            label="АКТИВИРОВАТЬ 3 ДНЯ"
            highlighted
            onClick={() => apiAction('/api/referrals/activate', {}, 55)}
          />
          <div className="text-[13px] text-white/85">Без списаний и автопродления.</div>
        </div>
      </div>
    );
  }

  if (stateId === 54) {
    return (
      <div className="flex flex-col justify-between min-h-full space-y-3 text-center">
        <div className="space-y-2.5">
          <SystemHeaderBox title="РЕФЕРАЛЬНЫЙ БОНУС" onBack={() => navigateState(48)} />
          <SystemSquareIcon kind="calendar" />
          <SystemHeaderBox title="БОНУСНЫЕ ДНИ" />

          <div className="space-y-1.5 border-b border-white/30 pb-2.5">
            <div className="text-[20px] font-extrabold">
              Накоплено: {user.subscription.referralBonusDaysAvailable || 3} дня
            </div>
            <div className="text-[14px] text-white/90">Платная подписка активна.</div>
          </div>

          <p className="text-[14px] text-white/90 leading-snug">
            Бонус можно использовать после оплаченного периода.
          </p>
        </div>

        <div className="space-y-2">
          <SystemButton
            label="ИСПОЛЬЗОВАТЬ ПОСЛЕ ПОДПИСКИ"
            highlighted
            onClick={() => apiAction('/api/referrals/schedule-after-paid', {}, 48)}
          />
          <p className="text-[13px] text-white/85 leading-snug">
            Отключит автопродление.
            <br />
            Оплаченный доступ сохранится.
          </p>
        </div>
      </div>
    );
  }

  if (stateId === 55) {
    return (
      <div className="flex flex-col justify-between min-h-full space-y-3 text-center">
        <div className="space-y-2.5">
          <SystemHeaderBox title="БОНУСНЫЙ ДОСТУП" onBack={() => navigateState(28)} />
          <SystemSquareIcon kind="gift" />

          <div className="text-[19px] font-bold pt-1">Система+ активна</div>

          <div className="py-2.5 px-3 rounded-[8px] border border-[#38f8ff] bg-[#062d4a]/80 flex items-center justify-center gap-2 text-[15px] font-bold font-tabular">
            <Clock className="w-5 h-5 text-[#38e8ff]" />
            <span>{user.subscription.referralBonusActiveRemaining || '3 дня активны'}</span>
          </div>

          <div className="text-[14px] text-white/85 pt-1">Без списаний и автопродления</div>
        </div>

        <SystemButton label="К ДЕЛАМ" highlighted onClick={() => navigateState(11)} />
      </div>
    );
  }

  if (stateId === 56) {
    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5 text-center">
        <div className="space-y-2">
          <SystemHeaderBox title="БОНУСНЫЙ ДОСТУП ЗАВЕРШЁН" onBack={() => navigateState(28)} />
          <SystemSquareIcon kind="hourglass" />

          <div className="text-[17px] font-bold leading-snug pt-1">
            Вы вернулись на
            <br />
            бесплатный доступ
          </div>
          <div className="text-[14px] text-white/85 border-t border-white/30 pt-2">
            Данные и игровой прогресс сохранены
          </div>
        </div>

        <div className="space-y-2">
          <SystemButton
            label="ПОДКЛЮЧИТЬ ЗА 99 ⭐"
            highlighted
            onClick={() => (openPlusModal ? openPlusModal('general') : navigateState(49))}
          />
          <SystemButton label="Пригласить игрока" bracketed={false} onClick={() => navigateState(52)} />
          <SystemButton label="Продолжить бесплатно" bracketed={false} onClick={() => navigateState(11)} />
        </div>
      </div>
    );
  }

  if (stateId === 57) {
    return (
      <div className="flex flex-col justify-between min-h-full space-y-3 text-center">
        <div className="space-y-2.5">
          <SystemHeaderBox title="ПРИГЛАШЕНИЕ НЕ ЗАСЧИТАНО" onBack={() => navigateState(28)} />
          <SystemSquareIcon kind="user-x" />

          <div className="text-[17px] font-bold leading-snug pt-1">
            Этот игрок уже
            <br />
            пользовался Системой
          </div>
          <div className="text-[14px] text-white/85 border-t border-white/30 pt-2">
            Повторный вход не даёт новый бонус
          </div>
        </div>

        <div className="space-y-2.5">
          <SystemButton label="ПРИГЛАСИТЬ ДРУГОГО" highlighted onClick={() => navigateState(52)} />
          <SystemButton label="Назад" bracketed={false} onClick={() => navigateState(28)} />
        </div>
      </div>
    );
  }

  // --- ЕЖЕДНЕВНЫЕ ДЕЙСТВИЯ И ФОКУС-СЕССИЯ (States 58, 59, 60) ---
  if (stateId === 58) {
    const targetEntry =
      (selectedEntryId && user.financialEntries.find((e) => e.id === selectedEntryId)) ||
      user.financialEntries[0];

    if (!targetEntry) {
      return (
        <div className="flex flex-col justify-between min-h-full space-y-3 text-center">
          <SystemHeaderBox title="ИЗМЕНИТЬ ЗАПИСЬ" onBack={() => navigateState(19)} />
          <div className="py-6 text-[15px] text-white/80">Запись не найдена или была удалена.</div>
          <SystemButton label="К ФИНАНСАМ" highlighted onClick={() => navigateState(19)} />
        </div>
      );
    }

    const headerTitle =
      targetEntry.type === 'income'
        ? 'ИЗМЕНИТЬ ДОХОД'
        : targetEntry.type === 'transfer'
          ? 'ИЗМЕНИТЬ ПЕРЕВОД'
          : 'ИЗМЕНИТЬ ТРАТУ';
    const canSaveEntry = !busy && editExpenseTitle.trim().length > 0 && editExpenseNewAmount > 0;
    const categoryList = [
      'Еда',
      'Продукты',
      'Транспорт',
      'Жильё и связь',
      'Дом и быт',
      'Покупки',
      'Подписки',
      'Здоровье',
      'Досуг',
      'Зарплата',
      'Фриланс',
      'Премия',
      'Бизнес',
      'Перевод',
      'Прочее',
      'Другое',
    ];
    const activeAccs = user.accounts.filter((a) => a.status === 'active' || a.id === editExpenseAccount);

    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5">
        <div className="space-y-2.5">
          <SystemHeaderBox title={headerTitle} onBack={() => navigateState(19)} />

          <div className="space-y-1">
            <label className="text-[13px] text-white/85">Название</label>
            <input
              type="text"
              value={editExpenseTitle}
              onChange={(e) => setEditExpenseTitle(e.target.value)}
              className="w-full px-3 py-2 rounded-[6px] border border-white/80 bg-[#031221] text-[16px] font-semibold"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[13px] text-white/85">Сумма</label>
            <div className="px-3 py-2 rounded-[6px] border border-white/80 bg-[#031221] flex items-center justify-between text-[16px] font-bold font-tabular">
              <span>{targetEntry.amountRub} → {editExpenseNewAmount} ₽</span>
              <input
                type="number"
                min={1}
                value={editExpenseNewAmount || ''}
                onChange={(e) => setEditExpenseNewAmount(Math.max(0, Number(e.target.value) || 0))}
                className="w-24 text-right bg-black/40 px-2 py-0.5 rounded border border-white/40"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[13px] text-white/85">Категория</label>
            <div className="relative">
              <select
                value={categoryList.includes(editExpenseCategory) ? editExpenseCategory : 'Прочее'}
                onChange={(e) => setEditExpenseCategory(e.target.value)}
                className="w-full appearance-none pl-3 pr-9 py-2 rounded-[6px] border border-white/80 bg-[#031221] text-white font-semibold focus:outline-none focus:border-[#00e5ff]"
              >
                <option value="Еда">Еда</option>
                <option value="Продукты">Продукты</option>
                <option value="Транспорт">Транспорт</option>
                <option value="Жильё и связь">Жильё и связь</option>
                <option value="Дом и быт">Дом и быт</option>
                <option value="Покупки">Покупки</option>
                <option value="Подписки">Подписки</option>
                <option value="Здоровье">Здоровье</option>
                <option value="Досуг">Досуг</option>
                <option value="Зарплата">Зарплата</option>
                <option value="Фриланс">Фриланс</option>
                <option value="Премия">Премия</option>
                <option value="Бизнес">Бизнес</option>
                <option value="Перевод">Перевод</option>
                <option value="Прочее">Прочее</option>
                {editExpenseCategory === 'Другое' && <option value="Другое">Другое</option>}
              </select>
              <ChevronDown className="w-4 h-4 text-[#9deeff] pointer-events-none absolute right-3 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          {targetEntry.type !== 'transfer' && (
            <div className="space-y-1">
              <label className="text-[13px] text-white/85">Счёт</label>
              <div className="relative">
                <select
                  value={editExpenseAccount}
                  onChange={(e) => setEditExpenseAccount(e.target.value)}
                  className="w-full appearance-none pl-3 pr-9 py-2 rounded-[6px] border border-white/80 bg-[#031221] text-white font-semibold focus:outline-none focus:border-[#00e5ff]"
                >
                  {(activeAccs.length > 0
                    ? activeAccs
                    : [
                        { id: 'acc_card', name: 'Карта' },
                        { id: 'acc_cash', name: 'Наличные' },
                      ]
                  ).map((acc) => (
                    <option key={acc.id} value={acc.id}>
                      {acc.name}
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-4 h-4 text-[#9deeff] pointer-events-none absolute right-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>
          )}
        </div>

        <div className="space-y-2.5 text-center">
          <SystemButton
            label="СОХРАНИТЬ ИЗМЕНЕНИЯ"
            highlighted
            disabled={!canSaveEntry}
            onClick={() =>
              apiAction(
                '/api/finance/update-entry',
                {
                  entryId: targetEntry.id,
                  newAmountRub: editExpenseNewAmount,
                  title: editExpenseTitle.trim(),
                  category: editExpenseCategory,
                  accountId: targetEntry.type !== 'transfer' ? editExpenseAccount : undefined,
                },
                19
              )
            }
          />
          <button
            type="button"
            disabled={busy}
            onClick={() =>
              apiAction('/api/finance/update-entry', { entryId: targetEntry.id, deleteEntry: true }, 19)
            }
            className="text-[15px] underline underline-offset-4 text-white/90 hover:text-[#ff6b6b] cursor-pointer disabled:opacity-45"
          >
            Удалить запись
          </button>
        </div>
      </div>
    );
  }

  if (stateId === 59) {
    const totalSec = Math.max(1, user.focusSession?.totalSeconds || 900);
    const totalMinutes = Math.max(1, Math.round(totalSec / 60));
    const strokeOffset = Math.round(427 * (1 - Math.min(1, focusSecLeft / totalSec)));
    const activeTask =
      (user.focusSession?.taskId && user.tasks.find((t) => t.id === user.focusSession.taskId)) ||
      user.tasks.find((t) => !t.completed) ||
      user.tasks[0] || { id: 'tsk_reading', title: 'Английский' };

    return (
      <div className="flex flex-col items-center justify-between min-h-full text-center space-y-3">
        <div className="w-full space-y-2">
          <SystemHeaderBox title="ФОКУС-СЕССИЯ" onBack={() => navigateState(11)} />
          <BookOpen className="w-9 h-9 mx-auto text-white mt-1" />
          <div className="text-[20px] font-bold">
            {(user.focusSession?.title || activeTask.title).split('·')[0].trim()}
          </div>
          {/* Quick Focus Gate Presets (60 & 90 min PRO) */}
          <div className="grid grid-cols-5 gap-1 pt-0.5">
            {[15, 25, 45, 60, 90].map((mins) => {
              const isProGate = mins >= 60;
              const locked = isProGate && !user.subscription.active;
              const isSelected = totalMinutes === mins;
              return (
                <button
                  key={mins}
                  type="button"
                  onClick={() => {
                    if (locked) {
                      openPlusModal?.('feature', `Врата фокуса ${mins} мин`);
                      return;
                    }
                    apiAction('/api/tasks/start-focus', {
                      taskId: activeTask.id,
                      durationMinutes: mins,
                    });
                  }}
                  className={`py-1 rounded border text-[11px] font-bold font-tabular cursor-pointer flex items-center justify-center gap-0.5 ${
                    isSelected
                      ? 'border-[#38f8ff] bg-[#063254] text-white'
                      : 'border-white/40 bg-black/40 text-white/80 hover:border-[#38e8ff]'
                  }`}
                >
                  <span>{mins}м</span>
                  {locked && <Lock className="w-2.5 h-2.5 text-[#38e8ff]" />}
                </button>
              );
            })}
          </div>
        </div>

        <div className="relative w-40 h-40 flex items-center justify-center my-1">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 160 160">
            <circle
              cx="80"
              cy="80"
              r="68"
              stroke="rgba(255,255,255,0.2)"
              strokeWidth="10"
              fill="none"
            />
            <circle
              cx="80"
              cy="80"
              r="68"
              stroke="#00e5ff"
              strokeWidth="10"
              strokeDasharray="427"
              strokeDashoffset={strokeOffset}
              strokeLinecap="round"
              fill="none"
              style={{ filter: 'drop-shadow(0 0 8px #00e5ff)' }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-[32px] font-extrabold font-tabular leading-none">
              {formatTimerMS(focusSecLeft)}
            </span>
            <span className="text-[13px] text-white/85 mt-1">Из {totalMinutes} минут</span>
          </div>
        </div>

        <div className="w-full space-y-2.5">
          <SystemButton
            label={focusPaused ? 'ПРОДОЛЖИТЬ' : 'ПАУЗА'}
            highlighted
            disabled={busy}
            onClick={() => {
              const nextPaused = !focusPaused;
              setFocusPaused(nextPaused);
              apiAction('/api/tasks/focus-pause', {
                paused: nextPaused,
                remainingSeconds: focusSecLeft,
              });
            }}
          />
          <button
            type="button"
            disabled={busy}
            onClick={() =>
              apiAction(
                '/api/tasks/toggle',
                { taskId: activeTask.id, withFocusBonus: true },
                27
              )
            }
            className="text-[15px] underline underline-offset-4 text-white/90 hover:text-white cursor-pointer disabled:opacity-45"
          >
            Завершить и подтвердить выполнение
          </button>
          <div className="border-t border-white/30 pt-2 text-[13px] text-white/85">
            XP — после подтверждения выполнения
          </div>
        </div>
      </div>
    );
  }

  if (stateId === 60) {
    const isEditingExisting = Boolean(
      selectedTaskId && user.tasks.some((t) => t.id === selectedTaskId)
    );
    const duePresets = ['Сегодня', 'Завтра', 'Через 7 дней'];
    const canSaveTask = !busy && editTaskTitle.trim().length > 0;

    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5">
        <div className="space-y-2.5">
          <SystemHeaderBox
            title={isEditingExisting ? 'ИЗМЕНИТЬ ЗАДАНИЕ' : 'НОВОЕ ЗАДАНИЕ'}
            onBack={() => {
              setSelectedTaskId?.(null);
              setSelectedGoalId?.(null);
              navigateState(11);
            }}
          />

          <div className="space-y-1">
            <label className="text-[13px] text-white/85">Название</label>
            <textarea
              rows={2}
              placeholder="Например: Собрать 3 кейса в портфолио"
              value={editTaskTitle}
              onChange={(e) => setEditTaskTitle(e.target.value)}
              className="w-full px-3 py-2 rounded-[6px] border border-white/80 bg-[#031221] text-[15px] font-semibold resize-none"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[13px] text-white/85">Связанная цель</label>
            <div className="relative">
              <select
                value={editTaskGoalId}
                onChange={(e) => setEditTaskGoalId(e.target.value)}
                className="w-full appearance-none pl-3 pr-9 py-2 rounded-[6px] border border-white/80 bg-[#031221] text-white font-semibold focus:outline-none focus:border-[#00e5ff]"
              >
                <option value="">Без привязки к цели</option>
                {user.goals.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.title}
                  </option>
                ))}
              </select>
              <ChevronDown className="w-4 h-4 text-[#9deeff] pointer-events-none absolute right-3 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <label className="text-[13px] text-white/85">Срок</label>
              <div className="relative">
                <select
                  value={editTaskDue}
                  onChange={(e) => setEditTaskDue(e.target.value)}
                  className="w-full appearance-none pl-3 pr-9 py-2 rounded-[6px] border border-white/80 bg-[#031221] text-white font-semibold focus:outline-none focus:border-[#00e5ff]"
                >
                  {!duePresets.includes(editTaskDue) && editTaskDue && (
                    <option value={editTaskDue}>{editTaskDue}</option>
                  )}
                  <option value="Сегодня">Сегодня</option>
                  <option value="Завтра">Завтра</option>
                  <option value="Через 7 дней">Через 7 дней</option>
                </select>
                <ChevronDown className="w-4 h-4 text-[#9deeff] pointer-events-none absolute right-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[13px] text-white/85">Приоритет</label>
              <div className="relative">
                <select
                  value={editTaskPriority}
                  onChange={(e) => setEditTaskPriority(e.target.value as 'normal' | 'high')}
                  className="w-full appearance-none pl-3 pr-9 py-2 rounded-[6px] border border-white/80 bg-[#031221] text-white font-semibold focus:outline-none focus:border-[#00e5ff]"
                >
                  <option value="normal">Обычный</option>
                  <option value="high">Высокий</option>
                </select>
                <ChevronDown className="w-4 h-4 text-[#9deeff] pointer-events-none absolute right-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>
          </div>

          {/* Recurring Task Autopilot (PRO) */}
          <div className="space-y-1">
            <label className="text-[13px] text-white/85 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Repeat className="w-3.5 h-3.5 text-[#38e8ff]" />
                Повтор (Автопилот)
              </span>
              {!user.subscription.active && (
                <span className="text-[11px] font-bold text-[#38f8ff]">СИСТЕМА+ ★</span>
              )}
            </label>
            <div className="relative">
              <select
                value={editTaskRecurrence}
                onChange={(e) => {
                  const val = e.target.value as 'none' | 'daily' | 'weekdays' | 'weekly';
                  if (val !== 'none' && !user.subscription.active) {
                    openPlusModal?.('feature', 'Автопилот повторяющихся задач');
                    return;
                  }
                  setEditTaskRecurrence(val);
                }}
                className="w-full appearance-none pl-3 pr-9 py-2 rounded-[6px] border border-white/80 bg-[#031221] text-white font-semibold focus:outline-none focus:border-[#00e5ff]"
              >
                <option value="none">Без повтора (разово)</option>
                <option value="daily">Каждый день</option>
                <option value="weekdays">По будням (ПН–ПТ)</option>
                <option value="weekly">Раз в неделю</option>
              </select>
              <ChevronDown className="w-4 h-4 text-[#9deeff] pointer-events-none absolute right-3 top-1/2 -translate-y-1/2" />
            </div>
          </div>
        </div>

        <div className="space-y-2.5 text-center">
          <SystemButton
            label="СОХРАНИТЬ"
            highlighted
            disabled={!canSaveTask}
            onClick={() => {
              const payload = {
                id: isEditingExisting ? selectedTaskId : undefined,
                title: editTaskTitle.trim(),
                goalId: editTaskGoalId,
                dueDateText: editTaskDue,
                priority: editTaskPriority,
                recurrence: editTaskRecurrence,
              };
              setSelectedTaskId?.(null);
              setSelectedGoalId?.(null);
              apiAction('/api/tasks/save', payload, 11);
            }}
          />
          {isEditingExisting && (
            <button
              type="button"
              disabled={busy}
              onClick={() => {
                const taskIdToDelete = selectedTaskId;
                setSelectedTaskId?.(null);
                setSelectedGoalId?.(null);
                apiAction('/api/tasks/save', { id: taskIdToDelete, deleteTask: true }, 11);
              }}
              className="text-[15px] underline underline-offset-4 text-white/90 hover:text-[#ff6b6b] cursor-pointer disabled:opacity-45"
            >
              Удалить задание
            </button>
          )}
        </div>
      </div>
    );
  }

  // --- МАТЕРИАЛ, ВОПРОСЫ И ЗАЧЁТ ШТРАФНОГО КВЕСТА (States 61..69) ---
  if (stateId === 61) {
    const remainingStageSec = Math.max(0, 150 - stageElapsedSec);

    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5">
        <div className="space-y-2">
          <div className="py-1.5 px-3 rounded-[6px] border border-white/75 bg-[#290408]/80 flex items-center justify-center gap-2 text-[14px] font-bold font-tabular">
            <Clock className="w-4 h-4" />
            <span>До окончания срока: {formatTimerHMS(penaltyDeadlineSec)}</span>
          </div>

          <SystemHeaderBox title="УЧЕБНЫЙ РАЗБОР" palette="red" onBack={() => navigateState(41)} />

          <div className="flex items-center justify-between py-1 border-b border-white/30">
            <div className="flex items-center gap-2.5">
              <BookOpen className="w-6 h-6" />
              <span className="text-[17px] font-bold">Этап {user.penaltyQuest.currentStage} / 2</span>
            </div>
            <button
              type="button"
              onClick={() => navigateState(42)}
              className="text-[12px] underline text-white/85 cursor-pointer"
            >
              Таймер этапа
            </button>
          </div>

          <div className="space-y-1.5 text-left">
            <div className="text-[13px] text-white/80">Тема:</div>
            <div className="text-[18px] font-bold border-b border-white/30 pb-1.5">
              Один конкретный шаг
            </div>
            <p className="text-[14px] text-white/95 leading-relaxed pt-1">
              Большую задачу проще начать с одного действия. Вместо „заняться портфолио“ запланируйте „выбрать три работы“. Укажите время начала и подготовьте нужные материалы.
            </p>
          </div>
        </div>

        <div className="space-y-2 text-center border-t border-white/30 pt-2">
          <div className="text-[13px] text-white/85">До проверки этапа:</div>
          <div className="text-[34px] font-extrabold font-tabular leading-none">
            {formatTimerMS(remainingStageSec)}
          </div>
          <SystemButton
            label="ПЕРЕЙТИ К ПРОВЕРКЕ"
            palette="red"
            highlighted
            onClick={() => navigateState(62)}
          />
        </div>
      </div>
    );
  }

  if (stateId === 62) {
    const activeQ = QUIZ_QUESTIONS[quizQuestionIdx % QUIZ_QUESTIONS.length];

    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5">
        <div className="space-y-2">
          <div className="py-1.5 px-3 rounded-[6px] border border-white/75 bg-[#290408]/80 flex items-center justify-center gap-2 text-[14px] font-bold font-tabular">
            <Clock className="w-4 h-4" />
            <span>До окончания срока: {formatTimerHMS(penaltyDeadlineSec)}</span>
          </div>

          <SystemHeaderBox title="ПРОВЕРКА ПОНИМАНИЯ" palette="red" onBack={() => navigateState(61)} />

          <div className="flex items-center gap-3 py-1 border-b border-white/30">
            <BookOpen className="w-6 h-6" />
            <span className="text-[17px] font-bold">
              Вопрос {Math.min(5, user.penaltyQuest.questionsPassed + 1)} из 5
            </span>
          </div>

          <div className="text-[17px] font-bold leading-snug py-1">
            {activeQ.prompt}
          </div>

          <div className="divide-y divide-white/25 border-t border-b border-white/30">
            {activeQ.options.map((opt, idx) => {
              const active = selectedQuizOption === idx;
              return (
                <button
                  key={opt}
                  type="button"
                  onClick={() => setSelectedQuizOption(idx)}
                  className="w-full py-2.5 flex items-center gap-3 text-left cursor-pointer hover:bg-white/5"
                >
                  <span className="w-6 h-6 rounded-full border-2 border-white flex items-center justify-center shrink-0">
                    {active && <span className="w-3 h-3 rounded-full bg-white" />}
                  </span>
                  <span className="text-[15px] font-semibold">{opt}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="space-y-2 text-center">
          <SystemButton
            label="ОТВЕТИТЬ"
            palette="red"
            highlighted
            onClick={() => {
              if (selectedQuizOption === activeQ.correctIndex) {
                const nextQIdx = quizQuestionIdx + 1;
                setQuizQuestionIdx(nextQIdx);
                const willCompleteAll5 = user.penaltyQuest.questionsPassed + 1 >= 5 || nextQIdx >= 5;
                apiAction(
                  '/api/penalty/answer',
                  { questionId: activeQ.id, optionIndex: selectedQuizOption },
                  willCompleteAll5 ? 63 : 62
                );
              } else {
                apiAction(
                  '/api/penalty/answer',
                  { questionId: activeQ.id, optionIndex: selectedQuizOption },
                  68
                );
              }
            }}
          />
          <div className="text-[12px] text-white/80 leading-snug">
            Правильный ответ открывает следующий вопрос
          </div>
        </div>
      </div>
    );
  }

  if (stateId === 63) {
    const reasons = ['Отвлёкся', 'Мало времени', 'Слишком устал', 'Большая задача', 'Забыл'];
    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5 pb-4">
        <div className="space-y-2">
          <div className="py-1 px-3 rounded-[6px] border border-white/75 bg-[#290408]/80 flex items-center justify-center gap-2 text-[13px] font-bold font-tabular">
            <Clock className="w-4 h-4" />
            <span>До окончания срока: {formatTimerHMS(penaltyDeadlineSec)}</span>
          </div>

          <SystemHeaderBox
            title="ФИКСАЦИЯ ПРОРЫВА"
            palette="red"
            onBack={() => navigateState(42)}
          />

          <div className="space-y-1">
            <div className="text-[12.5px] text-white/85">Почему возник срыв? (1 касание)</div>
            <div className="flex flex-wrap gap-1.5">
              {reasons.map((r) => {
                const active = reflectionReason === r;
                return (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setReflectionReason(r)}
                    className={`px-2.5 py-1 border text-[12px] font-semibold cursor-pointer ${
                      active
                        ? 'border-[#ff6b6b] bg-[#45070e] text-white'
                        : 'border-white/35 bg-black/45 text-white/80 hover:border-white'
                    }`}
                  >
                    {r}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[13px] text-white/85">Следующий шаг (добавится в задачи)</label>
            <textarea
              rows={2}
              value={nextStepActionText}
              onChange={(e) => setNextStepActionText(e.target.value)}
              className="w-full px-3 py-2 rounded-[6px] border border-white/80 bg-[#240307] text-[14.5px] font-semibold resize-none"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[13px] text-white/85">Когда выполнить</label>
            <input
              type="text"
              value={nextStepWhenText}
              onChange={(e) => setNextStepWhenText(e.target.value)}
              className="w-full px-3 py-2 rounded-[6px] border border-white/80 bg-[#240307] text-[14.5px] font-semibold"
            />
          </div>
        </div>

        <div className="space-y-2 text-center pt-1">
          <SystemButton
            label="СОХРАНИТЬ И СНЯТЬ ШТРАФ"
            palette="red"
            highlighted
            disabled={busy || !nextStepActionText.trim()}
            onClick={() =>
              apiAction(
                '/api/penalty/save-next-step',
                {
                  actionTitle: nextStepActionText.trim(),
                  whenText: nextStepWhenText.trim() || 'Завтра в 19:00',
                  reflectionReason,
                },
                69
              )
            }
          />
          <div className="text-[12px] text-white/75">
            Шаг автоматически попадёт в список «Сегодня»
          </div>
        </div>
      </div>
    );
  }

  if (stateId === 64) {
    const remainingStageSec = Math.max(0, 150 - stageElapsedSec);
    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5">
        <div className="space-y-2.5">
          <div className="py-1.5 px-3 rounded-[6px] border border-white/75 bg-[#290408]/80 text-center text-[14px] font-bold font-tabular">
            До окончания срока · {formatTimerHMS(penaltyDeadlineSec)}
          </div>
          <SystemSquareIcon kind="alert" palette="red" />
          <SystemHeaderBox title="КВЕСТ НА ПАУЗЕ" palette="red" />

          <div className="divide-y divide-white/25 border-t border-b border-white/30 text-[14px]">
            <div className="py-2 flex items-center gap-3">
              <BookOpen className="w-5 h-5 shrink-0" />
              <span>Засчитано {Math.floor(stageElapsedSec / 60)} мин {stageElapsedSec % 60} с</span>
            </div>
            <div className="py-2 flex items-center gap-3">
              <Hourglass className="w-5 h-5 shrink-0" />
              <span>До проверки этапа: {formatTimerMS(remainingStageSec)}</span>
            </div>
            <div className="py-2 flex items-center gap-3">
              <Ban className="w-5 h-5 shrink-0" />
              <span>Время вне модуля не добавляется</span>
            </div>
            <div className="py-2 flex items-center gap-3">
              <Check className="w-5 h-5 shrink-0" />
              <span>Днём отсчёт срока продолжается</span>
            </div>
          </div>
        </div>

        <SystemButton
          label="ПРОДОЛЖИТЬ"
          palette="red"
          highlighted
          onClick={() => navigateState(42)}
        />
      </div>
    );
  }

  if (stateId === 65) {
    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5">
        <div className="space-y-2.5">
          <div className="py-1.5 px-3 rounded-[6px] border border-white/75 bg-[#290408]/80 text-center text-[14px] font-bold">
            Днём срок продолжает идти
          </div>
          <SystemSquareIcon kind="alert" palette="red" />
          <SystemHeaderBox title="НЕТ СВЯЗИ" palette="red" />

          <div className="divide-y divide-white/25 border-t border-b border-white/30 text-[14px]">
            <div className="py-2.5 flex items-center gap-3">
              <WifiOff className="w-6 h-6 shrink-0" />
              <span>Последний подтверждённый прогресс сохранён</span>
            </div>
            <div className="py-2.5 flex items-center gap-3">
              <Wifi className="w-6 h-6 shrink-0" />
              <span>Проверка и завершение доступны после подключения</span>
            </div>
            <div className="py-2.5 flex items-center gap-3">
              <FileText className="w-6 h-6 shrink-0" />
              <span>Черновик ответа сохранён</span>
            </div>
          </div>
        </div>

        <SystemButton
          label="ПРОВЕРИТЬ СВЯЗЬ"
          palette="red"
          highlighted
          onClick={() => navigateState(42)}
        />
      </div>
    );
  }

  if (stateId === 66) {
    return (
      <div className="flex flex-col justify-between min-h-full space-y-3">
        <div className="space-y-2.5">
          <div className="py-1.5 px-3 rounded-[6px] border border-white/75 bg-[#290408]/80 text-center text-[14px] font-bold font-tabular">
            До окончания срока · {formatTimerHMS(penaltyDeadlineSec)}
          </div>
          <SystemSquareIcon kind="alert" palette="red" />
          <SystemHeaderBox title="КВЕСТ ОТКРЫТ В ДРУГОМ ОКНЕ" palette="red" />

          <div className="divide-y divide-white/25 border-t border-b border-white/30 text-[15px]">
            <div className="py-3 flex items-center gap-3">
              <Copy className="w-6 h-6 shrink-0" />
              <span>Одновременно работает одна сессия</span>
            </div>
            <div className="py-3 flex items-center gap-3">
              <PauseCircle className="w-6 h-6 shrink-0" />
              <span>Другое окно будет поставлено на паузу</span>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <SystemButton
            label="ПРОДОЛЖИТЬ ЗДЕСЬ"
            palette="red"
            highlighted
            onClick={() => navigateState(42)}
          />
          <SystemButton
            label="Назад"
            bracketed={false}
            palette="red"
            onClick={() => navigateState(11)}
          />
        </div>
      </div>
    );
  }

  if (stateId === 67) {
    const stagesReady = stageElapsedSec >= 150 && user.penaltyQuest.currentStage >= 2;
    const answersCount = Math.min(5, user.penaltyQuest.questionsPassed || 0);
    const answersReady = answersCount >= 5;
    const stepReady = Boolean(user.penaltyQuest.nextStepSaved);
    const allReady = stagesReady && answersReady && stepReady;

    const nextTargetState = !answersReady ? 62 : !stepReady ? 63 : !stagesReady ? 61 : 69;
    const nextButtonLabel = !answersReady
      ? 'ПРОДОЛЖИТЬ ПРОВЕРКУ'
      : !stepReady
        ? 'СОХРАНИТЬ ШАГ'
        : !stagesReady
          ? 'ВЕРНУТЬСЯ К РАЗБОРУ'
          : 'К ЗАЧЁТУ КВЕСТА';

    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5">
        <div className="space-y-2.5">
          <div className="py-1.5 px-3 rounded-[6px] border border-white/75 bg-[#290408]/80 flex items-center justify-center gap-2 text-[14px] font-bold font-tabular">
            <Clock className="w-4 h-4" />
            <span>До окончания срока: {formatTimerHMS(penaltyDeadlineSec)}</span>
          </div>
          <SystemHeaderBox title="КВЕСТ ЕЩЁ НЕ ЗАВЕРШЁН" palette="red" />

          <div className="divide-y divide-white/25 border-t border-b border-white/30">
            <SystemCheckbox
              checked={stagesReady}
              label={`Этапы ${stagesReady ? 2 : user.penaltyQuest.currentStage} / 2`}
            />
            <SystemCheckbox checked={answersReady} label={`Ответы ${answersCount} / 5`} />
            <SystemCheckbox
              checked={stepReady}
              label={stepReady ? 'Следующий шаг сохранён' : 'Следующий шаг не сохранён'}
            />
          </div>

          <div className="text-center text-[15px] font-semibold py-2">
            {allReady ? (
              'Все условия выполнены.'
            ) : (
              <>
                Одного ожидания
                <br />
                недостаточно.
              </>
            )}
          </div>
        </div>

        <SystemButton
          label={nextButtonLabel}
          palette="red"
          highlighted
          onClick={() => navigateState(nextTargetState)}
        />
      </div>
    );
  }

  if (stateId === 68) {
    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5">
        <div className="space-y-2">
          <div className="py-1.5 px-3 rounded-[6px] border border-white/75 bg-[#290408]/80 flex items-center justify-center gap-2 text-[14px] font-bold font-tabular">
            <Clock className="w-4 h-4" />
            <span>До окончания срока: {formatTimerHMS(penaltyDeadlineSec)}</span>
          </div>
          <SystemHeaderBox title="РАЗБОР ОТВЕТА" palette="red" />

          <div className="text-center text-[17px] font-bold py-1.5 border-b border-white/30">
            Ответ пока неверный.
          </div>

          <div className="divide-y divide-white/25 text-[14px]">
            <div className="py-2.5 flex items-start gap-3">
              <BookOpen className="w-6 h-6 shrink-0 mt-0.5" />
              <span>
                {user.penaltyQuest.lastAnswerError ||
                  'Конкретный шаг содержит действие и понятный результат. „Стать продуктивнее“ не задаёт результата.'}
              </span>
            </div>
            <div className="py-2.5 flex items-start gap-3">
              <RotateCcw className="w-6 h-6 shrink-0 mt-0.5" />
              <span>Вернитесь к материалу и попробуйте другой вопрос.</span>
            </div>
          </div>
        </div>

        <div className="space-y-2 text-center">
          <SystemButton
            label="К МАТЕРИАЛУ"
            palette="red"
            highlighted
            onClick={() => navigateState(61)}
          />
          <div className="text-[13px] text-white/85">Пройденные этапы не сбрасываются.</div>
        </div>
      </div>
    );
  }

  if (stateId === 69) {
    const chNames: Record<string, string> = {
      body: 'Выносливость (20 повторений)',
      focus: 'Концентрация (3 минуты)',
      revenge: 'Реванш по делу',
    };
    const trialDoneLabel =
      (user.penaltyQuest.selectedChallenge && chNames[user.penaltyQuest.selectedChallenge]) ||
      'Условие испытания выполнено';
    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5 pb-4">
        <div className="space-y-2">
          <div className="py-1.5 px-3 rounded-[6px] border border-white/75 bg-[#290408]/80 flex items-center justify-center gap-2 text-[14px] font-bold font-tabular">
            <Clock className="w-4 h-4" />
            <span>До окончания срока: {formatTimerHMS(penaltyDeadlineSec)}</span>
          </div>
          <SystemHeaderBox title="ГОТОВО К ЗАЧЁТУ" palette="red" />

          <div className="divide-y divide-white/25 border-t border-b border-white/30">
            <SystemCheckbox checked={true} label={trialDoneLabel} />
            <SystemCheckbox
              checked={true}
              label={`Причина: ${user.penaltyQuest.reflectionReason || 'разобрана'}`}
            />
            <SystemCheckbox checked={true} label="Следующий шаг сохранён" />
          </div>
        </div>

        <div className="space-y-2 text-center">
          <SystemButton
            label="ЗАВЕРШИТЬ КВЕСТ"
            palette="red"
            highlighted
            disabled={busy}
            onClick={() => apiAction('/api/penalty/complete', {}, 43)}
          />
          <div className="flex items-center justify-center gap-2.5 text-left text-[13px] py-1">
            <Gift className="w-5 h-5 shrink-0" />
            <span>Карантин снимется сразу после подтверждения.</span>
          </div>
        </div>
      </div>
    );
  }

  // --- НАСТРОЙКА НОЧНОГО ПЕРИОДА И ПРОФИЛЯ (States 70, 71, 72) ---
  if (stateId === 70) {
    const nightDurationHours = calculateNightWindowDurationHours(nightStart, nightEnd);
    const isNightValid = nightDurationHours > 0 && nightDurationHours <= 10;

    return (
      <div className="flex flex-col justify-between min-h-full space-y-2">
        <div className="space-y-2">
          <SystemHeaderBox title="НАСТРОЙКИ СИСТЕМЫ" onBack={() => navigateState(28)} />

          <div className="grid grid-cols-2 gap-1.5">
            <div className="p-2 rounded-[6px] border border-white/75 bg-[#031221] flex items-center justify-between">
              <span className="text-[13px] text-white/85">Сон с</span>
              <input
                type="time"
                value={nightStart}
                onChange={(e) => setNightStart(e.target.value)}
                className="px-1.5 py-0.5 rounded border border-white/70 bg-black/50 text-white text-[14px] font-bold font-tabular [color-scheme:dark]"
              />
            </div>

            <div className="p-2 rounded-[6px] border border-white/75 bg-[#031221] flex items-center justify-between">
              <span className="text-[13px] text-white/85">До</span>
              <input
                type="time"
                value={nightEnd}
                onChange={(e) => setNightEnd(e.target.value)}
                className="px-1.5 py-0.5 rounded border border-white/70 bg-black/50 text-white text-[14px] font-bold font-tabular [color-scheme:dark]"
              />
            </div>
          </div>

          <div
            className={`py-1.5 px-2.5 rounded-[6px] border text-[12px] flex items-center justify-between ${
              isNightValid
                ? 'border-white/60 bg-[#04182b] text-white/90'
                : 'border-[#ff6b6b] bg-[#2c050a] text-[#ff9b9b]'
            }`}
          >
            <span>
              {isNightValid
                ? `Ночная пауза: ${nightDurationHours.toFixed(1).replace('.0', '')} ч (макс. 10 ч)`
                : 'Окно паузы: от 1 мин до 10 ч'}
            </span>
            <span className={isNightValid ? 'text-[#38e8ff] font-semibold' : 'font-bold'}>
              {isNightValid ? 'Квест 12 ч' : 'Ошибка'}
            </span>
          </div>

          <div className="rounded-[6px] border border-white/65 bg-[#031221]/90 divide-y divide-white/20 px-2.5">
            <SystemCheckbox
              checked={soundOn}
              label="Звуковые эффекты Системы"
              onChange={() => {
                const next = !soundOn;
                setSoundOn(next);
                if (next) playSystemSound('ui_step', true);
              }}
            />
            <SystemCheckbox
              checked={hapticsOn}
              label="Тактильный отклик (Haptics)"
              onChange={() => {
                const next = !hapticsOn;
                setHapticsOn(next);
                if (next) triggerHaptic('light', true);
              }}
            />
            <SystemCheckbox
              checked={botPushOn}
              label="Push-напоминания в Telegram-боте"
              onChange={() => setBotPushOn((v) => !v)}
            />
          </div>

          {/* HUD Theme Switcher (4 Collectible Skins — No 10s Preview Button) */}
          <div className="p-2.5 rounded-[6px] border border-white/55 bg-[#031221]/85 space-y-2">
            <div className="flex items-center justify-between text-[11px] uppercase tracking-[0.06em] text-[#9deeff] font-bold">
              <span className="flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5" />
                Облик HUD и Карточки 9:16
              </span>
              {!user.subscription.active && (
                <span className="text-amber-300">3 скина в Система+ ★</span>
              )}
            </div>
            <div className="grid grid-cols-2 gap-2">
              {[
                {
                  id: 'blue' as const,
                  label: 'Кибер-Голубой',
                  dotColor: 'bg-[#00e5ff]',
                  activeCls: 'border-[#38f8ff] bg-[#063254] text-white',
                  pro: false,
                },
                {
                  id: 'monarch' as const,
                  label: 'Теневой Монарх',
                  dotColor: 'bg-[#a855f7]',
                  activeCls: 'border-[#c084fc] bg-[#240a3d] text-white',
                  pro: true,
                },
                {
                  id: 'igris' as const,
                  label: 'Алый Игрис',
                  dotColor: 'bg-[#fb7185]',
                  activeCls: 'border-[#fb7185] bg-[#3b0614] text-white',
                  pro: true,
                },
                {
                  id: 'sovereign' as const,
                  label: 'Золотой S-Ранг',
                  dotColor: 'bg-[#fbbf24]',
                  activeCls: 'border-[#fbbf24] bg-[#2e1c03] text-white',
                  pro: true,
                },
              ].map((skin) => {
                const isSelected = (user.hudTheme || 'blue') === skin.id;
                const locked = skin.pro && !user.subscription.active;
                return (
                  <button
                    key={skin.id}
                    type="button"
                    disabled={busy}
                    onClick={() => {
                      if (locked) {
                        openPlusModal?.('feature', `Облик «${skin.label}»`);
                        return;
                      }
                      apiAction('/api/settings/theme', { theme: skin.id });
                    }}
                    className={`min-h-[44px] py-2 px-2.5 rounded border text-[12px] font-bold cursor-pointer flex items-center justify-between gap-1.5 transition-colors ${
                      isSelected
                        ? skin.activeCls
                        : 'border-white/35 bg-black/45 text-white/85 hover:border-white/75'
                    }`}
                  >
                    <span className="flex items-center gap-1.5 min-w-0 truncate">
                      <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${skin.dotColor}`} />
                      <span className="truncate">{skin.label}</span>
                    </span>
                    {locked && <Lock className="w-3.5 h-3.5 text-amber-300 shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Admin-only Система+ Grant / Revoke Control */}
          {isAdmin && (
            <div className="p-2 rounded-[6px] border border-[#38f8ff]/45 bg-[#031221]/90 flex items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 text-[12px] font-bold text-white">
                  <Crown className="w-3.5 h-3.5 text-[#38f8ff] shrink-0" />
                  <span>Доступ «Система+» (Dev/Admin)</span>
                </div>
                <div className="text-[11px] text-[#9deeff]/85 truncate">
                  {user.subscription.active
                    ? 'Активна · Все PRO-функции открыты'
                    : 'Отключена · Базовый ранг (Free)'}
                </div>
              </div>
              <button
                type="button"
                disabled={busy}
                onClick={() =>
                  apiAction('/api/settings/toggle-plus', { enabled: !user.subscription.active })
                }
                className={`px-2.5 py-1.5 rounded border text-[11.5px] font-bold shrink-0 cursor-pointer transition-colors ${
                  user.subscription.active
                    ? 'border-[#ff6b6b]/70 bg-[#2e050a] text-[#ffb3b3] hover:border-[#ff4d4d]'
                    : 'border-[#38f8ff] bg-[#063456] text-white hover:bg-[#084675] shadow-[0_0_10px_rgba(0,225,255,0.35)]'
                }`}
              >
                {user.subscription.active ? 'Убрать Система+' : 'Выдать Система+'}
              </button>
            </div>
          )}

          <button
            type="button"
            onClick={() => {
              setSettingsReturnState?.(70);
              navigateState(4);
            }}
            className="w-full py-1.5 px-2.5 rounded-[6px] border border-white/45 bg-[#031221]/85 text-[12px] font-semibold text-white/90 hover:border-[#38e8ff] hover:text-white cursor-pointer"
          >
            Изменить имя и класс ({user.playerCallsign || 'Игрок'})
          </button>
        </div>

        <div className="space-y-1.5">
          <SystemButton
            label="СОХРАНИТЬ НАСТРОЙКИ"
            highlighted
            disabled={busy || !isNightValid}
            onClick={() =>
              apiAction(
                '/api/settings/night-window',
                {
                  start: nightStart,
                  end: nightEnd,
                  timezone: getClientTimezone(),
                  soundEnabled: soundOn,
                  hapticsEnabled: hapticsOn,
                  botNotificationsEnabled: botPushOn,
                },
                28
              )
            }
          />
          {isAdmin && (
            <div className="grid grid-cols-3 gap-1.5 pt-0.5">
              <button
                type="button"
                onClick={() => apiAction('/api/profile/reset-mode', { mode: 'new_player' }, 1)}
                className="py-1.5 px-1.5 rounded border border-white/40 bg-black/45 text-[11px] font-semibold text-white/85 hover:text-white hover:border-[#38e8ff] cursor-pointer flex items-center justify-center gap-1"
              >
                <UserPlus className="w-3.5 h-3.5 text-[#38e8ff] shrink-0" />
                <span>С 1 ур.</span>
              </button>
              <button
                type="button"
                onClick={() => apiAction('/api/profile/reset-mode', { mode: 'active_player' }, 10)}
                className="py-1.5 px-1.5 rounded border border-white/40 bg-black/45 text-[11px] font-semibold text-white/85 hover:text-white hover:border-[#38e8ff] cursor-pointer flex items-center justify-center gap-1"
              >
                <Crown className="w-3.5 h-3.5 text-[#38e8ff] shrink-0" />
                <span>Демо 12</span>
              </button>
              <button
                type="button"
                onClick={() => apiAction('/api/profile/reset-mode', { mode: 'penalty_demo' }, 40)}
                className="py-1.5 px-1.5 rounded border border-[#ff4d4d]/60 bg-[#2a0408]/60 text-[11px] font-semibold text-[#ffb3b3] hover:text-white hover:border-[#ff4d4d] cursor-pointer flex items-center justify-center gap-1"
              >
                <Ban className="w-3.5 h-3.5 text-[#ff4d4d] shrink-0" />
                <span>Штраф</span>
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (stateId === 71) {
    return (
      <div className="flex flex-col justify-between min-h-full space-y-2.5 text-center">
        <div className="space-y-2">
          <SystemSquareIcon kind="alert" palette="red" circleOnly />
          <SystemHeaderBox title="НОЧНАЯ ПАУЗА" palette="red" />

          <div className="py-1.5 rounded border border-white/65 bg-[#290408]/80 text-[15px] font-bold font-tabular">
            Пауза: {user.nightPeriodStart} — {user.nightPeriodEnd}
          </div>

          <div className="py-1">
            <div className="text-[36px] font-extrabold font-tabular leading-none">
              {formatTimerHMS(penaltyDeadlineSec)}
            </div>
            <div className="text-[14px] text-white/90 mt-1">Осталось на выполнение</div>
          </div>

          <div className="divide-y divide-white/25 border-t border-b border-white/35 text-left text-[14px]">
            <div className="py-2 flex items-center gap-3">
              <PauseCircle className="w-5 h-5 shrink-0" />
              <span>Отсчёт продолжится в {user.nightPeriodEnd}</span>
            </div>
            <div className="py-2 flex items-center gap-3">
              <Calendar className="w-5 h-5 shrink-0" />
              <span>Таймер на время сна заморожен</span>
            </div>
            <div className="py-2 flex items-center gap-3">
              <PlayCircle className="w-5 h-5 shrink-0" />
              <span>Квест можно пройти сейчас</span>
            </div>
          </div>
        </div>

        <SystemButton
          label="ПРОДОЛЖИТЬ КВЕСТ"
          palette="red"
          highlighted
          onClick={() => navigateState(42)}
        />
      </div>
    );
  }

  return (
    <div className="flex flex-col justify-between min-h-full space-y-2.5 text-center">
      <div className="space-y-2.5">
        <SystemSquareIcon kind="alert" palette="red" circleOnly />
        <SystemHeaderBox title="ОТСЧЁТ ВОЗОБНОВЛЁН" palette="red" />

        <div className="py-1.5 rounded border border-white/65 bg-[#290408]/80 text-[15px] font-bold font-tabular">
          Окно сна завершено ({user.nightPeriodEnd})
        </div>

        <div className="py-1">
          <div className="text-[36px] font-extrabold font-tabular leading-none">
            {formatTimerHMS(penaltyDeadlineSec)}
          </div>
          <div className="text-[14px] text-white/90 mt-1">До окончания срока</div>
        </div>

        <div className="divide-y divide-white/25 border-t border-b border-white/35 text-left text-[15px]">
          <div className="py-3 flex items-center gap-3">
            <Calendar className="w-6 h-6 shrink-0" />
            <span>Отсчёт времени квеста снова идёт</span>
          </div>
          <div className="py-3 flex items-center gap-3">
            <Layers className="w-6 h-6 shrink-0" />
            <span>Прогресс этапов сохранён</span>
          </div>
        </div>
      </div>

      <SystemButton
        label="ПРОДОЛЖИТЬ КВЕСТ"
        palette="red"
        highlighted
        onClick={() => navigateState(42)}
      />
    </div>
  );
});
