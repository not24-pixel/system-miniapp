import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Share2 } from 'lucide-react';
import { UserAppState } from '../shared/types';
import { playSystemSound } from '../shared/sound';
import { getHunterRankInfo, SystemButton, SystemProgressBar, SystemSquareIcon } from './SystemWidgets';
import { ManaParticleEmitter } from './ManaParticleEmitter';
import { RollingNumber } from './RollingNumber';

interface LevelUpOverlayProps {
  open: boolean;
  prevLevel: number;
  xpGain: number;
  user: UserAppState;
  onAllocatePoints: () => void;
  onDismiss: () => void;
  onOpenShareCard?: () => void;
}

export const LevelUpOverlay: React.FC<LevelUpOverlayProps> = ({
  open,
  prevLevel,
  xpGain,
  user,
  onAllocatePoints,
  onDismiss,
  onOpenShareCard,
}) => {
  const rankInfo = getHunterRankInfo(user.level);

  useEffect(() => {
    if (!open) return;
    playSystemSound('level_up', user.soundEnabled, user.hapticsEnabled);
  }, [open, user.soundEnabled, user.hapticsEnabled]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-50 bg-[#01050d]/94 flex items-center justify-center p-4"
        >
          <motion.div
            initial={
              user.reducedMotion
                ? { opacity: 0 }
                : {
                    scaleY: 0.02,
                    scaleX: 0.85,
                    opacity: 0.4,
                                      }
            }
            animate={{
              scaleY: 1,
              scaleX: 1,
              opacity: 1,
                          }}
            exit={{ opacity: 0, scaleY: 0.05 }}
            transition={{
              scaleX: { duration: 0.16, ease: [0.16, 1, 0.3, 1] },
              scaleY: { duration: 0.34, delay: 0.04, ease: [0.16, 1, 0.3, 1] },
                          }}
            className="relative w-full max-w-[400px] border-2 border-[#38f8ff] system-glass-blue p-6 text-center shadow-[0_0_54px_rgba(0,229,255,0.65),inset_0_0_28px_rgba(0,229,255,0.28)] overflow-hidden"
          >
            <ManaParticleEmitter palette="blue" reducedMotion={user.reducedMotion} burstKey={`lvl_${user.level}`} density={40} />
            <div className="pointer-events-none absolute inset-0 system-scanlines" />

            {/* Horizontal Awakening Flare */}
            {!user.reducedMotion && (
              <motion.div
                initial={{ opacity: 1, scaleX: 0.2, height: '6px' }}
                animate={{ opacity: 0, scaleX: 1.2, height: '160px' }}
                transition={{ duration: 0.45, ease: 'easeOut' }}
                className="pointer-events-none absolute left-0 right-0 top-1/2 -translate-y-1/2 bg-gradient-to-r from-transparent via-[#72f8ff] to-transparent z-30"
              />
            )}

            <div className="relative z-10 space-y-4">
              <SystemSquareIcon kind="double-up" palette="blue" />

              <div className="border border-white/90 bg-[#04182b]/90 py-2 px-3 shadow-[0_0_20px_rgba(0,229,255,0.45)]">
                <h2 className="text-[22px] font-extrabold tracking-[0.12em] uppercase text-white system-text-glow-blue">
                  УРОВЕНЬ ПОВЫШЕН!
                </h2>
              </div>

              <div className="border-t border-b border-white/35 py-4 space-y-2.5">
                <div className="text-[13px] uppercase tracking-[0.12em] text-[#9deeff]">
                  {user.playerCallsign?.trim() || 'Игрок'}
                </div>

                <div className="text-[30px] font-extrabold font-tabular text-white system-text-glow-blue leading-none">
                  УР. {prevLevel} → УР.{' '}
                  <RollingNumber value={user.level} animateFrom={prevLevel} reducedMotion={user.reducedMotion} />
                </div>

                <div className="inline-block px-3 py-1 border border-[#38f8ff] bg-[#062d4a]/90 text-[13px] font-bold tracking-[0.06em] text-[#72f8ff]">
                  [ {rankInfo.rank} · {rankInfo.title} ]
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2 text-[14px]">
                  <div className="border border-white/30 bg-black/40 py-2 px-2">
                    <div className="text-white/75 text-[11px] uppercase">Получен опыт</div>
                    <div className="text-[18px] font-extrabold text-[#38f8ff] font-tabular">
                      <RollingNumber
                        value={xpGain}
                        animateFrom={0}
                        prefix="+"
                        suffix=" XP"
                        reducedMotion={user.reducedMotion}
                      />
                    </div>
                  </div>
                  <div className="border border-[#38f8ff]/65 bg-[#062d4a]/50 py-2 px-2">
                    <div className="text-white/80 text-[11px] uppercase">Награда Системы</div>
                    <div className="text-[18px] font-extrabold text-white font-tabular">
                      +3 очка
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between text-[13px] text-white/85 font-tabular">
                  <span>Следующий уровень</span>
                  <span>
                    <RollingNumber
                      value={user.currentXp}
                      animateFrom={0}
                      useGrouping
                      reducedMotion={user.reducedMotion}
                    />{' '}
                    /{' '}
                    <RollingNumber
                      value={user.nextLevelXp}
                      useGrouping
                      reducedMotion={user.reducedMotion}
                    />{' '}
                    XP
                  </span>
                </div>
                <SystemProgressBar value={user.currentXp} max={user.nextLevelXp} />
              </div>

              <div className="space-y-2 pt-2">
                <SystemButton
                  label="РАСПРЕДЕЛИТЬ ОЧКИ"
                  highlighted
                  onClick={onAllocatePoints}
                />
                {onOpenShareCard && (
                  <button
                    type="button"
                    onClick={() => {
                      onDismiss();
                      onOpenShareCard();
                    }}
                    className="w-full min-h-[44px] px-3 py-2 border border-[#38f8ff]/80 bg-[#062d4a]/85 text-[13px] font-bold text-[#9deeff] hover:border-white hover:text-white flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Share2 className="w-4 h-4 text-[#38f8ff]" />
                    <span>ПОДЕЛИТЬСЯ РАНГОМ · 9:16</span>
                  </button>
                )}
                <SystemButton
                  label="ПРОДОЛЖИТЬ"
                  bracketed={false}
                  onClick={onDismiss}
                />
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
