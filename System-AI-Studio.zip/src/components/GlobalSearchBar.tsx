import React, { memo, useMemo, useState } from 'react';
import { CheckSquare, ChevronRight, Crown, ListChecks, Search, Target, X } from 'lucide-react';
import { SystemPalette, UserAppState } from '../shared/types';
import { formatRub } from '../shared/constants';
import { playSystemSound } from '../shared/sound';

interface GlobalSearchBarProps {
  user: UserAppState;
  palette: SystemPalette;
  monarchTheme: boolean;
  hudTheme?: 'blue' | 'monarch' | 'igris' | 'sovereign';
  onSelectTask: (taskId: string) => void;
  onSelectHabit: (habitId: string) => void;
  onSelectGoal: (goalId: string) => void;
  onOpenPlus?: () => void;
}

interface SearchHit {
  kind: 'task' | 'habit' | 'goal';
  id: string;
  title: string;
  meta: string;
  done?: boolean;
}

export const GlobalSearchBar: React.FC<GlobalSearchBarProps> = memo(({
  user,
  palette,
  monarchTheme,
  hudTheme,
  onSelectTask,
  onSelectHabit,
  onSelectGoal,
  onOpenPlus,
}) => {
  const [query, setQuery] = useState('');
  const [focused, setFocused] = useState(false);

  const normalized = query.trim().toLowerCase();

  const hits = useMemo<SearchHit[]>(() => {
    if (!normalized) return [];
    const results: SearchHit[] = [];

    for (const t of user.tasks) {
      if (
        t.title.toLowerCase().includes(normalized) ||
        t.dueDateText.toLowerCase().includes(normalized)
      ) {
        results.push({
          kind: 'task',
          id: t.id,
          title: t.title,
          meta: `Задача · ${t.dueDateText} · +${t.xpReward} XP`,
          done: t.completed,
        });
      }
    }

    for (const h of user.habits) {
      if (h.status === 'archived') continue;
      if (
        h.title.toLowerCase().includes(normalized) ||
        h.daysOfWeek.join(' ').toLowerCase().includes(normalized)
      ) {
        results.push({
          kind: 'habit',
          id: h.id,
          title: h.title,
          meta: `Привычка · ${h.currentMinutesToday}/${h.durationMinutes} мин`,
          done: h.completedToday,
        });
      }
    }

    for (const g of user.goals) {
      if (g.status === 'archived') continue;
      if (
        g.title.toLowerCase().includes(normalized) ||
        g.unit.toLowerCase().includes(normalized)
      ) {
        const progress =
          g.type === 'savings'
            ? `${formatRub(g.currentValue)} / ${formatRub(g.targetValue)}`
            : `${g.currentValue} / ${g.targetValue} ${g.unit}`;
        results.push({
          kind: 'goal',
          id: g.id,
          title: g.title,
          meta: `Цель · ${progress}`,
          done: g.status === 'completed',
        });
      }
    }

    return results.slice(0, 8);
  }, [normalized, user.tasks, user.habits, user.goals]);

  const isRed = palette === 'red';
  const skin = isRed ? 'red' : hudTheme || (monarchTheme ? 'monarch' : 'blue');
  const borderClass =
    skin === 'red'
      ? 'border-[#ff4d4d]/70 focus-within:border-[#ff8080]'
      : skin === 'monarch'
      ? 'border-[#a855f7]/70 focus-within:border-[#d8b4fe]'
      : skin === 'igris'
      ? 'border-[#f43f5e]/70 focus-within:border-[#fda4af]'
      : skin === 'sovereign'
      ? 'border-[#f59e0b]/70 focus-within:border-[#fde68a]'
      : 'border-[#38f8ff]/60 focus-within:border-[#72f8ff]';
  const iconColor =
    skin === 'red'
      ? 'text-[#ff7a7a]'
      : skin === 'monarch'
      ? 'text-[#d8b4fe]'
      : skin === 'igris'
      ? 'text-[#fda4af]'
      : skin === 'sovereign'
      ? 'text-[#fcd34d]'
      : 'text-[#38f8ff]';
  const dropdownThemeClass =
    skin === 'red'
      ? 'border-[#ff4d4d] bg-[#160306]/98'
      : skin === 'monarch'
      ? 'border-[#a855f7] bg-[#0b0416]/98'
      : skin === 'igris'
      ? 'border-[#f43f5e] bg-[#17040a]/98'
      : skin === 'sovereign'
      ? 'border-[#f59e0b] bg-[#140e03]/98'
      : 'border-[#38f8ff] bg-[#030e1c]/98';

  const handlePick = (hit: SearchHit) => {
    playSystemSound('ui_step', user.soundEnabled, user.hapticsEnabled);
    setQuery('');
    setFocused(false);
    if (hit.kind === 'task') onSelectTask(hit.id);
    else if (hit.kind === 'habit') onSelectHabit(hit.id);
    else onSelectGoal(hit.id);
  };

  return (
    <div className="relative z-40 px-4 pt-[26px] pb-1.5 shrink-0">
      <div className="flex items-center gap-1.5">
        <div
          className={`flex-1 min-w-0 min-h-[40px] flex items-center gap-2 px-2.5 py-1 border bg-[#020a14]/95 ${borderClass} transition-colors`}
        >
          <Search className={`w-3.5 h-3.5 shrink-0 ${iconColor}`} />
          <input
            type="text"
            value={query}
            onFocus={() => setFocused(true)}
            onBlur={() => {
              // Delay slightly so click on hit fires before dropdown closes
              setTimeout(() => setFocused(false), 160);
            }}
            onChange={(e) => {
              setQuery(e.target.value);
              if (!focused) setFocused(true);
            }}
            placeholder="Поиск: задача, привычка, цель..."
            aria-label="Глобальный поиск"
            className="w-full bg-transparent text-[12.5px] text-white placeholder:text-white/45 focus:outline-none"
          />
          {query && (
            <button
              type="button"
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => setQuery('')}
              aria-label="Очистить поиск"
              className="min-w-[32px] min-h-[32px] flex items-center justify-center text-white/65 hover:text-white cursor-pointer shrink-0"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
        {onOpenPlus && (
          <button
            type="button"
            onClick={() => {
              playSystemSound('ui_step', user.soundEnabled, user.hapticsEnabled);
              onOpenPlus();
            }}
            className={`min-h-[40px] px-2.5 border flex items-center gap-1 text-[11.5px] font-bold shrink-0 cursor-pointer transition-colors ${
              user.subscription.active
                ? 'border-amber-400/80 bg-[#1f1505]/90 text-amber-200 hover:border-amber-300'
                : 'border-amber-400/95 bg-gradient-to-r from-[#2e1c03] to-[#1a1004] text-amber-200 shadow-[0_0_12px_rgba(251,191,36,0.3)] hover:border-white hover:text-white'
            }`}
          >
            <Crown className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>{user.subscription.active ? 'PRO' : 'PRO · 99⭐'}</span>
          </button>
        )}
      </div>

      {/* Dropdown Search Results */}
      {focused && normalized.length > 0 && (
        <div
          className={`absolute left-4 right-4 top-full mt-1 border ${dropdownThemeClass} shadow-[0_14px_34px_rgba(0,0,0,0.92)] max-h-[260px] overflow-y-auto system-scroll z-50`}
        >
          {hits.length === 0 ? (
            <div className="px-3 py-2.5 text-[12px] text-white/65 text-center">
              Ничего не найдено по запросу «{query.trim()}»
            </div>
          ) : (
            <div className="divide-y divide-white/15">
              {hits.map((hit) => {
                const KindIcon =
                  hit.kind === 'task'
                    ? ListChecks
                    : hit.kind === 'habit'
                    ? CheckSquare
                    : Target;
                return (
                  <button
                    key={`${hit.kind}_${hit.id}`}
                    type="button"
                    onMouseDown={(e) => {
                      e.preventDefault();
                      handlePick(hit);
                    }}
                    className="w-full px-3 py-2 flex items-center justify-between gap-2 text-left hover:bg-white/10 cursor-pointer"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <KindIcon className={`w-4 h-4 shrink-0 ${iconColor}`} />
                      <div className="min-w-0">
                        <div
                          className={`text-[12.5px] font-semibold truncate ${
                            hit.done ? 'text-white/60 line-through' : 'text-white'
                          }`}
                        >
                          {hit.title}
                        </div>
                        <div className="text-[11px] text-white/65 truncate">{hit.meta}</div>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-white/50 shrink-0" />
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
});
