import React, { memo, useState } from 'react';
import {
  Crown,
  Infinity as InfinityIcon,
  Layers,
  Repeat,
  Shield,
  Sparkles,
  Star,
  TrendingUp,
  X,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { SUBSCRIPTION_PLANS } from '../shared/constants';
import { SubscriptionPlanId, UserAppState } from '../shared/types';
import { playSystemSound } from '../shared/sound';
import { getAuthHeaders } from '../shared/apiClient';
import { SystemButton } from './SystemWidgets';

export interface SystemPlusModalProps {
  open: boolean;
  reason?: 'habits' | 'goals' | 'accounts' | 'feature' | 'general';
  featureLabel?: string;
  user: UserAppState;
  busy: boolean;
  onClose: () => void;
  onPaymentSuccess: (planId: SubscriptionPlanId, chargeId?: string) => Promise<void>;
  onOpenReferral?: () => void;
}

interface TelegramWebAppLike {
  openInvoice?: (url: string, cb?: (status: string) => void) => void;
}

export const SystemPlusModal: React.FC<SystemPlusModalProps> = memo(({
  open,
  reason = 'general',
  featureLabel,
  user,
  busy,
  onClose,
  onPaymentSuccess,
  onOpenReferral,
}) => {
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlanId>('3m');
  const [invoiceLoading, setInvoiceLoading] = useState(false);
  const [paymentStatusNote, setPaymentStatusNote] = useState<string | null>(null);
  const [awaitingConfirmPlan, setAwaitingConfirmPlan] = useState<SubscriptionPlanId | null>(null);

  const reducedMotion = user.reducedMotion;
  const activePlan = SUBSCRIPTION_PLANS.find((p) => p.id === selectedPlan) || SUBSCRIPTION_PLANS[0];

  const activeHabits = user.habits.filter((h) => h.status !== 'archived').length;
  const activeGoals = user.goals.filter((g) => g.status === 'active').length;
  const activeAccounts = user.accounts.filter((a) => a.status === 'active').length;

  const limitHeadline =
    reason === 'habits'
      ? `Лимит привычек: ${activeHabits} / 3`
      : reason === 'goals'
      ? `Лимит целей: ${activeGoals} / 3`
      : reason === 'accounts'
      ? `Лимит счетов: ${activeAccounts} / 3`
      : reason === 'feature' && featureLabel
      ? `Модуль «${featureLabel}»`
      : 'Пробуждение полного доступа';

  const handleUpgradeNow = async () => {
    playSystemSound('ui_step', user.soundEnabled, user.hapticsEnabled);
    setPaymentStatusNote(null);
    setInvoiceLoading(true);
    try {
      const apiBase = ((import.meta as unknown as { env?: Record<string, string> }).env?.VITE_BOT_API_URL || '').replace(/\/$/, '');
      const res = await fetch(`${apiBase}/api/subscription/create-invoice`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          planId: activePlan.id,
          telegramId: user.telegramId,
        }),
      });
      const contentType = res.headers.get('content-type') || '';
      const data = contentType.includes('application/json')
        ? await res.json()
        : { ok: true, fallbackDemo: true };

      const tg = (window as unknown as { Telegram?: { WebApp?: TelegramWebAppLike } }).Telegram
        ?.WebApp;

      if (data.invoiceUrl && tg?.openInvoice) {
        tg.openInvoice(data.invoiceUrl, async (status: string) => {
          if (status === 'paid') {
            await onPaymentSuccess(activePlan.id, `xtr_${Date.now()}`);
            setInvoiceLoading(false);
            onClose();
          } else if (status === 'cancelled' || status === 'failed') {
            setPaymentStatusNote('Оплата Telegram Stars отменена. Попробуйте снова.');
            setInvoiceLoading(false);
          } else {
            setPaymentStatusNote(`Статус счёта: ${status}`);
            setInvoiceLoading(false);
          }
        });
        return;
      }

      setAwaitingConfirmPlan(activePlan.id);
      setInvoiceLoading(false);
    } catch {
      setAwaitingConfirmPlan(activePlan.id);
      setInvoiceLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={reducedMotion ? { opacity: 1 } : { opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={reducedMotion ? { opacity: 0 } : { opacity: 0 }}
          transition={{ duration: 0.16 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/90"
          role="dialog"
          aria-modal="true"
          aria-label="Подписка Система+"
        >
          {/* Outer fixed container keeps geometric white corner brackets & close button anchored */}
          <motion.div
            initial={reducedMotion ? false : { scale: 0.95, opacity: 0, y: 10 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={reducedMotion ? { opacity: 0 } : { scale: 0.96, opacity: 0, y: 6 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-[404px] max-h-[90dvh] flex flex-col border-2 border-[#38f8ff] system-glass-blue shadow-[0_0_45px_rgba(0,229,255,0.48),inset_0_0_24px_rgba(0,229,255,0.22)] text-white overflow-hidden"
          >
            {/* Static Non-Scrolling Geometric Corner Brackets */}
            <span className="pointer-events-none absolute top-1 left-1 w-3 h-3 border-t-2 border-l-2 border-white z-20" />
            <span className="pointer-events-none absolute top-1 right-1 w-3 h-3 border-t-2 border-r-2 border-white z-20" />
            <span className="pointer-events-none absolute bottom-1 left-1 w-3 h-3 border-b-2 border-l-2 border-white z-20" />
            <span className="pointer-events-none absolute bottom-1 right-1 w-3 h-3 border-b-2 border-r-2 border-white z-20" />

            <button
              type="button"
              onClick={() => {
                setAwaitingConfirmPlan(null);
                setPaymentStatusNote(null);
                onClose();
              }}
              aria-label="Закрыть"
              className="absolute top-1.5 right-1.5 z-30 min-w-[44px] min-h-[44px] flex items-center justify-center text-white/80 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Inner Scrollable Content Area with Priority Conversion Blocks First */}
            <div className="flex-1 overflow-y-auto system-scroll system-scroll-blue p-4 space-y-3.5">
              {/* 1. Header */}
              <div className="text-center space-y-1 pt-1 pr-6 pl-6">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 border border-[#38f8ff]/70 bg-[#062d4a]/80 text-[11px] font-mono uppercase tracking-[0.12em] text-[#72f8ff]">
                  <Crown className="w-3.5 h-3.5 text-amber-400" />
                  <span>СИСТЕМА+ · TELEGRAM STARS</span>
                </div>
                <h2 className="text-[19px] font-extrabold uppercase tracking-[0.05em] system-text-glow-blue pt-0.5 leading-tight">
                  {limitHeadline}
                </h2>
                <p className="text-[12.5px] text-white/80 leading-snug">
                  Базовый трекер и умная фин-строка всегда бесплатны. Система+ открывает безлимит и PRO-инструменты.
                </p>
              </div>

              {/* 2. Plan Selector (Immediate above-the-fold priority) */}
              <div className="grid grid-cols-3 gap-1.5">
                {SUBSCRIPTION_PLANS.map((plan) => {
                  const active = selectedPlan === plan.id;
                  return (
                    <button
                      key={plan.id}
                      type="button"
                      onClick={() => {
                        setAwaitingConfirmPlan(null);
                        setSelectedPlan(plan.id);
                      }}
                      className={`relative p-2 border text-center transition-colors cursor-pointer ${
                        active
                          ? 'border-[#38f8ff] bg-[#063254]/90 shadow-[0_0_14px_rgba(0,225,255,0.45)]'
                          : 'border-white/35 bg-black/45 hover:border-white/70'
                      }`}
                    >
                      {plan.badge && (
                        <span className="block text-[10px] font-bold text-amber-300 leading-none mb-1">
                          {plan.badge}
                        </span>
                      )}
                      <div className="text-[12px] font-bold text-white leading-tight">
                        {plan.title}
                      </div>
                      <div className="mt-1 flex items-center justify-center gap-1 text-[14px] font-extrabold text-[#72f8ff] font-tabular">
                        <span>{plan.stars}</span>
                        <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                      </div>
                    </button>
                  );
                })}
              </div>

              {paymentStatusNote && (
                <div className="p-2 border border-[#ff4d4d] bg-[#2c050a]/90 text-[12px] text-[#ffd2cf] text-center">
                  {paymentStatusNote}
                </div>
              )}

              {/* 3. Primary Payment CTA & Quick Actions (Immediate above-the-fold priority) */}
              {awaitingConfirmPlan ? (
                <div className="border border-[#38f8ff] bg-[#04182b]/95 p-3 space-y-2 text-center">
                  <div className="text-[12.5px] text-[#b9fbff] leading-snug">
                    Предпросмотр тарифа:{' '}
                    <strong className="text-white">{activePlan.stars} ⭐ ({activePlan.title})</strong>.{' '}
                    Внутри Telegram Mini App здесь сразу откроется официальная оплата Telegram Stars.
                  </div>
                  <SystemButton
                    label={`ТЕСТОВАЯ АКТИВАЦИЯ · ${activePlan.stars} ⭐`}
                    highlighted
                    disabled={busy}
                    onClick={async () => {
                      await onPaymentSuccess(awaitingConfirmPlan, `xtr_${Date.now()}`);
                      setAwaitingConfirmPlan(null);
                      onClose();
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setAwaitingConfirmPlan(null)}
                    className="text-[12px] text-white/75 underline cursor-pointer"
                  >
                    Выбрать другой тариф
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  <SystemButton
                    label={
                      invoiceLoading
                        ? 'ОТКРЫВАЕМ СЧЁТ...'
                        : `ПОДКЛЮЧИТЬ ЗА ${activePlan.stars} ⭐`
                    }
                    highlighted
                    disabled={busy || invoiceLoading}
                    onClick={handleUpgradeNow}
                  />

                  <div className="flex items-center justify-between text-[12px] pt-0.5">
                    {onOpenReferral ? (
                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          onOpenReferral();
                        }}
                        className="text-[#72f8ff] hover:text-white underline underline-offset-4 cursor-pointer flex items-center gap-1"
                      >
                        <Layers className="w-3.5 h-3.5" />
                        <span>+3 дня бесплатно за друга</span>
                      </button>
                    ) : (
                      <span />
                    )}
                    <button
                      type="button"
                      onClick={onClose}
                      className="min-h-[36px] px-2 text-white/75 hover:text-white cursor-pointer"
                    >
                      Остаться на Free
                    </button>
                  </div>
                </div>
              )}

              {/* 4. Scrollable PRO Value Details Below */}
              <div className="space-y-1.5 pt-1 border-t border-white/20">
                <div className="text-[11px] font-bold uppercase tracking-[0.08em] text-[#9deeff] text-center">
                  ЧТО ВХОДИТ В СИСТЕМА+
                </div>
                <div className="border border-white/30 bg-black/45 divide-y divide-white/15 text-left">
                  {[
                    {
                      Icon: Sparkles,
                      title: 'Армия Теней без лимита и ×2 XP + ×1.5 Сундук',
                      sub: 'Вместо 1 Тени (+5 XP) — безлимит Теней по +10 XP и усиленный сундук дня',
                    },
                    {
                      Icon: Crown,
                      title: '3 элитных облика HUD и 9:16 Карточки',
                      sub: '«Теневой Монарх», «Алый Игрис», «Золотой S-Ранг» для профиля и TikTok',
                    },
                    {
                      Icon: Shield,
                      title: 'Щит Системы (2 заморозки) · защита Серии',
                      sub: 'Снимает штрафной квест в 1 клик и сохраняет вашу серию дней',
                    },
                    {
                      Icon: InfinityIcon,
                      title: 'Безлимит ∞ целей, привычек, счетов + Умные этапы',
                      sub: 'Без ограничений 3/3 + безлимитный авто-план этапов под любую цель',
                    },
                    {
                      Icon: TrendingUp,
                      title: 'Прогноз даты накопления и аналитика трат',
                      sub: 'Точный срок достижения фин-цели + сравнение категорий по месяцам',
                    },
                    {
                      Icon: Repeat,
                      title: 'Личный бот-пинг в Telegram и автопилот задач',
                      sub: 'Утренние квесты, пинг за 1 час до штрафа, автоповтор и 60/90м врата',
                    },
                  ].map(({ Icon, title, sub }) => (
                    <div key={title} className="px-2.5 py-2.5 flex items-start gap-2.5">
                      <div className="w-6 h-6 mt-0.5 border border-[#38f8ff]/70 bg-[#062d4a]/80 flex items-center justify-center shrink-0">
                        <Icon className="w-3.5 h-3.5 text-[#72f8ff]" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-[13px] font-bold text-white leading-tight">{title}</div>
                        <div className="text-[11.5px] text-white/75 leading-snug mt-0.5">{sub}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
});
