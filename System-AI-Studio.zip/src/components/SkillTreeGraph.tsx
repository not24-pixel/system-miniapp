import React, { memo, useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity,
  ArrowUpCircle,
  Calendar,
  Check,
  ChevronRight,
  Lock,
  Shield,
  Sparkles,
  Target,
  Zap,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { SkillBranchId, SkillBranchState, StatKey, UserAppState } from '../shared/types';
import { SystemButton, getHunterRankInfo } from './SystemWidgets';
import { playSystemSound } from '../shared/sound';
import { RollingNumber } from './RollingNumber';

interface SkillTreeGraphProps {
  user: UserAppState;
  busy?: boolean;
  onSelectBranch?: (branchId: SkillBranchId) => void;
  onOpenBranchState: (stateId: number) => void;
  onUpgradeSkill: (branchId: SkillBranchId) => void;
  onOpenStatAllocation: () => void;
}

interface BranchMeta {
  id: SkillBranchId;
  areaLabel: string;
  title: string;
  statKey: StatKey;
  stateTarget: number;
  angleDeg: number;
  labelPos: { x: number; y: number; anchor: 'middle' | 'start' | 'end' };
  tierDescriptions: [string, string, string];
  Icon: React.FC<{ className?: string }>;
}

const BRANCH_METAS: BranchMeta[] = [
  {
    id: 'focus',
    areaLabel: 'Фокус',
    title: 'Фокус',
    statKey: 'intelligence',
    stateTarget: 32,
    angleDeg: -90,
    labelPos: { x: 180, y: 15, anchor: 'middle' },
    tierDescriptions: [
      '+5 XP за фокус-сессию · до 3 раз/день',
      '+10 XP · цепочка из 2 сессий',
      '+15 XP · цепочка из 3 сессий',
    ],
    Icon: Target,
  },
  {
    id: 'planning',
    areaLabel: 'Стратегия',
    title: 'Планирование',
    statKey: 'agility',
    stateTarget: 35,
    angleDeg: -18,
    labelPos: { x: 300, y: 100, anchor: 'middle' },
    tierDescriptions: [
      'Следующий шаг для 1 активной цели',
      'Следующие шаги сразу для 3 целей',
      'Авто-маршрут по всем активным целям',
    ],
    Icon: Calendar,
  },
  {
    id: 'control',
    areaLabel: 'Богатство',
    title: 'Контроль',
    statKey: 'perception',
    stateTarget: 36,
    angleDeg: 54,
    labelPos: { x: 266, y: 292, anchor: 'middle' },
    tierDescriptions: [
      'Ежедневная сверка счетов (+5 XP)',
      'Недельный аудит трат и доходов',
      'Сигналы при превышении лимитов',
    ],
    Icon: Shield,
  },
  {
    id: 'rhythm',
    areaLabel: 'Ритм',
    title: 'Ритм',
    statKey: 'endurance',
    stateTarget: 34,
    angleDeg: 126,
    labelPos: { x: 94, y: 292, anchor: 'middle' },
    tierDescriptions: [
      '1 защита игровой серии за 30 дней',
      '2 защиты игровой серии за 30 дней',
      '3 защиты игровой серии за 30 дней',
    ],
    Icon: Activity,
  },
  {
    id: 'impulse',
    areaLabel: 'Дисциплина',
    title: 'Импульс',
    statKey: 'strength',
    stateTarget: 37,
    angleDeg: 198,
    labelPos: { x: 60, y: 100, anchor: 'middle' },
    tierDescriptions: [
      '+5 XP за запланированную активность',
      '+10 XP за запланированную активность',
      '+15 XP за запланированную активность',
    ],
    Icon: Zap,
  },
];

const CENTER = { x: 180, y: 164 };
const TIER_RADII: [number, number, number] = [52, 88, 124];
const ROMAN: [string, string, string] = ['I', 'II', 'III'];

// Cross-navigation snapshot so returning from State 38 still highlights recent unlocks cleanly
const lastObservedLevels = new Map<SkillBranchId, number>();

function polarPoint(angleDeg: number, radius: number) {
  const rad = (angleDeg * Math.PI) / 180;
  return {
    x: Number((CENTER.x + Math.cos(rad) * radius).toFixed(1)),
    y: Number((CENTER.y + Math.sin(rad) * radius).toFixed(1)),
  };
}

type NodeStatus = 'unlocked' | 'upgrade_ready' | 'reachable_with_points' | 'locked';

function evaluateBranchStatus(
  skill: SkillBranchState | undefined,
  meta: BranchMeta,
  user: UserAppState
): {
  level: number;
  allNextMet: boolean;
  statReachableWithPoints: boolean;
  nextStatMissing: number;
} {
  if (!skill) {
    return { level: 1, allNextMet: false, statReachableWithPoints: false, nextStatMissing: 0 };
  }
  const isMax = skill.level >= skill.maxLevel;
  const reqs = skill.requirementsForNext || [];
  const allNextMet = !isMax && reqs.length > 0 && reqs.every((r) => r.current >= r.target);

  const statReq = reqs[0];
  const statVal = user.stats[meta.statKey] ?? 10;
  const missing = statReq ? Math.max(0, statReq.target - statVal) : 0;
  const statReachableWithPoints =
    !isMax &&
    !allNextMet &&
    missing > 0 &&
    user.unspentStatPoints >= missing;

  return {
    level: skill.level,
    allNextMet,
    statReachableWithPoints,
    nextStatMissing: missing,
  };
}

export const SkillTreeGraph: React.FC<SkillTreeGraphProps> = memo(({
  user,
  busy = false,
  onSelectBranch,
  onOpenBranchState,
  onUpgradeSkill,
  onOpenStatAllocation,
}) => {
  const branchStates = useMemo(() => {
    const map: Record<SkillBranchId, ReturnType<typeof evaluateBranchStatus>> = {
      focus: evaluateBranchStatus(user.skills.focus, BRANCH_METAS[0], user),
      planning: evaluateBranchStatus(user.skills.planning, BRANCH_METAS[1], user),
      control: evaluateBranchStatus(user.skills.control, BRANCH_METAS[2], user),
      rhythm: evaluateBranchStatus(user.skills.rhythm, BRANCH_METAS[3], user),
      impulse: evaluateBranchStatus(user.skills.impulse, BRANCH_METAS[4], user),
    };
    return map;
  }, [user]);

  const upgradableBranches = useMemo(
    () => BRANCH_METAS.filter((b) => branchStates[b.id].allNextMet),
    [branchStates]
  );

  const reachableBranches = useMemo(
    () => BRANCH_METAS.filter((b) => branchStates[b.id].statReachableWithPoints),
    [branchStates]
  );

  const initialFocusBranch: SkillBranchId =
    upgradableBranches[0]?.id ||
    reachableBranches[0]?.id ||
    user.selectedSkillId ||
    'focus';

  const [selectedBranchId, setSelectedBranchId] = useState<SkillBranchId>(initialFocusBranch);
  const [selectedTier, setSelectedTier] = useState<1 | 2 | 3>(() => {
    const lvl = user.skills[initialFocusBranch]?.level ?? 1;
    return Math.min(3, lvl + (branchStates[initialFocusBranch]?.allNextMet ? 1 : 0)) as 1 | 2 | 3;
  });

  // Tracks the connecting power-pulse wave when a skill node unlocks
  const [unlockPulse, setUnlockPulse] = useState<{
    branchId: SkillBranchId;
    unlockedTier: number;
    pulseId: number;
  } | null>(null);
  const pulseTimerRef = useRef<number | null>(null);

  useEffect(() => {
    let newlyUnlocked: { branchId: SkillBranchId; unlockedTier: number } | null = null;
    for (const meta of BRANCH_METAS) {
      const currentLevel = user.skills[meta.id]?.level ?? 1;
      const prevLevel = lastObservedLevels.get(meta.id);
      if (typeof prevLevel === 'number' && currentLevel > prevLevel) {
        newlyUnlocked = { branchId: meta.id, unlockedTier: currentLevel };
      }
      lastObservedLevels.set(meta.id, currentLevel);
    }

    if (newlyUnlocked) {
      setSelectedBranchId(newlyUnlocked.branchId);
      setSelectedTier(Math.min(3, newlyUnlocked.unlockedTier) as 1 | 2 | 3);
      setUnlockPulse({
        branchId: newlyUnlocked.branchId,
        unlockedTier: newlyUnlocked.unlockedTier,
        pulseId: Date.now(),
      });
      if (pulseTimerRef.current) window.clearTimeout(pulseTimerRef.current);
      pulseTimerRef.current = window.setTimeout(() => {
        setUnlockPulse(null);
      }, 1500);
    }
  }, [user.skills]);

  useEffect(() => {
    return () => {
      if (pulseTimerRef.current) window.clearTimeout(pulseTimerRef.current);
    };
  }, []);

  const activeMeta = BRANCH_METAS.find((b) => b.id === selectedBranchId) || BRANCH_METAS[0];
  const activeSkill = user.skills[activeMeta.id];
  const activeEval = branchStates[activeMeta.id];
  const rankInfo = getHunterRankInfo(user.level);

  const handleSelectNode = (branchId: SkillBranchId, tier: 1 | 2 | 3) => {
    playSystemSound('ui_step', user.soundEnabled, user.hapticsEnabled);
    setSelectedBranchId(branchId);
    setSelectedTier(tier);
    onSelectBranch?.(branchId);
  };

  const selectedTierIsUnlocked = selectedTier <= activeEval.level;
  const selectedTierIsNext = selectedTier === activeEval.level + 1;
  const canUpgradeSelected = selectedTierIsNext && activeEval.allNextMet;
  const canInvestStatForSelected =
    selectedTierIsNext && !activeEval.allNextMet && activeEval.nextStatMissing > 0 && user.unspentStatPoints > 0;

  return (
    <div className="flex flex-col space-y-2">
      {/* Level-Up & Upgrade Availability Callout */}
      <AnimatePresence mode="popLayout">
        {(upgradableBranches.length > 0 || (user.unspentStatPoints > 0 && reachableBranches.length > 0)) && (
          <motion.div
            key="upgrade_banner"
            layout
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.22 }}
            className="px-2.5 py-1.5 rounded-[6px] border border-[#ffd166]/85 bg-[#1a1405]/85 flex items-center justify-between gap-2 text-[12px]"
          >
            <div className="flex items-center gap-1.5 min-w-0">
              <Sparkles className="w-4 h-4 text-[#ffd166] shrink-0" />
              <span className="font-bold text-[#ffe599] truncate">
                {upgradableBranches.length > 0 ? (
                  <>
                    Доступно улучшений: <RollingNumber value={upgradableBranches.length} metricKey="skills_upg_avail" />
                  </>
                ) : (
                  <>
                    Очки (<RollingNumber value={user.unspentStatPoints} metricKey="skills_unspent" />) откроют {reachableBranches[0]?.title}
                  </>
                )}
              </span>
            </div>
            {upgradableBranches.length > 0 ? (
              <button
                type="button"
                onClick={() => {
                  const target = upgradableBranches[0];
                  handleSelectNode(target.id, Math.min(3, branchStates[target.id].level + 1) as 1 | 2 | 3);
                }}
                className="text-[11px] font-bold text-[#38f8ff] underline underline-offset-2 whitespace-nowrap shrink-0 cursor-pointer"
              >
                Показать
              </button>
            ) : (
              <button
                type="button"
                onClick={onOpenStatAllocation}
                className="text-[11px] font-bold text-[#38f8ff] underline underline-offset-2 whitespace-nowrap shrink-0 cursor-pointer"
              >
                Распределить
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Interactive Constellation SVG + Framer Motion Layout Nodes */}
      <div className="relative w-full aspect-[360/304] max-h-[296px] mx-auto rounded-[6px] border border-[#38f8ff]/35 bg-[#020b15]/85 overflow-hidden select-none">
        <svg
          viewBox="0 0 360 304"
          className="w-full h-full block"
          role="img"
          aria-label="Граф развития навыков игрока"
        >
          <defs>
            <filter id="node-glow-cyan" x="-40%" y="-40%" width="180%" height="180%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
            <filter id="node-glow-gold" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="3.5" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
            <filter id="node-glow-surge" x="-80%" y="-80%" width="260%" height="260%">
              <feGaussianBlur stdDeviation="4.5" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Subtle orbital constellation guide rings */}
          {TIER_RADII.map((r, idx) => (
            <circle
              key={r}
              cx={CENTER.x}
              cy={CENTER.y}
              r={r}
              fill="none"
              stroke="rgba(56, 248, 255, 0.1)"
              strokeWidth="1"
              strokeDasharray={idx === 2 ? '3 5' : undefined}
            />
          ))}

          {/* Edges connecting Core -> Tier 1 -> Tier 2 -> Tier 3 */}
          {BRANCH_METAS.map((branch) => {
            const evalInfo = branchStates[branch.id];
            const pts = [
              CENTER,
              polarPoint(branch.angleDeg, TIER_RADII[0]),
              polarPoint(branch.angleDeg, TIER_RADII[1]),
              polarPoint(branch.angleDeg, TIER_RADII[2]),
            ];

            return [1, 2, 3].map((tierNum) => {
              const p1 = pts[tierNum - 1];
              const p2 = pts[tierNum];
              const isUnlockedEdge = tierNum <= evalInfo.level;
              const isUpgradeReadyEdge = tierNum === evalInfo.level + 1 && evalInfo.allNextMet;
              const isReachableEdge =
                tierNum === evalInfo.level + 1 && evalInfo.statReachableWithPoints;
              const isPulsingBranch =
                unlockPulse &&
                unlockPulse.branchId === branch.id &&
                tierNum <= unlockPulse.unlockedTier;
              const isTargetSurgeEdge =
                unlockPulse &&
                unlockPulse.branchId === branch.id &&
                tierNum === unlockPulse.unlockedTier;

              return (
                <g key={`${branch.id}_edge_${tierNum}`}>
                  <line
                    x1={p1.x}
                    y1={p1.y}
                    x2={p2.x}
                    y2={p2.y}
                    stroke={
                      isUnlockedEdge
                        ? '#38f8ff'
                        : isUpgradeReadyEdge
                          ? '#ffd166'
                          : isReachableEdge
                            ? '#7dd3fc'
                            : 'rgba(255,255,255,0.2)'
                    }
                    strokeWidth={isUnlockedEdge || isUpgradeReadyEdge ? 2.4 : 1.3}
                    strokeDasharray={
                      isUpgradeReadyEdge || isReachableEdge
                        ? '5 4'
                        : isUnlockedEdge
                          ? undefined
                          : '2 4'
                    }
                    filter={
                      isUpgradeReadyEdge
                        ? 'url(#node-glow-gold)'
                        : isUnlockedEdge
                          ? 'url(#node-glow-cyan)'
                          : undefined
                    }
                  >
                    {!user.reducedMotion && (isUpgradeReadyEdge || isReachableEdge) && (
                      <animate
                        attributeName="stroke-dashoffset"
                        from="18"
                        to="0"
                        dur="1.1s"
                        repeatCount="indefinite"
                      />
                    )}
                  </line>

                  {/* Framer Motion Power-Flow Connecting Pulse on Unlock */}
                  {!user.reducedMotion && isPulsingBranch && unlockPulse && (
                    <>
                      <motion.line
                        key={`surge_line_${unlockPulse.pulseId}_${tierNum}`}
                        x1={p1.x}
                        y1={p1.y}
                        x2={p2.x}
                        y2={p2.y}
                        stroke="#ffffff"
                        strokeWidth={isTargetSurgeEdge ? 4.2 : 3.2}
                        strokeLinecap="round"
                        filter="url(#node-glow-surge)"
                        initial={{ pathLength: 0, opacity: 0.95 }}
                        animate={{ pathLength: 1, opacity: [0.95, 1, 0] }}
                        transition={{
                          duration: 0.55,
                          delay: (tierNum - 1) * 0.16,
                          ease: [0.16, 1, 0.3, 1],
                        }}
                      />
                      <motion.circle
                        key={`surge_orb_${unlockPulse.pulseId}_${tierNum}`}
                        r={isTargetSurgeEdge ? 5 : 3.6}
                        fill="#ffffff"
                        filter="url(#node-glow-surge)"
                        initial={{ cx: p1.x, cy: p1.y, opacity: 0, scale: 0.6 }}
                        animate={{
                          cx: [p1.x, p2.x],
                          cy: [p1.y, p2.y],
                          opacity: [0, 1, 1, 0],
                          scale: [0.7, 1.3, 0.9],
                        }}
                        transition={{
                          duration: 0.52,
                          delay: (tierNum - 1) * 0.16,
                          ease: [0.22, 1, 0.36, 1],
                        }}
                      />
                    </>
                  )}
                </g>
              );
            });
          })}

          {/* Branch area labels cleanly placed on outer constellation perimeter */}
          {BRANCH_METAS.map((branch) => {
            const isSelected = branch.id === selectedBranchId;
            const hasReady = branchStates[branch.id].allNextMet;
            return (
              <g key={`${branch.id}_label`}>
                <text
                  x={branch.labelPos.x}
                  y={branch.labelPos.y}
                  textAnchor={branch.labelPos.anchor}
                  fill={hasReady ? '#ffd166' : isSelected ? '#38f8ff' : 'rgba(255,255,255,0.82)'}
                  fontSize="11.5"
                  fontWeight={isSelected || hasReady ? '800' : '600'}
                  letterSpacing="0.03em"
                >
                  {branch.title}
                </text>
                <text
                  x={branch.labelPos.x}
                  y={branch.labelPos.y + 11}
                  textAnchor={branch.labelPos.anchor}
                  fill="rgba(186, 230, 253, 0.58)"
                  fontSize="9"
                  fontWeight="600"
                >
                  {branch.areaLabel}
                </text>
              </g>
            );
          })}

          {/* Central Player Core Node */}
          <g
            onClick={() =>
              user.unspentStatPoints > 0 ? onOpenStatAllocation() : onOpenBranchState(28)
            }
            className="cursor-pointer"
          >
            {(upgradableBranches.length > 0 || user.unspentStatPoints > 0) && (
              <circle
                cx={CENTER.x}
                cy={CENTER.y}
                r="26"
                fill="none"
                stroke={upgradableBranches.length > 0 ? '#ffd166' : '#38f8ff'}
                strokeWidth="1.4"
                strokeOpacity="0.6"
              >
                {!user.reducedMotion && (
                  <>
                    <animate attributeName="r" values="22;29;22" dur="2.2s" repeatCount="indefinite" />
                    <animate attributeName="opacity" values="0.8;0.15;0.8" dur="2.2s" repeatCount="indefinite" />
                  </>
                )}
              </circle>
            )}
            <polygon
              points={`${CENTER.x},${CENTER.y - 22} ${CENTER.x + 22},${CENTER.y} ${CENTER.x},${CENTER.y + 22} ${CENTER.x - 22},${CENTER.y}`}
              fill="#062c49"
              stroke="#38f8ff"
              strokeWidth="2"
              filter="url(#node-glow-cyan)"
            />
            <text
              x={CENTER.x}
              y={CENTER.y - 2}
              textAnchor="middle"
              fill="#ffffff"
              fontSize="11"
              fontWeight="800"
            >
              {rankInfo.rank}
            </text>
            <text
              x={CENTER.x}
              y={CENTER.y + 10}
              textAnchor="middle"
              fill="#72f8ff"
              fontSize="9.5"
              fontWeight="700"
            >
              Ур.{user.level}
            </text>
          </g>

          {/* 15 Interactive Tier Nodes across 5 Branches */}
          {BRANCH_METAS.map((branch) => {
            const evalInfo = branchStates[branch.id];
            return ([1, 2, 3] as const).map((tier) => {
              const pt = polarPoint(branch.angleDeg, TIER_RADII[tier - 1]);
              const isSelected = selectedBranchId === branch.id && selectedTier === tier;
              const isJustUnlockedNode =
                unlockPulse &&
                unlockPulse.branchId === branch.id &&
                unlockPulse.unlockedTier === tier;

              let status: NodeStatus = 'locked';
              if (tier <= evalInfo.level) {
                status = 'unlocked';
              } else if (tier === evalInfo.level + 1 && evalInfo.allNextMet) {
                status = 'upgrade_ready';
              } else if (tier === evalInfo.level + 1 && evalInfo.statReachableWithPoints) {
                status = 'reachable_with_points';
              }

              const fill =
                status === 'unlocked'
                  ? '#074266'
                  : status === 'upgrade_ready'
                    ? '#2b2005'
                    : status === 'reachable_with_points'
                      ? '#052742'
                      : '#030d18';
              const stroke =
                status === 'upgrade_ready'
                  ? '#ffd166'
                  : status === 'unlocked'
                    ? '#38f8ff'
                    : status === 'reachable_with_points'
                      ? '#7dd3fc'
                      : 'rgba(255,255,255,0.32)';

              const r = 13.5;
              return (
                <g
                  key={`${branch.id}_node_${tier}`}
                  onClick={() => handleSelectNode(branch.id, tier)}
                  className="cursor-pointer"
                >
                  {/* 44x44px hit expansion area */}
                  <circle cx={pt.x} cy={pt.y} r="22" fill="transparent" />

                  {/* Beacon pulse for ready upgrades */}
                  {status === 'upgrade_ready' && (
                    <circle
                      cx={pt.x}
                      cy={pt.y}
                      r="17"
                      fill="none"
                      stroke="#ffd166"
                      strokeWidth="1.5"
                    >
                      {!user.reducedMotion && (
                        <>
                          <animate attributeName="r" values="14;20;14" dur="1.6s" repeatCount="indefinite" />
                          <animate attributeName="opacity" values="0.9;0.2;0.9" dur="1.6s" repeatCount="indefinite" />
                        </>
                      )}
                    </circle>
                  )}

                  {/* Shockwave Ring when Power Flow Arrives at Newly Unlocked Node */}
                  {!user.reducedMotion && isJustUnlockedNode && unlockPulse && (
                    <motion.circle
                      key={`shockwave_${unlockPulse.pulseId}`}
                      cx={pt.x}
                      cy={pt.y}
                      fill="none"
                      stroke="#72f8ff"
                      filter="url(#node-glow-surge)"
                      initial={{ r: 12, opacity: 0, strokeWidth: 3.5 }}
                      animate={{
                        r: [12, 34],
                        opacity: [0, 0.95, 0],
                        strokeWidth: [3.5, 0.5],
                      }}
                      transition={{
                        duration: 0.75,
                        delay: (tier - 1) * 0.16 + 0.32,
                        ease: 'easeOut',
                      }}
                    />
                  )}

                  {/* Framer Motion Layout Transition Reticle gliding between selected nodes */}
                  {isSelected && (
                    <motion.circle
                      layoutId={!user.reducedMotion ? 'skill-selected-reticle' : undefined}
                      cx={pt.x}
                      cy={pt.y}
                      r="18"
                      fill="none"
                      stroke="#ffffff"
                      strokeWidth="1.6"
                      strokeDasharray="3 2"
                      transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                    />
                  )}

                  {/* Diamond node body with spring unlock pop */}
                  <motion.polygon
                    points={`${pt.x},${pt.y - r} ${pt.x + r},${pt.y} ${pt.x},${pt.y + r} ${pt.x - r},${pt.y}`}
                    fill={fill}
                    stroke={stroke}
                    strokeWidth={isSelected || status === 'upgrade_ready' ? 2.2 : 1.5}
                    filter={
                      status === 'upgrade_ready'
                        ? 'url(#node-glow-gold)'
                        : status === 'unlocked'
                          ? 'url(#node-glow-cyan)'
                          : undefined
                    }
                    style={{ transformOrigin: `${pt.x}px ${pt.y}px` }}
                    animate={
                      !user.reducedMotion && isJustUnlockedNode
                        ? { scale: [1, 1.38, 1] }
                        : { scale: 1 }
                    }
                    transition={{
                      duration: 0.45,
                      delay: isJustUnlockedNode ? (tier - 1) * 0.16 + 0.3 : 0,
                      type: 'spring',
                      stiffness: 340,
                      damping: 18,
                    }}
                  />

                  <text
                    x={pt.x}
                    y={pt.y + 3.5}
                    textAnchor="middle"
                    fill={
                      status === 'upgrade_ready'
                        ? '#ffe599'
                        : status === 'unlocked'
                          ? '#ffffff'
                          : status === 'reachable_with_points'
                            ? '#bae6fd'
                            : 'rgba(255,255,255,0.52)'
                    }
                    fontSize="10"
                    fontWeight="800"
                  >
                    {status === 'upgrade_ready' ? '▲' : ROMAN[tier - 1]}
                  </text>
                </g>
              );
            });
          })}
        </svg>
      </div>

      {/* Selected Node Inspector & Direct Action with Framer Motion Layout Transition */}
      <motion.div
        layout
        transition={{ duration: 0.2, ease: 'easeOut' }}
        className="p-2.5 rounded-[6px] border border-[#38f8ff]/55 bg-[#031221]/95 space-y-2"
      >
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <activeMeta.Icon className="w-4 h-4 text-[#38f8ff] shrink-0" />
            <div className="min-w-0">
              <div className="text-[14px] font-bold truncate">
                {activeMeta.title} · Узел {ROMAN[selectedTier - 1]}
              </div>
              <div className="text-[12px] text-white/75 truncate">
                {activeMeta.areaLabel} · {activeSkill.sourceStatName} ·{' '}
                {selectedTierIsUnlocked
                  ? 'Открыто'
                  : canUpgradeSelected
                    ? 'Готово к улучшению'
                    : selectedTierIsNext
                      ? 'Следующий узел'
                      : 'Заблокировано'}
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onOpenBranchState(activeMeta.stateTarget)}
            className="text-[12px] font-semibold text-[#38f8ff] hover:underline flex items-center gap-0.5 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <span>Ветка</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={`${activeMeta.id}_${selectedTier}`}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.16 }}
            className="text-[13px] text-white/95 border-t border-white/15 pt-1.5 leading-snug"
          >
            {activeMeta.tierDescriptions[selectedTier - 1]}
          </motion.div>
        </AnimatePresence>

        {/* Live Requirements when inspecting next tier */}
        {selectedTierIsNext && activeSkill.requirementsForNext.length > 0 && (
          <div className="space-y-1 border-t border-white/15 pt-1.5">
            {activeSkill.requirementsForNext.map((req) => {
              const met = req.current >= req.target;
              return (
                <div
                  key={req.id}
                  className="flex items-center justify-between text-[12px] font-tabular"
                >
                  <span className="flex items-center gap-1.5 text-white/85">
                    {met ? (
                      <Check className="w-3.5 h-3.5 text-[#38f8ff]" />
                    ) : (
                      <Lock className="w-3.5 h-3.5 text-white/45" />
                    )}
                    <span>{req.label}</span>
                  </span>
                  <span className={met ? 'font-bold text-[#72f8ff]' : 'font-semibold text-white/80'}>
                    <RollingNumber value={req.current} metricKey={`skill_req_${activeMeta.id}_${req.id}`} /> / {req.target}
                  </span>
                </div>
              );
            })}
          </div>
        )}

        {/* Contextual CTA Button */}
        {canUpgradeSelected ? (
          <SystemButton
            label={`УЛУЧШИТЬ · ${activeMeta.title.toUpperCase()} (${ROMAN[selectedTier - 1]})`}
            highlighted
            disabled={busy || Boolean(unlockPulse)}
            onClick={() => onUpgradeSkill(activeMeta.id)}
          />
        ) : canInvestStatForSelected ? (
          <button
            type="button"
            onClick={onOpenStatAllocation}
            className="w-full min-h-[44px] px-3 py-2 rounded-[5px] border border-[#38f8ff] bg-[#062d4a] text-[13px] font-bold text-[#72f8ff] hover:bg-[#083c63] flex items-center justify-center gap-2 cursor-pointer"
          >
            <ArrowUpCircle className="w-4 h-4 shrink-0" />
            <span>
              Распределить очки ({user.unspentStatPoints} дост., не хватает {activeEval.nextStatMissing})
            </span>
          </button>
        ) : (
          <SystemButton
            label={`ОТКРЫТЬ ВЕТКУ · ${activeMeta.title.toUpperCase()}`}
            bracketed={false}
            highlighted={false}
            onClick={() => onOpenBranchState(activeMeta.stateTarget)}
          />
        )}
      </motion.div>
    </div>
  );
});
