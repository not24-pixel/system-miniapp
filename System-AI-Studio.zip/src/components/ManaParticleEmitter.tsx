import React, { memo, useEffect, useRef } from 'react';
import { SystemPalette } from '../shared/types';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  maxAlpha: number;
  life: number;
  maxLife: number;
  phase: number;
  flickerSpeed: number;
  isWhiteCore: boolean;
}

interface ManaParticleEmitterProps {
  palette: SystemPalette;
  reducedMotion?: boolean;
  burstKey?: number | string;
  pulseKey?: number | string;
  density?: number;
}

const BLUE_TAILS = Array.from({ length: 10 }, (_, i) => `rgba(0, 229, 255, ${((i + 1) * 0.025).toFixed(3)})`);
const RED_TAILS = Array.from({ length: 10 }, (_, i) => `rgba(255, 50, 50, ${((i + 1) * 0.025).toFixed(3)})`);
const BLUE_HALOS = Array.from({ length: 10 }, (_, i) => `rgba(0, 229, 255, ${((i + 1) * 0.042).toFixed(3)})`);
const RED_HALOS = Array.from({ length: 10 }, (_, i) => `rgba(255, 42, 42, ${((i + 1) * 0.045).toFixed(3)})`);
const BLUE_CORES = Array.from({ length: 10 }, (_, i) => `rgba(114, 248, 255, ${((i + 1) * 0.09).toFixed(3)})`);
const RED_CORES = Array.from({ length: 10 }, (_, i) => `rgba(255, 115, 115, ${((i + 1) * 0.09).toFixed(3)})`);
const WHITE_CORES = Array.from({ length: 10 }, (_, i) => `rgba(255, 255, 255, ${((i + 1) * 0.088).toFixed(3)})`);

export const ManaParticleEmitter: React.FC<ManaParticleEmitterProps> = memo(({
  palette,
  reducedMotion = false,
  burstKey,
  pulseKey,
  density = 20,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const particlesRef = useRef<Particle[]>([]);
  const sizeRef = useRef<{ w: number; h: number }>({ w: 400, h: 800 });
  const paletteRef = useRef<SystemPalette>(palette);
  paletteRef.current = palette;

  const spawnParticle = (width: number, height: number, isBurst = false): Particle => {
    const isRed = paletteRef.current === 'red';
    const maxLife = isBurst ? 40 + Math.random() * 45 : 90 + Math.random() * 130;
    return {
      x: Math.random() * width,
      y: isBurst ? height * (0.4 + Math.random() * 0.6) : height + Math.random() * 32,
      vx: (Math.random() - 0.5) * (isBurst ? 0.65 : 0.28),
      vy: -((isRed ? 0.95 : 0.62) + Math.random() * (isBurst ? 1.8 : 0.95)),
      size: Math.random() < 0.24 ? 3 : Math.random() < 0.65 ? 2 : 1.5,
      maxAlpha: isBurst ? 0.36 + Math.random() * 0.42 : 0.2 + Math.random() * 0.34,
      life: 0,
      maxLife,
      phase: Math.random() * Math.PI * 2,
      flickerSpeed: 0.08 + Math.random() * 0.12,
      isWhiteCore: Math.random() < 0.28,
    };
  };

  useEffect(() => {
    if (reducedMotion || !canvasRef.current) return;
    const { w, h } = sizeRef.current;
    for (let i = 0; i < 10; i++) {
      particlesRef.current.push(spawnParticle(w, h, true));
    }
    if (particlesRef.current.length > 24) {
      particlesRef.current.splice(0, particlesRef.current.length - 24);
    }
  }, [burstKey, reducedMotion]);

  useEffect(() => {
    if (reducedMotion || !pulseKey || !canvasRef.current) return;
    const { w, h } = sizeRef.current;
    for (let i = 0; i < 4; i++) {
      const p = spawnParticle(w, h, false);
      p.y = h * (0.72 + Math.random() * 0.25);
      particlesRef.current.push(p);
    }
    if (particlesRef.current.length > 24) {
      particlesRef.current.splice(0, particlesRef.current.length - 24);
    }
  }, [pulseKey, reducedMotion]);

  useEffect(() => {
    if (reducedMotion) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      const parent = canvas.parentElement;
      if (!parent) return;
      const dpr = 1;
      const cssW = parent.clientWidth || 400;
      const cssH = parent.clientHeight || 800;
      sizeRef.current = { w: cssW, h: cssH };
      canvas.width = Math.round(cssW * dpr);
      canvas.height = Math.round(cssH * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();

    const ro = new ResizeObserver(resize);
    if (canvas.parentElement) ro.observe(canvas.parentElement);

    if (particlesRef.current.length === 0) {
      const { w, h } = sizeRef.current;
      for (let i = 0; i < density; i++) {
        const p = spawnParticle(w, h, false);
        p.y = Math.random() * h;
        p.life = Math.random() * p.maxLife * 0.6;
        particlesRef.current.push(p);
      }
    }

    let rafId = 0;
    let frame = 0;
    let tick = 0;

    const render = () => {
      rafId = requestAnimationFrame(render);
      if (document.hidden) return;
      frame += 1;
      // Run at ~30fps for smooth motion with half the GPU/CPU draw load
      if (frame % 3 !== 0) return;
      tick += 1;

      const { w, h } = sizeRef.current;
      ctx.clearRect(0, 0, w, h);
      ctx.globalCompositeOperation = 'lighter';

      const isRed = paletteRef.current === 'red';
      const tails = isRed ? RED_TAILS : BLUE_TAILS;
      const halos = isRed ? RED_HALOS : BLUE_HALOS;
      const cores = isRed ? RED_CORES : BLUE_CORES;
      const list = particlesRef.current;

      while (list.length < density) {
        list.push(spawnParticle(w, h, false));
      }

      for (let i = list.length - 1; i >= 0; i--) {
        const p = list[i];
        p.life += 1;
        p.x += p.vx + Math.sin(tick * 0.04 + p.phase) * (isRed ? 0.42 : 0.24);
        p.y += p.vy;

        if (p.life >= p.maxLife || p.y < -16) {
          list.splice(i, 1);
          continue;
        }

        const progress = p.life / p.maxLife;
        const fadeEnv =
          progress < 0.18
            ? progress / 0.18
            : progress > 0.72
            ? Math.max(0, (1 - progress) / 0.28)
            : 1;
        const flicker = 0.72 + 0.28 * Math.sin(tick * p.flickerSpeed + p.phase);
        const alpha = p.maxAlpha * fadeEnv * flicker;
        const bucket = Math.min(9, Math.max(0, Math.floor(alpha * 10)));

        const px = Math.round(p.x);
        const py = Math.round(p.y);

        if (p.size >= 2) {
          ctx.fillStyle = tails[bucket];
          ctx.fillRect(px, py + p.size, Math.max(1, p.size - 0.5), p.size * 2.2);
        }

        ctx.fillStyle = halos[bucket];
        ctx.fillRect(px - 1.5, py - 1.5, p.size + 3, p.size + 3);

        ctx.fillStyle = p.isWhiteCore ? WHITE_CORES[bucket] : cores[bucket];
        ctx.fillRect(px, py, p.size, p.size);
      }

      ctx.globalCompositeOperation = 'source-over';
    };

    rafId = requestAnimationFrame(render);
    return () => {
      cancelAnimationFrame(rafId);
      ro.disconnect();
    };
  }, [reducedMotion, density]);

  if (reducedMotion) return null;

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 w-full h-full z-0"
    />
  );
});
