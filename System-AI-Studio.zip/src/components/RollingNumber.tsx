import React, { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { SystemPalette } from '../shared/types';

export type HudSkinId = 'blue' | 'monarch' | 'igris' | 'sovereign';

interface SystemMetricsContextValue {
  reducedMotion: boolean;
  palette: SystemPalette;
  monarchTheme: boolean;
  hudTheme: HudSkinId;
}

const SystemMetricsContext = createContext<SystemMetricsContextValue>({
  reducedMotion: false,
  palette: 'blue',
  monarchTheme: false,
  hudTheme: 'blue',
});

export const useSystemMetrics = () => useContext(SystemMetricsContext);

export const SystemMetricsProvider: React.FC<{
  reducedMotion?: boolean;
  palette?: SystemPalette;
  monarchTheme?: boolean;
  hudTheme?: HudSkinId;
  children: React.ReactNode;
}> = ({ reducedMotion = false, palette = 'blue', monarchTheme = false, hudTheme, children }) => {
  const resolvedSkin: HudSkinId = hudTheme || (monarchTheme ? 'monarch' : 'blue');
  const resolvedMonarch = resolvedSkin === 'monarch';
  const value = useMemo(
    () => ({ reducedMotion, palette, monarchTheme: resolvedMonarch, hudTheme: resolvedSkin }),
    [reducedMotion, palette, resolvedMonarch, resolvedSkin]
  );
  return <SystemMetricsContext.Provider value={value}>{children}</SystemMetricsContext.Provider>;
};

// Persists last observed values across SystemFrame screen transitions so returning
// to Today / Goals / Player still triggers a smooth counter roll from old -> new.
const metricSnapshotStore = new Map<string, number>();

const REEL_STRIP = [
  '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
  '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
  '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
];

interface DigitReelProps {
  targetDigit: number;
  initialDigit: number;
  direction: 'up' | 'down' | 'none';
  delayMs: number;
  reducedMotion: boolean;
}

const DigitReel: React.FC<DigitReelProps> = ({
  targetDigit,
  initialDigit,
  direction,
  delayMs,
  reducedMotion,
}) => {
  const [slotIndex, setSlotIndex] = useState<number>(() =>
    direction === 'down' ? 10 + initialDigit : initialDigit
  );
  const [animate, setAnimate] = useState<boolean>(false);
  const slotRef = useRef<number>(slotIndex);
  slotRef.current = slotIndex;
  const lastTargetRef = useRef<number>(initialDigit);

  useEffect(() => {
    if (reducedMotion) {
      setAnimate(false);
      setSlotIndex(targetDigit);
      lastTargetRef.current = targetDigit;
      return;
    }

    if (targetDigit === lastTargetRef.current && slotRef.current % 10 === targetDigit) {
      return;
    }

    const curMod = slotRef.current % 10;
    let startSlot = slotRef.current;
    let nextSlot = targetDigit;

    if (direction === 'up') {
      // Keep within lower-to-mid strip so increasing numbers always roll upward cleanly
      if (startSlot >= 20) {
        startSlot = curMod;
      }
      nextSlot =
        targetDigit > curMod
          ? Math.floor(startSlot / 10) * 10 + targetDigit
          : (Math.floor(startSlot / 10) + 1) * 10 + targetDigit;
      if (nextSlot >= 30) {
        startSlot = curMod;
        nextSlot = targetDigit > curMod ? targetDigit : 10 + targetDigit;
      }
    } else if (direction === 'down') {
      if (startSlot < 10) {
        startSlot = 10 + curMod;
      }
      nextSlot =
        targetDigit < curMod
          ? Math.floor(startSlot / 10) * 10 + targetDigit
          : Math.max(0, (Math.floor(startSlot / 10) - 1) * 10 + targetDigit);
      if (nextSlot < 0) {
        startSlot = 20 + curMod;
        nextSlot = targetDigit < curMod ? 20 + targetDigit : 10 + targetDigit;
      }
    } else {
      startSlot = curMod;
      nextSlot = targetDigit;
    }

    lastTargetRef.current = targetDigit;

    let raf1 = 0;
    let raf2 = 0;

    if (startSlot !== slotRef.current) {
      setAnimate(false);
      setSlotIndex(startSlot);
      raf1 = requestAnimationFrame(() => {
        raf2 = requestAnimationFrame(() => {
          setAnimate(true);
          setSlotIndex(nextSlot);
        });
      });
    } else {
      raf1 = requestAnimationFrame(() => {
        setAnimate(true);
        setSlotIndex(nextSlot);
      });
    }

    return () => {
      cancelAnimationFrame(raf1);
      cancelAnimationFrame(raf2);
    };
  }, [targetDigit, direction, reducedMotion]);

  // Normalize back to canonical middle strip (10..19) silently after transition settles
  const handleTransitionEnd = () => {
    const canonical = 10 + (slotRef.current % 10);
    if (slotRef.current !== canonical) {
      setAnimate(false);
      setSlotIndex(canonical);
    }
  };

  return (
    <span className="relative inline-flex h-[1.18em] overflow-hidden align-bottom leading-[1.18em] font-tabular">
      <span
        onTransitionEnd={handleTransitionEnd}
        style={{
          transform: `translate3d(0, -${slotIndex * 1.18}em, 0)`,
          transition: animate
            ? `transform 420ms cubic-bezier(0.16, 1, 0.3, 1) ${delayMs}ms`
            : 'none',
        }}
        className="flex flex-col will-change-transform"
      >
        {REEL_STRIP.map((d, idx) => (
          <span
            key={idx}
            className="h-[1.18em] leading-[1.18em] flex items-center justify-center"
          >
            {d}
          </span>
        ))}
      </span>
    </span>
  );
};

export interface RollingNumberProps {
  value: number;
  metricKey?: string;
  animateFrom?: number;
  format?: (n: number) => string;
  prefix?: string;
  suffix?: string;
  useGrouping?: boolean;
  className?: string;
  reducedMotion?: boolean;
}

function defaultFormat(n: number, useGrouping: boolean): string {
  const rounded = Math.round(n);
  return useGrouping ? rounded.toLocaleString('ru-RU') : String(rounded);
}

export const RollingNumber: React.FC<RollingNumberProps> = ({
  value,
  metricKey,
  animateFrom,
  format,
  prefix = '',
  suffix = '',
  useGrouping = false,
  className = '',
  reducedMotion: reducedMotionProp,
}) => {
  const ctx = useContext(SystemMetricsContext);
  const reducedMotion = reducedMotionProp ?? ctx.reducedMotion;
  const isRed = ctx.palette === 'red';

  const safeValue = Number.isFinite(value) ? value : 0;

  const initialPrev =
    typeof animateFrom === 'number' && animateFrom !== safeValue
      ? animateFrom
      : metricKey && metricSnapshotStore.has(metricKey)
      ? metricSnapshotStore.get(metricKey)!
      : safeValue;

  const lastValueRef = useRef<number>(initialPrev);
  const prevValueRef = useRef<number>(initialPrev);
  if (safeValue !== lastValueRef.current) {
    prevValueRef.current = lastValueRef.current;
    lastValueRef.current = safeValue;
  }
  const prevValue = prevValueRef.current;

  const [rollingGlow, setRollingGlow] = useState<boolean>(false);
  const prevEffectValRef = useRef<number>(initialPrev);

  useEffect(() => {
    if (metricKey) {
      metricSnapshotStore.set(metricKey, safeValue);
    }

    if (safeValue !== prevEffectValRef.current) {
      prevEffectValRef.current = safeValue;
      if (!reducedMotion) {
        setRollingGlow(true);
        const timer = setTimeout(() => setRollingGlow(false), 480);
        return () => clearTimeout(timer);
      }
    }
    return undefined;
  }, [safeValue, metricKey, reducedMotion]);

  const formatFn = (n: number) => (format ? format(n) : defaultFormat(n, useGrouping));
  const prevFormatted = formatFn(prevValue);
  const targetFormatted = formatFn(safeValue);

  const direction: 'up' | 'down' | 'none' =
    safeValue > prevValue ? 'up' : safeValue < prevValue ? 'down' : 'none';

  // Extract only digit characters right-to-left so multi-digit shifts align cleanly
  const prevDigitsOnly = prevFormatted.replace(/\D/g, '');
  const targetChars = targetFormatted.split('');

  let totalTargetDigits = 0;
  for (const ch of targetChars) {
    if (ch >= '0' && ch <= '9') totalTargetDigits++;
  }

  let seenDigits = 0;
  const glowStyle = rollingGlow
    ? isRed
      ? 'text-[#ffd0d0]'
      : ctx.hudTheme === 'monarch'
      ? 'text-[#f3e8ff]'
      : ctx.hudTheme === 'igris'
      ? 'text-[#ffe4e6]'
      : ctx.hudTheme === 'sovereign'
      ? 'text-[#fef3c7]'
      : 'text-[#b9fbff]'
    : '';

  return (
    <span
      className={`inline-flex items-baseline font-tabular transition-[color,filter] duration-300 ${glowStyle} ${className}`}
    >
      {prefix && <span>{prefix}</span>}
      {targetChars.map((ch, idx) => {
        if (ch < '0' || ch > '9') {
          return (
            <span key={`sep_${idx}`} className="whitespace-pre">
              {ch}
            </span>
          );
        }

        const digitPosFromRight = totalTargetDigits - 1 - seenDigits;
        seenDigits += 1;

        const targetDigit = Number(ch);
        const prevIdxFromEnd = prevDigitsOnly.length - 1 - digitPosFromRight;
        const initialDigit =
          prevIdxFromEnd >= 0 ? Number(prevDigitsOnly[prevIdxFromEnd]) : 0;

        // Subtle cascade right-to-left (units roll first, higher places follow by 28ms)
        const delayMs = Math.min(140, digitPosFromRight * 28);

        return (
          <DigitReel
            key={`reel_${digitPosFromRight}`}
            targetDigit={targetDigit}
            initialDigit={initialDigit}
            direction={direction}
            delayMs={delayMs}
            reducedMotion={reducedMotion}
          />
        );
      })}
      {suffix && <span>{suffix}</span>}
    </span>
  );
};
