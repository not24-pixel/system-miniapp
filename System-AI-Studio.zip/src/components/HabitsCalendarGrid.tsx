import React, { memo, useMemo, useState } from 'react';
import { AlertTriangle, Calendar, Check, ChevronRight, Clock } from 'lucide-react';
import { HabitItem, HabitOccurrenceHistory, PenaltyQuestState } from '../shared/types';
import { useSystemMetrics } from './RollingNumber';

interface HabitsCalendarGridProps {
  habits: HabitItem[];
  penaltyQuest?: PenaltyQuestState;
  onOpenPenalty?: () => void;
  onOpenHabitHistory?: (habitId: string) => void;
}

type DayVisualStatus = 'penalty' | 'missed' | 'completed' | 'partial' | 'scheduled' | 'empty';

interface DayHabitDetail {
  habitId: string;
  habitTitle: string;
  status: 'completed' | 'partial' | 'missed' | 'pending' | 'unscheduled';
  hasPenalty: boolean;
  valueMinutes?: number;
  targetMinutes?: number;
}

const WEEKDAYS_HEADER = ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ', 'ВС'] as const;

const MONTHS_RU = [
  'Январь',
  'Февраль',
  'Март',
  'Апрель',
  'Май',
  'Июнь',
  'Июль',
  'Август',
  'Сентябрь',
  'Октябрь',
  'Ноябрь',
  'Декабрь',
];

function formatLocalIso(year: number, monthIndex: number, day: number): string {
  const m = String(monthIndex + 1).padStart(2, '0');
  const d = String(day).padStart(2, '0');
  return `${year}-${m}-${d}`;
}

function getRuWeekdayCode(date: Date): string {
  const map = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
  return map[date.getDay()] || 'ПН';
}

const STATUS_LABELS_RU: Record<string, string> = {
  penalty: 'Штраф',
  completed: 'Выполнено',
  missed: 'Пропущено',
  partial: 'Частично',
  scheduled: 'Запланировано',
  empty: 'Нет отметок',
};

export const HabitsCalendarGrid: React.FC<HabitsCalendarGridProps> = memo(({
  habits,
  penaltyQuest,
  onOpenPenalty,
  onOpenHabitHistory,
}) => {
  const { hudTheme } = useSystemMetrics();
  const [selectedHabitFilter, setSelectedHabitFilter] = useState<string>('all');

  const now = new Date();
  const year = now.getFullYear();
  const monthIndex = now.getMonth();
  const todayDay = now.getDate();
  const todayIso = formatLocalIso(year, monthIndex, todayDay);

  const [selectedIso, setSelectedIso] = useState<string>(todayIso);

  const activeHabits = useMemo(
    () => habits.filter((h) => h.status === 'active'),
    [habits]
  );

  const scopedHabits = useMemo(() => {
    if (selectedHabitFilter === 'all') return activeHabits;
    const found = activeHabits.filter((h) => h.id === selectedHabitFilter);
    return found.length > 0 ? found : activeHabits;
  }, [activeHabits, selectedHabitFilter]);

  const { leadingBlanks, daysData, summaryCounts } = useMemo(() => {
    const firstOfMonth = new Date(year, monthIndex, 1);
    const totalDays = new Date(year, monthIndex + 1, 0).getDate();
    const blanks = (firstOfMonth.getDay() + 6) % 7;

    let completedDays = 0;
    let missedDays = 0;
    let penaltyDays = 0;

    const list: Array<{
      day: number;
      iso: string;
      isToday: boolean;
      isFuture: boolean;
      visualStatus: DayVisualStatus;
      details: DayHabitDetail[];
    }> = [];

    for (let day = 1; day <= totalDays; day++) {
      const iso = formatLocalIso(year, monthIndex, day);
      const cellDate = new Date(year, monthIndex, day);
      const weekdayCode = getRuWeekdayCode(cellDate);
      const isToday = day === todayDay;
      const isFuture = day > todayDay;

      const details: DayHabitDetail[] = [];

      for (const habit of scopedHabits) {
        let matchedEntry: HabitOccurrenceHistory | undefined;
        if (isToday) {
          matchedEntry =
            habit.history.find((h) => h.isoDate === iso || h.dateLabel === 'Сегодня') || undefined;
          const liveStatus: DayHabitDetail['status'] = habit.completedToday
            ? 'completed'
            : habit.currentMinutesToday > 0
            ? 'partial'
            : matchedEntry?.status || 'pending';
          const hasPenalty = Boolean(
            matchedEntry?.triggeredPenaltyId ||
              (penaltyQuest?.active &&
                penaltyQuest.reasonTitle.toLowerCase().includes(habit.title.toLowerCase()) &&
                !habit.completedToday)
          );
          details.push({
            habitId: habit.id,
            habitTitle: habit.title,
            status: liveStatus,
            hasPenalty,
            valueMinutes: habit.currentMinutesToday,
            targetMinutes: habit.durationMinutes,
          });
        } else {
          matchedEntry = habit.history.find((h) => h.isoDate === iso);
          if (matchedEntry) {
            details.push({
              habitId: habit.id,
              habitTitle: habit.title,
              status: matchedEntry.status,
              hasPenalty: Boolean(matchedEntry.triggeredPenaltyId),
              valueMinutes: matchedEntry.valueMinutes,
              targetMinutes: matchedEntry.targetMinutes ?? habit.durationMinutes,
            });
          }
        }
      }

      const anyScheduled = scopedHabits.some((h) => h.daysOfWeek.includes(weekdayCode));

      let visualStatus: DayVisualStatus = 'empty';
      if (details.some((d) => d.hasPenalty)) {
        visualStatus = 'penalty';
        penaltyDays += 1;
      } else if (details.some((d) => d.status === 'missed')) {
        visualStatus = 'missed';
        missedDays += 1;
      } else if (details.length > 0 && details.every((d) => d.status === 'completed')) {
        visualStatus = 'completed';
        completedDays += 1;
      } else if (details.some((d) => d.status === 'completed' || d.status === 'partial')) {
        visualStatus = 'partial';
      } else if ((isToday || isFuture) && anyScheduled) {
        visualStatus = 'scheduled';
      }

      list.push({
        day,
        iso,
        isToday,
        isFuture,
        visualStatus,
        details,
      });
    }

    return {
      leadingBlanks: blanks,
      daysData: list,
      summaryCounts: { completedDays, missedDays, penaltyDays },
    };
  }, [year, monthIndex, todayDay, scopedHabits, penaltyQuest]);

  const selectedDayData =
    daysData.find((d) => d.iso === selectedIso) ||
    daysData.find((d) => d.isToday) ||
    daysData[0];

  const accentBorder =
    hudTheme === 'monarch'
      ? 'border-[#a855f7]/55'
      : hudTheme === 'igris'
      ? 'border-[#f43f5e]/55'
      : hudTheme === 'sovereign'
      ? 'border-[#f59e0b]/55'
      : 'border-[#38f8ff]/45';
  const accentText =
    hudTheme === 'monarch'
      ? 'text-[#d8b4fe]'
      : hudTheme === 'igris'
      ? 'text-[#fda4af]'
      : hudTheme === 'sovereign'
      ? 'text-[#fcd34d]'
      : 'text-[#9deeff]';
  const filterActiveClass =
    hudTheme === 'monarch'
      ? 'border-[#c084fc] bg-[#2a0c46] text-white'
      : hudTheme === 'igris'
      ? 'border-[#fb7185] bg-[#3f0917] text-white'
      : hudTheme === 'sovereign'
      ? 'border-[#fbbf24] bg-[#382305] text-white'
      : 'border-[#38f8ff] bg-[#063254] text-white';

  const getCellStyle = (status: DayVisualStatus, isToday: boolean, isSelected: boolean) => {
    const todayRing =
      hudTheme === 'monarch'
        ? 'ring-1 ring-[#c084fc]'
        : hudTheme === 'igris'
        ? 'ring-1 ring-[#fb7185]'
        : hudTheme === 'sovereign'
        ? 'ring-1 ring-[#fbbf24]'
        : 'ring-1 ring-[#38f8ff]';
    const selectedRing = isSelected ? 'ring-2 ring-white z-10' : isToday ? todayRing : '';

    switch (status) {
      case 'penalty':
        return `border-[#ff3b3b] bg-[#45070e]/90 text-[#ffd2d2] shadow-[0_0_8px_rgba(255,59,59,0.45)] ${selectedRing}`;
      case 'missed':
        return `border-amber-400/90 bg-amber-500/20 text-amber-100 shadow-[0_0_6px_rgba(251,191,36,0.28)] ${selectedRing}`;
      case 'completed':
        return `border-emerald-400/90 bg-emerald-500/25 text-emerald-100 shadow-[0_0_8px_rgba(16,185,129,0.35)] ${selectedRing}`;
      case 'partial':
        return hudTheme === 'monarch'
          ? `border-[#c084fc]/85 bg-[#2a0c46]/85 text-[#f3e8ff] ${selectedRing}`
          : hudTheme === 'igris'
          ? `border-[#fb7185]/85 bg-[#3f0917]/85 text-[#ffe4e6] ${selectedRing}`
          : hudTheme === 'sovereign'
          ? `border-[#fbbf24]/85 bg-[#382305]/85 text-[#fef3c7] ${selectedRing}`
          : `border-[#38f8ff]/85 bg-[#063254]/85 text-[#bff7ff] ${selectedRing}`;
      case 'scheduled':
        return `border-white/30 bg-[#04182b]/65 text-white/80 ${selectedRing}`;
      default:
        return `border-white/15 bg-black/35 text-white/40 ${selectedRing}`;
    }
  };

  return (
    <div className={`p-2.5 border ${accentBorder} bg-[#031221]/85 space-y-2`}>
      <div className="flex items-center justify-between gap-2">
        <div
          className={`flex items-center gap-1.5 text-[11.5px] font-bold uppercase tracking-[0.07em] ${accentText}`}
        >
          <Calendar className="w-3.5 h-3.5 shrink-0" />
          <span>
            {MONTHS_RU[monthIndex]} {year}
          </span>
        </div>
        <div className="flex items-center gap-2 text-[11px] font-mono font-tabular">
          <span className="text-emerald-300 font-bold">✓ {summaryCounts.completedDays}</span>
          <span className="text-amber-300 font-bold">• {summaryCounts.missedDays}</span>
          <span className="text-[#ff6b6b] font-bold">! {summaryCounts.penaltyDays}</span>
        </div>
      </div>

      {activeHabits.length > 0 && (
        <div className="flex flex-wrap gap-1">
          <button
            type="button"
            onClick={() => setSelectedHabitFilter('all')}
            className={`min-h-[32px] px-2.5 py-1 border text-[11px] font-semibold cursor-pointer transition-colors ${
              selectedHabitFilter === 'all'
                ? filterActiveClass
                : 'border-white/25 bg-black/40 text-white/70 hover:border-white/60'
            }`}
          >
            Все ({activeHabits.length})
          </button>
          {activeHabits.map((h) => {
            const active = selectedHabitFilter === h.id;
            return (
              <button
                key={h.id}
                type="button"
                onClick={() => setSelectedHabitFilter(h.id)}
                className={`min-h-[32px] px-2.5 py-1 border text-[11px] font-semibold cursor-pointer truncate max-w-[130px] transition-colors ${
                  active
                    ? filterActiveClass
                    : 'border-white/25 bg-black/40 text-white/70 hover:border-white/60'
                }`}
              >
                {h.title}
              </button>
            );
          })}
        </div>
      )}

      <div className="grid grid-cols-7 gap-1 text-center text-[10px] font-mono uppercase tracking-[0.06em] text-white/55 pt-0.5">
        {WEEKDAYS_HEADER.map((wd) => (
          <div key={wd} className="py-0.5">
            {wd}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-1">
        {Array.from({ length: leadingBlanks }).map((_, idx) => (
          <div key={`blank_${idx}`} className="h-[30px]" aria-hidden="true" />
        ))}

        {daysData.map((cell) => {
          const isSelected = selectedDayData?.iso === cell.iso;
          return (
            <button
              key={cell.iso}
              type="button"
              onClick={() => setSelectedIso(cell.iso)}
              aria-label={`${cell.day} ${MONTHS_RU[monthIndex]}: ${STATUS_LABELS_RU[cell.visualStatus]}`}
              className={`relative h-[30px] border flex items-center justify-center text-[11.5px] font-bold font-tabular cursor-pointer transition-colors ${getCellStyle(
                cell.visualStatus,
                cell.isToday,
                isSelected
              )}`}
            >
              <span>{cell.day}</span>
              {cell.visualStatus === 'penalty' && (
                <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 bg-[#ff3b3b]" />
              )}
              {cell.visualStatus === 'completed' && (
                <span className="absolute bottom-0.5 right-0.5 w-1.5 h-1.5 bg-emerald-400" />
              )}
              {cell.visualStatus === 'missed' && (
                <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 bg-amber-400" />
              )}
            </button>
          );
        })}
      </div>

      <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1 pt-1 border-t border-white/15 text-[10.5px] text-white/80">
        <span className="inline-flex items-center gap-1">
          <span className="w-2.5 h-2.5 border border-emerald-400 bg-emerald-500/35 inline-block" />
          Выполнено
        </span>
        <span className="inline-flex items-center gap-1">
          <span className="w-2.5 h-2.5 border border-[#38f8ff] bg-[#063254] inline-block" />
          Частично
        </span>
        <span className="inline-flex items-center gap-1">
          <span className="w-2.5 h-2.5 border border-amber-400 bg-amber-500/30 inline-block" />
          Пропущено
        </span>
        <span className="inline-flex items-center gap-1">
          <span className="w-2.5 h-2.5 border border-[#ff3b3b] bg-[#45070e] inline-block" />
          Штраф
        </span>
      </div>

      {selectedDayData && (
        <div className="p-2 border border-white/25 bg-black/45 space-y-1 text-[12px]">
          <div className="flex items-center justify-between gap-2">
            <span className="font-bold text-white">
              {selectedDayData.day} {MONTHS_RU[monthIndex].toLowerCase()}
              {selectedDayData.isToday ? ' (Сегодня)' : ''}
            </span>
            <span
              className={`text-[11px] font-bold uppercase ${
                selectedDayData.visualStatus === 'penalty'
                  ? 'text-[#ff7878]'
                  : selectedDayData.visualStatus === 'missed'
                  ? 'text-amber-300'
                  : selectedDayData.visualStatus === 'completed'
                  ? 'text-emerald-300'
                  : 'text-[#9deeff]'
              }`}
            >
              {STATUS_LABELS_RU[selectedDayData.visualStatus]}
            </span>
          </div>

          {selectedDayData.details.length === 0 ? (
            <div className="text-[11.5px] text-white/65">
              {selectedDayData.visualStatus === 'scheduled'
                ? 'Запланировано по расписанию привычек.'
                : 'За этот день отметок по привычкам нет.'}
            </div>
          ) : (
            <div className="space-y-1">
              {selectedDayData.details.map((d) => (
                <div
                  key={d.habitId}
                  className="flex items-center justify-between gap-2 text-[11.5px]"
                >
                  <button
                    type="button"
                    onClick={() => onOpenHabitHistory?.(d.habitId)}
                    className="flex items-center gap-1.5 text-left text-white/90 hover:text-[#38f8ff] truncate cursor-pointer"
                  >
                    {d.hasPenalty ? (
                      <AlertTriangle className="w-3.5 h-3.5 text-[#ff4d4d] shrink-0" />
                    ) : d.status === 'completed' ? (
                      <Check className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                    ) : (
                      <Clock className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                    )}
                    <span className="truncate">{d.habitTitle}</span>
                  </button>

                  {d.hasPenalty && onOpenPenalty ? (
                    <button
                      type="button"
                      onClick={onOpenPenalty}
                      className="text-[#ff8585] hover:text-white font-semibold inline-flex items-center gap-0.5 shrink-0 cursor-pointer"
                    >
                      <span>Штраф</span>
                      <ChevronRight className="w-3 h-3" />
                    </button>
                  ) : (
                    <span
                      className={`font-tabular shrink-0 ${
                        d.status === 'completed'
                          ? 'text-emerald-300'
                          : d.status === 'missed'
                          ? 'text-amber-300'
                          : 'text-[#9deeff]'
                      }`}
                    >
                      {d.status === 'completed'
                        ? 'Выполнено'
                        : d.status === 'missed'
                        ? 'Пропущено'
                        : d.status === 'partial' && typeof d.valueMinutes === 'number'
                        ? `${d.valueMinutes}/${d.targetMinutes || 15}м`
                        : 'В процессе'}
                    </span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
});
