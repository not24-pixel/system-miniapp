import React, { memo } from 'react';
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  BookOpen,
  Calendar,
  CheckSquare,
  ChevronRight,
  Coins,
  Crown,
  Flame,
  Ghost,
  Play,
  Plus,
  Share2,
  Sparkles,
  Target,
  User,
  Wallet,
} from 'lucide-react';
import { Goal, TaskItem, UserAppState } from '../shared/types';
import { playSystemSound } from '../shared/sound';
import { RollingNumber } from './RollingNumber';
import {
  SystemButton,
  SystemHeaderBox,
  SystemProgressBar,
  formatRolesSubtitle,
  getHunterRankInfo,
} from './SystemWidgets';
import { ElectricCheckboxBurst } from './ElectricBurst';

export interface DashboardOverviewProps {
  user: UserAppState;
  busy: boolean;
  navigateState: (id: number) => void;
  apiAction: (
    endpoint: string,
    body?: Record<string, unknown>,
    nextStateId?: number
  ) => Promise<void>;
  setSelectedGoalId?: (id: string | null) => void;
  setSelectedTaskId?: (id: string | null) => void;
  openPlusModal?: (
    reason?: 'habits' | 'goals' | 'accounts' | 'feature' | 'general',
    featureLabel?: string
  ) => void;
  onOpenShareCard?: () => void;
}

function getGoalProgressPercent(goal: Goal): number {
  if (!goal.targetValue || goal.targetValue <= 0) return 0;
  return Math.min(100, Math.max(0, Math.round((goal.currentValue / goal.targetValue) * 100)));
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = memo(({
  user,
  busy,
  navigateState,
  apiAction,
  setSelectedGoalId,
  setSelectedTaskId,
  openPlusModal,
  onOpenShareCard,
}) => {
  const reducedMotion = user.reducedMotion;
  const [completeSparkKey, setCompleteSparkKey] = React.useState(0);
  const rankInfo = getHunterRankInfo(user.level);
  const callsign = user.playerCallsign?.trim() || 'Игрок';

  // Day status metrics
  const totalTasks = user.tasks.length;
  const doneTasks = user.tasks.filter((t) => t.completed).length;
  const activeHabits = user.habits.filter((h) => h.status === 'active');
  const totalHabits = activeHabits.length;
  const doneHabits = activeHabits.filter((h) => h.completedToday).length;

  const totalDailyItems = totalTasks + totalHabits;
  const doneDailyItems = doneTasks + doneHabits;
  const daySyncPercent =
    totalDailyItems > 0 ? Math.round((doneDailyItems / totalDailyItems) * 100) : 100;

  const dayStatusLabel = user.penaltyQuest.active
    ? 'Штрафной режим'
    : totalDailyItems === 0
    ? 'Ожидает директив'
    : doneDailyItems === totalDailyItems
    ? 'План дня выполнен'
    : 'В активном строю';

  // Quests & goals
  const pendingTasks = user.tasks.filter((t) => !t.completed);
  const priorityTask: TaskItem | undefined =
    pendingTasks.find((t) => t.priority === 'high') || pendingTasks[0] || user.tasks[0];

  const activeGoals = user.goals.filter((g) => g.status === 'active');
  const leadGoal = activeGoals[0];

  // Financial summary
  const activeAccounts = user.accounts.filter((a) => a.status === 'active');
  const totalBalance = activeAccounts.reduce((sum, acc) => sum + acc.balanceRub, 0);
  const monthNet = user.monthIncomeRub - user.monthExpenseRub;

  const handleCardClick = (stateId: number) => {
    playSystemSound('tab_switch', user.soundEnabled, user.hapticsEnabled);
    navigateState(stateId);
  };

  return (
    <div className="flex flex-col justify-between min-h-full space-y-3.5 pb-3">
      {/* Header & Player Identity Banner */}
      <div className="space-y-2.5">
        <SystemHeaderBox
          title="СИСТЕМНАЯ СВОДКА"
          rightAction={
            <button
              type="button"
              onClick={() => handleCardClick(28)}
              aria-label="Профиль Игрока"
              className="min-h-[36px] min-w-[36px] flex items-center justify-center text-[#72f8ff] hover:text-white cursor-pointer"
            >
              <User className="w-4 h-4" />
            </button>
          }
        />

        <div
          className="relative border border-[#38e8ff]/55 bg-[#04182b]/75 p-3 overflow-hidden"
        >
          {!reducedMotion && (
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(0,229,255,0.22),transparent_65%)]"
            />
          )}

          <div className="relative z-10 flex items-start justify-between gap-2">
            <div className="min-w-0">
              <div className="text-[12px] font-semibold text-[#72f8ff] tracking-wide truncate">
                {rankInfo.rank} · {rankInfo.title}
              </div>
              <div className="text-[18px] font-bold text-white leading-tight mt-0.5 truncate">
                С возвращением, {callsign}
              </div>
              <div className="text-[12px] text-white/75 truncate mt-0.5">
                {formatRolesSubtitle(user.roles, user.customRoleText)}
              </div>
            </div>

            <div className="text-right shrink-0">
              <div className="text-[11px] text-white/70">Уровень</div>
              <div className="text-[22px] font-bold leading-none text-[#72f8ff] font-tabular">
                <RollingNumber value={user.level} metricKey="player_level" />
              </div>
            </div>
          </div>

          <div className="relative z-10 mt-2.5 space-y-1">
            <div className="flex items-center justify-between text-[12px] font-tabular text-white/85">
              <span>Опыт (XP)</span>
              <span>
                <RollingNumber value={user.currentXp} metricKey="player_xp" useGrouping /> /{' '}
                <RollingNumber value={user.nextLevelXp} useGrouping />
              </span>
            </div>
            <SystemProgressBar value={user.currentXp} max={user.nextLevelXp} />
          </div>

          <div className="relative z-10 mt-2.5 pt-2.5 border-t border-white/15 space-y-2 text-[12px] font-tabular">
            <div className="flex items-center justify-between gap-2">
              <span className="flex items-center gap-1.5 font-bold text-amber-300">
                <Flame className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Серия: {user.streakDays || 0} дн.</span>
              </span>
              <span className="flex items-center gap-1.5 font-semibold text-[#9deeff]">
                <Ghost className="w-4 h-4 text-[#38e8ff] shrink-0" />
                <span>Теней: {user.shadows?.length || 0}</span>
              </span>
            </div>
            {onOpenShareCard && (
              <button
                type="button"
                onClick={onOpenShareCard}
                className="w-full min-h-[44px] px-3 py-2 border border-[#38f8ff]/80 bg-[#062d4a]/90 text-[13px] font-bold text-[#9deeff] hover:border-white hover:text-white flex items-center justify-between gap-2 cursor-pointer shadow-[0_0_12px_rgba(0,225,255,0.22)]"
              >
                <span className="flex items-center gap-2">
                  <Share2 className="w-4 h-4 text-[#38f8ff]" />
                  <span>Карточка Охотника · 9:16</span>
                </span>
                <span className="text-[11px] uppercase tracking-wider text-white/85">
                  Сторис / TikTok →
                </span>
              </button>
            )}
          </div>

          {user.unspentStatPoints > 0 && (
            <button
              type="button"
              onClick={() => handleCardClick(29)}
              className="relative z-10 mt-2.5 w-full min-h-[40px] px-2.5 py-1.5 border border-[#38f8ff]/80 bg-[#072c48]/85 flex items-center justify-between text-[13px] font-semibold text-[#b9fbff] cursor-pointer hover:bg-[#0a3c61]"
            >
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-[#38f8ff]" />
                <span>
                  Доступно очков характеристик:{' '}
                  <RollingNumber value={user.unspentStatPoints} metricKey="player_unspent" />
                </span>
              </span>
              <span className="flex items-center gap-1 text-white font-bold text-[12px]">
                Распределить <ChevronRight className="w-3.5 h-3.5" />
              </span>
            </button>
          )}
        </div>
      </div>

      {/* Active Penalty Alert (if triggered) */}
      {user.penaltyQuest.active && (
        <button
          type="button"
          onClick={() => handleCardClick(40)}
          className="w-full min-h-[52px] p-3 border border-[#ff4d4d] bg-[#2b0408]/90 flex items-center justify-between gap-2.5 text-left cursor-pointer"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <AlertTriangle className="w-5 h-5 text-[#ff6b6b] shrink-0" />
            <div className="min-w-0">
              <div className="text-[13px] font-bold text-white">Карантин Системы · Штрафной квест</div>
              <div className="text-[12px] text-[#ffd2cf] truncate">
                Пропущено: {user.penaltyQuest.reasonTitle} · Финансы и Настройки открыты
              </div>
            </div>
          </div>
          <span className="px-2.5 py-1 border border-white/80 bg-[#520810] text-[12px] font-bold text-white shrink-0">
            Снять
          </span>
        </button>
      )}

      {/* Current Day Status Panel */}
      <div
        className="border border-white/35 bg-black/45 p-3 space-y-2.5"
      >
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 text-[13px] font-bold text-white">
            <Activity className="w-4 h-4 text-[#38e8ff]" />
            <span>Статус текущего дня</span>
          </div>
          <span
            className={`text-[12px] font-semibold ${
              user.penaltyQuest.active
                ? 'text-[#ff8080]'
                : daySyncPercent === 100 && totalDailyItems > 0
                ? 'text-[#72f8ff]'
                : 'text-white/80'
            }`}
          >
            {dayStatusLabel}
          </span>
        </div>

        <div className="grid grid-cols-3 gap-2 text-center">
          <button
            type="button"
            onClick={() => handleCardClick(11)}
            className="min-h-[56px] p-2 border border-white/25 bg-[#041322]/75 hover:border-[#38e8ff]/80 transition-colors cursor-pointer flex flex-col items-center justify-center"
          >
            <span className="text-[11px] text-white/70">Задания</span>
            <span className="text-[16px] font-bold text-white font-tabular">
              <RollingNumber value={doneTasks} metricKey="dash_tasks_done" /> /{' '}
              <RollingNumber value={totalTasks} metricKey="dash_tasks_total" />
            </span>
          </button>

          <button
            type="button"
            onClick={() => handleCardClick(13)}
            className="min-h-[56px] p-2 border border-white/25 bg-[#041322]/75 hover:border-[#38e8ff]/80 transition-colors cursor-pointer flex flex-col items-center justify-center"
          >
            <span className="text-[11px] text-white/70">Привычки</span>
            <span className="text-[16px] font-bold text-white font-tabular">
              <RollingNumber value={doneHabits} metricKey="dash_habits_done" /> /{' '}
              <RollingNumber value={totalHabits} metricKey="dash_habits_total" />
            </span>
          </button>

          <button
            type="button"
            onClick={() => handleCardClick(16)}
            className="min-h-[56px] p-2 border border-white/25 bg-[#041322]/75 hover:border-[#38e8ff]/80 transition-colors cursor-pointer flex flex-col items-center justify-center"
          >
            <span className="text-[11px] text-white/70">Цели</span>
            <span className="text-[16px] font-bold text-[#72f8ff] font-tabular">
              <RollingNumber value={activeGoals.length} metricKey="dash_goals_active" />
            </span>
          </button>
        </div>

        <div className="space-y-1">
          <div className="flex items-center justify-between text-[11px] text-white/75">
            <span>Синхронизация дня</span>
            <span className="font-tabular text-white font-semibold">
              <RollingNumber value={daySyncPercent} metricKey="dash_day_sync" suffix="%" />
            </span>
          </div>
          <SystemProgressBar value={doneDailyItems} max={Math.max(1, totalDailyItems)} />
        </div>
      </div>

      {/* Current Quests & Priority Goal */}
      <div
        className="border border-white/35 bg-black/45 p-3 space-y-2.5"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-[13px] font-bold text-white">
            <Target className="w-4 h-4 text-[#38e8ff]" />
            <span>Текущие квесты</span>
          </div>
          <button
            type="button"
            onClick={() => handleCardClick(11)}
            className="min-h-[32px] px-1 text-[12px] text-[#72f8ff] hover:text-white flex items-center gap-0.5 cursor-pointer"
          >
            <span>Все ({pendingTasks.length})</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {priorityTask ? (
          <div className="border border-[#38e8ff]/45 bg-[#051a2e]/85 p-2.5 space-y-2">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-start gap-2 min-w-0">
                <BookOpen className="w-4 h-4 text-[#38f8ff] shrink-0 mt-0.5" />
                <div className="min-w-0">
                  <div className="text-[14px] font-bold text-white leading-snug truncate">
                    {priorityTask.title}
                  </div>
                  <div className="text-[12px] text-white/75 font-tabular">
                    {priorityTask.durationMinutes ? `${priorityTask.durationMinutes} мин · ` : ''}
                    +{priorityTask.xpReward} XP · {priorityTask.dueDateText}
                  </div>
                </div>
              </div>
              {priorityTask.completed ? (
                <span className="text-[11px] font-semibold text-[#72f8ff] shrink-0">Выполнено</span>
              ) : (
                <span className="text-[11px] font-semibold text-white/80 shrink-0">Активно</span>
              )}
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                disabled={busy}
                onClick={() =>
                  apiAction('/api/tasks/start-focus', { taskId: priorityTask.id }, 59)
                }
                className="min-h-[42px] px-2.5 py-1.5 border border-[#38f8ff] bg-[#062c49]/90 hover:bg-[#083b61] text-[13px] font-bold text-white flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Начать фокус</span>
              </button>

              <button
                type="button"
                disabled={busy}
                onClick={() => {
                  if (!priorityTask.completed) {
                    setCompleteSparkKey((k) => k + 1);
                  }
                  apiAction(
                    '/api/tasks/toggle',
                    { taskId: priorityTask.id },
                    !priorityTask.completed ? 27 : undefined
                  );
                }}
                className="relative min-h-[42px] px-2.5 py-1.5 border border-white/75 bg-[#041322]/85 hover:bg-[#07223b] text-[13px] font-semibold text-white flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50 overflow-visible"
              >
                <ElectricCheckboxBurst
                  burstKey={completeSparkKey}
                  tagText={`+${priorityTask.xpReward || 25} XP`}
                />
                <CheckSquare className="w-3.5 h-3.5" />
                <span>{priorityTask.completed ? 'Вернуть' : 'Завершить'}</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="border border-white/25 bg-[#041322]/70 p-2.5 flex items-center justify-between gap-2">
            <span className="text-[13px] text-white/80">Активных квестов на сегодня нет.</span>
            <button
              type="button"
              onClick={() => {
                setSelectedTaskId?.(null);
                setSelectedGoalId?.(null);
                handleCardClick(60);
              }}
              className="min-h-[38px] px-2.5 border border-[#38e8ff]/70 bg-[#062c49]/80 text-[12px] font-bold text-white flex items-center gap-1 cursor-pointer shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Создать</span>
            </button>
          </div>
        )}

        {leadGoal && (
          <button
            type="button"
            onClick={() => {
              setSelectedGoalId?.(leadGoal.id);
              handleCardClick(16);
            }}
            className="w-full text-left border-t border-white/20 pt-2.5 space-y-1.5 cursor-pointer group"
          >
            <div className="flex items-center justify-between gap-2 text-[12px]">
              <span className="text-white/75 truncate">
                Главная цель: <strong className="text-white">{leadGoal.title}</strong>
              </span>
              <span className="font-tabular text-[#72f8ff] shrink-0">
                <RollingNumber value={getGoalProgressPercent(leadGoal)} suffix="%" />
              </span>
            </div>
            <SystemProgressBar value={leadGoal.currentValue} max={leadGoal.targetValue} />
          </button>
        )}
      </div>

      {/* Financial Balance Summary */}
      <div
        className="border border-white/35 bg-black/45 p-3 space-y-2"
      >
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 text-[13px] font-bold text-white">
            <Wallet className="w-4 h-4 text-[#38e8ff]" />
            <span>Финансовый баланс</span>
          </div>
          <button
            type="button"
            onClick={() => handleCardClick(19)}
            className="min-h-[32px] px-1 text-[12px] text-[#72f8ff] hover:text-white flex items-center gap-0.5 cursor-pointer"
          >
            <span>Счета ({activeAccounts.length})</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="flex items-baseline justify-between gap-2">
          <div className="text-[22px] font-bold text-white font-tabular leading-none">
            <RollingNumber
              value={totalBalance}
              metricKey="finance_total_balance"
              useGrouping
              suffix=" ₽"
            />
          </div>
          <div
            className={`text-[12px] font-semibold font-tabular ${
              monthNet >= 0 ? 'text-[#72f8ff]' : 'text-[#ff8a80]'
            }`}
          >
            {monthNet >= 0 ? 'Месяц +' : 'Месяц '}
            <RollingNumber value={monthNet} useGrouping suffix=" ₽" />
          </div>
        </div>

        <div className="flex items-center justify-between gap-2 text-[12px] text-white/75 font-tabular border-t border-white/15 pt-2">
          <span>
            Доход: +<RollingNumber value={user.monthIncomeRub} useGrouping /> ₽
          </span>
          <span aria-hidden="true">·</span>
          <span>
            Расход: −<RollingNumber value={user.monthExpenseRub} useGrouping /> ₽
          </span>
          <button
            type="button"
            onClick={() => handleCardClick(23)}
            className="ml-auto text-[#72f8ff] hover:text-white font-semibold cursor-pointer whitespace-nowrap"
          >
            + Запись
          </button>
        </div>
      </div>

      {/* Primary Action & Quick Section Jumps */}
      <div className="space-y-2 pt-0.5">
        <SystemButton
          label="ОТКРЫТЬ «СЕГОДНЯ»"
          highlighted
          onClick={() => handleCardClick(11)}
        />

        <div className="grid grid-cols-4 gap-1.5">
          {[
            { label: 'Сегодня', state: 11, Icon: Calendar },
            { label: 'Цели', state: 16, Icon: Target },
            { label: 'Привычки', state: 13, Icon: CheckSquare },
            { label: 'Финансы', state: 19, Icon: Coins },
          ].map(({ label, state, Icon }) => (
            <button
              key={label}
              type="button"
              onClick={() => handleCardClick(state)}
              className="min-h-[44px] py-1.5 px-1 border border-white/40 bg-[#041322]/80 hover:border-[#38e8ff] text-white/90 hover:text-white flex flex-col items-center justify-center gap-1 cursor-pointer transition-colors"
            >
              <Icon className="w-4 h-4 text-[#72f8ff]" />
              <span className="text-[11px] leading-none font-medium whitespace-nowrap">{label}</span>
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={() => (openPlusModal ? openPlusModal('general') : handleCardClick(47))}
          className={`w-full min-h-[54px] px-3.5 py-2.5 border text-left flex items-center justify-between gap-2.5 cursor-pointer transition-colors ${
            user.subscription.active
              ? 'border-[#38e8ff]/65 bg-[#051d33]/85 text-[#b9fbff]'
              : 'border-amber-400/85 bg-gradient-to-r from-[#261704]/90 via-[#162134]/90 to-[#062d4a]/90 hover:border-amber-300 text-amber-200 shadow-[0_0_16px_rgba(251,191,36,0.22)]'
          }`}
        >
          <span className="flex items-center gap-2.5 min-w-0">
            <Crown className="w-5 h-5 text-amber-400 shrink-0" />
            <span className="min-w-0">
              <span className="block text-[13.5px] font-extrabold text-white truncate">
                {user.subscription.active
                  ? `Система+ активна · Щиты: ${user.shieldChargesRemaining ?? 0}`
                  : 'СИСТЕМА+ · Усилить Игрока'}
              </span>
              <span className="block text-[11px] text-amber-100/80 truncate">
                {user.subscription.active
                  ? 'Тени ×2 XP, 3 облика HUD, Сундук ×1.5'
                  : 'Тени ×2 XP · 3 облика · Щит серии · ∞ цели'}
              </span>
            </span>
          </span>
          <span className="px-2.5 py-1 border border-amber-400/70 bg-black/45 text-[11.5px] font-extrabold uppercase tracking-wider shrink-0 text-amber-300">
            {user.subscription.active ? 'PRO' : '99 ⭐'}
          </span>
        </button>

        <button
          type="button"
          onClick={() => handleCardClick(28)}
          className="w-full min-h-[46px] border border-white/35 bg-black/40 hover:border-white/65 text-[13.5px] font-semibold text-white/95 hover:text-white flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
        >
          <span>Статус и древо навыков Игрока</span>
          <ArrowRight className="w-4 h-4 text-[#38e8ff]" />
        </button>
      </div>
    </div>
  );
});
