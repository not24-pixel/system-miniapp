import React, { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  Check,
  ChevronLeft,
  Calendar,
  Target,
  User,
  UserPlus,
  UserX,
  Gift,
  Hourglass,
  RefreshCw,
  Settings,
  Shield,
  Zap,
  Activity,
  Coins,
  ChevronUp,
} from 'lucide-react';
import { motion } from 'motion/react';
import { LifeRoleId, PlayerSubTabId, SystemPalette } from '../shared/types';
import { playSystemSound } from '../shared/sound';
import { RollingNumber, useSystemMetrics } from './RollingNumber';
import { ElectricCheckboxBurst, ElectricRowArc } from './ElectricBurst';

export function getHunterRankInfo(level: number): { rank: string; title: string } {
  if (level >= 25) return { rank: 'S-РАНГ', title: 'Владыка Системы' };
  if (level >= 18) return { rank: 'A-РАНГ', title: 'Мастер Дисциплины' };
  if (level >= 12) return { rank: 'B-РАНГ', title: 'Идущий против Системы' };
  if (level >= 7) return { rank: 'C-РАНГ', title: 'Пробуждённый Игрок' };
  if (level >= 3) return { rank: 'D-РАНГ', title: 'Искатель Ритма' };
  return { rank: 'E-РАНГ', title: 'Начинающий Игрок' };
}

export function formatRolesSubtitle(roles: LifeRoleId[], customText?: string): string {
  const map: Record<LifeRoleId, string> = {
    studying: 'Учёба',
    employed: 'Найм',
    freelance: 'Фриланс',
    business: 'Бизнес',
    family: 'Семья',
    custom: customText?.trim() || 'Свой путь',
  };
  if (!roles || roles.length === 0) return 'Найм';
  return roles.map((r) => map[r] || r).join(' · ');
}

export const SystemHeaderBox: React.FC<{
  title: string;
  palette?: SystemPalette;
  onBack?: () => void;
  rightAction?: React.ReactNode;
}> = ({ title, palette = 'blue', onBack, rightAction }) => {
  const { hudTheme } = useSystemMetrics();
  const isRed = palette === 'red';
  const skin = isRed ? 'red' : hudTheme;
  const boxToneClass =
    skin === 'red'
      ? 'bg-[#2a0408]/85 shadow-[0_0_18px_rgba(255,40,40,0.42),inset_0_0_12px_rgba(255,40,40,0.2)]'
      : skin === 'monarch'
      ? 'bg-[#17092b]/85 shadow-[0_0_18px_rgba(168,85,247,0.42),inset_0_0_12px_rgba(168,85,247,0.22)]'
      : skin === 'igris'
      ? 'bg-[#260610]/85 shadow-[0_0_18px_rgba(244,63,94,0.42),inset_0_0_12px_rgba(244,63,94,0.22)]'
      : skin === 'sovereign'
      ? 'bg-[#221604]/85 shadow-[0_0_18px_rgba(245,158,11,0.42),inset_0_0_12px_rgba(245,158,11,0.22)]'
      : 'bg-[#04182b]/85 shadow-[0_0_18px_rgba(0,212,255,0.38),inset_0_0_12px_rgba(0,212,255,0.18)]';
  const radialClass =
    skin === 'red'
      ? 'bg-[radial-gradient(ellipse_at_center,rgba(255,55,55,0.28),transparent_72%)]'
      : skin === 'monarch'
      ? 'bg-[radial-gradient(ellipse_at_center,rgba(168,85,247,0.28),transparent_72%)]'
      : skin === 'igris'
      ? 'bg-[radial-gradient(ellipse_at_center,rgba(244,63,94,0.28),transparent_72%)]'
      : skin === 'sovereign'
      ? 'bg-[radial-gradient(ellipse_at_center,rgba(245,158,11,0.28),transparent_72%)]'
      : 'bg-[radial-gradient(ellipse_at_center,rgba(0,229,255,0.24),transparent_72%)]';
  const glowTextClass =
    skin === 'red'
      ? 'system-text-glow-red system-digital-tearing'
      : skin === 'monarch'
      ? 'system-text-glow-monarch'
      : skin === 'igris'
      ? 'system-text-glow-igris'
      : skin === 'sovereign'
      ? 'system-text-glow-sovereign'
      : 'system-text-glow-blue';

  return (
    <div
      className={`relative w-full min-h-[48px] py-2 px-3 border border-white/90 flex items-center justify-center overflow-hidden ${boxToneClass}`}
    >
      <span
        aria-hidden="true"
        className={`pointer-events-none absolute inset-0 opacity-30 ${radialClass}`}
      />
      {onBack && (
        <button
          type="button"
          onClick={onBack}
          aria-label="Назад"
          className="absolute left-1.5 top-1/2 -translate-y-1/2 z-20 min-w-[40px] min-h-[40px] flex items-center justify-center text-white/90 hover:text-white active:scale-90 transition-transform cursor-pointer"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
      )}
      <h1
        className={`relative z-10 ${
          onBack || rightAction ? 'px-10' : 'px-2.5'
        } ${
          title.length > 16
            ? 'text-[16px] sm:text-[18px] tracking-[0.04em]'
            : 'text-[19px] sm:text-[20px] tracking-[0.07em]'
        } font-bold uppercase text-white text-center leading-tight whitespace-nowrap overflow-hidden text-ellipsis ${glowTextClass}`}
      >
        {title}
      </h1>
      {rightAction && (
        <div className="absolute right-1.5 top-1/2 -translate-y-1/2 z-20 flex items-center justify-center">
          {rightAction}
        </div>
      )}
    </div>
  );
};

export const SystemSquareIcon: React.FC<{
  kind:
    | 'alert'
    | 'check'
    | 'user'
    | 'target'
    | 'calendar'
    | 'settings'
    | 'refresh'
    | 'hourglass'
    | 'gift'
    | 'user-plus'
    | 'user-x'
    | 'shield'
    | 'zap'
    | 'activity'
    | 'coins'
    | 'double-up';
  palette?: SystemPalette;
  circleOnly?: boolean;
}> = ({ kind, palette = 'blue', circleOnly = false }) => {
  const isRed = palette === 'red';
  const glow = isRed
    ? 'shadow-[0_0_22px_rgba(255,45,45,0.6),inset_0_0_12px_rgba(255,45,45,0.32)] border-[#ff6b6b]'
    : 'shadow-[0_0_22px_rgba(0,225,255,0.52),inset_0_0_12px_rgba(0,225,255,0.28)] border-white/90';

  const renderInner = () => {
    switch (kind) {
      case 'alert':
        return (
          <motion.div
            animate={{ scale: [1, 1.08, 1] }}
            transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
            className="w-9 h-9 rounded-full border-2 border-white flex items-center justify-center font-bold text-xl shadow-[0_0_10px_rgba(255,255,255,0.5)]"
          >
            !
          </motion.div>
        );
      case 'check':
        return (
          <div className="w-9 h-9 rounded-full border-2 border-white flex items-center justify-center shadow-[0_0_10px_rgba(0,229,255,0.5)]">
            <Check className="w-5 h-5 stroke-[2.5]" />
          </div>
        );
      case 'user':
        return <User className="w-8 h-8 stroke-[1.8]" />;
      case 'target':
        return <Target className="w-8 h-8 stroke-[1.8]" />;
      case 'calendar':
        return <Calendar className="w-8 h-8 stroke-[1.8]" />;
      case 'settings':
        return <Settings className="w-9 h-9 stroke-[1.8]" />;
      case 'refresh':
        return <RefreshCw className="w-8 h-8 stroke-[1.8] animate-spin" />;
      case 'hourglass':
        return <Hourglass className="w-8 h-8 stroke-[1.8]" />;
      case 'gift':
        return <Gift className="w-8 h-8 stroke-[1.8]" />;
      case 'user-plus':
        return <UserPlus className="w-8 h-8 stroke-[1.8]" />;
      case 'user-x':
        return <UserX className="w-8 h-8 stroke-[1.8]" />;
      case 'shield':
        return <Shield className="w-7 h-7 stroke-[1.8]" />;
      case 'zap':
        return <Zap className="w-7 h-7 stroke-[1.8]" />;
      case 'activity':
        return <Activity className="w-7 h-7 stroke-[1.8]" />;
      case 'coins':
        return <Coins className="w-7 h-7 stroke-[1.8]" />;
      case 'double-up':
        return (
          <div className="flex flex-col -space-y-2.5 items-center">
            <ChevronUp className="w-7 h-7 stroke-[2.5]" />
            <ChevronUp className="w-7 h-7 stroke-[2.5]" />
          </div>
        );
      default:
        return <AlertCircle className="w-8 h-8" />;
    }
  };

  if (circleOnly) {
    return (
      <div className="mx-auto my-2 w-12 h-12 rounded-full border-2 border-white flex items-center justify-center shadow-[0_0_18px_rgba(255,255,255,0.55)]">
        <span className="text-2xl font-bold">!</span>
      </div>
    );
  }

  return (
    <div
      className={`relative mx-auto my-2 w-14 h-14 border ${glow} bg-black/45 flex items-center justify-center text-white overflow-hidden`}
    >
      <span
        aria-hidden="true"
        className={`pointer-events-none absolute inset-0 opacity-40 ${
          isRed
            ? 'bg-[radial-gradient(circle,rgba(255,60,60,0.28),transparent_70%)]'
            : 'bg-[radial-gradient(circle,rgba(0,229,255,0.26),transparent_70%)]'
        }`}
      />
      <div className="relative z-10">{renderInner()}</div>
    </div>
  );
};

export const SystemTypewriter: React.FC<{
  lines: string[];
  subLines?: string[];
  palette?: SystemPalette;
  soundEnabled?: boolean;
  speedMs?: number;
  onFinish?: () => void;
}> = ({
  lines,
  subLines = [],
  palette = 'blue',
  soundEnabled = true,
  speedMs = 24,
  onFinish,
}) => {
  const fullPrimary = lines.join('\n');
  const fullSecondary = subLines.join('\n');
  const totalChars = fullPrimary.length + fullSecondary.length;

  const [charCount, setCharCount] = useState(0);

  useEffect(() => {
    setCharCount(0);
  }, [fullPrimary, fullSecondary]);

  useEffect(() => {
    if (charCount >= totalChars) {
      onFinish?.();
      return;
    }
    const timer = setTimeout(() => {
      const next = charCount + 1;
      setCharCount(next);
      if (next % 3 === 0) {
        playSystemSound('type_tick', soundEnabled, false);
      }
    }, speedMs);
    return () => clearTimeout(timer);
  }, [charCount, totalChars, speedMs, soundEnabled, onFinish]);

  const primaryVisible = fullPrimary.slice(0, Math.min(charCount, fullPrimary.length));
  const secondaryChars = Math.max(0, charCount - fullPrimary.length);
  const secondaryVisible = fullSecondary.slice(0, secondaryChars);
  const isTypingPrimary = charCount < fullPrimary.length;
  const isTypingSecondary = !isTypingPrimary && charCount < totalChars;

  const isRed = palette === 'red';

  return (
    <div
      onClick={() => {
        if (charCount < totalChars) setCharCount(totalChars);
      }}
      className="space-y-6 my-auto px-2 cursor-pointer"
    >
      <p
        className={`text-[22px] font-semibold leading-snug text-white whitespace-pre-line ${
          isRed ? 'system-text-glow-red' : 'system-text-glow-blue'
        }`}
      >
        {primaryVisible}
        {isTypingPrimary && (
          <span
            className={`inline-block w-2.5 h-5 ml-1 align-middle animate-pulse ${
              isRed ? 'bg-[#ff4d4d]' : 'bg-[#38f8ff]'
            }`}
          />
        )}
      </p>

      {fullSecondary.length > 0 && (
        <p className="text-[19px] font-medium text-white/95 leading-snug whitespace-pre-line min-h-[28px]">
          {secondaryVisible}
          {isTypingSecondary && (
            <span
              className={`inline-block w-2 h-4 ml-1 align-middle animate-pulse ${
                isRed ? 'bg-[#ff4d4d]' : 'bg-[#38f8ff]'
              }`}
            />
          )}
        </p>
      )}
    </div>
  );
};

export const SystemButton: React.FC<{
  label: string;
  bracketed?: boolean;
  palette?: SystemPalette;
  highlighted?: boolean;
  disabled?: boolean;
  onClick?: () => void;
  className?: string;
}> = ({
  label,
  bracketed = true,
  palette = 'blue',
  highlighted = false,
  disabled = false,
  onClick,
  className = '',
}) => {
  const { reducedMotion, hudTheme } = useSystemMetrics();
  const isRed = palette === 'red';
  const skin = isRed ? 'red' : hudTheme;
  const baseStyle =
    skin === 'red'
      ? highlighted
        ? 'border-white bg-[#590710]/90 shadow-[0_0_20px_rgba(255,40,40,0.68),inset_0_0_14px_rgba(255,80,80,0.4)] hover:bg-[#700914]'
        : 'border-white/85 bg-[#290408]/75 hover:bg-[#42070e]/90 shadow-[0_0_12px_rgba(255,30,30,0.32)]'
      : skin === 'monarch'
      ? highlighted
        ? 'border-[#c084fc] bg-[#2e1065]/90 shadow-[0_0_20px_rgba(168,85,247,0.62),inset_0_0_14px_rgba(168,85,247,0.38)] hover:bg-[#3b0764]'
        : 'border-white/85 bg-[#150826]/80 hover:bg-[#240b42]/90 shadow-[0_0_12px_rgba(168,85,247,0.28)]'
      : skin === 'igris'
      ? highlighted
        ? 'border-[#fb7185] bg-[#4c0519]/90 shadow-[0_0_20px_rgba(244,63,94,0.62),inset_0_0_14px_rgba(244,63,94,0.38)] hover:bg-[#881337]'
        : 'border-white/85 bg-[#22050e]/80 hover:bg-[#3a0817]/90 shadow-[0_0_12px_rgba(244,63,94,0.28)]'
      : skin === 'sovereign'
      ? highlighted
        ? 'border-[#fbbf24] bg-[#451a03]/90 shadow-[0_0_20px_rgba(245,158,11,0.62),inset_0_0_14px_rgba(245,158,11,0.38)] hover:bg-[#78350f]'
        : 'border-white/85 bg-[#1f1303]/80 hover:bg-[#362105]/90 shadow-[0_0_12px_rgba(245,158,11,0.28)]'
      : highlighted
      ? 'border-[#38f8ff] bg-[#062c49]/90 shadow-[0_0_20px_rgba(0,229,255,0.62),inset_0_0_14px_rgba(0,229,255,0.38)] hover:bg-[#083b61]'
      : 'border-white/85 bg-[#041322]/80 hover:bg-[#07223b]/90 shadow-[0_0_12px_rgba(0,212,255,0.25)]';

  const radialOverlay =
    skin === 'red'
      ? 'bg-[radial-gradient(ellipse_at_center,rgba(255,75,75,0.35),transparent_72%)]'
      : skin === 'monarch'
      ? 'bg-[radial-gradient(ellipse_at_center,rgba(168,85,247,0.35),transparent_72%)]'
      : skin === 'igris'
      ? 'bg-[radial-gradient(ellipse_at_center,rgba(244,63,94,0.35),transparent_72%)]'
      : skin === 'sovereign'
      ? 'bg-[radial-gradient(ellipse_at_center,rgba(245,158,11,0.35),transparent_72%)]'
      : 'bg-[radial-gradient(ellipse_at_center,rgba(0,229,255,0.32),transparent_72%)]';

  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={`group relative overflow-hidden w-full min-h-[46px] py-2.5 px-4 border text-[15px] sm:text-[16px] font-bold tracking-[0.05em] text-white transition-[colors,transform] duration-100 active:scale-[0.97] cursor-pointer disabled:opacity-50 disabled:pointer-events-none flex items-center justify-center ${baseStyle} ${className}`}
    >
      {!disabled && (
        <span
          aria-hidden="true"
          className={`pointer-events-none absolute inset-0 ${highlighted ? 'opacity-35' : 'opacity-15'} ${radialOverlay}`}
        />
      )}
      <span className="relative z-10 whitespace-nowrap">{bracketed ? `[ ${label} ]` : label}</span>
    </button>
  );
};

export const SystemProgressBar: React.FC<{
  value: number;
  max: number;
  palette?: SystemPalette;
  showCenterPercent?: boolean;
}> = ({ value, max, palette = 'blue', showCenterPercent = false }) => {
  const { hudTheme } = useSystemMetrics();
  const skin = palette === 'red' ? 'red' : hudTheme;
  const pct = max > 0 ? Math.min(100, Math.max(0, Math.round((value / max) * 100))) : 0;
  const trackBg =
    skin === 'red'
      ? 'bg-[#290408]/85'
      : skin === 'monarch'
      ? 'bg-[#1a082e]/85'
      : skin === 'igris'
      ? 'bg-[#2a0612]/85'
      : skin === 'sovereign'
      ? 'bg-[#241604]/85'
      : 'bg-[#03192b]/85';
  const fillClass =
    skin === 'red'
      ? 'crystal-bar-red'
      : skin === 'monarch'
      ? 'crystal-bar-monarch'
      : skin === 'igris'
      ? 'crystal-bar-igris'
      : skin === 'sovereign'
      ? 'crystal-bar-sovereign'
      : 'crystal-bar-blue';

  return (
    <div
      className={`relative w-full h-[18px] rounded-[2px] border border-white/85 p-[2px] overflow-hidden ${trackBg}`}
    >
      <div
        className={`h-full rounded-[1px] transition-all duration-300 ${fillClass}`}
        style={{ width: `${pct}%` }}
      />
      {showCenterPercent && (
        <span className="absolute inset-0 flex items-center justify-center text-[11px] font-bold text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] font-tabular">
          <RollingNumber value={pct} suffix="%" />
        </span>
      )}
    </div>
  );
};

export const SystemCheckbox: React.FC<{
  checked: boolean;
  missed?: boolean;
  onChange?: () => void;
  label?: string;
  sublabel?: string;
  rightSlot?: React.ReactNode;
  electricTag?: string;
  initialBurst?: boolean;
  disabled?: boolean;
}> = ({
  checked,
  missed = false,
  onChange,
  label,
  sublabel,
  rightSlot,
  electricTag,
  initialBurst = false,
  disabled = false,
}) => {
  const { reducedMotion } = useSystemMetrics();
  const prevCheckedRef = useRef(checked);
  const manualFiredRef = useRef(false);
  const [burstKey, setBurstKey] = useState(initialBurst ? 1 : 0);

  useEffect(() => {
    if (!prevCheckedRef.current && checked) {
      if (manualFiredRef.current) {
        manualFiredRef.current = false;
      } else {
        setBurstKey((k) => k + 1);
      }
    }
    prevCheckedRef.current = checked;
  }, [checked]);

  const handleToggle = () => {
    if (disabled) return;
    if (!checked && !missed) {
      manualFiredRef.current = true;
      setBurstKey((k) => k + 1);
    }
    onChange?.();
  };

  return (
    <div className="relative w-full py-2.5 flex items-center justify-between gap-3 border-b border-white/25 overflow-visible">
      <ElectricRowArc burstKey={burstKey} />
      <motion.button
        type="button"
        disabled={disabled}
        onClick={handleToggle}
        whileTap={reducedMotion ? undefined : { scale: 0.985 }}
        transition={{ duration: 0.14 }}
        className="relative z-10 flex items-center gap-3 text-left flex-1 min-h-[40px] cursor-pointer group disabled:cursor-default"
      >
        <span
          className={`relative w-6 h-6 shrink-0 rounded-[4px] border-2 flex items-center justify-center transition-colors ${
            missed
              ? 'border-[#ff4d4d] bg-[#3b0509] text-[#ff6b6b] shadow-[0_0_8px_rgba(255,50,50,0.5)]'
              : checked
              ? 'border-[#38f8ff] bg-[#062d4a] text-white shadow-[0_0_12px_rgba(0,229,255,0.65)]'
              : 'border-white/80 bg-black/40 group-hover:border-[#00e5ff]'
          }`}
        >
          <ElectricCheckboxBurst burstKey={burstKey} tagText={electricTag} />
          {missed ? (
            <span className="w-3 h-0.5 bg-[#ff6b6b] block" />
          ) : checked ? (
            <motion.span
              initial={reducedMotion ? false : { scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.15 }}
            >
              <Check className="w-4 h-4 stroke-[3]" />
            </motion.span>
          ) : null}
        </span>
        {label && (
          <div className="flex flex-col min-w-0">
            <span className={`text-[16px] font-semibold leading-snug ${missed ? 'text-[#ff6b6b]' : 'text-white'}`}>
              {label}
            </span>
            {sublabel && <span className="text-[14px] text-white/80 leading-snug">{sublabel}</span>}
          </div>
        )}
      </motion.button>
      {rightSlot && <div className="relative z-10 shrink-0">{rightSlot}</div>}
    </div>
  );
};

export const PlayerTopTabs: React.FC<{
  active: PlayerSubTabId;
  onSelect: (sub: PlayerSubTabId) => void;
  soundEnabled?: boolean;
  hapticsEnabled?: boolean;
}> = ({ active, onSelect, soundEnabled = true, hapticsEnabled = true }) => {
  const { reducedMotion, hudTheme } = useSystemMetrics();
  const tabGlowClass =
    hudTheme === 'monarch'
      ? 'bg-gradient-to-r from-[#581c87] via-[#9333ea] to-[#581c87] shadow-[0_0_12px_rgba(168,85,247,0.65)]'
      : hudTheme === 'igris'
      ? 'bg-gradient-to-r from-[#881337] via-[#e11d48] to-[#881337] shadow-[0_0_12px_rgba(244,63,94,0.65)]'
      : hudTheme === 'sovereign'
      ? 'bg-gradient-to-r from-[#78350f] via-[#d97706] to-[#78350f] shadow-[0_0_12px_rgba(245,158,11,0.65)]'
      : 'bg-gradient-to-r from-[#0066cc] via-[#00bfff] to-[#0066cc] shadow-[0_0_12px_rgba(0,212,255,0.65)]';
  return (
    <div className="w-full grid grid-cols-2 rounded-[4px] border border-white/75 bg-[#03101f] p-0.5 my-2.5">
      {(['status', 'skills'] as const).map((tabId) => {
        const isActive = active === tabId;
        const label = tabId === 'status' ? 'Статус' : 'Навыки';
        return (
          <motion.button
            key={tabId}
            type="button"
            whileHover={reducedMotion ? undefined : { scale: 1.01 }}
            whileTap={reducedMotion ? undefined : { scale: 0.965 }}
            transition={{ duration: 0.15 }}
            onClick={() => {
              playSystemSound('tab_switch', soundEnabled, hapticsEnabled);
              onSelect(tabId);
            }}
            className={`relative min-h-[40px] py-1.5 text-[15px] font-bold rounded-[2px] transition-colors cursor-pointer ${
              isActive ? 'text-white' : 'text-white/80 hover:text-white'
            }`}
          >
            {isActive && (
              <motion.span
                layoutId="player-subtab-glow"
                transition={{ duration: reducedMotion ? 0 : 0.22, ease: [0.16, 1, 0.3, 1] }}
                className={`absolute inset-0 rounded-[2px] border border-white/80 ${tabGlowClass}`}
              />
            )}
            <span className="relative z-10">{label}</span>
          </motion.button>
        );
      })}
    </div>
  );
};
