import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { playSystemSound, unlockSystemAudio } from '../shared/sound';
import { ManaParticleEmitter } from './ManaParticleEmitter';

interface SystemInitializationProps {
  soundEnabled?: boolean;
  hapticsEnabled?: boolean;
  reducedMotion?: boolean;
  onComplete: () => void;
}

const MANIFEST_LINES = [
  { text: 'КАРДИОМОНИТОРИНГ: КРИТИЧЕСКИЙ ПОРОГ', alert: true },
  { text: 'ДО ОСТАНОВКИ СЕРДЦА: 00:00:02', alert: true },
  { text: 'ПОИСК ПОДХОДЯЩЕГО НОСИТЕЛЯ... [ НАЙДЕН ]', alert: false },
  { text: 'ВСЕ УСЛОВИЯ СЕКРЕТНОГО ЗАДАНИЯ ВЫПОЛНЕНЫ.', alert: false },
  { text: 'ВЫ ПОЛУЧИЛИ ПРАВО СТАТЬ ИГРОКОМ.', alert: false },
];

export const SystemInitialization: React.FC<SystemInitializationProps> = ({
  soundEnabled = true,
  hapticsEnabled = true,
  reducedMotion = false,
  onComplete,
}) => {
  const [lineIdx, setLineIdx] = useState(0);
  const [vitalMs, setVitalMs] = useState(200);
  const [subPhase, setSubPhase] = useState<'scanning' | 'flashing'>('scanning');

  useEffect(() => {
    if (reducedMotion) {
      const t = setTimeout(onComplete, 450);
      return () => clearTimeout(t);
    }

    playSystemSound('init_scan', soundEnabled, hapticsEnabled);

    const countdownInterval = setInterval(() => {
      setVitalMs((prev) => Math.max(2, prev - 7));
    }, 95);

    const t1 = setTimeout(() => {
      setLineIdx(1);
      playSystemSound('penalty_alert', soundEnabled, hapticsEnabled);
    }, 520);
    const t2 = setTimeout(() => {
      setLineIdx(2);
      playSystemSound('init_scan', soundEnabled, hapticsEnabled);
    }, 1150);
    const t3 = setTimeout(() => {
      setLineIdx(3);
      playSystemSound('type_tick', soundEnabled, false);
    }, 1820);
    const t4 = setTimeout(() => {
      setLineIdx(4);
      playSystemSound('system_notice', soundEnabled, hapticsEnabled);
    }, 2460);
    const tFlash = setTimeout(() => {
      setSubPhase('flashing');
    }, 3220);
    const tDone = setTimeout(() => {
      onComplete();
    }, 3600);

    return () => {
      clearInterval(countdownInterval);
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
      clearTimeout(tFlash);
      clearTimeout(tDone);
    };
  }, [reducedMotion, soundEnabled, hapticsEnabled, onComplete]);

  const handleSkip = () => {
    unlockSystemAudio();
    onComplete();
  };

  const isCriticalPhase = lineIdx <= 1;

  return (
    <div
      onClick={handleSkip}
      className="fixed inset-0 z-50 bg-[#010308] flex items-center justify-center p-4 cursor-pointer select-none overflow-hidden"
    >
      <motion.div
        animate={
          reducedMotion
            ? {}
            : isCriticalPhase
              ? { x: [0, -2, 2, -1, 0] }
              : { x: 0 }
        }
        transition={{ duration: 0.45, repeat: isCriticalPhase ? Infinity : 0 }}
        className={`relative w-full max-w-[430px] h-[100dvh] sm:h-[844px] sm:max-h-[94dvh] border ${
          isCriticalPhase
            ? 'border-[#ff4d4d]/75 system-glass-red shadow-[0_0_54px_rgba(255,30,39,0.45)]'
            : 'border-[#00e5ff]/75 system-glass-blue shadow-[0_0_54px_rgba(0,229,255,0.42)]'
        } flex flex-col justify-between p-6 overflow-hidden transition-colors duration-300`}
      >
        <ManaParticleEmitter
          palette={isCriticalPhase ? 'red' : 'blue'}
          reducedMotion={reducedMotion}
          burstKey={lineIdx}
          density={32}
        />
        <div
          className={`pointer-events-none absolute inset-0 ${
            isCriticalPhase ? 'system-scanlines-red' : 'system-scanlines'
          }`}
        />
        {isCriticalPhase && (
          <div className="pointer-events-none absolute inset-0 system-bloodlust-vignette" />
        )}

        {/* Vertical Sweeping Laser Scan */}
        {!reducedMotion && (
          <motion.div
            initial={{ y: -40 }}
            animate={{ y: 860 }}
            transition={{ duration: 1.35, repeat: Infinity, ease: 'linear' }}
            className={`pointer-events-none absolute inset-x-0 h-16 z-10 ${
              isCriticalPhase
                ? 'bg-gradient-to-b from-transparent via-[#ff3b3b]/25 to-[#ff8080]/80 shadow-[0_2px_20px_#ff1e27]'
                : 'bg-gradient-to-b from-transparent via-[#00e5ff]/20 to-[#72f8ff]/75 shadow-[0_2px_18px_#00e5ff]'
            }`}
          />
        )}

        {/* Top Terminal Biometric Bar */}
        <div
          className={`relative z-20 flex items-center justify-between border-b pb-2.5 text-[11px] font-mono tracking-[0.14em] ${
            isCriticalPhase
              ? 'border-[#ff4d4d]/60 text-[#ff9999]'
              : 'border-[#00e5ff]/55 text-[#72f8ff]'
          }`}
        >
          <span>{isCriticalPhase ? 'ТРЕВОГА // ПУЛЬС: КРИТИЧ.' : 'СИСТЕМА // КВАЛИФИКАЦИЯ'}</span>
          <span className="font-bold font-tabular animate-pulse">
            {isCriticalPhase
              ? `00:${String(Math.floor(vitalMs / 100)).padStart(2, '0')}.${String(vitalMs % 100).padStart(2, '0')} СЕК`
              : '● СИНХР. 100%'}
          </span>
        </div>

        {/* Center Flickering Anime Manifest */}
        <motion.div
          animate={
            reducedMotion
              ? {}
              : {
                  opacity: [0.9, 1, 0.78, 1, 0.94],
                }
          }
          transition={{ duration: 1.4, repeat: Infinity }}
          className="relative z-20 space-y-4 my-auto px-2"
        >
          <div
            className={`text-[11px] font-mono uppercase tracking-[0.2em] ${
              isCriticalPhase ? 'text-[#ff7a7a]' : 'text-[#38f8ff]/85'
            }`}
          >
            {isCriticalPhase
              ? 'ОБНАРУЖЕН СМЕРТЕЛЬНЫЙ ПОРОГ'
              : 'ПРОТОКОЛ ПРОБУЖДЕНИЯ // ИГРОК'}
          </div>

          <div className="space-y-3 font-mono">
            {MANIFEST_LINES.slice(0, lineIdx + 1).map((item, idx) => {
              const isFinal = idx === MANIFEST_LINES.length - 1;
              return (
                <motion.div
                  key={item.text}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.2 }}
                  className={`leading-snug ${
                    isFinal
                      ? 'text-[18px] font-extrabold text-white system-text-glow-blue pt-2.5 border-t border-[#00e5ff]/60'
                      : item.alert && isCriticalPhase
                        ? 'text-[13.5px] font-bold text-[#ffb8b8] system-text-glow-red'
                        : 'text-[13.5px] text-[#bfefff]'
                  }`}
                >
                  <span className={item.alert && isCriticalPhase ? 'text-[#ff4d4d] mr-2' : 'text-[#00e5ff] mr-2'}>
                    &gt;
                  </span>
                  {item.text}
                  {idx === lineIdx && (
                    <span
                      className={`inline-block w-2 h-4 ml-1.5 align-middle animate-pulse ${
                        isCriticalPhase ? 'bg-[#ff4d4d]' : 'bg-[#38f8ff]'
                      }`}
                    />
                  )}
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Bottom Hint */}
        <div
          className={`relative z-20 flex items-center justify-between border-t pt-2.5 text-[11px] font-mono ${
            isCriticalPhase
              ? 'border-[#ff4d4d]/40 text-[#ffb3b3]/80'
              : 'border-[#00e5ff]/35 text-white/65'
          }`}
        >
          <span>{isCriticalPhase ? 'ОЖИДАНИЕ ОТКЛИКА НОСИТЕЛЯ...' : 'ПРОЕКЦИЯ ГОТОВА'}</span>
          <span className="underline underline-offset-4 text-[#72f8ff]">Нажмите, чтобы пропустить</span>
        </div>

        {/* Explosive Laser Slice Transition into State 01 */}
        {subPhase === 'flashing' && !reducedMotion && (
          <motion.div
            initial={{ opacity: 0, scaleY: 0.02 }}
            animate={{ opacity: [0, 1, 1], scaleY: [0.02, 0.14, 1.8] }}
            transition={{ duration: 0.36, ease: 'easeIn' }}
            className="pointer-events-none absolute inset-0 bg-[#aefaff] z-40"
          />
        )}
      </motion.div>
    </div>
  );
};
