import { useCallback } from 'react';

export type SystemSoundCue =
  | 'system_notice'
  | 'refusal_rejected'
  | 'penalty_alert'
  | 'system_activated'
  | 'type_tick'
  | 'ui_step'
  | 'tab_switch'
  | 'scroll_tick'
  | 'level_up'
  | 'goal_completed'
  | 'quest_complete'
  | 'stat_tick'
  | 'init_scan';

export type SystemHapticInteraction =
  | 'list_nav'
  | 'scroll_tick'
  | 'tab_switch'
  | 'system_notice'
  | 'stat_tick'
  | 'quest_complete'
  | 'goal_completed'
  | 'level_up'
  | 'refusal_rejected'
  | 'penalty_alert'
  | 'ui_step'
  | 'init_scan';

interface TgHapticFeedback {
  impactOccurred?: (style: 'light' | 'medium' | 'heavy' | 'rigid' | 'soft') => void;
  notificationOccurred?: (type: 'error' | 'success' | 'warning') => void;
  selectionChanged?: () => void;
}

function getTelegramHaptic(): TgHapticFeedback | null {
  if (typeof window === 'undefined') return null;
  return (
    (window as unknown as {
      Telegram?: { WebApp?: { HapticFeedback?: TgHapticFeedback } };
    }).Telegram?.WebApp?.HapticFeedback || null
  );
}

/**
 * Audio playback has been intentionally removed per user direction.
 * Retained as a no-op stub so existing lifecycle hooks remain safe.
 */
export function unlockSystemAudio() {
  // No-op: all synthesized sounds removed
}

export function triggerHaptic(
  kind: 'light' | 'medium' | 'heavy' | 'error' | 'success' | 'selection' = 'light',
  enabled = true
) {
  if (!enabled || typeof window === 'undefined') return;
  try {
    const tg = getTelegramHaptic();
    if (tg) {
      if (kind === 'selection') {
        tg.selectionChanged?.();
      } else if (kind === 'error' || kind === 'success') {
        tg.notificationOccurred?.(kind);
      } else {
        tg.impactOccurred?.(kind);
      }
      return;
    }

    if ('vibrate' in navigator) {
      if (kind === 'error') navigator.vibrate([45, 35, 70]);
      else if (kind === 'success') navigator.vibrate([18, 28, 38]);
      else if (kind === 'heavy') navigator.vibrate(32);
      else if (kind === 'medium') navigator.vibrate(16);
      else if (kind === 'selection') navigator.vibrate(5);
      else navigator.vibrate(8);
    }
  } catch {
    // Ignore haptic errors
  }
}

export function triggerSystemHaptic(interaction: SystemHapticInteraction, enabled = true) {
  if (!enabled || typeof window === 'undefined') return;

  switch (interaction) {
    case 'list_nav':
    case 'scroll_tick':
      triggerHaptic('selection', true);
      break;
    case 'tab_switch':
    case 'ui_step':
    case 'init_scan':
      triggerHaptic('light', true);
      break;
    case 'stat_tick':
      triggerHaptic('medium', true);
      break;
    case 'system_notice':
      triggerHaptic('selection', true);
      setTimeout(() => triggerHaptic('medium', true), 38);
      break;
    case 'goal_completed':
    case 'quest_complete':
      triggerHaptic('light', true);
      setTimeout(() => triggerHaptic('heavy', true), 85);
      setTimeout(() => triggerHaptic('success', true), 160);
      break;
    case 'level_up':
      triggerHaptic('medium', true);
      setTimeout(() => triggerHaptic('light', true), 90);
      setTimeout(() => triggerHaptic('light', true), 175);
      setTimeout(() => triggerHaptic('heavy', true), 265);
      setTimeout(() => triggerHaptic('success', true), 340);
      break;
    case 'refusal_rejected':
    case 'penalty_alert':
      triggerHaptic('heavy', true);
      setTimeout(() => triggerHaptic('error', true), 110);
      break;
    default:
      triggerHaptic('light', true);
  }
}

export function useSystemHaptics(enabled = true) {
  return useCallback(
    (interaction: SystemHapticInteraction) => {
      triggerSystemHaptic(interaction, enabled);
    },
    [enabled]
  );
}

/**
 * Sound synthesis removed completely; triggers only optional physical haptics.
 */
export function playSystemSound(
  cue: SystemSoundCue,
  _soundEnabled = true,
  hapticsEnabled = true
) {
  if (cue !== 'type_tick' && cue !== 'scroll_tick') {
    if (cue === 'system_activated') {
      triggerSystemHaptic('goal_completed', hapticsEnabled);
    } else {
      triggerSystemHaptic(cue as SystemHapticInteraction, hapticsEnabled);
    }
  }
}
