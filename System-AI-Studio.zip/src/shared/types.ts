export type SystemPalette = 'blue' | 'red';

export type MainTabId = 'today' | 'goals' | 'habits' | 'finance' | 'player';
export type PlayerSubTabId = 'status' | 'skills';

export type BootstrapState =
  | 'new_invitation'
  | 'refusal_rejected'
  | 'accepted'
  | 'onboarding_profile'
  | 'onboarding_goal_type'
  | 'onboarding_goal_setup'
  | 'first_task'
  | 'returning_welcome'
  | 'penalty_alert'
  | 'ready';

export type LifeRoleId =
  | 'studying'
  | 'employed'
  | 'freelance'
  | 'business'
  | 'family'
  | 'custom';

export type GoalType = 'scheduled_action' | 'deadline_project' | 'savings';

export interface GoalMilestone {
  id: string;
  goalId: string;
  title: string;
  order: number;
  completed: boolean;
  locked: boolean;
  mandatory: boolean;
  deadlineDate?: string;
}

export interface Goal {
  id: string;
  type: GoalType;
  title: string;
  currentValue: number;
  targetValue: number;
  unit: string; // 'занятий' | 'этапов' | '₽'
  status: 'active' | 'completed' | 'archived';
  mandatoryDeadline?: boolean;
  deadlineText?: string;
  durationMinutes?: number;
  daysPerWeek?: number;
  preferredTime?: string;
  milestones?: GoalMilestone[];
  rewardXpGranted?: boolean;
}

export interface TaskItem {
  id: string;
  title: string;
  description?: string;
  goalId?: string;
  habitId?: string;
  durationMinutes?: number;
  xpReward: number;
  skillBonusXp?: number;
  skillBonusName?: string;
  completed: boolean;
  completedAt?: string;
  dueDateText: string;
  priority: 'normal' | 'high';
  mandatory?: boolean;
  recurrence?: 'none' | 'daily' | 'weekdays' | 'weekly';
}

export interface HabitOccurrenceHistory {
  dateLabel: string; // 'Сегодня', 'Вчера', 'Позавчера'
  isoDate: string;
  status: 'completed' | 'partial' | 'missed' | 'unscheduled' | 'pending';
  valueMinutes?: number;
  targetMinutes?: number;
  triggeredPenaltyId?: string;
}

export interface HabitItem {
  id: string;
  title: string;
  durationMinutes: number;
  currentMinutesToday: number;
  completedToday: boolean;
  daysOfWeek: string[]; // ['ПН','ВТ','СР','ЧТ','ПТ','СБ','ВС']
  deadlineTime: string; // '23:00'
  mandatory: boolean;
  status: 'active' | 'archived';
  createdAtIso?: string;
  history: HabitOccurrenceHistory[];
}

export interface ShadowSoldier {
  id: string;
  name: string;
  rank: string;
  bonusText: string;
  extractedAt: string;
}

export interface AccountItem {
  id: string;
  name: string;
  type: 'card' | 'cash' | 'savings';
  balanceRub: number; // integer rubles
  status: 'active' | 'archived';
}

export interface FinancialEntry {
  id: string;
  type: 'expense' | 'income' | 'transfer';
  title: string;
  category: string;
  amountRub: number;
  accountId: string;
  toAccountId?: string;
  dateLabel: string;
  createdAt: string;
  idempotencyKey?: string;
}

export interface ParsedFinanceDraftItem {
  id: string;
  rawFragment: string;
  type: 'expense' | 'income';
  title: string;
  category: string;
  categoryUncertain: boolean;
  amountRub: number | null;
  accountId: string;
  accountName: string;
  dateLabel: string;
}

export type StatKey = 'strength' | 'endurance' | 'agility' | 'intelligence' | 'perception';

export interface PlayerStats {
  strength: number;
  endurance: number;
  agility: number;
  intelligence: number;
  perception: number;
}

export type SkillBranchId = 'impulse' | 'rhythm' | 'focus' | 'planning' | 'control';

export interface SkillRequirement {
  id: string;
  label: string;
  current: number;
  target: number;
  met: boolean;
}

export interface SkillBranchState {
  id: SkillBranchId;
  name: string;
  sourceStat: StatKey;
  sourceStatName: string;
  level: number;
  maxLevel: number;
  currentEffectText: string;
  limitText: string;
  whyUsefulText: string;
  nextLevelText: string;
  actionButtonLabel: string;
  requirementsForNext: SkillRequirement[];
}

export interface PenaltyQuestion {
  id: string;
  stage: 1 | 2;
  competencyId: string;
  questionIndex: number;
  totalQuestions: number;
  prompt: string;
  options: string[];
}

export interface PenaltyQuestState {
  id: string;
  active: boolean;
  reasonTitle: string; // 'Чтение · 15 минут'
  status:
    | 'assigned'
    | 'terms_viewed'
    | 'in_progress'
    | 'paused'
    | 'night_pause'
    | 'overdue'
    | 'completed'
    | 'completed_late'
    | 'cancelled_error';
  presentedAt: string | null;
  budgetTotalSeconds: number; // 43200 (12 hours)
  remainingBudgetSeconds: number;
  nightWindowStart: string; // '23:00'
  nightWindowEnd: string; // '08:00'
  currentStage: 1 | 2;
  stage1ConfirmedSeconds: number; // target 150
  stage2ConfirmedSeconds: number; // target 150
  questionsPassed: number; // target 5
  totalQuestionsRequired: number; // 5
  selectedAnswerIndex: number | null;
  lastAnswerError: string | null;
  nextStepAction: string;
  nextStepWhen: string;
  nextStepSaved: boolean;
  sessionVersion: number;
  sessionConflictDetected: boolean;
  offlineDetected: boolean;
  lastHeartbeatToken: string;
  selectedChallenge?: 'body' | 'focus' | 'revenge' | null;
  challengeDone?: boolean;
  reflectionReason?: string;
}

export type SubscriptionPlanId = '1m' | '3m' | '12m';

export interface SubscriptionState {
  tier: 'free' | 'paid' | 'bonus';
  active: boolean;
  planId?: SubscriptionPlanId;
  planLabel?: string;
  priceStars: number; // 99
  periodDays: number; // 30
  autoRenew: boolean;
  expiresAtLabel: string;
  paymentCheckStatus: 'idle' | 'checking' | 'failed' | 'completed' | 'expired_free';
  referralBonusDaysAvailable: number; // e.g., 3
  referralBonusActiveRemaining: string; // '2 дня 23 часа'
  referralScheduledAfterPaid: boolean;
  referralLastInviteStatus: 'none' | 'credited' | 'duplicate_rejected';
  referralCode: string;
  botUsername?: string;
}

export interface UserAppState {
  userId: string;
  telegramId: string;
  bootstrapState: BootstrapState;
  playerCallsign?: string;
  roles: LifeRoleId[];
  customRoleText: string;
  onboardingSelectedGoalType: GoalType;
  level: number;
  currentXp: number;
  nextLevelXp: number;
  unspentStatPoints: number;
  stats: PlayerStats;
  pendingStatAdditions: Record<StatKey, number>;
  skills: Record<SkillBranchId, SkillBranchState>;
  selectedSkillId: SkillBranchId;
  goals: Goal[];
  tasks: TaskItem[];
  habits: HabitItem[];
  accounts: AccountItem[];
  financialEntries: FinancialEntry[];
  monthIncomeRub: number;
  monthExpenseRub: number;
  allocatedToGoalsRub: number;
  prevMonthExpensesByCategory?: Record<string, number>;
  nightPeriodStart: string;
  nightPeriodEnd: string;
  timezone: string;
  soundEnabled: boolean;
  hapticsEnabled: boolean;
  reducedMotion: boolean;
  hudTheme?: 'blue' | 'monarch' | 'igris' | 'sovereign';
  shieldChargesRemaining?: number;
  lastDailyClaimDate?: string;
  lastPenaltyCheckDate?: string;
  lastActiveDate?: string;
  streakDays?: number;
  bestStreakDays?: number;
  createdAtIso?: string;
  monthStatsKey?: string;
  botNotificationsEnabled?: boolean;
  smartStepsUsedCount?: number;
  trophies?: string[];
  shadows?: ShadowSoldier[];
  lastChestBonusText?: string;
  penaltyQuest: PenaltyQuestState;
  penaltyHistory: Array<{
    id: string;
    dateLabel: string;
    title: string;
    outcome: 'completed' | 'completed_late' | 'cancelled_error';
  }>;
  subscription: SubscriptionState;
  focusSession: {
    active: boolean;
    paused: boolean;
    taskId: string;
    title: string;
    totalSeconds: number;
    remainingSeconds: number;
    startedAtMs?: number;
  };
  lastCompletedTaskBreakdown: {
    taskId: string;
    title: string;
    baseXp: number;
    bonusXp: number;
    bonusName: string;
    totalXp: number;
    goalTitle?: string;
    goalProgressText: string;
    goalProgressPercent: number;
  } | null;
  lastCompletedGoalTitle?: string;
  lastCompletedGoalProgress?: string;
  lastLevelUpXpGain?: number;
  lastUpgradedSkillId?: SkillBranchId;
}

export interface StateSpecItem {
  id: number; // 1..72
  code: string; // '01'..'72'
  sheetNumber: number; // 1..24
  sheetCode: string; // '01'..'24'
  sheetTitle: string;
  columnIndex: 0 | 1 | 2; // Left, Center, Right on sheet
  columnTitle: string;
  palette: SystemPalette;
  tab: MainTabId | null;
  playerSubTab?: PlayerSubTabId;
  imageAsset: string;
  description: string;
  audioCueId: string;
  motionSceneId: string;
}
