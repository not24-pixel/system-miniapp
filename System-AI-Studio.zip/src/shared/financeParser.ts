import { AccountItem, ParsedFinanceDraftItem } from './types';

interface CategoryRule {
  category: string;
  type: 'expense' | 'income';
  keywords: string[];
}

const CATEGORY_RULES: CategoryRule[] = [
  {
    category: 'Зарплата',
    type: 'income',
    keywords: ['зарплат', 'зп', 'аванс', 'премия', 'salary', 'оклад', 'отпускн'],
  },
  {
    category: 'Фриланс',
    type: 'income',
    keywords: ['фриланс', 'заказ', 'гонорар', 'проект', 'выплата', 'доход', 'приход', 'поступлен', 'freelance', 'кэшбэк', 'кешбэк', 'возврат', 'дивиденд'],
  },
  {
    category: 'Еда',
    type: 'expense',
    keywords: [
      'кофе', 'coffee', 'латте', 'капучино', 'американо', 'раф', 'чай', 'кафе', 'cafe',
      'обед', 'ужин', 'завтрак', 'ресторан', 'бургер', 'пицц', 'суши', 'роллы', 'шаурм',
      'доставка еды', 'перекус', 'столов', 'пекарн', 'булоч', 'starbucks', 'додо', 'kfc', 'вкусно',
      'lunch', 'dinner', 'breakfast', 'snack',
    ],
  },
  {
    category: 'Продукты',
    type: 'expense',
    keywords: [
      'продукт', 'магазин', 'супермаркет', 'молоко', 'хлеб', 'сыр', 'мясо', 'овощ', 'фрукт',
      'пятёрочк', 'пятерочк', 'магнит', 'перекрёст', 'перекрест', 'вкусвилл', 'ашан', 'лента',
      'дикси', 'окей', 'светофор', 'самокат', 'лавка', 'grocery', 'market', 'вода', 'яйца',
    ],
  },
  {
    category: 'Транспорт',
    type: 'expense',
    keywords: [
      'такси', 'taxi', 'uber', 'убер', 'ситимобил', 'метро', 'автобус', 'троллейбус', 'трамвай',
      'электрич', 'поезд', 'самолёт', 'самолет', 'авиа', 'билет', 'бензин', 'заправк', 'азс',
      'парковк', 'каршеринг', 'драйв', 'проезд', 'тройка', 'подорожник', 'газпром', 'лукойл',
    ],
  },
  {
    category: 'Подписки',
    type: 'expense',
    keywords: [
      'подписк', 'spotify', 'спотифай', 'netflix', 'нетфликс', 'youtube', 'ютуб', 'telegram',
      'премиум', 'icloud', 'яндекс плюс', 'плюс', 'кинопоиск', 'okko', 'ivi', 'vpn', 'впн',
      'chatgpt', 'gpt', 'openai', 'steam', 'стим', 'playstation', 'xbox', 'music', 'музык', 'система+',
    ],
  },
  {
    category: 'Жильё и связь',
    type: 'expense',
    keywords: [
      'интернет', 'связь', 'телефон', 'тариф', 'мтс', 'билайн', 'мегафон', 'теле2', 'yota',
      'аренда', 'квартира', 'жкх', 'коммуналк', 'электрич', 'отоплен', 'квартплат', 'дом', 'ремонт', 'rent',
    ],
  },
  {
    category: 'Здоровье',
    type: 'expense',
    keywords: [
      'аптек', 'лекарств', 'таблетк', 'врач', 'клиник', 'стоматолог', 'анализ', 'здоров',
      'спортзал', 'зал', 'фитнес', 'абонемент', 'тренировк', 'gym', 'fitness', 'бассейн', 'витамин',
    ],
  },
  {
    category: 'Покупки',
    type: 'expense',
    keywords: [
      'ozon', 'озон', 'wb', 'вб', 'wildberries', 'вайлдберриз', 'маркет', 'алиэкспресс', 'aliexpress',
      'одежд', 'обувь', 'кроссовк', 'куртк', 'джинс', 'футболк', 'техник', 'гаджет', 'чехол',
      'наушник', 'косметик', 'подарок', 'подарк', 'цветы', 'shopping',
    ],
  },
  {
    category: 'Досуг',
    type: 'expense',
    keywords: [
      'кино', 'cinema', 'театр', 'концерт', 'музей', 'выставк', 'книг', 'бар', 'паб', 'клуб',
      'боулинг', 'кальян', 'бильярд', 'развлеч', 'отдых', 'игр', 'game',
    ],
  },
];

const NOISE_WORDS_REGEX =
  /\b(купил[аи]?|потратил[аи]?|оплатил[аи]?|заплатил[аи]?|взял[аи]?|списал[аи]?|получил[аи]?|приш[её]л[аои]?|за|на|в|по|с|от|из|рублей|рубля|руб|р\.?|₽|rub)\b/gi;

function extractDateLabel(text: string): { dateLabel: string; cleaned: string } {
  const lower = text.toLowerCase();
  if (lower.includes('позавчера')) {
    return { dateLabel: 'Позавчера', cleaned: text.replace(/позавчера/gi, ' ') };
  }
  if (lower.includes('вчера')) {
    return { dateLabel: 'Вчера', cleaned: text.replace(/вчера/gi, ' ') };
  }
  if (lower.includes('сегодня')) {
    return { dateLabel: 'Сегодня', cleaned: text.replace(/сегодня/gi, ' ') };
  }
  return { dateLabel: 'Сегодня', cleaned: text };
}

function detectAccount(
  text: string,
  accounts: AccountItem[] | undefined,
  defaultAccountId: string,
  defaultAccountName: string
): { accountId: string; accountName: string; cleaned: string } {
  const lower = text.toLowerCase();
  const list = accounts && accounts.length > 0 ? accounts : [];
  const defaultAcc = list.find((a) => a.id === defaultAccountId) || list[0];
  let accountId = defaultAcc ? defaultAcc.id : defaultAccountId;
  let accountName = defaultAcc ? defaultAcc.name : defaultAccountName;
  let cleaned = text;

  // Match explicitly by any user account name first
  for (const acc of list) {
    const accLower = acc.name.toLowerCase();
    if (accLower.length >= 3 && lower.includes(accLower)) {
      accountId = acc.id;
      accountName = acc.name;
      const escaped = acc.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      cleaned = cleaned.replace(new RegExp(escaped, 'gi'), ' ');
      return { accountId, accountName, cleaned };
    }
  }

  const cashAcc = list.find((a) => a.type === 'cash' || a.id === 'acc_cash');
  const savingsAcc = list.find((a) => a.type === 'savings' || a.id === 'acc_savings');
  const cardAcc = list.find((a) => a.type === 'card' || a.id === 'acc_card');

  if (/\b(наличн\w*|нал|кэш|cash)\b/i.test(lower)) {
    if (cashAcc) {
      accountId = cashAcc.id;
      accountName = cashAcc.name;
    }
    cleaned = cleaned.replace(/\b(наличными|наличные|нал|кэш|cash)\b/gi, ' ');
  } else if (/\b(накопительн\w*|копилк\w*|вклад\w*|сейф\w*)\b/i.test(lower)) {
    if (savingsAcc) {
      accountId = savingsAcc.id;
      accountName = savingsAcc.name;
    }
    cleaned = cleaned.replace(/\b(накопительный|накопительном|накопит\w*|копилка|вклад)\b/gi, ' ');
  } else if (/\b(карт\w*|сбер\w*|тиньк\w*|т-?банк\w*|альфа\w*|card)\b/i.test(lower)) {
    if (cardAcc) {
      accountId = cardAcc.id;
      accountName = cardAcc.name;
    }
    cleaned = cleaned.replace(/\b(с карты|на карту|картой|карта|сбер\w*|тиньк\w*|card)\b/gi, ' ');
  }

  return { accountId, accountName, cleaned };
}

function splitSegments(rawInput: string): string[] {
  // Replace separators: newline, semicolon, " + " (item separator, not "+500"), " и " between items with numbers
  const preSplit = rawInput
    .replace(/[\r\n;]+/g, '\n')
    .replace(/\s+\+\s+(?=[а-яёa-z+])/gi, '\n')
    .replace(/\s+и\s+(?=[а-яёa-z+\d])/gi, '\n');

  const lines = preSplit.split('\n');
  const result: string[] = [];
  for (const line of lines) {
    // Split by comma ONLY when it's NOT a decimal comma like "200,50"
    const parts = line
      .split(/,(?!\s*\d{1,2}(?:\D|$))/g)
      .map((s) => s.trim())
      .filter(Boolean);
    result.push(...parts);
  }
  return result;
}

/**
 * Natural language finance entry parser (RU + EN).
 * Supports multi-entry batches ("Кофе 200, такси 500, +50к аванс"),
 * English + Russian brands ("Coffee 200", "Taxi 500", "Ozon 1800"),
 * dates ("вчера", "позавчера"), multipliers ("к", "тыс"), and account matching.
 */
export function parseNaturalFinanceInput(
  rawInput: string,
  accounts?: AccountItem[],
  defaultAccountId = 'acc_card',
  defaultAccountName = 'Карта'
): ParsedFinanceDraftItem[] {
  const trimmed = rawInput.trim();
  if (!trimmed) return [];

  const segments = splitSegments(trimmed);

  return segments.map((seg, idx) => {
    const lower = seg.toLowerCase();
    const explicitIncome = /^\s*\+/.test(seg);
    const explicitExpense = /^\s*-/.test(seg);

    const dateRes = extractDateLabel(seg);
    const accRes = detectAccount(dateRes.cleaned, accounts, defaultAccountId, defaultAccountName);
    let working = accRes.cleaned;

    // Extract amount (supports "+50 000", "1.5к", "200,50", "500р", "12 тыс")
    const amountRegex = /([+-]?\s*\d[\d\s]*(?:[.,]\d{1,2})?)\s*(к|k|тыс\.?)?(?:\s*(?:₽|руб\.?|р\.?))?/i;
    const match = working.match(amountRegex);
    let amountRub: number | null = null;

    if (match) {
      const signPart = match[1].trim();
      const rawNum = signPart.replace(/^[+-]\s*/, '').replace(/\s+/g, '').replace(',', '.');
      const parsed = parseFloat(rawNum);
      if (!Number.isNaN(parsed) && parsed > 0) {
        const mult = match[2] ? 1000 : 1;
        amountRub = Math.round(parsed * mult);
      }
      working = working.replace(match[0], ' ');
    }

    working = working
      .replace(NOISE_WORDS_REGEX, ' ')
      .replace(/^[+\-.,:;!?]+|[+\-.,:;!?]+$/g, ' ')
      .replace(/\s{2,}/g, ' ')
      .trim();

    let matchedCategory = 'Прочее';
    let categoryUncertain = true;
    let entryType: 'expense' | 'income' = explicitIncome ? 'income' : 'expense';

    for (const rule of CATEGORY_RULES) {
      if (rule.keywords.some((k) => lower.includes(k))) {
        matchedCategory = rule.category;
        entryType = explicitExpense ? 'expense' : explicitIncome ? 'income' : rule.type;
        categoryUncertain = false;
        break;
      }
    }

    if (explicitIncome && categoryUncertain) {
      matchedCategory = 'Фриланс';
      entryType = 'income';
      categoryUncertain = false;
    }

    const title = working
      ? working.charAt(0).toUpperCase() + working.slice(1)
      : matchedCategory !== 'Прочее'
      ? matchedCategory
      : entryType === 'income'
      ? 'Поступление'
      : 'Расход';

    return {
      id: `draft_${idx}_${Date.now()}`,
      rawFragment: seg,
      type: entryType,
      title,
      category: matchedCategory,
      categoryUncertain,
      amountRub,
      accountId: accRes.accountId,
      accountName: accRes.accountName,
      dateLabel: dateRes.dateLabel,
    };
  });
}
