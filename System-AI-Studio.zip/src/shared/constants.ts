import { AccountItem, StateSpecItem, ParsedFinanceDraftItem, SubscriptionPlanId } from './types';
import { parseNaturalFinanceInput } from './financeParser';

export const SUBSCRIPTION_PLANS: Array<{
  id: SubscriptionPlanId;
  title: string;
  days: number;
  stars: number;
  badge?: string;
}> = [
  { id: '1m', title: '1 месяц', days: 30, stars: 99 },
  { id: '3m', title: '3 месяца', days: 90, stars: 249, badge: '−16%' },
  { id: '12m', title: '12 месяцев', days: 365, stars: 799, badge: '−33%' },
];

export const SHEET_ASSETS: Record<number, string> = {};

export const STATES_CATALOG: StateSpecItem[] = [
  // Sheet 01: ПЕРВЫЙ ВХОД
  { id: 1, code: '01', sheetNumber: 1, sheetCode: '01', sheetTitle: 'ПЕРВЫЙ ВХОД', columnIndex: 0, columnTitle: 'ПРИГЛАШЕНИЕ', palette: 'blue', tab: null, imageAsset: SHEET_ASSETS[1], description: 'Принять → сохранение принятия; отказаться → красная ветка', audioCueId: 'system_notice', motionSceneId: 'intro_invitation' },
  { id: 2, code: '02', sheetNumber: 1, sheetCode: '01', sheetTitle: 'ПЕРВЫЙ ВХОД', columnIndex: 1, columnTitle: 'ОТКАЗ НЕ ПРИНЯТ', palette: 'red', tab: null, imageAsset: SHEET_ASSETS[1], description: 'Единственная сюжетная кнопка принять; нативное закрытие работает', audioCueId: 'refusal_rejected', motionSceneId: 'refusal_red_shift' },
  { id: 3, code: '03', sheetNumber: 1, sheetCode: '01', sheetTitle: 'ПЕРВЫЙ ВХОД', columnIndex: 2, columnTitle: 'ПРИНЯТИЕ', palette: 'blue', tab: null, imageAsset: SHEET_ASSETS[1], description: 'Добро пожаловать, Игрок. Система активирована. Продолжить → профиль', audioCueId: 'system_activated', motionSceneId: 'acceptance_blue_restore' },

  // Sheet 02: ПРОФИЛЬ И НАСТРОЙКА
  { id: 4, code: '04', sheetNumber: 2, sheetCode: '02', sheetTitle: 'ПРОФИЛЬ И НАСТРОЙКА', columnIndex: 0, columnTitle: 'ВАША ЖИЗНЬ', palette: 'blue', tab: null, imageAsset: SHEET_ASSETS[2], description: 'Множественные роли; сохранить выбор без ограничения вкладок', audioCueId: 'ui_step', motionSceneId: 'panel_transition' },
  { id: 5, code: '05', sheetNumber: 2, sheetCode: '02', sheetTitle: 'ПРОФИЛЬ И НАСТРОЙКА', columnIndex: 1, columnTitle: 'ТИП ЦЕЛИ', palette: 'blue', tab: null, imageAsset: SHEET_ASSETS[2], description: 'Выбор действия по расписанию, проекта со сроком или накопления', audioCueId: 'ui_step', motionSceneId: 'panel_transition' },
  { id: 6, code: '06', sheetNumber: 2, sheetCode: '02', sheetTitle: 'ПРОФИЛЬ И НАСТРОЙКА', columnIndex: 2, columnTitle: 'РЕГУЛЯРНОЕ ДЕЙСТВИЕ', palette: 'blue', tab: null, imageAsset: SHEET_ASSETS[2], description: 'Название, длительность, дни и время; создать связанную цель', audioCueId: 'ui_step', motionSceneId: 'panel_transition' },

  // Sheet 03: ВАРИАНТЫ ЦЕЛЕЙ
  { id: 7, code: '07', sheetNumber: 3, sheetCode: '03', sheetTitle: 'ВАРИАНТЫ ЦЕЛЕЙ', columnIndex: 0, columnTitle: 'ПРОЕКТ', palette: 'blue', tab: 'today', imageAsset: SHEET_ASSETS[3], description: 'Срок, первый шаг, обязательность со штрафом; создать проект', audioCueId: 'ui_step', motionSceneId: 'panel_transition' },
  { id: 8, code: '08', sheetNumber: 3, sheetCode: '03', sheetTitle: 'ВАРИАНТЫ ЦЕЛЕЙ', columnIndex: 1, columnTitle: 'НАКОПЛЕНИЕ', palette: 'blue', tab: 'today', imageAsset: SHEET_ASSETS[3], description: 'Сумма и выделение существующих денег внутри остатка на счетах', audioCueId: 'ui_step', motionSceneId: 'panel_transition' },
  { id: 9, code: '09', sheetNumber: 3, sheetCode: '03', sheetTitle: 'ВАРИАНТЫ ЦЕЛЕЙ', columnIndex: 2, columnTitle: 'ПЕРВОЕ ЗАДАНИЕ', palette: 'blue', tab: 'today', imageAsset: SHEET_ASSETS[3], description: 'Игрок · Уровень 1 (0/100 XP), первое действие +30 XP, кнопка НАЧАТЬ', audioCueId: 'system_notice', motionSceneId: 'first_task_reveal' },

  // Sheet 04: ВОЗВРАЩЕНИЕ И ГЛАВНАЯ
  { id: 10, code: '10', sheetNumber: 4, sheetCode: '04', sheetTitle: 'ВОЗВРАЩЕНИЕ И ГЛАВНАЯ', columnIndex: 0, columnTitle: 'С ВОЗВРАЩЕНИЕМ', palette: 'blue', tab: null, imageAsset: SHEET_ASSETS[4], description: 'С возвращением, Игрок. Актуальный уровень 12, 750/1000 XP, очки: 3', audioCueId: 'welcome_back', motionSceneId: 'returning_welcome' },
  { id: 11, code: '11', sheetNumber: 4, sheetCode: '04', sheetTitle: 'ВОЗВРАЩЕНИЕ И ГЛАВНАЯ', columnIndex: 1, columnTitle: 'СЕГОДНЯ · ВЕРХ', palette: 'blue', tab: 'today', imageAsset: SHEET_ASSETS[4], description: 'Уровень 12, следующее действие (Английский 15 мин) и задания дня', audioCueId: 'none', motionSceneId: 'tab_switch' },
  { id: 12, code: '12', sheetNumber: 4, sheetCode: '04', sheetTitle: 'ВОЗВРАЩЕНИЕ И ГЛАВНАЯ', columnIndex: 2, columnTitle: 'СЕГОДНЯ · НИЖЕ', palette: 'blue', tab: 'today', imageAsset: SHEET_ASSETS[4], description: 'Остальные задания, сводка «На счетах 48 600 ₽», кнопки финансов и добавления', audioCueId: 'none', motionSceneId: 'tab_switch' },

  // Sheet 05: ПРИВЫЧКИ
  { id: 13, code: '13', sheetNumber: 5, sheetCode: '05', sheetTitle: 'ПРИВЫЧКИ', columnIndex: 0, columnTitle: 'СПИСОК', palette: 'blue', tab: 'habits', imageAsset: SHEET_ASSETS[5], description: 'Сегодня 2/3 выполнено, частичный прогресс +5 мин, лимит 3/3', audioCueId: 'none', motionSceneId: 'tab_switch' },
  { id: 14, code: '14', sheetNumber: 5, sheetCode: '05', sheetTitle: 'ПРИВЫЧКИ', columnIndex: 1, columnTitle: 'НАСТРОЙКА', palette: 'blue', tab: 'habits', imageAsset: SHEET_ASSETS[5], description: 'Название, длительность, дни недели, время, переключатель Обязательная', audioCueId: 'none', motionSceneId: 'detail_open' },
  { id: 15, code: '15', sheetNumber: 5, sheetCode: '05', sheetTitle: 'ПРИВЫЧКИ', columnIndex: 2, columnTitle: 'ИСТОРИЯ', palette: 'blue', tab: 'habits', imageAsset: SHEET_ASSETS[5], description: 'Сегодня Выполнено, Вчера Пропуск, баннер «Штрафной квест назначен»', audioCueId: 'none', motionSceneId: 'detail_open' },

  // Sheet 06: ЦЕЛИ И ПРОГРЕСС
  { id: 16, code: '16', sheetNumber: 6, sheetCode: '06', sheetTitle: 'ЦЕЛИ И ПРОГРЕСС', columnIndex: 0, columnTitle: 'МОИ ЦЕЛИ', palette: 'blue', tab: 'goals', imageAsset: SHEET_ASSETS[6], description: '3 типа целей: 9/20 (45%), 1/3 этапов, 30 000 / 100 000 ₽ (30%)', audioCueId: 'none', motionSceneId: 'tab_switch' },
  { id: 17, code: '17', sheetNumber: 6, sheetCode: '06', sheetTitle: 'ЦЕЛИ И ПРОГРЕСС', columnIndex: 1, columnTitle: 'ЭТАПЫ ПРОЕКТА', palette: 'blue', tab: 'goals', imageAsset: SHEET_ASSETS[6], description: 'Портфолио 1/3 этапов: выполненный, активный и заблокированный этап', audioCueId: 'none', motionSceneId: 'detail_open' },
  { id: 18, code: '18', sheetNumber: 6, sheetCode: '06', sheetTitle: 'ЦЕЛИ И ПРОГРЕСС', columnIndex: 2, columnTitle: 'ЦЕЛЬ ВЫПОЛНЕНА', palette: 'blue', tab: 'goals', imageAsset: SHEET_ASSETS[6], description: 'Системное уведомление ЦЕЛЬ ВЫПОЛНЕНА, 100%, +500 XP (20/20)', audioCueId: 'goal_completed', motionSceneId: 'system_reward' },

  // Sheet 07: ЗАПИСЬ ТРАТ
  { id: 19, code: '19', sheetNumber: 7, sheetCode: '07', sheetTitle: 'ЗАПИСЬ ТРАТ', columnIndex: 0, columnTitle: 'ФИНАНСЫ', palette: 'blue', tab: 'finance', imageAsset: SHEET_ASSETS[7], description: 'На счетах 48 600 ₽ (Карта 41 100, Наличные 2 500, Накопительный 5 000), итоги месяца', audioCueId: 'none', motionSceneId: 'tab_switch' },
  { id: 20, code: '20', sheetNumber: 7, sheetCode: '07', sheetTitle: 'ЗАПИСЬ ТРАТ', columnIndex: 1, columnTitle: 'УМНАЯ СТРОКА', palette: 'blue', tab: 'finance', imageAsset: SHEET_ASSETS[7], description: 'Быстрый ввод «Кофе 200, продукты 1500» → предпросмотр 2 строк до записи', audioCueId: 'none', motionSceneId: 'detail_open' },
  { id: 21, code: '21', sheetNumber: 7, sheetCode: '07', sheetTitle: 'ЗАПИСЬ ТРАТ', columnIndex: 2, columnTitle: 'ПРОВЕРКА ЗАПИСИ', palette: 'blue', tab: 'finance', imageAsset: SHEET_ASSETS[7], description: 'Новая трата 200 ₽: Категория, Счёт, Дата, Название, подтверждение', audioCueId: 'none', motionSceneId: 'detail_open' },

  // Sheet 08: ДОХОДЫ И СЧЕТА
  { id: 22, code: '22', sheetNumber: 8, sheetCode: '08', sheetTitle: 'ДОХОДЫ И СЧЕТА', columnIndex: 0, columnTitle: 'НОВЫЙ ДОХОД', palette: 'blue', tab: 'finance', imageAsset: SHEET_ASSETS[8], description: 'Сумма 50 000 ₽, Зарплата, Карта, Сегодня, кнопка ЗАПИСАТЬ ДОХОД', audioCueId: 'none', motionSceneId: 'detail_open' },
  { id: 23, code: '23', sheetNumber: 8, sheetCode: '08', sheetTitle: 'ДОХОДЫ И СЧЕТА', columnIndex: 1, columnTitle: 'ПЕРЕВОД', palette: 'blue', tab: 'finance', imageAsset: SHEET_ASSETS[8], description: 'Перевод 1 000 ₽ Карта → Накопительный без изменения общего остатка', audioCueId: 'none', motionSceneId: 'detail_open' },
  { id: 24, code: '24', sheetNumber: 8, sheetCode: '08', sheetTitle: 'ДОХОДЫ И СЧЕТА', columnIndex: 2, columnTitle: 'СЧЕТА', palette: 'blue', tab: 'finance', imageAsset: SHEET_ASSETS[8], description: 'Мои счета 48 600 ₽ (3/3), пометка «Цели 30 000 ₽ уже внутри счетов»', audioCueId: 'none', motionSceneId: 'detail_open' },

  // Sheet 09: ПУСТОТА И ОБРАТНАЯ СВЯЗЬ
  { id: 25, code: '25', sheetNumber: 9, sheetCode: '09', sheetTitle: 'ПУСТОТА И ОБРАТНАЯ СВЯЗЬ', columnIndex: 0, columnTitle: 'ПУСТОЙ ДЕНЬ', palette: 'blue', tab: 'today', imageAsset: SHEET_ASSETS[9], description: 'На сегодня заданий нет. Добавить задание вручную или выбрать из цели', audioCueId: 'none', motionSceneId: 'tab_switch' },
  { id: 26, code: '26', sheetNumber: 9, sheetCode: '09', sheetTitle: 'ПУСТОТА И ОБРАТНАЯ СВЯЗЬ', columnIndex: 1, columnTitle: 'ОШИБКА СОХРАНЕНИЯ', palette: 'blue', tab: 'finance', imageAsset: SHEET_ASSETS[9], description: 'Локальная ошибка «Не удалось сохранить. Черновик сохранён.» Повторить', audioCueId: 'none', motionSceneId: 'error_notice' },
  { id: 27, code: '27', sheetNumber: 9, sheetCode: '09', sheetTitle: 'ПУСТОТА И ОБРАТНАЯ СВЯЗЬ', columnIndex: 2, columnTitle: 'РЕЗУЛЬТАТ И ОТМЕНА', palette: 'blue', tab: 'today', imageAsset: SHEET_ASSETS[9], description: 'Получено 35 XP (Задание 30 · Фокус +5), цель 10/20, кнопка ОТМЕНИТЬ ВЫПОЛНЕНИЕ', audioCueId: 'task_completed', motionSceneId: 'xp_gain' },

  // Sheet 10: ХАРАКТЕРИСТИКИ
  { id: 28, code: '28', sheetNumber: 10, sheetCode: '10', sheetTitle: 'ХАРАКТЕРИСТИКИ', columnIndex: 0, columnTitle: 'СТАТУС', palette: 'blue', tab: 'player', playerSubTab: 'status', imageAsset: SHEET_ASSETS[10], description: 'Уровень 12, 750/1000 XP, Очки прокачки: 3, 5 характеристик (18/17/16/13/16)', audioCueId: 'none', motionSceneId: 'tab_switch' },
  { id: 29, code: '29', sheetNumber: 10, sheetCode: '10', sheetTitle: 'ХАРАКТЕРИСТИКИ', columnIndex: 1, columnTitle: 'ПРЕДПРОСМОТР ОЧКА', palette: 'blue', tab: 'player', playerSubTab: 'status', imageAsset: SHEET_ASSETS[10], description: 'Интеллект 13 → 14 (Выбрано 1 · Осталось 2), предпросмотр порога Фокус · уровень 2', audioCueId: 'none', motionSceneId: 'stat_preview' },
  { id: 30, code: '30', sheetNumber: 10, sheetCode: '10', sheetTitle: 'ХАРАКТЕРИСТИКИ', columnIndex: 2, columnTitle: 'НОВЫЙ УРОВЕНЬ', palette: 'blue', tab: 'player', playerSubTab: 'status', imageAsset: SHEET_ASSETS[10], description: 'УРОВЕНЬ ПОВЫШЕН: 12 → 13, +250 XP, +3 очка прокачки, шкала 0 / 1 200 XP', audioCueId: 'level_up', motionSceneId: 'level_up_scene' },

  // Sheet 11: НАВЫК ФОКУС
  { id: 31, code: '31', sheetNumber: 11, sheetCode: '11', sheetTitle: 'НАВЫК ФОКУС', columnIndex: 0, columnTitle: 'ВЕТКИ РАЗВИТИЯ', palette: 'blue', tab: 'player', playerSubTab: 'skills', imageAsset: SHEET_ASSETS[11], description: '5 веток: Импульс, Ритм, Фокус, Планирование, Контроль', audioCueId: 'none', motionSceneId: 'tab_switch' },
  { id: 32, code: '32', sheetNumber: 11, sheetCode: '11', sheetTitle: 'НАВЫК ФОКУС', columnIndex: 1, columnTitle: 'ФОКУС · ПОЛЬЗА', palette: 'blue', tab: 'player', playerSubTab: 'skills', imageAsset: SHEET_ASSETS[11], description: 'Фокус Уровень 1/3: +5 XP за сессию, до 3 раз в день, следующий уровень +10 XP', audioCueId: 'none', motionSceneId: 'detail_open' },
  { id: 33, code: '33', sheetNumber: 11, sheetCode: '11', sheetTitle: 'НАВЫК ФОКУС', columnIndex: 2, columnTitle: 'ФОКУС · УСЛОВИЯ', palette: 'blue', tab: 'player', playerSubTab: 'skills', imageAsset: SHEET_ASSETS[11], description: 'До уровня 2: Интеллект 14/14 (выполнено), Сессии 9/10 (90%, осталась 1 сессия)', audioCueId: 'none', motionSceneId: 'detail_open' },

  // Sheet 12: ПОЛЕЗНОСТЬ НАВЫКОВ
  { id: 34, code: '34', sheetNumber: 12, sheetCode: '12', sheetTitle: 'ПОЛЕЗНОСТЬ НАВЫКОВ', columnIndex: 0, columnTitle: 'РИТМ', palette: 'blue', tab: 'player', playerSubTab: 'skills', imageAsset: SHEET_ASSETS[12], description: '1 защита игровой серии на 30 дней; пропуск и штрафной квест сохраняются', audioCueId: 'none', motionSceneId: 'detail_open' },
  { id: 35, code: '35', sheetNumber: 12, sheetCode: '12', sheetTitle: 'ПОЛЕЗНОСТЬ НАВЫКОВ', columnIndex: 1, columnTitle: 'ПЛАНИРОВАНИЕ', palette: 'blue', tab: 'player', playerSubTab: 'skills', imageAsset: SHEET_ASSETS[12], description: 'Следующий шаг по одной цели; ручное редактирование доступно без навыка', audioCueId: 'none', motionSceneId: 'detail_open' },
  { id: 36, code: '36', sheetNumber: 12, sheetCode: '12', sheetTitle: 'ПОЛЕЗНОСТЬ НАВЫКОВ', columnIndex: 2, columnTitle: 'КОНТРОЛЬ', palette: 'blue', tab: 'player', playerSubTab: 'skills', imageAsset: SHEET_ASSETS[12], description: 'Проверка финансового учёта +5 XP не чаще 1 раза в день; без XP за сами траты', audioCueId: 'none', motionSceneId: 'detail_open' },

  // Sheet 13: РАЗВИТИЕ НАВЫКОВ
  { id: 37, code: '37', sheetNumber: 13, sheetCode: '13', sheetTitle: 'РАЗВИТИЕ НАВЫКОВ', columnIndex: 0, columnTitle: 'ИМПУЛЬС', palette: 'blue', tab: 'player', playerSubTab: 'skills', imageAsset: SHEET_ASSETS[13], description: 'Источник: Сила. Дополнительный +5 XP за запланированную активность 1 раз в день', audioCueId: 'none', motionSceneId: 'detail_open' },
  { id: 38, code: '38', sheetNumber: 13, sheetCode: '13', sheetTitle: 'РАЗВИТИЕ НАВЫКОВ', columnIndex: 1, columnTitle: 'УЛУЧШЕНИЕ', palette: 'blue', tab: 'player', playerSubTab: 'skills', imageAsset: SHEET_ASSETS[13], description: 'НАВЫК УЛУЧШЕН: Фокус · уровень 2 (+5 → +10 XP, цепочка из 2 сессий)', audioCueId: 'skill_upgraded', motionSceneId: 'skill_upgrade_scene' },
  { id: 39, code: '39', sheetNumber: 13, sheetCode: '13', sheetTitle: 'РАЗВИТИЕ НАВЫКОВ', columnIndex: 2, columnTitle: 'УСЛОВИЕ НЕ ВЫПОЛНЕНО', palette: 'blue', tab: 'player', playerSubTab: 'skills', imageAsset: SHEET_ASSETS[13], description: 'Фокус · Уровень 3: Интеллект 14/18 (пусто), Сессии 10/25 (пусто)', audioCueId: 'none', motionSceneId: 'detail_open' },

  // Sheet 14: ШТРАФНОЙ КВЕСТ
  { id: 40, code: '40', sheetNumber: 14, sheetCode: '14', sheetTitle: 'ШТРАФНОЙ КВЕСТ', columnIndex: 0, columnTitle: 'НАЗНАЧЕНИЕ', palette: 'red', tab: 'today', imageAsset: SHEET_ASSETS[14], description: 'ШТРАФНОЙ КВЕСТ: Пропущено Чтение · 15 минут. Срок 12 часов (11:59:59). Ночная пауза 23:00–08:00', audioCueId: 'penalty_assigned', motionSceneId: 'penalty_red_scene' },
  { id: 41, code: '41', sheetNumber: 14, sheetCode: '14', sheetTitle: 'ШТРАФНОЙ КВЕСТ', columnIndex: 1, columnTitle: 'УСЛОВИЯ ЗАЧЁТА', palette: 'red', tab: 'today', imageAsset: SHEET_ASSETS[14], description: 'ВОЗВРАЩЕНИЕ В СТРОЙ: 2 этапа по 2:30, правильные ответы 5 из 5, следующий шаг сохранён', audioCueId: 'none', motionSceneId: 'penalty_red_scene' },
  { id: 42, code: '42', sheetNumber: 14, sheetCode: '14', sheetTitle: 'ШТРАФНОЙ КВЕСТ', columnIndex: 2, columnTitle: 'ПРОХОЖДЕНИЕ', palette: 'red', tab: 'today', imageAsset: SHEET_ASSETS[14], description: 'Этап 1/2, до проверки этапа 01:12 (засчитано 1 мин 18 с из 2 мин 30 с — 52%), кнопка ПАУЗА', audioCueId: 'none', motionSceneId: 'penalty_red_scene' },

  // Sheet 15: ИСХОДЫ ШТРАФНОГО КВЕСТА
  { id: 43, code: '43', sheetNumber: 15, sheetCode: '15', sheetTitle: 'ИСХОДЫ ШТРАФНОГО КВЕСТА', columnIndex: 0, columnTitle: 'ВОССТАНОВЛЕНО', palette: 'blue', tab: 'today', imageAsset: SHEET_ASSETS[15], description: 'КВЕСТ ЗАВЕРШЁН: бонусы навыков восстановлены, пропуск остаётся в истории, XP не начисляется', audioCueId: 'penalty_resolved', motionSceneId: 'penalty_blue_restore' },
  { id: 44, code: '44', sheetNumber: 15, sheetCode: '15', sheetTitle: 'ИСХОДЫ ШТРАФНОГО КВЕСТА', columnIndex: 1, columnTitle: 'СРОК ИСТЁК', palette: 'red', tab: 'today', imageAsset: SHEET_ASSETS[15], description: 'КВЕСТ ПРОСРОЧЕН 00:00:00: пройденные этапы сохранены, бонусы приостановлены, ПРОДОЛЖИТЬ КВЕСТ', audioCueId: 'none', motionSceneId: 'penalty_red_scene' },
  { id: 45, code: '45', sheetNumber: 15, sheetCode: '15', sheetTitle: 'ИСХОДЫ ШТРАФНОГО КВЕСТА', columnIndex: 2, columnTitle: 'ИСТОРИЯ', palette: 'blue', tab: 'today', imageAsset: SHEET_ASSETS[15], description: 'ИСТОРИЯ КВЕСТОВ: Выполнен / Выполнен с просрочкой, несколько пропусков — один активный квест', audioCueId: 'none', motionSceneId: 'detail_open' },

  // Sheet 16: СИСТЕМА+
  { id: 46, code: '46', sheetNumber: 16, sheetCode: '16', sheetTitle: 'СИСТЕМА+', columnIndex: 0, columnTitle: 'ЛИМИТ', palette: 'blue', tab: 'player', imageAsset: SHEET_ASSETS[16], description: 'ЛИМИТ ПРИВЫЧЕК: Активных привычек 3/3. Открыть Систему+ / Управлять привычками / Позже', audioCueId: 'none', motionSceneId: 'detail_open' },
  { id: 47, code: '47', sheetNumber: 16, sheetCode: '16', sheetTitle: 'СИСТЕМА+', columnIndex: 1, columnTitle: 'ПРЕИМУЩЕСТВА', palette: 'blue', tab: 'player', imageAsset: SHEET_ASSETS[16], description: 'СИСТЕМА+: 99 Stars / 30 дней, без лимита, сравнение месяцев, сценарии, напоминания', audioCueId: 'none', motionSceneId: 'detail_open' },
  { id: 48, code: '48', sheetNumber: 16, sheetCode: '16', sheetTitle: 'СИСТЕМА+', columnIndex: 2, columnTitle: 'УПРАВЛЕНИЕ', palette: 'blue', tab: 'player', imageAsset: SHEET_ASSETS[16], description: 'ПОДПИСКА: Система+ активна (99 Stars · 30 дней), ОТКЛЮЧИТЬ АВТОПРОДЛЕНИЕ', audioCueId: 'none', motionSceneId: 'detail_open' },

  // Sheet 17: ОПЛАТА И ОКОНЧАНИЕ ДОСТУПА
  { id: 49, code: '49', sheetNumber: 17, sheetCode: '17', sheetTitle: 'ОПЛАТА И ОКОНЧАНИЕ ДОСТУПА', columnIndex: 0, columnTitle: 'ОБРАБОТКА', palette: 'blue', tab: 'player', playerSubTab: 'status', imageAsset: SHEET_ASSETS[17], description: 'ПРОВЕРКА ОПЛАТЫ: Ожидаем подтверждение Telegram (99 Stars · 30 дней)', audioCueId: 'none', motionSceneId: 'detail_open' },
  { id: 50, code: '50', sheetNumber: 17, sheetCode: '17', sheetTitle: 'ОПЛАТА И ОКОНЧАНИЕ ДОСТУПА', columnIndex: 1, columnTitle: 'ОПЛАТА НЕ ЗАВЕРШЕНА', palette: 'blue', tab: 'player', playerSubTab: 'status', imageAsset: SHEET_ASSETS[17], description: 'ОПЛАТА НЕ ЗАВЕРШЕНА: Подписка пока не подключена. Повторить оплату / Продолжить бесплатно', audioCueId: 'none', motionSceneId: 'error_notice' },
  { id: 51, code: '51', sheetNumber: 17, sheetCode: '17', sheetTitle: 'ОПЛАТА И ОКОНЧАНИЕ ДОСТУПА', columnIndex: 2, columnTitle: 'БЕСПЛАТНЫЙ ДОСТУП', palette: 'blue', tab: 'player', playerSubTab: 'status', imageAsset: SHEET_ASSETS[17], description: 'СИСТЕМА+ ЗАВЕРШЕНА: Бесплатный доступ, созданные записи и история сохранены', audioCueId: 'none', motionSceneId: 'detail_open' },

  // Sheet 18: РЕФЕРАЛЬНЫЙ БОНУС
  { id: 52, code: '52', sheetNumber: 18, sheetCode: '18', sheetTitle: 'РЕФЕРАЛЬНЫЙ БОНУС', columnIndex: 0, columnTitle: 'ПРИГЛАСИТЬ', palette: 'blue', tab: 'player', imageAsset: SHEET_ASSETS[18], description: 'ПРИГЛАСИТЬ ИГРОКА: +3 дня Системы+ за первый запуск новым игроком. Поделиться / Скопировать', audioCueId: 'none', motionSceneId: 'detail_open' },
  { id: 53, code: '53', sheetNumber: 18, sheetCode: '18', sheetTitle: 'РЕФЕРАЛЬНЫЙ БОНУС', columnIndex: 1, columnTitle: 'НАЧИСЛЕНО', palette: 'blue', tab: 'player', imageAsset: SHEET_ASSETS[18], description: 'БОНУС НАЧИСЛЕН: +3 дня Системы+ ждёт ручной активации. АКТИВИРОВАТЬ 3 ДНЯ', audioCueId: 'none', motionSceneId: 'detail_open' },
  { id: 54, code: '54', sheetNumber: 18, sheetCode: '18', sheetTitle: 'РЕФЕРАЛЬНЫЙ БОНУС', columnIndex: 2, columnTitle: 'ПРИ АКТИВНОЙ ПОДПИСКЕ', palette: 'blue', tab: 'player', imageAsset: SHEET_ASSETS[18], description: 'БОНУСНЫЕ ДНИ (Накоплено: 3 дня): ИСПОЛЬЗОВАТЬ ПОСЛЕ ПОДПИСКИ (отключит автопродление)', audioCueId: 'none', motionSceneId: 'detail_open' },

  // Sheet 19: СОСТОЯНИЯ ПРИГЛАШЕНИЙ
  { id: 55, code: '55', sheetNumber: 19, sheetCode: '19', sheetTitle: 'СОСТОЯНИЯ ПРИГЛАШЕНИЙ', columnIndex: 0, columnTitle: 'БОНУС АКТИВЕН', palette: 'blue', tab: 'player', playerSubTab: 'status', imageAsset: SHEET_ASSETS[19], description: 'БОНУСНЫЙ ДОСТУП: Система+ активна, осталось 2 дня 23 часа, без списаний', audioCueId: 'none', motionSceneId: 'detail_open' },
  { id: 56, code: '56', sheetNumber: 19, sheetCode: '19', sheetTitle: 'СОСТОЯНИЯ ПРИГЛАШЕНИЙ', columnIndex: 1, columnTitle: 'БОНУС ЗАВЕРШЁН', palette: 'blue', tab: 'player', playerSubTab: 'status', imageAsset: SHEET_ASSETS[19], description: 'БОНУСНЫЙ ДОСТУП ЗАВЕРШЁН: возврат на бесплатный доступ, данные сохранены', audioCueId: 'none', motionSceneId: 'detail_open' },
  { id: 57, code: '57', sheetNumber: 19, sheetCode: '19', sheetTitle: 'СОСТОЯНИЯ ПРИГЛАШЕНИЙ', columnIndex: 2, columnTitle: 'ПОВТОРНЫЙ ПОЛЬЗОВАТЕЛЬ', palette: 'blue', tab: 'player', playerSubTab: 'status', imageAsset: SHEET_ASSETS[19], description: 'ПРИГЛАШЕНИЕ НЕ ЗАСЧИТАНО: Этот игрок уже пользовался Системой', audioCueId: 'none', motionSceneId: 'detail_open' },

  // Sheet 20: ЕЖЕДНЕВНЫЕ ДЕЙСТВИЯ
  { id: 58, code: '58', sheetNumber: 20, sheetCode: '20', sheetTitle: 'ЕЖЕДНЕВНЫЕ ДЕЙСТВИЯ', columnIndex: 0, columnTitle: 'ИСПРАВЛЕНИЕ ТРАТЫ', palette: 'blue', tab: 'finance', imageAsset: SHEET_ASSETS[20], description: 'ИЗМЕНИТЬ ТРАТУ: Кофе 200 → 250 ₽ (списывается разница 50 ₽), Удалить запись', audioCueId: 'none', motionSceneId: 'detail_open' },
  { id: 59, code: '59', sheetNumber: 20, sheetCode: '20', sheetTitle: 'ЕЖЕДНЕВНЫЕ ДЕЙСТВИЯ', columnIndex: 1, columnTitle: 'ФОКУС-СЕССИЯ', palette: 'blue', tab: 'today', imageAsset: SHEET_ASSETS[20], description: 'ФОКУС-СЕССИЯ: Английский 11:25 из 15 минут, ПАУЗА, Завершить досрочно', audioCueId: 'none', motionSceneId: 'detail_open' },
  { id: 60, code: '60', sheetNumber: 20, sheetCode: '20', sheetTitle: 'ЕЖЕДНЕВНЫЕ ДЕЙСТВИЯ', columnIndex: 2, columnTitle: 'ПРАВКА ЗАДАНИЯ', palette: 'blue', tab: 'today', imageAsset: SHEET_ASSETS[20], description: 'ЗАДАНИЕ: Оформить страницу портфолио, цель Портфолио, срок Через 7 дней', audioCueId: 'none', motionSceneId: 'detail_open' },

  // Sheet 21: ПРОВЕРКА ВЫПОЛНЕНИЯ
  { id: 61, code: '61', sheetNumber: 21, sheetCode: '21', sheetTitle: 'ПРОВЕРКА ВЫПОЛНЕНИЯ', columnIndex: 0, columnTitle: 'МАТЕРИАЛ ЭТАПА', palette: 'red', tab: 'today', imageAsset: SHEET_ASSETS[21], description: 'УЧЕБНЫЙ РАЗБОР Этап 1/2: Тема «Один конкретный шаг», таймер этапа 01:12', audioCueId: 'none', motionSceneId: 'penalty_red_scene' },
  { id: 62, code: '62', sheetNumber: 21, sheetCode: '21', sheetTitle: 'ПРОВЕРКА ВЫПОЛНЕНИЯ', columnIndex: 1, columnTitle: 'ПРОВЕРКА ПОНИМАНИЯ', palette: 'red', tab: 'today', imageAsset: SHEET_ASSETS[21], description: 'ПРОВЕРКА ПОНИМАНИЯ Вопрос 1 из 5: «Какой шаг проще проверить?»', audioCueId: 'none', motionSceneId: 'penalty_red_scene' },
  { id: 63, code: '63', sheetNumber: 21, sheetCode: '21', sheetTitle: 'ПРОВЕРКА ВЫПОЛНЕНИЯ', columnIndex: 2, columnTitle: 'СЛЕДУЮЩИЙ ШАГ', palette: 'red', tab: 'today', imageAsset: SHEET_ASSETS[21], description: 'СЛЕДУЮЩИЙ ШАГ: Этапы 2/2, Ответы 5/5. Действие «Выбрать три работы для портфолио»', audioCueId: 'none', motionSceneId: 'penalty_red_scene' },

  // Sheet 22: ПРЕРЫВАНИЯ И ВОЗВРАТ
  { id: 64, code: '64', sheetNumber: 22, sheetCode: '22', sheetTitle: 'ПРЕРЫВАНИЯ И ВОЗВРАТ', columnIndex: 0, columnTitle: 'ПОСЛЕ ПАУЗЫ', palette: 'red', tab: 'player', imageAsset: SHEET_ASSETS[22], description: 'КВЕСТ НА ПАУЗЕ: Засчитано 1 мин 18 с, до проверки 01:12, днём отсчёт срока продолжается', audioCueId: 'none', motionSceneId: 'penalty_red_scene' },
  { id: 65, code: '65', sheetNumber: 22, sheetCode: '22', sheetTitle: 'ПРЕРЫВАНИЯ И ВОЗВРАТ', columnIndex: 1, columnTitle: 'НЕТ СВЯЗИ', palette: 'red', tab: 'player', imageAsset: SHEET_ASSETS[22], description: 'НЕТ СВЯЗИ: Последний подтверждённый прогресс и черновик ответа сохранены', audioCueId: 'none', motionSceneId: 'penalty_red_scene' },
  { id: 66, code: '66', sheetNumber: 22, sheetCode: '22', sheetTitle: 'ПРЕРЫВАНИЯ И ВОЗВРАТ', columnIndex: 2, columnTitle: 'ДРУГОЕ ОКНО', palette: 'red', tab: 'player', imageAsset: SHEET_ASSETS[22], description: 'КВЕСТ ОТКРЫТ В ДРУГОМ ОКНЕ: Одновременно работает одна сессия. ПРОДОЛЖИТЬ ЗДЕСЬ', audioCueId: 'none', motionSceneId: 'penalty_red_scene' },

  // Sheet 23: ОШИБКИ И ЗАЧЁТ
  { id: 67, code: '67', sheetNumber: 23, sheetCode: '23', sheetTitle: 'ОШИБКИ И ЗАЧЁТ', columnIndex: 0, columnTitle: 'УСЛОВИЯ НЕ ВЫПОЛНЕНЫ', palette: 'red', tab: 'player', imageAsset: SHEET_ASSETS[23], description: 'КВЕСТ ЕЩЁ НЕ ЗАВЕРШЁН: Этапы 2/2, Ответы 4/5 (пусто), Следующий шаг не сохранён', audioCueId: 'none', motionSceneId: 'penalty_red_scene' },
  { id: 68, code: '68', sheetNumber: 23, sheetCode: '23', sheetTitle: 'ОШИБКИ И ЗАЧЁТ', columnIndex: 1, columnTitle: 'РАЗБОР ОТВЕТА', palette: 'red', tab: 'player', imageAsset: SHEET_ASSETS[23], description: 'РАЗБОР ОТВЕТА: Ответ пока неверный. «Стать продуктивнее» не задаёт результата', audioCueId: 'none', motionSceneId: 'penalty_red_scene' },
  { id: 69, code: '69', sheetNumber: 23, sheetCode: '23', sheetTitle: 'ОШИБКИ И ЗАЧЁТ', columnIndex: 2, columnTitle: 'ФИНАЛЬНАЯ ПРОВЕРКА', palette: 'red', tab: 'player', imageAsset: SHEET_ASSETS[23], description: 'ГОТОВО К ЗАЧЁТУ: Этапы 2/2, Ответы 5/5, Следующий шаг сохранён. ЗАВЕРШИТЬ КВЕСТ', audioCueId: 'none', motionSceneId: 'penalty_red_scene' },

  // Sheet 24: НОЧНОЙ ПЕРИОД
  { id: 70, code: '70', sheetNumber: 24, sheetCode: '24', sheetTitle: 'НОЧНОЙ ПЕРИОД', columnIndex: 0, columnTitle: 'НАСТРОЙКА ПЕРИОДА', palette: 'blue', tab: 'player', imageAsset: SHEET_ASSETS[24], description: 'НОЧНОЙ ПЕРИОД: Начало 23:00, Окончание 08:00 (до 10 часов). Изменения — для будущих квестов', audioCueId: 'none', motionSceneId: 'detail_open' },
  { id: 71, code: '71', sheetNumber: 24, sheetCode: '24', sheetTitle: 'НОЧНОЙ ПЕРИОД', columnIndex: 1, columnTitle: 'НОЧНАЯ ПАУЗА', palette: 'red', tab: 'today', imageAsset: SHEET_ASSETS[24], description: 'НОЧНАЯ ПАУЗА (Сейчас 23:10): 11:00:00 осталось, отсчёт продолжится в 08:00, можно пройти сейчас', audioCueId: 'none', motionSceneId: 'penalty_red_scene' },
  { id: 72, code: '72', sheetNumber: 24, sheetCode: '24', sheetTitle: 'НОЧНОЙ ПЕРИОД', columnIndex: 2, columnTitle: 'ВОЗОБНОВЛЕНИЕ', palette: 'red', tab: 'today', imageAsset: SHEET_ASSETS[24], description: 'ОТСЧЁТ ВОЗОБНОВЛЁН (Сейчас 08:00): 11:00:00 до окончания срока (сегодня до 19:00)', audioCueId: 'none', motionSceneId: 'penalty_red_scene' },
];

export { parseNaturalFinanceInput } from './financeParser';

export function parseSmartFinanceInput(
  rawInput: string,
  defaultAccountId = 'acc_card',
  defaultAccountName = 'Карта',
  accounts?: AccountItem[]
): ParsedFinanceDraftItem[] {
  return parseNaturalFinanceInput(rawInput, accounts, defaultAccountId, defaultAccountName);
}

/**
 * Formats integer Rubles with narrow non-breaking spaces: 48600 -> "48 600 ₽"
 */
export function formatRub(amount: number): string {
  const sign = amount < 0 ? '−' : '';
  const abs = Math.abs(Math.round(amount));
  const formatted = abs.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  return `${sign}${formatted} ₽`;
}

/**
 * Formats seconds into HH:MM:SS or MM:SS
 */
export function formatTimerHMS(totalSeconds: number): string {
  const clamped = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(clamped / 3600);
  const m = Math.floor((clamped % 3600) / 60);
  const s = clamped % 60;
  return [h, m, s].map((v) => String(v).padStart(2, '0')).join(':');
}

export function formatTimerMS(totalSeconds: number): string {
  const clamped = Math.max(0, Math.floor(totalSeconds));
  const m = Math.floor(clamped / 60);
  const s = clamped % 60;
  return [m, s].map((v) => String(v).padStart(2, '0')).join(':');
}
