import {
  calculateNightWindowDurationHours,
  createAlbumFixtureState,
  createNewUserState,
  getCurrentMonthKey,
  getTzIsoDaysAgo,
  getTzWeekday,
} from './fixtures';
import { parseNaturalFinanceInput } from './financeParser';
import { SUBSCRIPTION_PLANS } from './constants';
import { LifeRoleId, StatKey, SubscriptionPlanId, UserAppState } from './types';

const STORAGE_KEY = 'systema_miniapp_user_v1';
const RECONCILE_STORAGE_KEY = 'systema_reconcile_date_v1';
const API_BASE = ((import.meta as unknown as { env?: Record<string, string> }).env?.VITE_BOT_API_URL || '').replace(/\/$/, '');

const PENALTY_ANSWERS: Record<string, { correctIndex: number; explanation: string }> = {
  q1_step_clarity: {
    correctIndex: 1,
    explanation: 'Конкретный шаг содержит действие и понятный результат. «Стать продуктивнее» не задаёт результата.',
  },
  q2_start_time: {
    correctIndex: 1,
    explanation: 'Фиксация времени начала и подготовка материалов заранее убирают трение старта.',
  },
  q3_scope_limit: {
    correctIndex: 0,
    explanation: 'Короткий 15-минутный этап с понятным результатом позволяет начать действие без перегрузки.',
  },
  q4_miss_recovery: {
    correctIndex: 1,
    explanation: 'Штрафной модуль восстанавливает бонусы навыков, но не переписывает историю прошлых отметок и не даёт XP.',
  },
  q5_next_step: {
    correctIndex: 1,
    explanation: 'Для завершения модуля необходимо сохранить конкретное следующее действие и время его начала.',
  },
};

export interface ApiActionResponse {
  ok: boolean;
  user?: UserAppState;
  code?: string;
  error?: string;
  message?: string;
  leveledUp?: boolean;
  goalJustCompleted?: boolean;
  correct?: boolean;
  explanation?: string;
  invoiceUrl?: string;
  fallbackDemo?: boolean;
  steps?: string[];
  xpGain?: number;
  alreadyReconciled?: boolean;
}

let memoryUserCache: UserAppState | null = null;
let persistTimer: number | null = null;

function readLocalUser(): UserAppState {
  if (memoryUserCache) {
    return memoryUserCache;
  }
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      memoryUserCache = JSON.parse(raw) as UserAppState;
      return memoryUserCache;
    }
  } catch {
    // ignore
  }
  const fresh = createNewUserState('usr_local', getTelegramUserId());
  fresh.timezone = getClientTimezone();
  writeLocalUser(fresh);
  return fresh;
}

function writeLocalUser(user: UserAppState) {
  memoryUserCache = user;
  if (persistTimer !== null) {
    window.clearTimeout(persistTimer);
  }
  persistTimer = window.setTimeout(() => {
    persistTimer = null;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
    } catch {
      // ignore
    }
  }, 0);
}

export function getTelegramUserId(): string {
  try {
    const tg = (window as unknown as { Telegram?: { WebApp?: { initDataUnsafe?: { user?: { id?: number } } } } }).Telegram?.WebApp;
    const id = tg?.initDataUnsafe?.user?.id;
    if (id) return String(id);
  } catch {
    // ignore
  }
  return '104920112';
}

export function getTelegramInitData(): string {
  try {
    const tg = (window as unknown as { Telegram?: { WebApp?: { initData?: string } } }).Telegram?.WebApp;
    return tg?.initData || '';
  } catch {
    return '';
  }
}

export function getClientTimezone(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || 'Europe/Moscow';
  } catch {
    return 'Europe/Moscow';
  }
}

export function getAuthHeaders(): Record<string, string> {
  const tgId = getTelegramUserId();
  const initData = getTelegramInitData();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'x-systema-user': `tg_${tgId}`,
    'x-systema-tz': getClientTimezone(),
  };
  if (initData) {
    headers['x-telegram-init-data'] = initData;
  }
  return headers;
}

function addXpLocal(user: UserAppState, amount: number): boolean {
  let leveledUp = false;
  user.currentXp += amount;
  while (user.currentXp >= user.nextLevelXp) {
    user.currentXp -= user.nextLevelXp;
    user.level += 1;
    user.unspentStatPoints += 3;
    user.nextLevelXp = user.level >= 13 ? 1200 : user.nextLevelXp + 100;
    user.lastLevelUpXpGain = amount;
    leveledUp = true;
  }
  return leveledUp;
}

function subtractXpLocal(user: UserAppState, amount: number) {
  let rem = Math.max(0, amount);
  while (rem > 0) {
    if (user.currentXp >= rem) {
      user.currentXp -= rem;
      rem = 0;
    } else if (user.level > 1) {
      rem -= user.currentXp;
      user.level -= 1;
      user.nextLevelXp = user.level >= 13 ? 1200 : Math.max(100, user.nextLevelXp - 100);
      user.currentXp = user.nextLevelXp;
      user.unspentStatPoints = Math.max(0, user.unspentStatPoints - 3);
    } else {
      user.currentXp = 0;
      rem = 0;
    }
  }
}

function getShadowBonusLocal(user: UserAppState): number {
  const count = user.shadows?.length || 0;
  if (count === 0) return 0;
  return user.subscription.active ? Math.min(40, count * 10) : 5;
}

function syncStreakLocal(user: UserAppState, tz: string): number {
  const todayIso = getTzIsoDaysAgo(0, tz);
  const yesterdayIso = getTzIsoDaysAgo(1, tz);
  let nextStreak = user.streakDays || 0;
  if (user.lastActiveDate !== todayIso) {
    if (nextStreak === 0) {
      nextStreak = 1;
    } else if (user.lastActiveDate === yesterdayIso || user.lastDailyClaimDate === yesterdayIso) {
      nextStreak += 1;
    } else {
      nextStreak = 1;
    }
    user.lastActiveDate = todayIso;
  } else if (nextStreak === 0) {
    nextStreak = 1;
  }
  user.streakDays = nextStreak;
  user.bestStreakDays = Math.max(user.bestStreakDays || 0, nextStreak);
  return nextStreak;
}

function syncSkillStatReqsLocal(user: UserAppState) {
  const statReqMap: Array<{ skill: keyof UserAppState['skills']; reqId: string; stat: StatKey }> = [
    { skill: 'impulse', reqId: 'req_str', stat: 'strength' },
    { skill: 'rhythm', reqId: 'req_end', stat: 'endurance' },
    { skill: 'focus', reqId: 'req_int', stat: 'intelligence' },
    { skill: 'planning', reqId: 'req_agi', stat: 'agility' },
    { skill: 'control', reqId: 'req_per', stat: 'perception' },
  ];
  for (const { skill, reqId, stat } of statReqMap) {
    const reqItem = user.skills[skill]?.requirementsForNext.find((r) => r.id === reqId);
    if (reqItem) {
      reqItem.current = user.stats[stat];
      reqItem.met = user.stats[stat] >= reqItem.target;
    }
  }
}

function grantShadowLocal(user: UserAppState, id: string, name: string, rank: string, bonusText: string) {
  if (!user.shadows) user.shadows = [];
  if (user.shadows.some((s) => s.id === id)) return;
  if (!user.subscription.active && user.shadows.length >= 1) return;
  user.shadows.unshift({ id, name, rank, bonusText, extractedAt: 'Сегодня' });
}

function recomputeLocalTotals(user: UserAppState) {
  user.allocatedToGoalsRub = user.goals
    .filter((g) => g.status === 'active' && g.type === 'savings')
    .reduce((acc, g) => acc + g.currentValue, 0);
}

function isLocalQuarantined(user: UserAppState): boolean {
  return Boolean(
    user.penaltyQuest.active &&
      user.penaltyQuest.status !== 'completed' &&
      user.penaltyQuest.status !== 'completed_late' &&
      user.penaltyQuest.status !== 'cancelled_error'
  );
}

function normalizeLocalDailyRollover(user: UserAppState): boolean {
  const tz = user.timezone || getClientTimezone();
  const todayIso = getTzIsoDaysAgo(0, tz);
  const currentMonth = getCurrentMonthKey(tz);
  let changed = false;

  if (!user.monthStatsKey) {
    user.monthStatsKey = currentMonth;
    changed = true;
  } else if (user.monthStatsKey !== currentMonth) {
    user.monthStatsKey = currentMonth;
    user.monthIncomeRub = 0;
    user.monthExpenseRub = 0;
    changed = true;
  }

  for (const habit of user.habits) {
    if (habit.status !== 'active') continue;
    const todayEntry = habit.history.find((h) => h.isoDate === todayIso);
    if (!todayEntry && (habit.completedToday || habit.currentMinutesToday > 0)) {
      habit.completedToday = false;
      habit.currentMinutesToday = 0;
      changed = true;
    }
    for (const h of habit.history) {
      if (h.isoDate !== todayIso && h.dateLabel === 'Сегодня') {
        h.dateLabel = h.isoDate === getTzIsoDaysAgo(1, tz) ? 'Вчера' : h.isoDate;
        changed = true;
      }
    }
  }
  return changed;
}

function evaluateLocalAutomaticPenalties(user: UserAppState): boolean {
  let changed = normalizeLocalDailyRollover(user);
  if (user.bootstrapState !== 'ready') return changed;

  const tz = user.timezone || getClientTimezone();
  const todayIso = getTzIsoDaysAgo(0, tz);
  if (user.lastPenaltyCheckDate === todayIso) return changed;
  user.lastPenaltyCheckDate = todayIso;
  changed = true;

  if (user.createdAtIso) {
    const ageMs = Date.now() - Date.parse(user.createdAtIso);
    if (Number.isFinite(ageMs) && ageMs < 24 * 3600_000) {
      return changed;
    }
  }

  const yesterdayIso = getTzIsoDaysAgo(1, tz);
  const yWeekday = getTzWeekday(1, tz);

  if (user.lastActiveDate && user.lastActiveDate !== todayIso && user.lastActiveDate !== yesterdayIso) {
    user.streakDays = 0;
  }

  for (const habit of user.habits) {
    if (habit.status !== 'active' || !habit.mandatory) continue;
    if (!habit.daysOfWeek.includes(yWeekday)) continue;
    if (!habit.createdAtIso || habit.createdAtIso >= yesterdayIso) continue;
    const entry = habit.history.find((h) => h.isoDate === yesterdayIso);
    if (entry && (entry.status === 'completed' || entry.triggeredPenaltyId)) continue;

    const penaltyId = `pq_auto_${habit.id}_${yesterdayIso}`;
    if (entry) {
      entry.status = 'missed';
      entry.triggeredPenaltyId = penaltyId;
    } else {
      habit.history.unshift({
        dateLabel: 'Вчера',
        isoDate: yesterdayIso,
        status: 'missed',
        triggeredPenaltyId: penaltyId,
      });
    }
    if (!user.penaltyQuest.active) {
      user.streakDays = 0;
      user.penaltyQuest = {
        ...user.penaltyQuest,
        id: penaltyId,
        active: true,
        reasonTitle: `${habit.title} · ${habit.durationMinutes} минут`,
        status: 'assigned',
        presentedAt: null,
        budgetTotalSeconds: 43200,
        remainingBudgetSeconds: 43200,
        currentStage: 1,
        stage1ConfirmedSeconds: 0,
        stage2ConfirmedSeconds: 0,
        questionsPassed: 0,
        nextStepSaved: false,
        selectedChallenge: null,
        challengeDone: false,
        reflectionReason: '',
      };
    }
  }
  return changed;
}

function executeLocalFallback(endpoint: string, body: Record<string, unknown> = {}): ApiActionResponse {
  const user: UserAppState = JSON.parse(JSON.stringify(readLocalUser()));

  if (endpoint === '/api/profile/reset-mode') {
    let next: UserAppState;
    if (body.mode === 'new_player') {
      next = createNewUserState(`tg_${getTelegramUserId()}`, getTelegramUserId());
    } else if (body.mode === 'penalty_demo') {
      next = createAlbumFixtureState(`tg_${getTelegramUserId()}`, getTelegramUserId());
      next.bootstrapState = 'penalty_alert';
      next.penaltyQuest.active = true;
    } else {
      next = createAlbumFixtureState(`tg_${getTelegramUserId()}`, getTelegramUserId());
    }
    writeLocalUser(next);
    return { ok: true, user: next };
  }

  if (endpoint === '/api/onboarding/refuse') {
    user.bootstrapState = 'refusal_rejected';
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/onboarding/accept') {
    const fn = typeof body.firstName === 'string' ? body.firstName.trim() : '';
    if (fn && (!user.playerCallsign || user.playerCallsign === 'Игрок')) {
      user.playerCallsign = fn.slice(0, 32);
    }
    if (['new_invitation', 'refusal_rejected', 'accepted'].includes(user.bootstrapState)) {
      user.bootstrapState = 'accepted';
    }
    if (!user.trophies) user.trophies = [];
    if (!user.trophies.includes('Контракт с Системой')) {
      user.trophies.push('Контракт с Системой');
    }
    let leveledUp = false;
    if (user.level === 1 && user.currentXp === 0) {
      leveledUp = addXpLocal(user, 15);
    }
    writeLocalUser(user);
    return { ok: true, user, leveledUp };
  }

  if (endpoint === '/api/onboarding/roles') {
    const wasFirst = user.roles.length === 0;
    if (Array.isArray(body.roles) && body.roles.length > 0) {
      user.roles = body.roles as LifeRoleId[];
    }
    if (typeof body.customRoleText === 'string') {
      user.customRoleText = body.customRoleText.slice(0, 120);
    }
    if (typeof body.playerCallsign === 'string') {
      user.playerCallsign = (body.playerCallsign.trim() || 'Игрок').slice(0, 32);
    }
    if (wasFirst && user.roles.length > 0) {
      const primary = user.roles[0];
      if (primary === 'studying') user.stats.intelligence += 2;
      else if (primary === 'employed') user.stats.endurance += 2;
      else if (primary === 'freelance') user.stats.agility += 2;
      else if (primary === 'business') user.stats.perception += 2;
      else if (primary === 'family') user.stats.strength += 2;
      else {
        user.stats.intelligence += 1;
        user.stats.endurance += 1;
      }
      syncSkillStatReqsLocal(user);
    }
    if (body.quickStart) {
      if (user.goals.length === 0) {
        const primary = user.roles[0] || 'employed';
        const customTopic = user.customRoleText?.trim();
        const starterTitle =
          primary === 'studying'
            ? 'Изучение материала по плану'
            : primary === 'freelance'
            ? 'Отклики и поиск клиентов'
            : primary === 'business'
            ? 'Рост выручки и воронки'
            : primary === 'family'
            ? 'Спорт и восстановление энергии'
            : primary === 'custom'
            ? customTopic
              ? `Практика: ${customTopic}`
              : 'Практика ключевого навыка'
            : 'Глубокая работа без отвлечений';
        const gId = `goal_start_${Date.now()}`;
        user.goals.push({
          id: gId,
          type: 'scheduled_action',
          title: starterTitle,
          currentValue: 0,
          targetValue: 21,
          unit: 'сессий',
          status: 'active',
          durationMinutes: 15,
          daysPerWeek: 5,
          preferredTime: 'Вечером',
        });
        user.tasks.unshift(
          {
            id: `tsk_start_${Date.now()}`,
            title: `${starterTitle} · 15 минут`,
            goalId: gId,
            durationMinutes: 15,
            xpReward: 30,
            completed: false,
            dueDateText: 'Сегодня',
            priority: 'high',
          },
          {
            id: `tsk_intro_${Date.now() + 1}`,
            title: 'Калибровка дня: записать 1 трату или план',
            xpReward: 20,
            completed: false,
            dueDateText: 'Сегодня',
            priority: 'normal',
          }
        );
      }
      user.bootstrapState = 'ready';
    } else if (user.bootstrapState !== 'ready') {
      user.bootstrapState = 'onboarding_goal_type';
    }
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/onboarding/complete') {
    user.bootstrapState = 'ready';
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/goals/create') {
    const isOnboarding = Boolean(body.isOnboarding);
    const activeGoalsCount = user.goals.filter((g) => g.status === 'active').length;
    const allowOnboardingBypass = Boolean(isOnboarding && user.bootstrapState !== 'ready' && activeGoalsCount === 0);
    if (!allowOnboardingBypass && !user.subscription.active && activeGoalsCount >= 3) {
      return { ok: false, code: 'FREE_GOAL_LIMIT_REACHED', user };
    }
    const type = (body.type as UserAppState['onboardingSelectedGoalType']) || 'scheduled_action';
    if (isOnboarding) user.onboardingSelectedGoalType = type;
    const goalId = `goal_${Date.now()}`;
    if (type === 'scheduled_action') {
      const cleanTitle = String(body.title || 'Фокус над проектом').trim();
      const mins = Number(body.durationMinutes) || 15;
      const targetSessions = Math.max(5, Math.min(90, Number(body.targetValue) || 21));
      user.goals.push({
        id: goalId,
        type: 'scheduled_action',
        title: cleanTitle,
        currentValue: 0,
        targetValue: targetSessions,
        unit: 'сессий',
        status: 'active',
        durationMinutes: mins,
        daysPerWeek: Number(body.daysPerWeek) || 5,
        preferredTime: String(body.preferredTime || 'Вечером'),
      });
      const tsk = {
        id: `tsk_${Date.now()}`,
        title: `${cleanTitle} · ${mins} минут`,
        goalId,
        durationMinutes: mins,
        xpReward: 30,
        completed: false,
        dueDateText: 'Сегодня',
        priority: 'normal' as const,
      };
      user.tasks.unshift(tsk);
      if (isOnboarding) {
        user.focusSession = { active: false, paused: false, taskId: tsk.id, title: cleanTitle, totalSeconds: mins * 60, remainingSeconds: mins * 60 };
      }
    } else if (type === 'deadline_project') {
      const cleanTitle = String(body.title || 'Запустить портфолио').trim();
      const step1 = String(body.firstStepTitle || 'Собрать примеры работ').trim();
      user.goals.push({
        id: goalId,
        type: 'deadline_project',
        title: cleanTitle,
        currentValue: 0,
        targetValue: 3,
        unit: 'этапов',
        status: 'active',
        mandatoryDeadline: Boolean(body.mandatoryDeadline),
        deadlineText: String(body.deadlineText || 'Через 30 дней'),
        milestones: [
          { id: `ms_1_${Date.now()}`, goalId, title: step1, order: 1, completed: false, locked: false, mandatory: Boolean(body.mandatoryDeadline) },
          { id: `ms_2_${Date.now()}`, goalId, title: 'Оформить страницы', order: 2, completed: false, locked: true, mandatory: Boolean(body.mandatoryDeadline), deadlineDate: 'Через 7 дней' },
          { id: `ms_3_${Date.now()}`, goalId, title: 'Опубликовать', order: 3, completed: false, locked: true, mandatory: Boolean(body.mandatoryDeadline) },
        ],
      });
      const tsk = {
        id: `tsk_${Date.now()}`,
        title: step1,
        goalId,
        durationMinutes: 15,
        xpReward: 30,
        completed: false,
        dueDateText: 'Сегодня',
        priority: 'normal' as const,
        mandatory: Boolean(body.mandatoryDeadline),
      };
      user.tasks.unshift(tsk);
      if (isOnboarding) {
        user.focusSession = { active: false, paused: false, taskId: tsk.id, title: step1, totalSeconds: 900, remainingSeconds: 900 };
      }
    } else {
      const saved = Math.max(0, Math.round(Number(body.alreadySavedRub) || 0));
      const target = Math.max(1000, Math.round(Number(body.targetSavingsRub) || 100000));
      const cleanTitle = String(body.title || 'Подушка безопасности').trim();
      const totalBal = user.accounts.filter((a) => a.status === 'active').reduce((s, a) => s + a.balanceRub, 0);
      const existingAllocated = user.goals
        .filter((g) => g.status === 'active' && g.type === 'savings')
        .reduce((s, g) => s + g.currentValue, 0);
      if (saved > 0 && existingAllocated + saved > totalBal) {
        if (isOnboarding && totalBal === 0 && existingAllocated === 0) {
          const card = user.accounts.find((a) => a.type === 'card') || user.accounts[0];
          if (card) card.balanceRub = saved;
        } else {
          const available = Math.max(0, totalBal - existingAllocated);
          return {
            ok: false,
            code: 'SAVINGS_EXCEEDS_ACCOUNT_BALANCE',
            message: `Доступно для распределения: ${available.toLocaleString('ru-RU')} ₽ (остаток ${totalBal.toLocaleString('ru-RU')} ₽ с учётом других копилок).`,
            user,
          };
        }
      }
      user.goals.push({
        id: goalId,
        type: 'savings',
        title: cleanTitle,
        currentValue: saved,
        targetValue: target,
        unit: '₽',
        status: 'active',
        deadlineText: String(body.deadlineText || 'Без жёсткой даты'),
      });
      if (isOnboarding) {
        const tsk = {
          id: `tsk_${Date.now()}`,
          title: `План накоплений: ${cleanTitle}`,
          goalId,
          durationMinutes: 10,
          xpReward: 30,
          completed: false,
          dueDateText: 'Сегодня',
          priority: 'normal' as const,
        };
        user.tasks.unshift(tsk);
        user.focusSession = { active: false, paused: false, taskId: tsk.id, title: tsk.title, totalSeconds: 600, remainingSeconds: 600 };
      }
    }
    if (isOnboarding) user.bootstrapState = 'first_task';
    recomputeLocalTotals(user);
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/goals/smart-steps') {
    const targetGoal = body.goalId ? user.goals.find((g) => g.id === body.goalId) : undefined;
    const rawTitle = String(body.title || targetGoal?.title || 'Ключевой проект').trim();
    const lower = rawTitle.toLowerCase();
    let steps: [string, string, string];
    if (lower.includes('портфолио') || lower.includes('сайт') || lower.includes('дизайн') || lower.includes('резюме')) {
      steps = [
        'Отобрать 3 лучших кейса и тезисы результата (15 мин)',
        'Сверстать / оформить витрину и описание услуг',
        'Проверить ссылки и опубликовать ссылку в профиле',
      ];
    } else if (lower.includes('англ') || lower.includes('язык') || lower.includes('экзам') || lower.includes('диплом') || lower.includes('учеб')) {
      steps = [
        'Составить список ключевых тем и пройти тест-срез',
        'Закрыть слабые блоки по 25 минут в день',
        'Пройти контрольный разбор и финальную сдачу',
      ];
    } else if (lower.includes('доход') || lower.includes('клиент') || lower.includes('запуск') || lower.includes('бизнес') || lower.includes('канал') || lower.includes('tiktok')) {
      steps = [
        'Сформулировать оффер / тему первых 3 публикаций',
        'Сделать первый тестовый выпуск и разослать 5 касаний',
        'Зафиксировать конверсию и докрутить воронку',
      ];
    } else {
      steps = [
        `Декомпозиция «${rawTitle.slice(0, 28)}»: первый шаг на 15 мин`,
        `Основной рывок: закрыть ядро результата по «${rawTitle.slice(0, 22)}»`,
        'Финальная полировка и фиксация итога в Системе',
      ];
    }
    if (body.apply && targetGoal && targetGoal.type === 'deadline_project') {
      const usedCount = user.smartStepsUsedCount || 0;
      if (!user.subscription.active && usedCount >= 2) {
        return {
          ok: false,
          code: 'SYSTEM_PLUS_REQUIRED',
          message: 'Лимит бесплатных авто-разбивок (2 / 2). Безлимит умных этапов доступен в Система+.',
          user,
        };
      }
      const mandatory = Boolean(targetGoal.mandatoryDeadline);
      targetGoal.milestones = steps.map((stepTitle, idx) => ({
        id: `ms_${idx + 1}_${Date.now()}`,
        goalId: targetGoal.id,
        title: stepTitle,
        order: idx + 1,
        completed: false,
        locked: idx > 0,
        mandatory,
        deadlineDate: idx === 1 ? 'Через 7 дней' : undefined,
      }));
      targetGoal.currentValue = 0;
      targetGoal.targetValue = steps.length;
      targetGoal.unit = 'этапов';
      const existingTask = user.tasks.find((t) => t.goalId === targetGoal.id && !t.completed);
      if (existingTask) existingTask.title = steps[0];
      else user.tasks.unshift({ id: `tsk_ms_${Date.now()}`, title: steps[0], goalId: targetGoal.id, durationMinutes: 15, xpReward: 30, completed: false, dueDateText: 'Сегодня', priority: 'high' });
      if (!user.subscription.active) {
        user.smartStepsUsedCount = usedCount + 1;
      }
      writeLocalUser(user);
    }
    return { ok: true, steps, user };
  }

  if (endpoint === '/api/goals/milestone-toggle') {
    const goal = user.goals.find((g) => g.id === body.goalId);
    const ms = goal?.milestones?.find((m) => m.id === body.milestoneId);
    if (!goal || !goal.milestones || !ms || ms.locked) return { ok: false, message: 'Этап заблокирован', user };
    ms.completed = !ms.completed;
    goal.milestones.forEach((m, i) => {
      m.locked = i === 0 ? false : !goal.milestones![i - 1].completed;
    });
    goal.currentValue = goal.milestones.filter((m) => m.completed).length;
    const tz = user.timezone || getClientTimezone();
    syncStreakLocal(user, tz);
    let goalJustCompleted = false;
    let leveledUp = false;
    if (goal.currentValue >= goal.targetValue) {
      goal.status = 'completed';
      if (!goal.rewardXpGranted) {
        goal.rewardXpGranted = true;
        goalJustCompleted = true;
        user.lastCompletedGoalTitle = goal.title;
        user.lastCompletedGoalProgress = `${goal.currentValue} / ${goal.targetValue} этапов`;
        leveledUp = addXpLocal(user, 500);
        grantShadowLocal(user, `shd_goal_${goal.id}`, 'Беру · Тень Проекта', 'A-Тень', '+5 XP за задания');
      }
    } else if (goal.status === 'completed') {
      goal.status = 'active';
    }
    writeLocalUser(user);
    return { ok: true, user, goalJustCompleted, leveledUp };
  }

  if (endpoint === '/api/goals/update-savings') {
    const goal = user.goals.find((g) => g.id === body.goalId);
    if (!goal) return { ok: false, message: 'Цель не найдена', user };
    const totalBal = user.accounts.filter((a) => a.status === 'active').reduce((s, a) => s + a.balanceRub, 0);
    const otherAllocated = user.goals
      .filter((g) => g.id !== goal.id && g.status === 'active' && g.type === 'savings')
      .reduce((s, g) => s + g.currentValue, 0);
    const clamped = Math.max(0, Math.round(Number(body.newAllocatedRub) || 0));
    if (otherAllocated + clamped > totalBal) {
      const maxForGoal = Math.max(0, totalBal - otherAllocated);
      return {
        ok: false,
        code: 'SAVINGS_EXCEEDS_ACCOUNT_BALANCE',
        message: `С учётом остальных целей-копилок максимум для этой цели: ${maxForGoal.toLocaleString('ru-RU')} ₽.`,
        user,
      };
    }
    goal.currentValue = clamped;
    recomputeLocalTotals(user);
    let goalJustCompleted = false;
    let leveledUp = false;
    if (goal.currentValue >= goal.targetValue) {
      goal.status = 'completed';
      if (!goal.rewardXpGranted) {
        goal.rewardXpGranted = true;
        goalJustCompleted = true;
        user.lastCompletedGoalTitle = goal.title;
        user.lastCompletedGoalProgress = `${goal.currentValue.toLocaleString('ru-RU')} / ${goal.targetValue.toLocaleString('ru-RU')} ₽`;
        leveledUp = addXpLocal(user, 500);
        grantShadowLocal(user, `shd_sav_${goal.id}`, 'Грид · Тень Резерва', 'A-Тень', '+5 XP за задания');
      }
    }
    writeLocalUser(user);
    return { ok: true, user, goalJustCompleted, leveledUp };
  }

  if (endpoint === '/api/goals/update') {
    const goal = user.goals.find((g) => g.id === body.goalId);
    if (goal) {
      if (typeof body.title === 'string' && body.title.trim()) goal.title = body.title.trim();
      if (typeof body.deadlineText === 'string' && body.deadlineText.trim()) goal.deadlineText = body.deadlineText.trim();
      if (typeof body.mandatoryDeadline === 'boolean') goal.mandatoryDeadline = body.mandatoryDeadline;
      if (goal.type === 'scheduled_action') {
        if (typeof body.durationMinutes === 'number' && body.durationMinutes > 0) goal.durationMinutes = Math.round(body.durationMinutes);
        if (typeof body.targetValue === 'number' && body.targetValue >= 1) goal.targetValue = Math.max(goal.currentValue, Math.round(body.targetValue));
        if (typeof body.daysPerWeek === 'number' && body.daysPerWeek >= 1 && body.daysPerWeek <= 7) goal.daysPerWeek = Math.round(body.daysPerWeek);
        if (typeof body.preferredTime === 'string' && body.preferredTime.trim()) goal.preferredTime = body.preferredTime.trim();
      }
      writeLocalUser(user);
    }
    return { ok: true, user };
  }

  if (endpoint === '/api/goals/delete') {
    const idx = user.goals.findIndex((g) => g.id === body.goalId);
    if (idx === -1) return { ok: false, message: 'Цель не найдена', user };
    const goal = user.goals[idx];
    const mode = (body.mode as 'archive' | 'restore' | 'delete') || 'delete';
    if (mode === 'archive') {
      goal.status = 'archived';
      recomputeLocalTotals(user);
      writeLocalUser(user);
      return { ok: true, user };
    }
    if (mode === 'restore') {
      if (!user.subscription.active && user.goals.filter((g) => g.status === 'active').length >= 3) {
        return { ok: false, code: 'FREE_GOAL_LIMIT_REACHED', message: 'Активных целей: 3 / 3. Подключите Систему+ или завершите одну из текущих.', user };
      }
      goal.status = 'active';
      recomputeLocalTotals(user);
      writeLocalUser(user);
      return { ok: true, user };
    }
    user.goals.splice(idx, 1);
    const removedTaskIds = new Set<string>();
    if (body.deleteLinkedTasks) {
      user.tasks = user.tasks.filter((t) => {
        if (t.goalId === body.goalId && !t.completed) {
          removedTaskIds.add(t.id);
          return false;
        }
        if (t.goalId === body.goalId) t.goalId = undefined;
        return true;
      });
    } else {
      user.tasks.forEach((t) => {
        if (t.goalId === body.goalId) t.goalId = undefined;
      });
    }
    if (user.focusSession.taskId && removedTaskIds.has(user.focusSession.taskId)) {
      user.focusSession.active = false;
      user.focusSession.paused = false;
      user.focusSession.taskId = '';
    }
    recomputeLocalTotals(user);
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/tasks/start-focus') {
    if (isLocalQuarantined(user)) {
      return { ok: false, code: 'PENALTY_LOCKED', message: 'Штрафной квест активен: фокус и прокачка заморожены до снятия штрафа.', user };
    }
    const durationOverride = Number(body.durationMinutes) || 0;
    if (durationOverride >= 60 && !user.subscription.active) {
      return { ok: false, code: 'SYSTEM_PLUS_REQUIRED', message: 'Врата на 60 и 90 минут доступны с Система+.', user };
    }
    let task =
      (body.taskId ? user.tasks.find((t) => t.id === body.taskId) : undefined) ||
      (body.goalId ? user.tasks.find((t) => t.goalId === body.goalId && !t.completed) : undefined) ||
      user.tasks.find((t) => !t.completed);
    if (!task) {
      const mins = durationOverride || 15;
      task = {
        id: `tsk_focus_${Date.now()}`,
        title: `Фокус-сессия · ${mins} минут`,
        durationMinutes: mins,
        xpReward: 30,
        completed: false,
        dueDateText: 'Сегодня',
        priority: 'normal',
      };
      user.tasks.unshift(task);
    }
    const mins = durationOverride || task.durationMinutes || 15;
    user.focusSession = {
      active: true,
      paused: false,
      taskId: task.id,
      title: task.title,
      totalSeconds: mins * 60,
      remainingSeconds: mins * 60,
      startedAtMs: Date.now(),
    };
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/tasks/focus-pause') {
    if (body.cancel) {
      user.focusSession.active = false;
      user.focusSession.paused = false;
      user.focusSession.startedAtMs = undefined;
    } else if (user.focusSession.active) {
      if (typeof body.remainingSeconds === 'number' && Number.isFinite(body.remainingSeconds)) {
        user.focusSession.remainingSeconds = Math.max(0, Math.round(body.remainingSeconds));
      }
      if (typeof body.paused === 'boolean') {
        user.focusSession.paused = body.paused;
        user.focusSession.startedAtMs = body.paused
          ? undefined
          : Date.now() - Math.max(0, user.focusSession.totalSeconds - user.focusSession.remainingSeconds) * 1000;
      }
    }
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/tasks/toggle') {
    if (isLocalQuarantined(user)) {
      return { ok: false, code: 'PENALTY_LOCKED', message: 'Штрафной квест активен: выполнение заданий и начисление XP заблокированы.', user };
    }
    const task = user.tasks.find((t) => t.id === body.taskId);
    if (!task) return { ok: false, message: 'Задание не найдено', user };
    const focusLvl = user.skills.focus?.level || 1;
    const focusBonus = focusLvl === 3 ? 15 : focusLvl === 2 ? 10 : 5;
    const intelBonus = Math.floor(Math.max(0, (user.stats.intelligence || 10) - 10) / 2);
    const shadowBonus = getShadowBonusLocal(user);
    const tz = user.timezone || getClientTimezone();
    const todayIso = getTzIsoDaysAgo(0, tz);

    let leveledUp = false;
    let goalJustCompleted = false;
    if (!task.completed) {
      task.completed = true;
      task.completedAt = new Date().toISOString();
      const baseXp = task.xpReward || 30;
      const focusPart = body.withFocusBonus !== false ? focusBonus : 0;
      const bonusXp = focusPart + intelBonus + shadowBonus;
      task.skillBonusXp = bonusXp;
      const parts: string[] = [];
      if (focusPart > 0) parts.push('Фокус');
      if (intelBonus > 0) parts.push('ИНТ');
      if (shadowBonus > 0) parts.push('Тень');
      task.skillBonusName = parts.length > 0 ? parts.join(' + ') : undefined;

      leveledUp = addXpLocal(user, baseXp + bonusXp);
      syncStreakLocal(user, tz);
      if (user.focusSession.active && user.focusSession.taskId === task.id) {
        user.focusSession.active = false;
        user.focusSession.paused = false;
        user.focusSession.startedAtMs = undefined;
      }
      if (body.withFocusBonus) {
        const focusSessionsReq = user.skills.focus?.requirementsForNext.find((r) => r.id === 'req_sessions');
        if (focusSessionsReq) {
          focusSessionsReq.current += 1;
          focusSessionsReq.met = focusSessionsReq.current >= focusSessionsReq.target;
        }
      }
      const impulseActReq = user.skills.impulse?.requirementsForNext.find((r) => r.id === 'req_imp_act');
      if (impulseActReq) {
        impulseActReq.current += 1;
        impulseActReq.met = impulseActReq.current >= impulseActReq.target;
      }

      const linkedGoal = task.goalId ? user.goals.find((g) => g.id === task.goalId) : undefined;
      if (linkedGoal && linkedGoal.type === 'scheduled_action') {
        linkedGoal.currentValue = Math.min(linkedGoal.targetValue, linkedGoal.currentValue + 1);
        if (linkedGoal.currentValue >= linkedGoal.targetValue) {
          linkedGoal.status = 'completed';
          if (!linkedGoal.rewardXpGranted) {
            linkedGoal.rewardXpGranted = true;
            goalJustCompleted = true;
            user.lastCompletedGoalTitle = linkedGoal.title;
            user.lastCompletedGoalProgress = `${linkedGoal.currentValue} / ${linkedGoal.targetValue}`;
            if (addXpLocal(user, 500)) leveledUp = true;
            grantShadowLocal(user, `shd_sch_${linkedGoal.id}`, 'Игрис · Рыцарь Фокуса', 'S-Тень', '+5 XP за задания');
          }
        }
      }
      if (task.recurrence && task.recurrence !== 'none' && user.subscription.active) {
        let nextOffset = task.recurrence === 'weekly' ? 7 : 1;
        if (task.recurrence === 'weekdays') {
          const wd = getTzWeekday(1, tz);
          if (wd === 'СБ') nextOffset = 3;
          else if (wd === 'ВС') nextOffset = 2;
        }
        const targetIso = getTzIsoDaysAgo(-nextOffset, tz);
        const [, mm, dd] = targetIso.split('-');
        const nextDueLabel = nextOffset === 1 ? `Завтра (${dd}.${mm})` : `${dd}.${mm}`;
        if (!user.tasks.some((t) => !t.completed && t.title === task.title && t.dueDateText === nextDueLabel)) {
          user.tasks.push({ ...task, id: `tsk_rec_${Date.now()}`, completed: false, completedAt: undefined, dueDateText: nextDueLabel });
        }
      }
      user.lastCompletedTaskBreakdown = {
        taskId: task.id,
        title: task.title,
        baseXp,
        bonusXp,
        bonusName: task.skillBonusName || 'Фокус',
        totalXp: baseXp + bonusXp,
        goalTitle: linkedGoal?.title,
        goalProgressText: linkedGoal ? `${linkedGoal.currentValue} / ${linkedGoal.targetValue} ${linkedGoal.unit}` : '',
        goalProgressPercent: linkedGoal ? Math.round((linkedGoal.currentValue / Math.max(1, linkedGoal.targetValue)) * 100) : 0,
      };
    } else {
      const revert = (task.xpReward || 30) + (task.skillBonusXp || 0);
      task.completed = false;
      task.completedAt = undefined;
      subtractXpLocal(user, revert);
      const linkedGoal = task.goalId ? user.goals.find((g) => g.id === task.goalId) : undefined;
      if (linkedGoal && linkedGoal.type === 'scheduled_action') {
        linkedGoal.currentValue = Math.max(0, linkedGoal.currentValue - 1);
        if (linkedGoal.status === 'completed' && linkedGoal.currentValue < linkedGoal.targetValue) {
          linkedGoal.status = 'active';
        }
      }
      user.lastCompletedTaskBreakdown = null;
    }
    writeLocalUser(user);
    return { ok: true, user, leveledUp, goalJustCompleted };
  }

  if (endpoint === '/api/tasks/save') {
    if (body.deleteTask && body.id) {
      user.tasks = user.tasks.filter((t) => t.id !== body.id);
      writeLocalUser(user);
      return { ok: true, user };
    }
    if (!body.title || !String(body.title).trim()) {
      return { ok: false, code: 'INVALID_TITLE', message: 'Введите название задания', user };
    }
    if (body.recurrence && body.recurrence !== 'none' && !user.subscription.active) {
      return { ok: false, code: 'SYSTEM_PLUS_REQUIRED', message: 'Автопилот повторов доступен в Система+.', user };
    }
    const existing = user.tasks.find((t) => t.id === body.id);
    if (existing) {
      existing.title = String(body.title).trim();
      existing.goalId = typeof body.goalId === 'string' && body.goalId.trim() ? body.goalId.trim() : undefined;
      existing.dueDateText = String(body.dueDateText || existing.dueDateText);
      existing.priority = (body.priority as 'normal' | 'high') || existing.priority;
      if (body.recurrence !== undefined) existing.recurrence = body.recurrence as UserAppState['tasks'][0]['recurrence'];
    } else {
      user.tasks.unshift({
        id: `tsk_${Date.now()}`,
        title: String(body.title).trim(),
        goalId: typeof body.goalId === 'string' && body.goalId.trim() ? body.goalId.trim() : undefined,
        dueDateText: String(body.dueDateText || 'Сегодня'),
        priority: (body.priority as 'normal' | 'high') || 'normal',
        recurrence: (body.recurrence as UserAppState['tasks'][0]['recurrence']) || 'none',
        xpReward: 30,
        completed: false,
      });
    }
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/habits/progress') {
    if (isLocalQuarantined(user)) {
      return { ok: false, code: 'PENALTY_LOCKED', message: 'Штрафной квест активен: отметка привычек заморожена до снятия штрафа.', user };
    }
    const habit = user.habits.find((h) => h.id === body.habitId);
    if (!habit) return { ok: false, message: 'Привычка не найдена', user };
    const tz = user.timezone || getClientTimezone();
    const todayIso = getTzIsoDaysAgo(0, tz);
    let leveledUp = false;
    const wasDone = habit.completedToday;
    if (typeof body.addMinutes === 'number') {
      const deltaMin = Math.max(1, Math.min(240, Math.round(body.addMinutes)));
      habit.currentMinutesToday = Math.min(habit.durationMinutes, habit.currentMinutesToday + deltaMin);
      if (habit.currentMinutesToday >= habit.durationMinutes && !wasDone) {
        habit.completedToday = true;
        leveledUp = addXpLocal(user, 20);
        syncStreakLocal(user, tz);
      }
    } else {
      habit.completedToday = !habit.completedToday;
      habit.currentMinutesToday = habit.completedToday ? habit.durationMinutes : 0;
      if (habit.completedToday && !wasDone) {
        leveledUp = addXpLocal(user, 20);
        syncStreakLocal(user, tz);
      } else if (!habit.completedToday && wasDone) {
        subtractXpLocal(user, 20);
      }
    }
    const todayStatus = habit.completedToday ? 'completed' : habit.currentMinutesToday > 0 ? 'partial' : 'pending';
    const existingTodayIdx = habit.history.findIndex((h) => h.isoDate === todayIso || h.dateLabel === 'Сегодня');
    const todayEntry = {
      dateLabel: 'Сегодня',
      isoDate: todayIso,
      status: todayStatus as 'completed' | 'partial' | 'pending',
      valueMinutes: habit.currentMinutesToday,
      targetMinutes: habit.durationMinutes,
    };
    if (existingTodayIdx >= 0) habit.history[existingTodayIdx] = todayEntry;
    else habit.history.unshift(todayEntry);
    writeLocalUser(user);
    return { ok: true, user, leveledUp };
  }

  if (endpoint === '/api/habits/save') {
    const tz = user.timezone || getClientTimezone();
    const todayIso = getTzIsoDaysAgo(0, tz);
    const idx = user.habits.findIndex((h) => h.id === body.id);
    const existing = idx >= 0 ? user.habits[idx] : undefined;
    if (body.deleteHabit && idx >= 0) {
      user.habits.splice(idx, 1);
      writeLocalUser(user);
      return { ok: true, user };
    }
    if (existing) {
      if (body.archive) {
        existing.status = 'archived';
      } else if (body.restore) {
        if (!user.subscription.active && user.habits.filter((h) => h.status === 'active').length >= 3) {
          return { ok: false, code: 'FREE_HABIT_LIMIT_REACHED', message: 'Активных привычек: 3 / 3. Подключите Систему+ или архивируйте другую.', user };
        }
        existing.status = 'active';
      } else {
        existing.title = String(body.title || existing.title).trim();
        existing.durationMinutes = Number(body.durationMinutes) || existing.durationMinutes;
        existing.daysOfWeek = Array.isArray(body.daysOfWeek) ? (body.daysOfWeek as string[]) : existing.daysOfWeek;
        existing.deadlineTime = String(body.deadlineTime || existing.deadlineTime);
        existing.mandatory = Boolean(body.mandatory);
      }
      writeLocalUser(user);
      return { ok: true, user };
    }
    if (!user.subscription.active && user.habits.filter((h) => h.status === 'active').length >= 3) {
      return { ok: false, code: 'FREE_HABIT_LIMIT_REACHED', user };
    }
    user.habits.push({
      id: `hab_${Date.now()}`,
      title: String(body.title || 'Новая привычка').trim(),
      durationMinutes: Number(body.durationMinutes) || 15,
      currentMinutesToday: 0,
      completedToday: false,
      daysOfWeek: Array.isArray(body.daysOfWeek) ? (body.daysOfWeek as string[]) : ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ'],
      deadlineTime: String(body.deadlineTime || '23:00'),
      mandatory: Boolean(body.mandatory),
      status: 'active',
      createdAtIso: todayIso,
      history: [{ dateLabel: 'Сегодня', isoDate: todayIso, status: 'pending' }],
    });
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/finance/commit-batch') {
    const items = Array.isArray(body.items) ? (body.items as Array<{ title: string; category: string; amountRub: number; accountId: string; type: 'expense' | 'income'; dateLabel?: string }>) : [];
    const valid = items.filter((i) => Math.round(Math.abs(Number(i.amountRub) || 0)) > 0);
    if (valid.length === 0) return { ok: false, message: 'Укажите сумму больше 0 ₽', user };
    for (const item of valid) {
      const amount = Math.round(Math.abs(Number(item.amountRub) || 0));
      const acc =
        user.accounts.find((a) => a.id === item.accountId) ||
        user.accounts.find((a) => a.status === 'active') ||
        user.accounts[0];
      if (acc) {
        if (item.type === 'income') {
          acc.balanceRub += amount;
          user.monthIncomeRub += amount;
        } else {
          acc.balanceRub -= amount;
          user.monthExpenseRub += amount;
        }
      }
      user.financialEntries.unshift({
        id: `fin_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        type: item.type || 'expense',
        title: item.title?.trim() || item.category || 'Запись',
        category: item.category || 'Еда',
        amountRub: amount,
        accountId: acc?.id || 'acc_card',
        dateLabel: item.dateLabel || 'Сегодня',
        createdAt: new Date().toISOString(),
      });
    }
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/finance/update-entry') {
    const idx = user.financialEntries.findIndex((e) => e.id === body.entryId);
    if (idx === -1) return { ok: false, message: 'Запись не найдена', user };
    const entry = user.financialEntries[idx];
    const oldAcc = user.accounts.find((a) => a.id === entry.accountId) || user.accounts[0];
    if (body.deleteEntry) {
      if (oldAcc) {
        if (entry.type === 'expense') {
          oldAcc.balanceRub += entry.amountRub;
          user.monthExpenseRub = Math.max(0, user.monthExpenseRub - entry.amountRub);
        } else if (entry.type === 'income') {
          oldAcc.balanceRub -= entry.amountRub;
          user.monthIncomeRub = Math.max(0, user.monthIncomeRub - entry.amountRub);
        }
      }
      user.financialEntries.splice(idx, 1);
      writeLocalUser(user);
      return { ok: true, user };
    }
    const parsedNew = Math.round(Number(body.newAmountRub));
    if (!Number.isFinite(parsedNew) || parsedNew <= 0) return { ok: false, message: 'Сумма должна быть больше 0 ₽', user };
    const newAcc = (body.accountId ? user.accounts.find((a) => a.id === body.accountId) : undefined) || oldAcc;
    const diff = parsedNew - entry.amountRub;
    if (entry.type === 'expense') {
      if (oldAcc && newAcc && oldAcc.id !== newAcc.id) {
        oldAcc.balanceRub += entry.amountRub;
        newAcc.balanceRub -= parsedNew;
        entry.accountId = newAcc.id;
      } else if (oldAcc) {
        oldAcc.balanceRub -= diff;
      }
      user.monthExpenseRub = Math.max(0, user.monthExpenseRub + diff);
    }
    entry.amountRub = parsedNew;
    if (typeof body.title === 'string' && body.title.trim()) entry.title = body.title.trim();
    if (typeof body.category === 'string' && body.category.trim()) entry.category = body.category.trim();
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/finance/transfer') {
    const amount = Math.round(Math.abs(Number(body.amountRub) || 0));
    const fromAcc = user.accounts.find((a) => a.id === body.fromAccountId);
    const toAcc = user.accounts.find((a) => a.id === body.toAccountId);
    if (!fromAcc || !toAcc || amount <= 0 || fromAcc.id === toAcc.id) {
      return { ok: false, message: 'Выберите разные счета и сумму больше 0 ₽', user };
    }
    fromAcc.balanceRub -= amount;
    toAcc.balanceRub += amount;
    user.financialEntries.unshift({
      id: `tr_${Date.now()}`,
      type: 'transfer',
      title: `Перевод: ${fromAcc.name} → ${toAcc.name}`,
      category: 'Перевод',
      amountRub: amount,
      accountId: fromAcc.id,
      toAccountId: toAcc.id,
      dateLabel: 'Сегодня',
      createdAt: new Date().toISOString(),
    });
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/finance/create-account') {
    if (!user.subscription.active && user.accounts.filter((a) => a.status === 'active').length >= 3) {
      return { ok: false, code: 'FREE_ACCOUNT_LIMIT_REACHED', user };
    }
    user.accounts.push({
      id: `acc_${Date.now()}`,
      name: String(body.name || 'Новый счёт').trim(),
      type: (body.type as 'card' | 'cash' | 'savings') || 'card',
      balanceRub: Math.round(Number(body.balanceRub) || 0),
      status: 'active',
    });
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/finance/manage-account') {
    const idx = user.accounts.findIndex((a) => a.id === body.accountId);
    if (idx === -1) return { ok: false, message: 'Счёт не найден', user };
    const acc = user.accounts[idx];
    const activeAccounts = user.accounts.filter((a) => a.status === 'active');
    const action = (body.action as 'archive' | 'restore' | 'delete') || 'archive';
    if (action === 'restore') {
      if (!user.subscription.active && activeAccounts.length >= 3) {
        return { ok: false, code: 'FREE_ACCOUNT_LIMIT_REACHED', message: 'Активных счетов: 3 / 3.', user };
      }
      acc.status = 'active';
      writeLocalUser(user);
      return { ok: true, user };
    }
    if (acc.status === 'active' && activeAccounts.length <= 1) {
      return { ok: false, code: 'ONLY_ONE_ACTIVE_ACCOUNT', message: 'Должен остаться хотя бы один активный счёт.', user };
    }
    if (action === 'archive') {
      acc.status = 'archived';
      writeLocalUser(user);
      return { ok: true, user };
    }
    if (acc.balanceRub !== 0) {
      const targetAcc = body.transferToAccountId
        ? user.accounts.find((a) => a.id === body.transferToAccountId && a.id !== acc.id && a.status === 'active')
        : undefined;
      if (!targetAcc) {
        return { ok: false, code: 'ACCOUNT_BALANCE_NOT_ZERO', message: 'На счёте ненулевой остаток — переведите его на другой счёт или архивируйте.', user };
      }
      targetAcc.balanceRub += acc.balanceRub;
      user.financialEntries.unshift({
        id: `tr_close_${Date.now()}`,
        type: 'transfer',
        title: `Закрытие счёта ${acc.name} → ${targetAcc.name}`,
        category: 'Перевод',
        amountRub: Math.abs(acc.balanceRub),
        accountId: acc.id,
        toAccountId: targetAcc.id,
        dateLabel: 'Сегодня',
        createdAt: new Date().toISOString(),
      });
    }
    user.accounts.splice(idx, 1);
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/finance/reconcile') {
    const tz = user.timezone || getClientTimezone();
    const todayIso = getTzIsoDaysAgo(0, tz);
    const ctrlLvl = user.skills.control?.level || 1;
    const xpGain = ctrlLvl >= 3 ? 15 : ctrlLvl === 2 ? 10 : 5;
    let prevDate = '';
    try {
      prevDate = localStorage.getItem(RECONCILE_STORAGE_KEY) || '';
    } catch {
      // ignore
    }
    if (prevDate === todayIso) {
      return { ok: true, user, leveledUp: false, xpGain, alreadyReconciled: true };
    }
    try {
      localStorage.setItem(RECONCILE_STORAGE_KEY, todayIso);
    } catch {
      // ignore
    }
    const leveledUp = addXpLocal(user, xpGain);
    writeLocalUser(user);
    return { ok: true, user, leveledUp, xpGain, alreadyReconciled: false };
  }

  if (endpoint === '/api/player/stats/preview') {
    const stat = body.stat as StatKey;
    const totalPending = (Object.values(user.pendingStatAdditions) as number[]).reduce((a, b) => a + b, 0);
    if (body.delta === 1 && totalPending < user.unspentStatPoints) {
      user.pendingStatAdditions[stat] += 1;
    } else if (body.delta === -1 && user.pendingStatAdditions[stat] > 0) {
      user.pendingStatAdditions[stat] -= 1;
    }
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/player/stats/reset') {
    user.pendingStatAdditions = { strength: 0, endurance: 0, agility: 0, intelligence: 0, perception: 0 };
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/player/stats/commit') {
    if (isLocalQuarantined(user)) {
      return { ok: false, code: 'PENALTY_LOCKED', message: 'Штрафной квест активен: распределение характеристик заморожено.', user };
    }
    const totalPending = (Object.values(user.pendingStatAdditions) as number[]).reduce((a, b) => a + b, 0);
    if (totalPending <= 0 || totalPending > user.unspentStatPoints) return { ok: false, message: 'Выберите характеристики', user };
    (Object.keys(user.pendingStatAdditions) as StatKey[]).forEach((k) => {
      user.stats[k] += user.pendingStatAdditions[k];
      user.pendingStatAdditions[k] = 0;
    });
    user.unspentStatPoints -= totalPending;
    syncSkillStatReqsLocal(user);
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/player/skills/upgrade') {
    if (isLocalQuarantined(user)) {
      return { ok: false, code: 'PENALTY_LOCKED', message: 'Штрафной квест активен: улучшение навыков заморожено.', user };
    }
    const skill = user.skills[body.skillId as keyof UserAppState['skills']];
    if (skill && skill.level < skill.maxLevel) {
      skill.level += 1;
      user.lastUpgradedSkillId = skill.id;
      writeLocalUser(user);
    }
    return { ok: true, user };
  }

  if (endpoint === '/api/penalty/present') {
    if (!user.penaltyQuest.presentedAt) {
      user.penaltyQuest.presentedAt = new Date().toISOString();
      user.penaltyQuest.status = 'terms_viewed';
      writeLocalUser(user);
    }
    return { ok: true, user };
  }

  if (endpoint === '/api/penalty/heartbeat') {
    const addSec = Math.min(10, Math.max(1, Number(body.secondsDelta) || 10));
    if (user.penaltyQuest.currentStage === 1) user.penaltyQuest.stage1ConfirmedSeconds = Math.min(150, user.penaltyQuest.stage1ConfirmedSeconds + addSec);
    else user.penaltyQuest.stage2ConfirmedSeconds = Math.min(150, user.penaltyQuest.stage2ConfirmedSeconds + addSec);
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/penalty/answer') {
    const q = PENALTY_ANSWERS[String(body.questionId)] || PENALTY_ANSWERS.q1_step_clarity;
    const correct = Number(body.optionIndex) === q.correctIndex;
    user.penaltyQuest.selectedAnswerIndex = Number(body.optionIndex);
    if (correct) {
      user.penaltyQuest.lastAnswerError = null;
      user.penaltyQuest.questionsPassed = Math.min(5, user.penaltyQuest.questionsPassed + 1);
      if (user.penaltyQuest.questionsPassed >= 3) user.penaltyQuest.currentStage = 2;
    } else {
      user.penaltyQuest.lastAnswerError = q.explanation;
    }
    writeLocalUser(user);
    return { ok: true, correct, explanation: q.explanation, user };
  }

  if (endpoint === '/api/penalty/select-challenge') {
    const ch = body.challenge as 'body' | 'focus' | 'revenge';
    if (ch === 'body' || ch === 'focus' || ch === 'revenge') {
      user.penaltyQuest.selectedChallenge = ch;
      user.penaltyQuest.challengeDone = false;
      user.penaltyQuest.status = 'in_progress';
      writeLocalUser(user);
    }
    return { ok: true, user };
  }

  if (endpoint === '/api/penalty/trial-complete') {
    const ch = body.challenge as 'body' | 'focus' | 'revenge' | undefined;
    if (ch === 'body' || ch === 'focus' || ch === 'revenge') {
      user.penaltyQuest.selectedChallenge = ch;
    }
    user.penaltyQuest.challengeDone = true;
    user.penaltyQuest.status = 'in_progress';
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/penalty/save-next-step') {
    if (!body.actionTitle || !String(body.actionTitle).trim()) return { ok: false, message: 'Укажите действие', user };
    if (typeof body.reflectionReason === 'string') {
      user.penaltyQuest.reflectionReason = body.reflectionReason.trim().slice(0, 140);
    }
    user.penaltyQuest.nextStepAction = String(body.actionTitle).trim();
    user.penaltyQuest.nextStepWhen = String(body.whenText || 'Завтра в 19:00').trim();
    user.penaltyQuest.nextStepSaved = true;
    user.tasks.unshift({
      id: `tsk_recov_${Date.now()}`,
      title: user.penaltyQuest.nextStepAction,
      dueDateText: user.penaltyQuest.nextStepWhen,
      xpReward: 30,
      completed: false,
      priority: 'normal',
    });
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/penalty/complete') {
    if (!user.penaltyQuest.nextStepSaved) return { ok: false, message: 'Сохраните следующий шаг.', user };
    user.penaltyQuest.active = false;
    user.penaltyQuest.status = 'completed';
    if (user.bootstrapState === 'penalty_alert') user.bootstrapState = 'ready';
    const trialTitleMap: Record<string, string> = {
      body: 'Испытание: Выносливость (20 повт.)',
      focus: 'Испытание: Концентрация (3 мин)',
      revenge: 'Испытание: Реванш по задаче',
    };
    const histTitle =
      (user.penaltyQuest.selectedChallenge && trialTitleMap[user.penaltyQuest.selectedChallenge]) ||
      'Учебный разбор';
    user.penaltyHistory.unshift({ id: `pq_${Date.now()}`, dateLabel: 'Сегодня', title: histTitle, outcome: 'completed' });
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/penalty/use-shield') {
    if (!user.subscription.active) return { ok: false, code: 'SYSTEM_PLUS_REQUIRED', message: 'Щит Системы доступен с подпиской Система+.', user };
    if ((user.shieldChargesRemaining ?? 0) <= 0) return { ok: false, message: 'Заряды Щита Системы исчерпаны.', user };
    user.shieldChargesRemaining = (user.shieldChargesRemaining ?? 0) - 1;
    user.penaltyQuest.active = false;
    user.penaltyQuest.status = 'completed';
    if (user.bootstrapState === 'penalty_alert') user.bootstrapState = 'ready';
    user.penaltyHistory.unshift({ id: `pq_shield_${Date.now()}`, dateLabel: 'Сегодня', title: `${user.penaltyQuest.reasonTitle} (Щит Системы+)`, outcome: 'completed' });
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/daily-quest/claim') {
    if (isLocalQuarantined(user)) {
      return { ok: false, code: 'PENALTY_LOCKED', message: 'Штрафной квест активен: сундук Ежедневного Квеста откроется после снятия штрафа.', user };
    }
    const tz = user.timezone || getClientTimezone();
    const todayKey = getTzIsoDaysAgo(0, tz);
    if (user.lastDailyClaimDate === todayKey) return { ok: false, message: 'Награда сегодня уже получена.', user };
    const doneCount = user.tasks.filter((t) => t.completed).length + user.habits.filter((h) => h.status === 'active' && h.completedToday).length;
    if (doneCount < 2) return { ok: false, message: 'Выполните минимум 2 действия дня, чтобы открыть сундук Системы.', user };
    const curStreak = syncStreakLocal(user, tz);
    user.lastDailyClaimDate = todayKey;

    let chestXp = 100;
    let bonusLabel = '+100 XP · Сундук Системы';
    if (curStreak > 0 && curStreak % 7 === 0) {
      chestXp = 150;
      user.shieldChargesRemaining = (user.shieldChargesRemaining || 0) + 1;
      bonusLabel = `+150 XP + 1 Щит · Серия ${curStreak} дн.!`;
      grantShadowLocal(user, 'shd_streak_7', 'Айрон · Хранитель Серии', 'A-Тень', '+5 XP за задания');
    } else if (curStreak > 0 && curStreak % 3 === 0) {
      chestXp = 125;
      bonusLabel = `+125 XP · Резонанс серии ${curStreak} дн.`;
    }
    if (user.subscription.active) {
      chestXp = Math.round(chestXp * 1.5);
      bonusLabel = `+${chestXp} XP (×1.5 PRO) · Серия ${curStreak} дн.`;
    }
    user.lastChestBonusText = bonusLabel;

    const leveledUp = addXpLocal(user, chestXp);
    if (!user.trophies) user.trophies = [];
    if (!user.trophies.includes('Сундук Ежедневного Квеста')) user.trophies.push('Сундук Ежедневного Квеста');
    writeLocalUser(user);
    return { ok: true, user, leveledUp };
  }

  if (endpoint === '/api/settings/theme') {
    const th = body.theme as 'blue' | 'monarch' | 'igris' | 'sovereign';
    const isProTheme = th === 'monarch' || th === 'igris' || th === 'sovereign';
    if (isProTheme && !user.subscription.active) return { ok: false, code: 'SYSTEM_PLUS_REQUIRED', user };
    user.hudTheme = isProTheme ? th : 'blue';
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/settings/night-window') {
    if (typeof body.soundEnabled === 'boolean') user.soundEnabled = body.soundEnabled;
    if (typeof body.hapticsEnabled === 'boolean') user.hapticsEnabled = body.hapticsEnabled;
    if (typeof body.botNotificationsEnabled === 'boolean') user.botNotificationsEnabled = body.botNotificationsEnabled;
    if (typeof body.timezone === 'string' && body.timezone.trim()) user.timezone = body.timezone.trim();
    if (body.start && body.end) {
      const hours = calculateNightWindowDurationHours(String(body.start), String(body.end));
      if (hours <= 0 || hours > 10) return { ok: false, code: 'NIGHT_WINDOW_TOO_LONG', message: 'Ночной период до 10 часов в сутки.', user };
      user.nightPeriodStart = String(body.start);
      user.nightPeriodEnd = String(body.end);
    }
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/settings/toggle-plus') {
    const nextActive = typeof body.enabled === 'boolean' ? body.enabled : !user.subscription.active;
    if (nextActive) {
      user.subscription.tier = 'paid';
      user.subscription.active = true;
      user.subscription.planId = '12m';
      user.subscription.planLabel = 'Система+ · Личный доступ';
      user.subscription.priceStars = 0;
      user.subscription.periodDays = 365;
      user.subscription.autoRenew = false;
      user.subscription.paymentCheckStatus = 'completed';
      user.subscription.expiresAtLabel = 'Включено в настройках';
      user.shieldChargesRemaining = Math.max(user.shieldChargesRemaining || 0, 2);
    } else {
      user.subscription.tier = 'free';
      user.subscription.active = false;
      user.subscription.planId = undefined;
      user.subscription.planLabel = 'Бесплатно';
      user.subscription.priceStars = 99;
      user.subscription.periodDays = 30;
      user.subscription.autoRenew = false;
      user.subscription.paymentCheckStatus = 'idle';
      user.subscription.expiresAtLabel = '';
      user.shieldChargesRemaining = 0;
      if (user.hudTheme && user.hudTheme !== 'blue') {
        user.hudTheme = 'blue';
      }
      let sg = 0;
      for (const g of user.goals) if (g.status === 'active' && ++sg > 3) g.status = 'archived';
      let sh = 0;
      for (const h of user.habits) if (h.status === 'active' && ++sh > 3) h.status = 'archived';
      let sa = 0;
      for (const a of user.accounts) if (a.status === 'active' && ++sa > 3) a.status = 'archived';
      recomputeLocalTotals(user);
    }
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/subscription/subscribe') {
    const plan = SUBSCRIPTION_PLANS.find((p) => p.id === (body.planId as SubscriptionPlanId)) || SUBSCRIPTION_PLANS[0];
    user.subscription.tier = 'paid';
    user.subscription.active = true;
    user.subscription.planId = plan.id;
    user.subscription.planLabel = plan.title;
    user.subscription.priceStars = plan.stars;
    user.subscription.periodDays = plan.days;
    user.subscription.autoRenew = true;
    user.subscription.paymentCheckStatus = 'completed';
    user.subscription.expiresAtLabel = `Через ${plan.days} дней`;
    user.shieldChargesRemaining = Math.max(user.shieldChargesRemaining || 0, 2);
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/subscription/toggle-autorenew') {
    user.subscription.autoRenew = !user.subscription.autoRenew;
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/referrals/activate') {
    if (user.subscription.referralBonusDaysAvailable < 3) return { ok: false, message: 'Нет доступных бонусных дней', user };
    user.subscription.referralBonusDaysAvailable -= 3;
    user.subscription.tier = 'bonus';
    user.subscription.active = true;
    user.subscription.autoRenew = false;
    user.subscription.referralBonusActiveRemaining = '3 дня активны';
    user.shieldChargesRemaining = Math.max(user.shieldChargesRemaining || 0, 1);
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/referrals/schedule-after-paid') {
    user.subscription.autoRenew = false;
    user.subscription.referralScheduledAfterPaid = true;
    writeLocalUser(user);
    return { ok: true, user };
  }

  if (endpoint === '/api/finance/parse') {
    const defaultAcc = user.accounts.find((a) => a.status === 'active') || user.accounts[0] || { id: 'acc_card', name: 'Карта' };
    const items = parseNaturalFinanceInput(String(body.text || ''), user.accounts, defaultAcc.id, defaultAcc.name);
    return { ok: true, items } as unknown as ApiActionResponse;
  }

  return { ok: true, user };
}

export async function bootstrapAppStateWithMeta(): Promise<{ user: UserAppState; isAdmin: boolean }> {
  try {
    const res = await fetch(`${API_BASE}/api/bootstrap`, { headers: getAuthHeaders() });
    const ct = res.headers.get('content-type') || '';
    if (res.ok && ct.includes('application/json')) {
      const data = (await res.json()) as { user?: UserAppState; isAdmin?: boolean };
      if (data.user) {
        writeLocalUser(data.user);
        return { user: data.user, isAdmin: Boolean(data.isAdmin) };
      }
    }
  } catch {
    // Fallback below
  }
  const local = readLocalUser();
  if (evaluateLocalAutomaticPenalties(local)) {
    writeLocalUser(local);
  }
  return { user: local, isAdmin: true };
}

export async function bootstrapAppState(): Promise<UserAppState> {
  const { user } = await bootstrapAppStateWithMeta();
  return user;
}

export async function postApiAction(
  endpoint: string,
  body: Record<string, unknown> = {}
): Promise<ApiActionResponse> {
  try {
    const res = await fetch(`${API_BASE}${endpoint}`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(body),
    });
    const ct = res.headers.get('content-type') || '';
    if (ct.includes('application/json')) {
      const data = (await res.json()) as ApiActionResponse;
      if (data.user) {
        writeLocalUser(data.user);
      }
      return data;
    }
  } catch {
    // Static Cloudflare Pages Direct Upload or offline fallback
  }
  return executeLocalFallback(endpoint, body);
}
