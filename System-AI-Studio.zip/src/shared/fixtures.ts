import { UserAppState, SkillBranchId, SkillBranchState } from './types';

export function getTzIsoDaysAgo(daysAgo = 0, timeZone = 'Europe/Moscow'): string {
  const target = new Date(Date.now() - daysAgo * 86_400_000);
  try {
    const parts = new Intl.DateTimeFormat('en-CA', {
      timeZone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).formatToParts(target);
    const y = parts.find((p) => p.type === 'year')?.value;
    const m = parts.find((p) => p.type === 'month')?.value;
    const d = parts.find((p) => p.type === 'day')?.value;
    if (y && m && d) return `${y}-${m}-${d}`;
  } catch {
    // Fallback to local time if timeZone is invalid
  }
  const y = target.getFullYear();
  const m = String(target.getMonth() + 1).padStart(2, '0');
  const day = String(target.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function getTzWeekday(daysAgo = 0, timeZone = 'Europe/Moscow'): string {
  const iso = getTzIsoDaysAgo(daysAgo, timeZone);
  const [y, m, d] = iso.split('-').map(Number);
  const dt = new Date(Date.UTC(y || 2026, (m || 1) - 1, d || 1, 12, 0, 0));
  const ruWeekdays = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
  return ruWeekdays[dt.getUTCDay()] || 'ПН';
}

export function getCurrentMonthKey(timeZone = 'Europe/Moscow'): string {
  return getTzIsoDaysAgo(0, timeZone).slice(0, 7);
}

export function localIsoDaysAgo(daysAgo = 0, timeZone?: string): string {
  if (timeZone) return getTzIsoDaysAgo(daysAgo, timeZone);
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function createInitialSkills(
  intelligence = 13,
  focusSessions = 9,
  statsOverride?: { strength: number; endurance: number; agility: number; perception: number }
): Record<SkillBranchId, SkillBranchState> {
  const s = statsOverride || { strength: 18, endurance: 17, agility: 16, perception: 16 };
  return {
    impulse: {
      id: 'impulse',
      name: 'Импульс',
      sourceStat: 'strength',
      sourceStatName: 'Сила',
      level: 1,
      maxLevel: 3,
      currentEffectText: 'Дополнительный XP за запланированную активность.',
      limitText: '+5 XP · не чаще 1 раза в день',
      whyUsefulText: 'Поддерживает выполнение запланированных действий.',
      nextLevelText: 'Следующий уровень (2): +10 XP · Уровень 3: +15 XP',
      actionButtonLabel: 'ВЫБРАТЬ ЗАДАНИЕ',
      requirementsForNext: [
        { id: 'req_str', label: 'Сила', current: s.strength, target: 18, met: s.strength >= 18 },
        { id: 'req_imp_act', label: 'Запланированные задачи', current: focusSessions >= 8 ? 8 : 0, target: 10, met: false },
      ],
    },
    rhythm: {
      id: 'rhythm',
      name: 'Ритм',
      sourceStat: 'endurance',
      sourceStatName: 'Выносливость',
      level: 1,
      maxLevel: 3,
      currentEffectText: '1 защита игровой серии на 30 дней',
      limitText: 'Сохраняет серию при одном пропуске.',
      whyUsefulText: 'Пропуск остаётся в истории. Штрафной квест сохраняется.',
      nextLevelText: 'Уровень 2: 2 защиты · Уровень 3: 3 защиты',
      actionButtonLabel: 'ОТКРЫТЬ ИСТОРИЮ',
      requirementsForNext: [
        { id: 'req_end', label: 'Выносливость', current: s.endurance, target: 18, met: s.endurance >= 18 },
      ],
    },
    focus: {
      id: 'focus',
      name: 'Фокус',
      sourceStat: 'intelligence',
      sourceStatName: 'Интеллект',
      level: 1,
      maxLevel: 3,
      currentEffectText: 'Сейчас: +5 XP за фокус-сессию',
      limitText: 'До 3 раз в день',
      whyUsefulText: 'Работа над одной задачей.',
      nextLevelText: 'Две сессии с перерывом · +10 XP',
      actionButtonLabel: 'НАЧАТЬ СЕССИЮ',
      requirementsForNext: [
        {
          id: 'req_int',
          label: 'Интеллект',
          current: intelligence,
          target: 14,
          met: intelligence >= 14,
        },
        {
          id: 'req_sessions',
          label: 'Сессии',
          current: focusSessions,
          target: 10,
          met: focusSessions >= 10,
        },
      ],
    },
    planning: {
      id: 'planning',
      name: 'Планирование',
      sourceStat: 'agility',
      sourceStatName: 'Ловкость',
      level: 1,
      maxLevel: 3,
      currentEffectText: 'Следующий шаг по одной цели',
      limitText: 'Система предлагает первое незавершённое действие.',
      whyUsefulText: 'Ручное редактирование задач и целей доступно без этого навыка.',
      nextLevelText: 'Уровень 2: Для 3 целей · Уровень 3: Для всех активных целей',
      actionButtonLabel: 'ВЫБРАТЬ ЦЕЛЬ',
      requirementsForNext: [
        { id: 'req_agi', label: 'Ловкость', current: s.agility, target: 18, met: s.agility >= 18 },
      ],
    },
    control: {
      id: 'control',
      name: 'Контроль',
      sourceStat: 'perception',
      sourceStatName: 'Восприятие',
      level: 1,
      maxLevel: 3,
      currentEffectText: 'Проверка финансового учёта (+5 XP за завершённую сверку)',
      limitText: 'Не чаще 1 раза в день.',
      whyUsefulText: 'XP не начисляется за траты или пополнения.',
      nextLevelText: 'Уровень 2: Недельный обзор · Уровень 3: Проверка лимитов категорий',
      actionButtonLabel: 'ПРОВЕРИТЬ ЗАПИСИ',
      requirementsForNext: [
        { id: 'req_per', label: 'Восприятие', current: s.perception, target: 18, met: s.perception >= 18 },
      ],
    },
  };
}

export function createNewUserState(userId = 'usr_new_1', telegramId = '900100200'): UserAppState {
  return {
    userId,
    telegramId,
    bootstrapState: 'new_invitation',
    playerCallsign: 'Игрок',
    roles: [],
    customRoleText: '',
    onboardingSelectedGoalType: 'scheduled_action',
    level: 1,
    currentXp: 0,
    nextLevelXp: 100,
    unspentStatPoints: 0,
    stats: {
      strength: 10,
      endurance: 10,
      agility: 10,
      intelligence: 10,
      perception: 10,
    },
    pendingStatAdditions: {
      strength: 0,
      endurance: 0,
      agility: 0,
      intelligence: 0,
      perception: 0,
    },
    skills: createInitialSkills(10, 0, {
      strength: 10,
      endurance: 10,
      agility: 10,
      perception: 10,
    }),
    selectedSkillId: 'focus',
    goals: [],
    tasks: [],
    habits: [],
    accounts: [
      { id: 'acc_card', name: 'Карта', type: 'card', balanceRub: 0, status: 'active' },
      { id: 'acc_cash', name: 'Наличные', type: 'cash', balanceRub: 0, status: 'active' },
    ],
    financialEntries: [],
    monthIncomeRub: 0,
    monthExpenseRub: 0,
    allocatedToGoalsRub: 0,
    prevMonthExpensesByCategory: {},
    nightPeriodStart: '23:00',
    nightPeriodEnd: '08:00',
    timezone: 'Europe/Moscow',
    soundEnabled: true,
    hapticsEnabled: true,
    reducedMotion: false,
    hudTheme: 'blue',
    shieldChargesRemaining: 0,
    trophies: ['Контракт с Системой'],
    penaltyQuest: {
      id: 'pq_none',
      active: false,
      reasonTitle: '',
      status: 'assigned',
      presentedAt: null,
      budgetTotalSeconds: 43200,
      remainingBudgetSeconds: 43200,
      nightWindowStart: '23:00',
      nightWindowEnd: '08:00',
      currentStage: 1,
      stage1ConfirmedSeconds: 0,
      stage2ConfirmedSeconds: 0,
      questionsPassed: 0,
      totalQuestionsRequired: 5,
      selectedAnswerIndex: null,
      lastAnswerError: null,
      nextStepAction: '',
      nextStepWhen: 'Завтра в 19:00',
      nextStepSaved: false,
      sessionVersion: 1,
      sessionConflictDetected: false,
      offlineDetected: false,
      lastHeartbeatToken: 'hb_init_1',
      selectedChallenge: null,
      challengeDone: false,
      reflectionReason: '',
    },
    lastPenaltyCheckDate: getTzIsoDaysAgo(0, 'Europe/Moscow'),
    lastActiveDate: getTzIsoDaysAgo(0, 'Europe/Moscow'),
    streakDays: 0,
    bestStreakDays: 0,
    createdAtIso: new Date().toISOString(),
    monthStatsKey: getCurrentMonthKey('Europe/Moscow'),
    botNotificationsEnabled: true,
    smartStepsUsedCount: 0,
    shadows: [],
    penaltyHistory: [],
    subscription: {
      tier: 'free',
      active: false,
      priceStars: 99,
      periodDays: 30,
      autoRenew: false,
      expiresAtLabel: '—',
      paymentCheckStatus: 'idle',
      referralBonusDaysAvailable: 0,
      referralBonusActiveRemaining: '',
      referralScheduledAfterPaid: false,
      referralLastInviteStatus: 'none',
      referralCode: `ref_${telegramId}`,
    },
    focusSession: {
      active: false,
      paused: false,
      taskId: '',
      title: '',
      totalSeconds: 900,
      remainingSeconds: 900,
    },
    lastCompletedTaskBreakdown: null,
  };
}

export function createAlbumFixtureState(userId = 'usr_album_12', telegramId = '104920112'): UserAppState {
  return {
    userId,
    telegramId,
    bootstrapState: 'ready',
    roles: ['studying', 'employed'],
    customRoleText: '',
    onboardingSelectedGoalType: 'scheduled_action',
    level: 12,
    currentXp: 750,
    nextLevelXp: 1000,
    unspentStatPoints: 3,
    stats: {
      strength: 18,
      endurance: 17,
      agility: 16,
      intelligence: 13,
      perception: 16,
    },
    pendingStatAdditions: {
      strength: 0,
      endurance: 0,
      agility: 0,
      intelligence: 0,
      perception: 0,
    },
    skills: createInitialSkills(13, 9),
    selectedSkillId: 'focus',
    goals: [
      {
        id: 'goal_eng',
        type: 'scheduled_action',
        title: '20 занятий английским',
        currentValue: 9,
        targetValue: 20,
        unit: 'занятий',
        status: 'active',
        durationMinutes: 15,
        daysPerWeek: 5,
        preferredTime: 'Вечером',
      },
      {
        id: 'goal_portfolio',
        type: 'deadline_project',
        title: 'Портфолио',
        currentValue: 1,
        targetValue: 3,
        unit: 'этапов',
        status: 'active',
        mandatoryDeadline: true,
        deadlineText: 'через 7 дней',
        milestones: [
          {
            id: 'ms_1',
            goalId: 'goal_portfolio',
            title: 'Собрать примеры',
            order: 1,
            completed: true,
            locked: false,
            mandatory: true,
          },
          {
            id: 'ms_2',
            goalId: 'goal_portfolio',
            title: 'Оформить страницы',
            order: 2,
            completed: false,
            locked: false,
            mandatory: true,
            deadlineDate: 'Через 7 дней',
          },
          {
            id: 'ms_3',
            goalId: 'goal_portfolio',
            title: 'Опубликовать',
            order: 3,
            completed: false,
            locked: true,
            mandatory: true,
          },
        ],
      },
      {
        id: 'goal_cushion',
        type: 'savings',
        title: 'Подушка безопасности',
        currentValue: 30000,
        targetValue: 100000,
        unit: '₽',
        status: 'active',
      },
    ],
    tasks: [
      {
        id: 'tsk_expenses',
        title: 'Записать расходы',
        xpReward: 15,
        completed: true,
        dueDateText: 'Сегодня',
        priority: 'normal',
      },
      {
        id: 'tsk_reading',
        title: 'Чтение · 15 минут',
        habitId: 'hab_reading',
        durationMinutes: 15,
        xpReward: 30,
        completed: false,
        dueDateText: 'Сегодня',
        priority: 'normal',
      },
      {
        id: 'tsk_workout',
        title: 'Тренировка · 10 / 30 мин',
        habitId: 'hab_workout',
        durationMinutes: 30,
        xpReward: 30,
        completed: false,
        dueDateText: 'Сегодня',
        priority: 'normal',
      },
      {
        id: 'tsk_portfolio_page',
        title: 'Оформить страницу портфолио',
        goalId: 'goal_portfolio',
        xpReward: 40,
        completed: false,
        dueDateText: 'Через 7 дней',
        priority: 'normal',
      },
    ],
    habits: [
      {
        id: 'hab_english',
        title: 'Английский',
        durationMinutes: 15,
        currentMinutesToday: 15,
        completedToday: true,
        daysOfWeek: ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ'],
        deadlineTime: '23:00',
        mandatory: false,
        status: 'active',
        createdAtIso: getTzIsoDaysAgo(7, 'Europe/Moscow'),
        history: [
          { dateLabel: 'Сегодня', isoDate: getTzIsoDaysAgo(0, 'Europe/Moscow'), status: 'completed' },
          { dateLabel: 'Вчера', isoDate: getTzIsoDaysAgo(1, 'Europe/Moscow'), status: 'completed' },
          { dateLabel: 'Позавчера', isoDate: getTzIsoDaysAgo(2, 'Europe/Moscow'), status: 'completed' },
          { dateLabel: '3 дня назад', isoDate: getTzIsoDaysAgo(3, 'Europe/Moscow'), status: 'completed' },
          { dateLabel: '4 дня назад', isoDate: getTzIsoDaysAgo(4, 'Europe/Moscow'), status: 'completed' },
        ],
      },
      {
        id: 'hab_reading',
        title: 'Чтение',
        durationMinutes: 15,
        currentMinutesToday: 15,
        completedToday: true,
        daysOfWeek: ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ'],
        deadlineTime: '23:00',
        mandatory: true,
        status: 'active',
        createdAtIso: getTzIsoDaysAgo(7, 'Europe/Moscow'),
        history: [
          { dateLabel: 'Сегодня', isoDate: getTzIsoDaysAgo(0, 'Europe/Moscow'), status: 'completed' },
          { dateLabel: 'Вчера', isoDate: getTzIsoDaysAgo(1, 'Europe/Moscow'), status: 'missed', triggeredPenaltyId: 'pq_reading_1' },
          { dateLabel: 'Позавчера', isoDate: getTzIsoDaysAgo(2, 'Europe/Moscow'), status: 'completed' },
          { dateLabel: '3 дня назад', isoDate: getTzIsoDaysAgo(3, 'Europe/Moscow'), status: 'completed' },
          { dateLabel: '5 дней назад', isoDate: getTzIsoDaysAgo(5, 'Europe/Moscow'), status: 'completed' },
        ],
      },
      {
        id: 'hab_workout',
        title: 'Тренировка',
        durationMinutes: 30,
        currentMinutesToday: 10,
        completedToday: false,
        daysOfWeek: ['ПН', 'СР', 'ПТ'],
        deadlineTime: '23:00',
        mandatory: false,
        status: 'active',
        createdAtIso: getTzIsoDaysAgo(7, 'Europe/Moscow'),
        history: [
          { dateLabel: 'Сегодня', isoDate: getTzIsoDaysAgo(0, 'Europe/Moscow'), status: 'partial', valueMinutes: 10, targetMinutes: 30 },
          { dateLabel: 'Позавчера', isoDate: getTzIsoDaysAgo(2, 'Europe/Moscow'), status: 'completed' },
          { dateLabel: '4 дня назад', isoDate: getTzIsoDaysAgo(4, 'Europe/Moscow'), status: 'missed' },
          { dateLabel: '6 дней назад', isoDate: getTzIsoDaysAgo(6, 'Europe/Moscow'), status: 'completed' },
        ],
      },
    ],
    accounts: [
      { id: 'acc_card', name: 'Карта', type: 'card', balanceRub: 41100, status: 'active' },
      { id: 'acc_cash', name: 'Наличные', type: 'cash', balanceRub: 2500, status: 'active' },
      { id: 'acc_savings', name: 'Накопительный', type: 'savings', balanceRub: 5000, status: 'active' },
    ],
    financialEntries: [
      {
        id: 'fin_1',
        type: 'expense',
        title: 'Продукты',
        category: 'Продукты',
        amountRub: 1500,
        accountId: 'acc_card',
        dateLabel: 'Сегодня',
        createdAt: '2026-11-14T10:00:00Z',
      },
      {
        id: 'fin_2',
        type: 'expense',
        title: 'Кофе',
        category: 'Еда',
        amountRub: 200,
        accountId: 'acc_card',
        dateLabel: 'Сегодня',
        createdAt: '2026-11-14T09:15:00Z',
      },
    ],
    monthIncomeRub: 65000,
    monthExpenseRub: 51400,
    allocatedToGoalsRub: 30000,
    prevMonthExpensesByCategory: {
      Еда: 6400,
      Продукты: 18500,
      Транспорт: 5200,
      Подписки: 1900,
      'Жильё и связь': 22000,
    },
    nightPeriodStart: '23:00',
    nightPeriodEnd: '08:00',
    timezone: 'Europe/Moscow',
    soundEnabled: true,
    hapticsEnabled: true,
    reducedMotion: false,
    hudTheme: 'blue',
    shieldChargesRemaining: 2,
    trophies: ['Пробуждённый Игрок', 'Хранитель ритма'],
    penaltyQuest: {
      id: 'pq_reading_1',
      active: false,
      reasonTitle: 'Чтение · 15 минут',
      status: 'assigned',
      presentedAt: null,
      budgetTotalSeconds: 43200, // 12 hours
      remainingBudgetSeconds: 43199, // 11:59:59
      nightWindowStart: '23:00',
      nightWindowEnd: '08:00',
      currentStage: 1,
      stage1ConfirmedSeconds: 78, // 1 мин 18 с (52% of 150s) -> 01:12 remaining
      stage2ConfirmedSeconds: 0,
      questionsPassed: 0,
      totalQuestionsRequired: 5,
      selectedAnswerIndex: 1,
      lastAnswerError: null,
      nextStepAction: 'Выбрать три работы для портфолио',
      nextStepWhen: 'Завтра в 19:00',
      nextStepSaved: false,
      sessionVersion: 1,
      sessionConflictDetected: false,
      offlineDetected: false,
      lastHeartbeatToken: 'hb_tok_101',
      selectedChallenge: 'focus',
      challengeDone: false,
      reflectionReason: '',
    },
    lastPenaltyCheckDate: getTzIsoDaysAgo(0, 'Europe/Moscow'),
    lastActiveDate: getTzIsoDaysAgo(0, 'Europe/Moscow'),
    streakDays: 6,
    bestStreakDays: 14,
    createdAtIso: new Date(Date.now() - 10 * 86_400_000).toISOString(),
    monthStatsKey: getCurrentMonthKey('Europe/Moscow'),
    botNotificationsEnabled: true,
    smartStepsUsedCount: 0,
    shadows: [
      {
        id: 'sh_igris',
        name: 'Игрис · Рыцарь Фокуса',
        rank: 'B-РАНГ',
        bonusText: '+5 XP за завершение фокус-сессии',
        extractedAt: 'Вчера',
      },
    ],
    penaltyHistory: [
      { id: 'pq_hist_1', dateLabel: 'Сегодня', title: 'Учебный разбор', outcome: 'completed' },
      { id: 'pq_hist_2', dateLabel: 'Ранее', title: 'Учебный разбор', outcome: 'completed_late' },
    ],
    subscription: {
      tier: 'free',
      active: false,
      priceStars: 99,
      periodDays: 30,
      autoRenew: true,
      expiresAtLabel: 'Через 30 дней',
      paymentCheckStatus: 'idle',
      referralBonusDaysAvailable: 3,
      referralBonusActiveRemaining: '2 дня 23 часа',
      referralScheduledAfterPaid: false,
      referralLastInviteStatus: 'credited',
      referralCode: 'ref_104920112',
    },
    focusSession: {
      active: true,
      paused: false,
      taskId: 'tsk_eng_1',
      title: 'Английский',
      totalSeconds: 900,
      remainingSeconds: 685, // 11:25
    },
    lastCompletedTaskBreakdown: {
      taskId: 'tsk_eng_1',
      title: 'Английский · 15 минут',
      baseXp: 30,
      bonusXp: 5,
      bonusName: 'Фокус',
      totalXp: 35,
      goalProgressText: '10 / 20 занятий',
      goalProgressPercent: 50,
    },
  };
}

/**
 * Validates that a night interval (HH:MM to HH:MM) does not exceed 10 hours.
 */
export function calculateNightWindowDurationHours(startHHMM: string, endHHMM: string): number {
  const [sh, sm] = startHHMM.split(':').map(Number);
  const [eh, em] = endHHMM.split(':').map(Number);
  if ([sh, sm, eh, em].some((n) => Number.isNaN(n))) return 0;
  const startMinutes = sh * 60 + sm;
  const endMinutes = eh * 60 + em;
  const diff = endMinutes >= startMinutes ? endMinutes - startMinutes : 24 * 60 - startMinutes + endMinutes;
  return diff / 60;
}
