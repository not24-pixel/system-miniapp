import React, {
  Suspense,
  lazy,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { SystemPalette, UserAppState } from './shared/types';
import { MainTabId, SubscriptionPlanId } from './shared/types';
import { STATES_CATALOG } from './shared/constants';
import { bootstrapAppStateWithMeta, postApiAction } from './shared/apiClient';
import { playSystemSound, unlockSystemAudio } from './shared/sound';
import { SystemFrame } from './components/SystemFrame';
import { GlobalSearchBar } from './components/GlobalSearchBar';
import { StatesPart1 } from './components/StatesPart1';
const StatesPart2 = lazyWithRetry(() =>
  import('./components/StatesPart2').then((m) => ({ default: m.StatesPart2 }))
);

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function lazyWithRetry<T extends React.ComponentType<any>>(
  loader: () => Promise<{ default: T }>,
  retries = 2
): React.LazyExoticComponent<T> {
  return lazy(async () => {
    let lastError: unknown;
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        return await loader();
      } catch (err) {
        lastError = err;
        if (attempt < retries) {
          await new Promise((r) => setTimeout(r, 350 * (attempt + 1)));
        }
      }
    }
    throw lastError;
  });
}

const SystemPlusModal = lazyWithRetry(() =>
  import('./components/SystemPlusModal').then((m) => ({ default: m.SystemPlusModal }))
);
const HunterShareCardModal = lazyWithRetry(() =>
  import('./components/HunterShareCardModal').then((m) => ({ default: m.HunterShareCardModal }))
);
const LevelUpOverlay = lazyWithRetry(() =>
  import('./components/LevelUpOverlay').then((m) => ({ default: m.LevelUpOverlay }))
);
const SystemInitialization = lazyWithRetry(() =>
  import('./components/SystemInitialization').then((m) => ({ default: m.SystemInitialization }))
);

interface PlusModalState {
  open: boolean;
  reason: 'habits' | 'goals' | 'accounts' | 'feature' | 'general';
  featureLabel?: string;
}

const BOOTSTRAP_STATE_MAP: Record<string, number> = {
  new_invitation: 1,
  refusal_rejected: 2,
  accepted: 3,
  onboarding_profile: 4,
  onboarding_goal_type: 5,
  onboarding_goal_setup: 6,
  first_task: 9,
  returning_welcome: 10,
  penalty_alert: 40,
  ready: 10,
};

const TAB_TO_STATE_MAP: Record<MainTabId, number> = {
  today: 11,
  goals: 16,
  habits: 13,
  finance: 19,
  player: 28,
};

const API_ERROR_MESSAGES: Record<string, string> = {
  INVITATION_REJECTED: 'Вы не можете отказаться от Системы.',
  NIGHT_WINDOW_EXCEEDS_10H: 'Ночной период не может превышать 10 часов.',
  NIGHT_WINDOW_TOO_LONG: 'Ночной период должен быть одним интервалом до 10 часов.',
  STAGE1_COUNT_TOO_LOW: 'Выполните все 20 повторений первого этапа.',
  STAGE2_READING_INCOMPLETE: 'Завершите 2 минуты 30 секунд чтения и отметьте чекбокс.',
  STAGE3_REFLECTION_TOO_SHORT: 'Напишите осмысленный вывод (минимум 80 символов).',
  PAYMENT_FAILED_OR_CANCELLED: 'Оплата не завершена. Попробуйте снова.',
  DAILY_TASK_XP_CAP_REACHED: 'Достигнут дневной лимит опыта за быстрые задачи.',
  PENALTY_LOCKED: 'Штрафной квест активен: сначала снимите карантин в «Штрафном квесте».',
};

export default function App() {
  const [user, setUser] = useState<UserAppState | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [currentStateId, setCurrentStateId] = useState<number>(1);
  const [busy, setBusy] = useState<boolean>(false);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);
  const [selectedEntryId, setSelectedEntryId] = useState<string | null>(null);
  const [selectedHabitId, setSelectedHabitId] = useState<string | null>(null);
  const [selectedGoalId, setSelectedGoalId] = useState<string | null>(null);
  const [limitReason, setLimitReason] = useState<'habits' | 'goals' | 'accounts'>('habits');
  const [settingsReturnState, setSettingsReturnState] = useState<number | null>(null);
  const [plusModal, setPlusModal] = useState<PlusModalState>({
    open: false,
    reason: 'general',
  });
  const [shareCardOpen, setShareCardOpen] = useState<boolean>(false);
  const [showPrologue, setShowPrologue] = useState<boolean>(false);
  const [levelUpModal, setLevelUpModal] = useState<{
    prevLevel: number;
    xpGain: number;
  } | null>(null);
  const [manaPulse, setManaPulse] = useState<number>(0);
  const [electricPulse, setElectricPulse] = useState<number>(0);

  const userRef = useRef<UserAppState | null>(null);
  userRef.current = user;

  const triggerManaPulse = useCallback(() => {
    setManaPulse((n) => n + 1);
  }, []);

  const triggerElectricPulse = useCallback(() => {
    setElectricPulse((n) => n + 1);
  }, []);

  const openPlusModal = useCallback(
    (
      reason: 'habits' | 'goals' | 'accounts' | 'feature' | 'general' = 'general',
      featureLabel?: string
    ) => {
      if (reason === 'habits' || reason === 'goals' || reason === 'accounts') {
        setLimitReason(reason);
      }
      setPlusModal({ open: true, reason, featureLabel });
    },
    []
  );

  // Initialize Telegram Mini App viewport + unlock Web Audio API on first user gesture
  useEffect(() => {
    try {
      const tg = (
        window as unknown as {
          Telegram?: { WebApp?: { ready?: () => void; expand?: () => void } };
        }
      ).Telegram?.WebApp;
      tg?.ready?.();
      tg?.expand?.();
    } catch {
      // ignore outside Telegram
    }

    const handleUnlock = () => unlockSystemAudio();
    window.addEventListener('pointerdown', handleUnlock, { once: true, passive: true });
    window.addEventListener('touchstart', handleUnlock, { once: true, passive: true });
    window.addEventListener('keydown', handleUnlock, { once: true, passive: true });
    return () => {
      window.removeEventListener('pointerdown', handleUnlock);
      window.removeEventListener('touchstart', handleUnlock);
      window.removeEventListener('keydown', handleUnlock);
    };
  }, []);

  const loadBootstrap = useCallback(async () => {
    try {
      const { user: loadedUser, isAdmin: adminFlag } = await bootstrapAppStateWithMeta();
      setIsAdmin(adminFlag);
      if (loadedUser) {
        setUser(loadedUser);
        const initialId = BOOTSTRAP_STATE_MAP[loadedUser.bootstrapState] ?? 1;
        setCurrentStateId(initialId);
        if (loadedUser.bootstrapState === 'new_invitation') {
          setShowPrologue(true);
        }

        const botApiBase = (
          (import.meta as unknown as { env?: Record<string, string> }).env?.VITE_BOT_API_URL || ''
        )
          .trim()
          .replace(/\/$/, '');
        if (botApiBase && loadedUser.telegramId) {
          fetch(
            `${botApiBase}/api/subscription/status?telegramId=${encodeURIComponent(loadedUser.telegramId)}`
          )
            .then((r) => (r.ok ? r.json() : null))
            .then((subData) => {
              if (!subData?.ok) return;
              setUser((prev) => {
                if (!prev) return prev;
                const nextSub = { ...prev.subscription };
                if (typeof subData.botUsername === 'string' && subData.botUsername) {
                  nextSub.botUsername = subData.botUsername;
                }
                if (typeof subData.referralBonusDays === 'number' && subData.referralBonusDays > prev.subscription.referralBonusDaysAvailable) {
                  nextSub.referralBonusDaysAvailable = subData.referralBonusDays;
                }
                if (subData.active && !prev.subscription.active) {
                  nextSub.active = true;
                  nextSub.tier = 'paid';
                  nextSub.planId = subData.planId || '1m';
                  nextSub.expiresAtLabel = subData.expiresAt
                    ? `До ${new Date(subData.expiresAt).toLocaleDateString('ru-RU')}`
                    : 'Активна';
                }
                return { ...prev, subscription: nextSub };
              });
            })
            .catch(() => {});
        }
      }
    } catch (e) {
      console.error('Bootstrap error', e);
    }
  }, []);

  useEffect(() => {
    loadBootstrap();
  }, [loadBootstrap]);

  // Sync Mini App daily state to bot push scheduler (when VITE_BOT_API_URL is configured)
  useEffect(() => {
    if (!user) return;
    const botApiBase = (
      (import.meta as unknown as { env?: Record<string, string> }).env?.VITE_BOT_API_URL || ''
    )
      .trim()
      .replace(/\/$/, '');
    if (!botApiBase || !user.telegramId || user.telegramId === 'web_local') return;

    const timer = window.setTimeout(() => {
      const pendingTasksCount = user.tasks.filter((t) => !t.completed).length;
      const pendingHabitsCount = user.habits.filter(
        (h) => h.status === 'active' && !h.completedToday
      ).length;
      fetch(`${botApiBase}/api/bot/sync-state`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          telegramId: user.telegramId,
          callsign: user.playerCallsign,
          notificationsEnabled: user.botNotificationsEnabled !== false,
          nightStart: user.nightPeriodStart,
          nightEnd: user.nightPeriodEnd,
          pendingTasksCount,
          pendingHabitsCount,
          penaltyActive: Boolean(user.penaltyQuest?.active),
        }),
      }).catch(() => {});
    }, 800);

    return () => window.clearTimeout(timer);
  }, [user]);

  // Play canonical Solo Leveling audio cue when key System windows materialize
  useEffect(() => {
    if (!user || showPrologue) return;
    const s = user.soundEnabled;
    const h = user.hapticsEnabled;
    if (currentStateId === 1 || currentStateId === 9 || currentStateId === 10) {
      playSystemSound('system_notice', s, h);
    } else if (currentStateId === 2) {
      playSystemSound('refusal_rejected', s, h);
    } else if (
      currentStateId === 40 ||
      currentStateId === 44 ||
      currentStateId === 71 ||
      currentStateId === 72
    ) {
      playSystemSound('penalty_alert', s, h);
    } else if (currentStateId === 3) {
      playSystemSound('system_activated', s, h);
    } else if (currentStateId === 30 || currentStateId === 38) {
      playSystemSound('level_up', s, h);
    } else if (currentStateId === 18 || currentStateId === 27 || currentStateId === 43) {
      playSystemSound('quest_complete', s, h);
    }
  }, [currentStateId, showPrologue, user?.soundEnabled, user?.hapticsEnabled]);

  const navigateState = useCallback((id: number) => {
    const clamped = Math.max(1, Math.min(72, id));
    setCurrentStateId(clamped);
    setErrorBanner(null);
  }, []);

  const apiAction = useCallback(
    async (endpoint: string, body?: Record<string, unknown>, nextStateId?: number) => {
      setBusy(true);
      setErrorBanner(null);
      const prevLevel = userRef.current?.level ?? 1;
      const prevXp = userRef.current?.currentXp ?? 0;
      try {
        const data = await postApiAction(endpoint, body || {});
        if (data.user) {
          setUser(data.user);
        }
        if (data.ok === false) {
          const code = data.error || data.code || 'ERROR';
          if (code === 'FREE_HABIT_LIMIT_REACHED') {
            openPlusModal('habits');
            return;
          }
          if (code === 'FREE_GOAL_LIMIT_REACHED') {
            openPlusModal('goals');
            return;
          }
          if (code === 'FREE_ACCOUNT_LIMIT_REACHED') {
            openPlusModal('accounts');
            return;
          }
          if (code === 'SYSTEM_PLUS_REQUIRED') {
            openPlusModal('feature', data.message || 'Функция Система+');
            return;
          }
          if (code === 'PENALTY_LOCKED') {
            setErrorBanner(data.message || API_ERROR_MESSAGES.PENALTY_LOCKED);
            navigateState(40);
            return;
          }
          setErrorBanner(data.message || API_ERROR_MESSAGES[code] || code);
        } else {
          if (endpoint === '/api/profile/reset-mode') {
            setSelectedTaskId(null);
            setSelectedEntryId(null);
            setSelectedHabitId(null);
            setSelectedGoalId(null);
            setSettingsReturnState(null);
            if (body?.mode === 'new_player') {
              setShowPrologue(true);
            }
          }

          if (data.leveledUp && data.user) {
            setLevelUpModal({
              prevLevel,
              xpGain: data.user.lastLevelUpXpGain || 150,
            });
          }
          triggerManaPulse();

          const isElectricProgressionEndpoint =
            endpoint === '/api/tasks/toggle' ||
            endpoint === '/api/habits/progress' ||
            endpoint === '/api/goals/milestone-toggle' ||
            endpoint === '/api/daily-quest/claim' ||
            endpoint === '/api/penalty/trial-complete' ||
            endpoint === '/api/penalty/complete';
          const gainedXp =
            Boolean(data.leveledUp) ||
            (data.user ? data.user.level > prevLevel || data.user.currentXp > prevXp : false);
          if (isElectricProgressionEndpoint && (gainedXp || endpoint === '/api/habits/progress')) {
            triggerElectricPulse();
          }

          if (data.goalJustCompleted) {
            setCurrentStateId(18);
          } else if (typeof nextStateId === 'number') {
            setCurrentStateId(nextStateId);
          }
        }
      } catch {
        setErrorBanner('Ошибка соединения. Проверьте подключение.');
      } finally {
        setBusy(false);
      }
    },
    [triggerManaPulse, triggerElectricPulse, openPlusModal, navigateState]
  );

  const handleSelectTab = useCallback(
    (tab: MainTabId) => {
      setSelectedTaskId(null);
      setSelectedEntryId(null);
      setSelectedHabitId(null);
      setSelectedGoalId(null);
      setSettingsReturnState(null);
      navigateState(TAB_TO_STATE_MAP[tab]);
    },
    [navigateState]
  );

  const handleClosePlusModal = useCallback(() => {
    setPlusModal((prev) => ({ ...prev, open: false }));
  }, []);

  const handlePaymentSuccess = useCallback(
    async (planId: SubscriptionPlanId, chargeId?: string) => {
      await apiAction('/api/subscription/subscribe', { planId, chargeId }, 48);
    },
    [apiAction]
  );

  const handleOpenReferral = useCallback(() => {
    navigateState(52);
  }, [navigateState]);

  const handleAllocatePoints = useCallback(() => {
    setLevelUpModal(null);
    navigateState(29);
  }, [navigateState]);

  const handleDismissLevelUp = useCallback(() => {
    setLevelUpModal(null);
  }, []);

  const handleCompletePrologue = useCallback(() => {
    setShowPrologue(false);
  }, []);

  const handleDismissError = useCallback(() => {
    setErrorBanner(null);
  }, []);

  const handleSearchSelectTask = useCallback(
    (taskId: string) => {
      setSelectedTaskId(taskId);
      setSelectedGoalId(null);
      navigateState(60);
    },
    [navigateState]
  );

  const handleSearchSelectHabit = useCallback(
    (habitId: string) => {
      setSelectedHabitId(habitId);
      navigateState(15);
    },
    [navigateState]
  );

  const handleSearchSelectGoal = useCallback(
    (goalId: string) => {
      setSelectedGoalId(goalId);
      const targetGoal = userRef.current?.goals.find((g) => g.id === goalId);
      if (targetGoal?.type === 'savings') {
        navigateState(8);
      } else if (targetGoal?.type === 'deadline_project') {
        navigateState(17);
      } else {
        navigateState(16);
      }
    },
    [navigateState]
  );

  const handleOpenShareCard = useCallback(() => {
    setShareCardOpen(true);
  }, []);

  const currentMeta = useMemo(
    () => STATES_CATALOG.find((item) => item.id === currentStateId) || STATES_CATALOG[10],
    [currentStateId]
  );

  const activeHudSkin: 'blue' | 'monarch' | 'igris' | 'sovereign' = user?.subscription.active
    ? user.hudTheme || 'blue'
    : 'blue';
  const monarchThemeActive = activeHudSkin === 'monarch';

  const topSearchSlot = useMemo(() => {
    if (!user || currentMeta.tab === null) return null;
    return (
      <GlobalSearchBar
        user={user}
        palette={currentMeta.palette}
        monarchTheme={monarchThemeActive}
        hudTheme={activeHudSkin}
        onSelectTask={handleSearchSelectTask}
        onSelectHabit={handleSearchSelectHabit}
        onSelectGoal={handleSearchSelectGoal}
        onOpenPlus={() => openPlusModal('general')}
      />
    );
  }, [
    user,
    currentMeta.tab,
    currentMeta.palette,
    monarchThemeActive,
    activeHudSkin,
    handleSearchSelectTask,
    handleSearchSelectHabit,
    handleSearchSelectGoal,
    openPlusModal,
  ]);

  if (!user) {
    return (
      <div className="min-h-[100dvh] bg-[#02050B] text-white flex items-center justify-center p-4">
        <div className="border border-[#00e5ff] bg-[#030e1c]/90 px-8 py-6 text-center shadow-[0_0_28px_rgba(0,229,255,0.45)]">
          <div className="text-[18px] font-bold tracking-[0.16em] uppercase text-white mb-2 system-text-glow-blue">
            СИСТЕМА
          </div>
          <div className="text-[14px] text-[#B8D9FF] animate-pulse">
            Синхронизация пробуждения Игрока...
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[100dvh] bg-[#02050B] text-white flex flex-col items-center justify-center sm:py-3 select-none">
      <Suspense fallback={null}>
        {showPrologue && (
          <SystemInitialization
            soundEnabled={user.soundEnabled}
            hapticsEnabled={user.hapticsEnabled}
            reducedMotion={user.reducedMotion}
            onComplete={handleCompletePrologue}
          />
        )}

        {levelUpModal && (
          <LevelUpOverlay
            open={true}
            prevLevel={levelUpModal.prevLevel}
            xpGain={levelUpModal.xpGain}
            user={user}
            onAllocatePoints={handleAllocatePoints}
            onDismiss={handleDismissLevelUp}
            onOpenShareCard={handleOpenShareCard}
          />
        )}

        {plusModal.open && (
          <SystemPlusModal
            open={true}
            reason={plusModal.reason}
            featureLabel={plusModal.featureLabel}
            user={user}
            busy={busy}
            onClose={handleClosePlusModal}
            onPaymentSuccess={handlePaymentSuccess}
            onOpenReferral={handleOpenReferral}
          />
        )}

        {shareCardOpen && (
          <HunterShareCardModal
            open={true}
            user={user}
            monarchTheme={monarchThemeActive}
            onClose={() => setShareCardOpen(false)}
            onOpenPlus={openPlusModal}
          />
        )}
      </Suspense>

      <div className="w-full max-w-[430px] relative">
        {errorBanner && (
          <div className="absolute top-3 left-5 right-5 z-50 bg-[#24060B]/95 border border-[#FF3B30] px-3.5 py-2.5 text-[13px] text-[#FFD2CF] flex items-center justify-between shadow-[0_0_20px_rgba(255,59,48,0.45)]">
            <span>{errorBanner}</span>
            <button
              type="button"
              onClick={handleDismissError}
              className="text-white font-bold ml-3 cursor-pointer"
            >
              ✕
            </button>
          </div>
        )}
        <SystemFrame
          stateId={currentStateId}
          palette={currentMeta.palette}
          monarchTheme={monarchThemeActive}
          hudTheme={activeHudSkin}
          activeTab={currentMeta.tab}
          onSelectTab={handleSelectTab}
          reducedMotion={user.reducedMotion}
          soundEnabled={user.soundEnabled}
          hapticsEnabled={user.hapticsEnabled}
          manaPulse={manaPulse}
          electricPulse={electricPulse}
          topSlot={topSearchSlot}
        >
          {currentStateId <= 39 ? (
            <StatesPart1
              stateId={currentStateId}
              user={user}
              navigateState={navigateState}
              apiAction={apiAction}
              busy={busy}
              prologueActive={showPrologue}
              errorBanner={errorBanner}
              selectedTaskId={selectedTaskId}
              setSelectedTaskId={setSelectedTaskId}
              selectedEntryId={selectedEntryId}
              setSelectedEntryId={setSelectedEntryId}
              selectedHabitId={selectedHabitId}
              setSelectedHabitId={setSelectedHabitId}
              selectedGoalId={selectedGoalId}
              setSelectedGoalId={setSelectedGoalId}
              limitReason={limitReason}
              setLimitReason={setLimitReason}
              openPlusModal={openPlusModal}
              settingsReturnState={settingsReturnState}
              setSettingsReturnState={setSettingsReturnState}
              isAdmin={isAdmin}
              onOpenShareCard={handleOpenShareCard}
            />
          ) : (
            <Suspense fallback={null}>
              <StatesPart2
              stateId={currentStateId}
              user={user}
              navigateState={navigateState}
              apiAction={apiAction}
              busy={busy}
              errorBanner={errorBanner}
              selectedTaskId={selectedTaskId}
              setSelectedTaskId={setSelectedTaskId}
              selectedEntryId={selectedEntryId}
              setSelectedEntryId={setSelectedEntryId}
              selectedHabitId={selectedHabitId}
              setSelectedHabitId={setSelectedHabitId}
              selectedGoalId={selectedGoalId}
              setSelectedGoalId={setSelectedGoalId}
              limitReason={limitReason}
              setLimitReason={setLimitReason}
              openPlusModal={openPlusModal}
              settingsReturnState={settingsReturnState}
              setSettingsReturnState={setSettingsReturnState}
              isAdmin={isAdmin}
              onOpenShareCard={handleOpenShareCard}
            />
            </Suspense>
          )}
        </SystemFrame>
      </div>
    </div>
  );
}
