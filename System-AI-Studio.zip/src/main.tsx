import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

interface ErrorBoundaryState {
  hasError: boolean;
}

class AppErrorBoundary extends React.Component<
  { children: React.ReactNode },
  ErrorBoundaryState
> {
  state: ErrorBoundaryState = { hasError: false };

  static getDerivedStateFromError(): ErrorBoundaryState {
    return { hasError: true };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-[100dvh] w-full bg-[#020810] text-white flex flex-col items-center justify-center p-6 text-center space-y-4">
          <div className="max-w-xs w-full p-5 border border-[#38f8ff]/70 bg-[#031221]/95 space-y-3">
            <div className="text-[13px] font-mono uppercase tracking-[0.14em] text-[#72f8ff]">
              [ СИСТЕМА · ВОССТАНОВЛЕНИЕ ]
            </div>
            <div className="text-[14px] text-white/85">
              Соединение с интерфейсом прервалось. Нажмите кнопку ниже, чтобы обновить экран.
            </div>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="w-full min-h-[44px] px-4 py-2 border border-[#38f8ff] bg-[#063254] text-[13px] font-bold uppercase tracking-wider text-white cursor-pointer hover:bg-[#084573]"
            >
              Обновить экран
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

createRoot(document.getElementById('root')!).render(
  <AppErrorBoundary>
    <App />
  </AppErrorBoundary>
);
